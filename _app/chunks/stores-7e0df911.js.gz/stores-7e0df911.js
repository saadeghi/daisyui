import{D as r}from"./vendor-bfed1aed.js";const p=r("");export{p};
