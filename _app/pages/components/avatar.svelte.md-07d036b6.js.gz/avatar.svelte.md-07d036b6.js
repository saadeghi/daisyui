import{S as ie,i as re,s as ce,C as ee,w as W,x as H,y as L,z as oe,A as ae,q as Q,o as U,B as Y,K as de,ag as le,k as C,m as T,g as h,d as r,e as p,c as n,a as u,O as k,b as v,F as m,t as M,h as P,a9 as G,W as R}from"../../chunks/vendor-c5cb7521.js";import{M as ve}from"../../chunks/_markdown-02b3e42a.js";import{p as pe,C as ne,a as Z,r as q}from"../../chunks/actions-8d57d530.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-ca6b08e9.js";import"../../chunks/index-e2cd6035.js";import"../../chunks/SEO-3b885c97.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-4f850e23.js";function me(_){let e,c,l,i;return{c(){e=p("div"),c=p("div"),l=p("img"),this.h()},l(s){e=n(s,"DIV",{class:!0});var d=u(e);c=n(d,"DIV",{class:!0});var t=u(c);l=n(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 rounded bg-base-300"),v(e,"class","avatar")},m(s,d){h(s,e,d),m(e,c),m(c,l)},d(s){s&&r(e)}}}function ue(_){let e,c=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function fe(_){let e,c=`<div className="$$avatar">
  <div className="w-24 rounded">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function $e(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V,b,A,N,D,x;return{c(){e=p("div"),c=p("div"),l=p("img"),s=C(),d=p("div"),t=p("div"),a=p("img"),w=C(),g=p("div"),I=p("div"),E=p("img"),b=C(),A=p("div"),N=p("div"),D=p("img"),this.h()},l($){e=n($,"DIV",{class:!0});var o=u(e);c=n(o,"DIV",{class:!0});var f=u(c);l=n(f,"IMG",{src:!0,alt:!0}),f.forEach(r),o.forEach(r),s=T($),d=n($,"DIV",{class:!0});var K=u(d);t=n(K,"DIV",{class:!0});var O=u(t);a=n(O,"IMG",{src:!0,alt:!0}),O.forEach(r),K.forEach(r),w=T($),g=n($,"DIV",{class:!0});var J=u(g);I=n(J,"DIV",{class:!0});var X=u(I);E=n(X,"IMG",{src:!0,alt:!0}),X.forEach(r),J.forEach(r),b=T($),A=n($,"DIV",{class:!0});var z=u(A);N=n(z,"DIV",{class:!0});var j=u(N);D=n(j,"IMG",{src:!0,alt:!0}),j.forEach(r),z.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 rounded bg-base-300"),v(e,"class","avatar"),k(a.src,S="https://placeimg.com/192/192/people")||v(a,"src",S),v(a,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-16 rounded bg-base-300"),v(d,"class","avatar"),k(E.src,V="https://placeimg.com/192/192/people")||v(E,"src",V),v(E,"alt","Tailwind-CSS-Avatar-component"),v(I,"class","w-12 rounded bg-base-300"),v(g,"class","avatar"),k(D.src,x="https://placeimg.com/192/192/people")||v(D,"src",x),v(D,"alt","Tailwind-CSS-Avatar-component"),v(N,"class","w-8 rounded bg-base-300"),v(A,"class","avatar")},m($,o){h($,e,o),m(e,c),m(c,l),h($,s,o),h($,d,o),m(d,t),m(t,a),h($,w,o),h($,g,o),m(g,I),m(I,E),h($,b,o),h($,A,o),m(A,N),m(N,D)},d($){$&&r(e),$&&r(s),$&&r(d),$&&r(w),$&&r(g),$&&r(b),$&&r(A)}}}function _e(_){let e,c=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function he(_){let e,c=`<div className="$$avatar">
  <div className="w-32 rounded">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-20 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-16 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-8 rounded">
    <img src="https://placeimg.com/192/192/people" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function ge(_){let e,c,l,i,s,d,t,a,S;return{c(){e=p("div"),c=p("div"),l=p("img"),s=C(),d=p("div"),t=p("div"),a=p("img"),this.h()},l(w){e=n(w,"DIV",{class:!0});var g=u(e);c=n(g,"DIV",{class:!0});var I=u(c);l=n(I,"IMG",{src:!0,alt:!0}),I.forEach(r),g.forEach(r),s=T(w),d=n(w,"DIV",{class:!0});var E=u(d);t=n(E,"DIV",{class:!0});var V=u(t);a=n(V,"IMG",{src:!0,alt:!0}),V.forEach(r),E.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 rounded-xl bg-base-300"),v(e,"class","avatar"),k(a.src,S="https://placeimg.com/192/192/people")||v(a,"src",S),v(a,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 rounded-full bg-base-300"),v(d,"class","avatar")},m(w,g){h(w,e,g),m(e,c),m(c,l),h(w,s,g),h(w,d,g),m(d,t),m(t,a)},d(w){w&&r(e),w&&r(s),w&&r(d)}}}function we(_){let e,c=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Ee(_){let e,c=`<div className="$$avatar">
  <div className="w-24 rounded-xl">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Ie(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V;return{c(){e=p("div"),c=p("div"),l=p("img"),s=C(),d=p("div"),t=p("div"),a=p("img"),w=C(),g=p("div"),I=p("div"),E=p("img"),this.h()},l(b){e=n(b,"DIV",{class:!0});var A=u(e);c=n(A,"DIV",{class:!0});var N=u(c);l=n(N,"IMG",{src:!0,alt:!0}),N.forEach(r),A.forEach(r),s=T(b),d=n(b,"DIV",{class:!0});var D=u(d);t=n(D,"DIV",{class:!0});var x=u(t);a=n(x,"IMG",{src:!0,alt:!0}),x.forEach(r),D.forEach(r),w=T(b),g=n(b,"DIV",{class:!0});var $=u(g);I=n($,"DIV",{class:!0});var o=u(I);E=n(o,"IMG",{src:!0,alt:!0}),o.forEach(r),$.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 mask mask-squircle bg-base-300"),v(e,"class","avatar"),k(a.src,S="https://placeimg.com/192/192/people")||v(a,"src",S),v(a,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 mask mask-hexagon bg-base-300"),v(d,"class","avatar"),k(E.src,V="https://placeimg.com/192/192/people")||v(E,"src",V),v(E,"alt","Tailwind-CSS-Avatar-component"),v(I,"class","w-24 mask mask-triangle bg-base-300"),v(g,"class","avatar")},m(b,A){h(b,e,A),m(e,c),m(c,l),h(b,s,A),h(b,d,A),m(d,t),m(t,a),h(b,w,A),h(b,g,A),m(g,I),m(I,E)},d(b){b&&r(e),b&&r(s),b&&r(d),b&&r(w),b&&r(g)}}}function be(_){let e,c=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Ne(_){let e,c=`<div className="$$avatar">
  <div className="w-24 $$mask $$mask-squircle">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 $$mask $$mask-hexagon">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 $$mask $$mask-triangle">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Se(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V,b,A,N,D,x,$;return{c(){e=p("div"),c=p("div"),l=p("div"),i=p("img"),d=C(),t=p("div"),a=p("div"),S=p("img"),g=C(),I=p("div"),E=p("div"),V=p("img"),A=C(),N=p("div"),D=p("div"),x=p("img"),this.h()},l(o){e=n(o,"DIV",{class:!0});var f=u(e);c=n(f,"DIV",{class:!0});var K=u(c);l=n(K,"DIV",{class:!0});var O=u(l);i=n(O,"IMG",{src:!0,alt:!0}),O.forEach(r),K.forEach(r),d=T(f),t=n(f,"DIV",{class:!0});var J=u(t);a=n(J,"DIV",{class:!0});var X=u(a);S=n(X,"IMG",{src:!0,alt:!0}),X.forEach(r),J.forEach(r),g=T(f),I=n(f,"DIV",{class:!0});var z=u(I);E=n(z,"DIV",{class:!0});var j=u(E);V=n(j,"IMG",{src:!0,alt:!0}),j.forEach(r),z.forEach(r),A=T(f),N=n(f,"DIV",{class:!0});var B=u(N);D=n(B,"DIV",{class:!0});var F=u(D);x=n(F,"IMG",{src:!0,alt:!0}),F.forEach(r),B.forEach(r),f.forEach(r),this.h()},h(){k(i.src,s="https://placeimg.com/192/192/people")||v(i,"src",s),v(i,"alt","Tailwind-CSS-Avatar-component"),v(l,"class","w-12 bg-base-300"),v(c,"class","avatar"),k(S.src,w="https://placeimg.com/192/192/people")||v(S,"src",w),v(S,"alt","Tailwind-CSS-Avatar-component"),v(a,"class","w-12 bg-base-300"),v(t,"class","avatar"),k(V.src,b="https://placeimg.com/192/192/people")||v(V,"src",b),v(V,"alt","Tailwind-CSS-Avatar-component"),v(E,"class","w-12 bg-base-300"),v(I,"class","avatar"),k(x.src,$="https://placeimg.com/192/192/people")||v(x,"src",$),v(x,"alt","Tailwind-CSS-Avatar-component"),v(D,"class","w-12 bg-base-300"),v(N,"class","avatar"),v(e,"class","avatar-group -space-x-6")},m(o,f){h(o,e,f),m(e,c),m(c,l),m(l,i),m(e,d),m(e,t),m(t,a),m(a,S),m(e,g),m(e,I),m(I,E),m(E,V),m(e,A),m(e,N),m(N,D),m(D,x)},d(o){o&&r(e)}}}function Ae(_){let e,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function De(_){let e,c=`<div className="$$avatar-group -space-x-6">
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Ve(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V,b,A,N,D,x,$;return{c(){e=p("div"),c=p("div"),l=p("div"),i=p("img"),d=C(),t=p("div"),a=p("div"),S=p("img"),g=C(),I=p("div"),E=p("div"),V=p("img"),A=C(),N=p("div"),D=p("div"),x=p("span"),$=M("+99"),this.h()},l(o){e=n(o,"DIV",{class:!0});var f=u(e);c=n(f,"DIV",{class:!0});var K=u(c);l=n(K,"DIV",{class:!0});var O=u(l);i=n(O,"IMG",{src:!0,alt:!0}),O.forEach(r),K.forEach(r),d=T(f),t=n(f,"DIV",{class:!0});var J=u(t);a=n(J,"DIV",{class:!0});var X=u(a);S=n(X,"IMG",{src:!0,alt:!0}),X.forEach(r),J.forEach(r),g=T(f),I=n(f,"DIV",{class:!0});var z=u(I);E=n(z,"DIV",{class:!0});var j=u(E);V=n(j,"IMG",{src:!0,alt:!0}),j.forEach(r),z.forEach(r),A=T(f),N=n(f,"DIV",{class:!0});var B=u(N);D=n(B,"DIV",{class:!0});var F=u(D);x=n(F,"SPAN",{});var y=u(x);$=P(y,"+99"),y.forEach(r),F.forEach(r),B.forEach(r),f.forEach(r),this.h()},h(){k(i.src,s="https://placeimg.com/192/192/people")||v(i,"src",s),v(i,"alt","Tailwind-CSS-Avatar-component"),v(l,"class","w-12 bg-base-300"),v(c,"class","avatar"),k(S.src,w="https://placeimg.com/192/192/people")||v(S,"src",w),v(S,"alt","Tailwind-CSS-Avatar-component"),v(a,"class","w-12 bg-base-300"),v(t,"class","avatar"),k(V.src,b="https://placeimg.com/192/192/people")||v(V,"src",b),v(V,"alt","Tailwind-CSS-Avatar-component"),v(E,"class","w-12 bg-base-300"),v(I,"class","avatar"),v(D,"class","w-12 bg-neutral-focus text-neutral-content"),v(N,"class","avatar placeholder"),v(e,"class","avatar-group -space-x-6")},m(o,f){h(o,e,f),m(e,c),m(c,l),m(l,i),m(e,d),m(e,t),m(t,a),m(a,S),m(e,g),m(e,I),m(I,E),m(E,V),m(e,A),m(e,N),m(N,D),m(D,x),m(x,$)},d(o){o&&r(e)}}}function xe(_){let e,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Ce(_){let e,c=`<div className="$$avatar-group -space-x-6">
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="https://placeimg.com/192/192/people" />
    </div>
  </div>
  <div className="$$avatar $$placeholder">
    <div className="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Te(_){let e,c,l,i;return{c(){e=p("div"),c=p("div"),l=p("img"),this.h()},l(s){e=n(s,"DIV",{class:!0});var d=u(e);c=n(d,"DIV",{class:!0});var t=u(c);l=n(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"),v(e,"class","avatar")},m(s,d){h(s,e,d),m(e,c),m(c,l)},d(s){s&&r(e)}}}function Me(_){let e,c=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Pe(_){let e,c=`<div className="$$avatar">
  <div className="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function ke(_){let e,c,l,i,s,d,t,a,S;return{c(){e=p("div"),c=p("div"),l=p("img"),s=C(),d=p("div"),t=p("div"),a=p("img"),this.h()},l(w){e=n(w,"DIV",{class:!0});var g=u(e);c=n(g,"DIV",{class:!0});var I=u(c);l=n(I,"IMG",{src:!0,alt:!0}),I.forEach(r),g.forEach(r),s=T(w),d=n(w,"DIV",{class:!0});var E=u(d);t=n(E,"DIV",{class:!0});var V=u(t);a=n(V,"IMG",{src:!0,alt:!0}),V.forEach(r),E.forEach(r),this.h()},h(){k(l.src,i="https://placeimg.com/192/192/people")||v(l,"src",i),v(l,"alt","Tailwind-CSS-Avatar-component"),v(c,"class","w-24 rounded-full bg-base-300"),v(e,"class","avatar online"),k(a.src,S="https://placeimg.com/192/192/people")||v(a,"src",S),v(a,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 rounded-full bg-base-300"),v(d,"class","avatar offline")},m(w,g){h(w,e,g),m(e,c),m(c,l),h(w,s,g),h(w,d,g),m(d,t),m(t,a)},d(w){w&&r(e),w&&r(s),w&&r(d)}}}function Ge(_){let e,c=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Re(_){let e,c=`<div className="$$avatar $$online">
  <div className="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>
<div className="$$avatar $$offline">
  <div className="w-24 rounded-full">
    <img src="https://placeimg.com/192/192/people" />
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function qe(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V,b,A,N,D,x;return{c(){e=p("div"),c=p("div"),l=p("span"),i=M("K"),s=C(),d=p("div"),t=p("div"),a=p("span"),S=M("JO"),w=C(),g=p("div"),I=p("div"),E=p("span"),V=M("MX"),b=C(),A=p("div"),N=p("div"),D=p("span"),x=M("AA"),this.h()},l($){e=n($,"DIV",{class:!0});var o=u(e);c=n(o,"DIV",{class:!0});var f=u(c);l=n(f,"SPAN",{class:!0});var K=u(l);i=P(K,"K"),K.forEach(r),f.forEach(r),o.forEach(r),s=T($),d=n($,"DIV",{class:!0});var O=u(d);t=n(O,"DIV",{class:!0});var J=u(t);a=n(J,"SPAN",{class:!0});var X=u(a);S=P(X,"JO"),X.forEach(r),J.forEach(r),O.forEach(r),w=T($),g=n($,"DIV",{class:!0});var z=u(g);I=n(z,"DIV",{class:!0});var j=u(I);E=n(j,"SPAN",{});var B=u(E);V=P(B,"MX"),B.forEach(r),j.forEach(r),z.forEach(r),b=T($),A=n($,"DIV",{class:!0});var F=u(A);N=n(F,"DIV",{class:!0});var y=u(N);D=n(y,"SPAN",{class:!0});var te=u(D);x=P(te,"AA"),te.forEach(r),y.forEach(r),F.forEach(r),this.h()},h(){v(l,"class","text-3xl"),v(c,"class","bg-neutral-focus text-neutral-content rounded-full w-24"),v(e,"class","avatar placeholder"),v(a,"class","text-xl"),v(t,"class","bg-neutral-focus text-neutral-content rounded-full w-16"),v(d,"class","avatar online placeholder"),v(I,"class","bg-neutral-focus text-neutral-content rounded-full w-12"),v(g,"class","avatar placeholder"),v(D,"class","text-xs"),v(N,"class","bg-neutral-focus text-neutral-content rounded-full w-8"),v(A,"class","avatar placeholder")},m($,o){h($,e,o),m(e,c),m(c,l),m(l,i),h($,s,o),h($,d,o),m(d,t),m(t,a),m(a,S),h($,w,o),h($,g,o),m(g,I),m(I,E),m(E,V),h($,b,o),h($,A,o),m(A,N),m(N,D),m(D,x)},d($){$&&r(e),$&&r(s),$&&r(d),$&&r(w),$&&r(g),$&&r(b),$&&r(A)}}}function Ke(_){let e,c=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","html")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Oe(_){let e,c=`<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span className="text-3xl">K</span>
  </div>
</div> 
<div className="$$avatar $$online $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span className="text-xl">JO</span>
  </div>
</div> 
<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span className="text-xs">AA</span>
  </div>
</div>`,l,i,s,d;return{c(){e=p("pre"),l=M(c),this.h()},l(t){e=n(t,"PRE",{slot:!0});var a=u(e);l=P(a,c),a.forEach(r),this.h()},h(){v(e,"slot","react")},m(t,a){h(t,e,a),m(e,l),s||(d=G(i=q.call(null,e,{to:_[0]})),s=!0)},p(t,a){i&&R(i.update)&&a&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(e),s=!1,d()}}}function Je(_){let e,c,l,i,s,d,t,a,S,w,g,I,E,V,b,A,N,D,x,$;return e=new ne({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as offline indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),l=new Z({props:{title:"Avatar",$$slots:{react:[fe],html:[ue],default:[me]},$$scope:{ctx:_}}}),s=new Z({props:{title:"Avatar in custom sizes",$$slots:{react:[he],html:[_e],default:[$e]},$$scope:{ctx:_}}}),t=new Z({props:{title:"Avatar rounded",$$slots:{react:[Ee],html:[we],default:[ge]},$$scope:{ctx:_}}}),S=new Z({props:{title:"Avatar with mask",$$slots:{react:[Ne],html:[be],default:[Ie]},$$scope:{ctx:_}}}),g=new Z({props:{title:"Avatar group",$$slots:{react:[De],html:[Ae],default:[Se]},$$scope:{ctx:_}}}),E=new Z({props:{title:"Avatar group with counter",$$slots:{react:[Ce],html:[xe],default:[Ve]},$$scope:{ctx:_}}}),b=new Z({props:{title:"Avatar with ring",$$slots:{react:[Pe],html:[Me],default:[Te]},$$scope:{ctx:_}}}),N=new Z({props:{title:"Avatar with presence indicator",$$slots:{react:[Re],html:[Ge],default:[ke]},$$scope:{ctx:_}}}),x=new Z({props:{title:"Avatar placeholder",$$slots:{react:[Oe],html:[Ke],default:[qe]},$$scope:{ctx:_}}}),{c(){W(e.$$.fragment),c=C(),W(l.$$.fragment),i=C(),W(s.$$.fragment),d=C(),W(t.$$.fragment),a=C(),W(S.$$.fragment),w=C(),W(g.$$.fragment),I=C(),W(E.$$.fragment),V=C(),W(b.$$.fragment),A=C(),W(N.$$.fragment),D=C(),W(x.$$.fragment)},l(o){H(e.$$.fragment,o),c=T(o),H(l.$$.fragment,o),i=T(o),H(s.$$.fragment,o),d=T(o),H(t.$$.fragment,o),a=T(o),H(S.$$.fragment,o),w=T(o),H(g.$$.fragment,o),I=T(o),H(E.$$.fragment,o),V=T(o),H(b.$$.fragment,o),A=T(o),H(N.$$.fragment,o),D=T(o),H(x.$$.fragment,o)},m(o,f){L(e,o,f),h(o,c,f),L(l,o,f),h(o,i,f),L(s,o,f),h(o,d,f),L(t,o,f),h(o,a,f),L(S,o,f),h(o,w,f),L(g,o,f),h(o,I,f),L(E,o,f),h(o,V,f),L(b,o,f),h(o,A,f),L(N,o,f),h(o,D,f),L(x,o,f),$=!0},p(o,f){const K={};f&5&&(K.$$scope={dirty:f,ctx:o}),l.$set(K);const O={};f&5&&(O.$$scope={dirty:f,ctx:o}),s.$set(O);const J={};f&5&&(J.$$scope={dirty:f,ctx:o}),t.$set(J);const X={};f&5&&(X.$$scope={dirty:f,ctx:o}),S.$set(X);const z={};f&5&&(z.$$scope={dirty:f,ctx:o}),g.$set(z);const j={};f&5&&(j.$$scope={dirty:f,ctx:o}),E.$set(j);const B={};f&5&&(B.$$scope={dirty:f,ctx:o}),b.$set(B);const F={};f&5&&(F.$$scope={dirty:f,ctx:o}),N.$set(F);const y={};f&5&&(y.$$scope={dirty:f,ctx:o}),x.$set(y)},i(o){$||(Q(e.$$.fragment,o),Q(l.$$.fragment,o),Q(s.$$.fragment,o),Q(t.$$.fragment,o),Q(S.$$.fragment,o),Q(g.$$.fragment,o),Q(E.$$.fragment,o),Q(b.$$.fragment,o),Q(N.$$.fragment,o),Q(x.$$.fragment,o),$=!0)},o(o){U(e.$$.fragment,o),U(l.$$.fragment,o),U(s.$$.fragment,o),U(t.$$.fragment,o),U(S.$$.fragment,o),U(g.$$.fragment,o),U(E.$$.fragment,o),U(b.$$.fragment,o),U(N.$$.fragment,o),U(x.$$.fragment,o),$=!1},d(o){Y(e,o),o&&r(c),Y(l,o),o&&r(i),Y(s,o),o&&r(d),Y(t,o),o&&r(a),Y(S,o),o&&r(w),Y(g,o),o&&r(I),Y(E,o),o&&r(V),Y(b,o),o&&r(A),Y(N,o),o&&r(D),Y(x,o)}}}function Xe(_){let e,c;const l=[_[1],se];let i={$$slots:{default:[Je]},$$scope:{ctx:_}};for(let s=0;s<l.length;s+=1)i=ee(i,l[s]);return e=new ve({props:i}),{c(){W(e.$$.fragment)},l(s){H(e.$$.fragment,s)},m(s,d){L(e,s,d),c=!0},p(s,[d]){const t=d&2?oe(l,[d&2&&ae(s[1]),d&0&&ae(se)]):{};d&5&&(t.$$scope={dirty:d,ctx:s}),e.$set(t)},i(s){c||(Q(e.$$.fragment,s),c=!0)},o(s){U(e.$$.fragment,s),c=!1},d(s){Y(e,s)}}}const se={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0};function ze(_,e,c){let l;return de(_,pe,i=>c(0,l=i)),_.$$set=i=>{c(1,e=ee(ee({},e),le(i)))},e=le(e),[l,e]}class Ze extends ie{constructor(e){super();re(this,e,ze,Xe,ce,{})}}export{Ze as default,se as metadata};
