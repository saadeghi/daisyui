import{S as he,i as _e,s as ve,C as le,w as V,x as G,y as z,z as be,A as ce,q as O,o as Y,B as j,K as ge,ag as de,k as S,m as L,g as w,d as i,e as d,t as y,c as $,a as f,h as P,b as c,F as p,a9 as I,Q as A,H as $e,I as fe}from"../../chunks/vendor-3400f70d.js";import{M as Ee}from"../../chunks/_markdown-20b89140.js";import{p as xe,C as Ne,a as X,r as k}from"../../chunks/actions-4450930a.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-2d1e86ec.js";import"../../chunks/index-dd870235.js";import"../../chunks/SEO-1c5a2870.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-06a003a6.js";function ye(m){let e,n,a,s,o,r,t,l,b,h;return{c(){e=d("div"),n=d("label"),a=d("span"),s=y("Your Email"),o=S(),r=d("label"),t=d("span"),l=y("Email"),b=S(),h=d("input"),this.h()},l(_){e=$(_,"DIV",{class:!0});var g=f(e);n=$(g,"LABEL",{class:!0});var x=f(n);a=$(x,"SPAN",{class:!0});var N=f(a);s=P(N,"Your Email"),N.forEach(i),x.forEach(i),o=L(g),r=$(g,"LABEL",{class:!0});var E=f(r);t=$(E,"SPAN",{});var T=f(t);l=P(T,"Email"),T.forEach(i),b=L(E),h=$(E,"INPUT",{type:!0,placeholder:!0,class:!0}),E.forEach(i),g.forEach(i),this.h()},h(){c(a,"class","label-text"),c(n,"class","label"),c(h,"type","text"),c(h,"placeholder","info@site.com"),c(h,"class","input input-bordered"),c(r,"class","input-group"),c(e,"class","form-control")},m(_,g){w(_,e,g),p(e,n),p(n,a),p(a,s),p(e,o),p(e,r),p(r,t),p(t,l),p(r,b),p(r,h)},d(_){_&&i(e)}}}function Pe(m){let e,n=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Your Email</span>
  </label>
  <label class="$$input-group">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" class="$$input $$input-bordered" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Te(m){let e,n=`<div className="$$form-control">
  <label className="$$label">
    <span className="$$label-text">Your Email</span>
  </label>
  <label className="$$input-group">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" className="$$input $$input-bordered" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function we(m){let e,n,a,s,o,r,t,l,b,h;return{c(){e=d("div"),n=d("label"),a=d("span"),s=y("Enter amount"),o=S(),r=d("label"),t=d("input"),l=S(),b=d("span"),h=y("BTC"),this.h()},l(_){e=$(_,"DIV",{class:!0});var g=f(e);n=$(g,"LABEL",{class:!0});var x=f(n);a=$(x,"SPAN",{class:!0});var N=f(a);s=P(N,"Enter amount"),N.forEach(i),x.forEach(i),o=L(g),r=$(g,"LABEL",{class:!0});var E=f(r);t=$(E,"INPUT",{type:!0,placeholder:!0,class:!0}),l=L(E),b=$(E,"SPAN",{});var T=f(b);h=P(T,"BTC"),T.forEach(i),E.forEach(i),g.forEach(i),this.h()},h(){c(a,"class","label-text"),c(n,"class","label"),c(t,"type","text"),c(t,"placeholder","0.01"),c(t,"class","input input-bordered"),c(r,"class","input-group"),c(e,"class","form-control")},m(_,g){w(_,e,g),p(e,n),p(n,a),p(a,s),p(e,o),p(e,r),p(r,t),p(r,l),p(r,b),p(b,h)},d(_){_&&i(e)}}}function Se(m){let e,n=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Enter amount</span>
  </label>
  <label class="$$input-group">
    <input type="text" placeholder="0.01" class="$$input $$input-bordered" />
    <span>BTC</span>
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Le(m){let e,n=`<div className="$$form-control">
  <label className="$$label">
    <span className="$$label-text">Enter amount</span>
  </label>
  <label className="$$input-group">
    <input type="text" placeholder="0.01" className="$$input $$input-bordered" />
    <span>BTC</span>
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Ie(m){let e,n,a,s,o,r,t,l,b,h,_,g,x;return{c(){e=d("div"),n=d("label"),a=d("span"),s=y("Enter amount"),o=S(),r=d("label"),t=d("span"),l=y("Price"),b=S(),h=d("input"),_=S(),g=d("span"),x=y("USD"),this.h()},l(N){e=$(N,"DIV",{class:!0});var E=f(e);n=$(E,"LABEL",{class:!0});var T=f(n);a=$(T,"SPAN",{class:!0});var u=f(a);s=P(u,"Enter amount"),u.forEach(i),T.forEach(i),o=L(E),r=$(E,"LABEL",{class:!0});var v=f(r);t=$(v,"SPAN",{});var B=f(t);l=P(B,"Price"),B.forEach(i),b=L(v),h=$(v,"INPUT",{type:!0,placeholder:!0,class:!0}),_=L(v),g=$(v,"SPAN",{});var D=f(g);x=P(D,"USD"),D.forEach(i),v.forEach(i),E.forEach(i),this.h()},h(){c(a,"class","label-text"),c(n,"class","label"),c(h,"type","text"),c(h,"placeholder","10"),c(h,"class","input input-bordered"),c(r,"class","input-group"),c(e,"class","form-control")},m(N,E){w(N,e,E),p(e,n),p(n,a),p(a,s),p(e,o),p(e,r),p(r,t),p(t,l),p(r,b),p(r,h),p(r,_),p(r,g),p(g,x)},d(N){N&&i(e)}}}function Ae(m){let e,n=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Enter amount</span>
  </label>
  <label class="$$input-group">
    <span>Price</span>
    <input type="text" placeholder="10" class="$$input $$input-bordered" />
    <span>USD</span>
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function ke(m){let e,n=`<div className="$$form-control">
  <label className="$$label">
    <span className="$$label-text">Enter amount</span>
  </label>
  <label className="$$input-group">
    <span>Price</span>
    <input type="text" placeholder="10" className="$$input $$input-bordered" />
    <span>USD</span>
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Be(m){let e,n,a,s,o,r,t,l,b,h;return{c(){e=d("div"),n=d("label"),a=d("span"),s=y("Your Email"),o=S(),r=d("label"),t=d("span"),l=y("Email"),b=S(),h=d("input"),this.h()},l(_){e=$(_,"DIV",{class:!0});var g=f(e);n=$(g,"LABEL",{class:!0});var x=f(n);a=$(x,"SPAN",{class:!0});var N=f(a);s=P(N,"Your Email"),N.forEach(i),x.forEach(i),o=L(g),r=$(g,"LABEL",{class:!0});var E=f(r);t=$(E,"SPAN",{});var T=f(t);l=P(T,"Email"),T.forEach(i),b=L(E),h=$(E,"INPUT",{type:!0,placeholder:!0,class:!0}),E.forEach(i),g.forEach(i),this.h()},h(){c(a,"class","label-text"),c(n,"class","label"),c(h,"type","text"),c(h,"placeholder","info@site.com"),c(h,"class","input input-bordered"),c(r,"class","input-group input-group-vertical"),c(e,"class","form-control")},m(_,g){w(_,e,g),p(e,n),p(n,a),p(a,s),p(e,o),p(e,r),p(r,t),p(t,l),p(r,b),p(r,h)},d(_){_&&i(e)}}}function De(m){let e,n=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Your Email</span>
  </label>
  <label class="$$input-group $$input-group-vertical">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" class="$$input $$input-bordered" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Me(m){let e,n=`<div className="$$form-control">
  <label className="$$label">
    <span className="$$label-text">Your Email</span>
  </label>
  <label className="$$input-group $$input-group-vertical">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" className="$$input $$input-bordered" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Ue(m){let e,n,a,s,o,r,t,l,b,h,_,g,x,N,E,T,u,v,B,D,C,F,R,M,q,ee,te,H;return{c(){e=d("div"),n=d("div"),a=d("label"),s=d("span"),o=y("LG"),r=S(),t=d("input"),l=S(),b=d("div"),h=d("label"),_=d("span"),g=y("MD"),x=S(),N=d("input"),E=S(),T=d("div"),u=d("label"),v=d("span"),B=y("SM"),D=S(),C=d("input"),F=S(),R=d("div"),M=d("label"),q=d("span"),ee=y("XS"),te=S(),H=d("input"),this.h()},l(K){e=$(K,"DIV",{class:!0});var U=f(e);n=$(U,"DIV",{class:!0});var ae=f(n);a=$(ae,"LABEL",{class:!0});var Q=f(a);s=$(Q,"SPAN",{});var se=f(s);o=P(se,"LG"),se.forEach(i),r=L(Q),t=$(Q,"INPUT",{type:!0,placeholder:!0,class:!0}),Q.forEach(i),ae.forEach(i),l=L(U),b=$(U,"DIV",{class:!0});var re=f(b);h=$(re,"LABEL",{class:!0});var W=f(h);_=$(W,"SPAN",{});var oe=f(_);g=P(oe,"MD"),oe.forEach(i),x=L(W),N=$(W,"INPUT",{type:!0,placeholder:!0,class:!0}),W.forEach(i),re.forEach(i),E=L(U),T=$(U,"DIV",{class:!0});var ne=f(T);u=$(ne,"LABEL",{class:!0});var J=f(u);v=$(J,"SPAN",{});var pe=f(v);B=P(pe,"SM"),pe.forEach(i),D=L(J),C=$(J,"INPUT",{type:!0,placeholder:!0,class:!0}),J.forEach(i),ne.forEach(i),F=L(U),R=$(U,"DIV",{class:!0});var ue=f(R);M=$(ue,"LABEL",{class:!0});var Z=f(M);q=$(Z,"SPAN",{});var ie=f(q);ee=P(ie,"XS"),ie.forEach(i),te=L(Z),H=$(Z,"INPUT",{type:!0,placeholder:!0,class:!0}),Z.forEach(i),ue.forEach(i),U.forEach(i),this.h()},h(){c(t,"type","text"),c(t,"placeholder","Type here"),c(t,"class","input input-bordered input-lg"),c(a,"class","input-group input-group-lg"),c(n,"class","form-control"),c(N,"type","text"),c(N,"placeholder","Type here"),c(N,"class","input input-bordered input-md"),c(h,"class","input-group input-group-md"),c(b,"class","form-control"),c(C,"type","text"),c(C,"placeholder","Type here"),c(C,"class","input input-bordered input-sm"),c(u,"class","input-group input-group-sm"),c(T,"class","form-control"),c(H,"type","text"),c(H,"placeholder","Type here"),c(H,"class","input input-bordered input-xs"),c(M,"class","input-group input-group-xs"),c(R,"class","form-control"),c(e,"class","flex flex-col gap-4 items-center")},m(K,U){w(K,e,U),p(e,n),p(n,a),p(a,s),p(s,o),p(a,r),p(a,t),p(e,l),p(e,b),p(b,h),p(h,_),p(_,g),p(h,x),p(h,N),p(e,E),p(e,T),p(T,u),p(u,v),p(v,B),p(u,D),p(u,C),p(e,F),p(e,R),p(R,M),p(M,q),p(q,ee),p(M,te),p(M,H)},d(K){K&&i(e)}}}function Ce(m){let e,n=`<div class="$$form-control">
  <label class="$$input-group $$input-group-lg">
    <span>LG</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-lg" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-md">
    <span>MD</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-md" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-sm">
    <span>SM</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-sm" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-xs">
    <span>XS</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-xs" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Re(m){let e,n=`<div className="$$form-control">
  <label className="$$input-group $$input-group-lg">
    <span>LG</span>
    <input type="text" placeholder="Type here" className="$$input $$input-bordered $$input-lg" />
  </label>
</div>
<div className="$$form-control">
  <label className="$$input-group $$input-group-md">
    <span>MD</span>
    <input type="text" placeholder="Type here" className="$$input $$input-bordered $$input-md" />
  </label>
</div>
<div className="$$form-control">
  <label className="$$input-group $$input-group-sm">
    <span>SM</span>
    <input type="text" placeholder="Type here" className="$$input $$input-bordered $$input-sm" />
  </label>
</div>
<div className="$$form-control">
  <label className="$$input-group $$input-group-xs">
    <span>XS</span>
    <input type="text" placeholder="Type here" className="$$input $$input-bordered $$input-xs" />
  </label>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Ve(m){let e,n,a,s,o,r,t;return{c(){e=d("div"),n=d("div"),a=d("input"),s=S(),o=d("button"),r=$e("svg"),t=$e("path"),this.h()},l(l){e=$(l,"DIV",{class:!0});var b=f(e);n=$(b,"DIV",{class:!0});var h=f(n);a=$(h,"INPUT",{type:!0,placeholder:!0,class:!0}),s=L(h),o=$(h,"BUTTON",{class:!0});var _=f(o);r=fe(_,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var g=f(r);t=fe(g,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),f(t).forEach(i),g.forEach(i),_.forEach(i),h.forEach(i),b.forEach(i),this.h()},h(){c(a,"type","text"),c(a,"placeholder","Search\u2026"),c(a,"class","input input-bordered"),c(t,"stroke-linecap","round"),c(t,"stroke-linejoin","round"),c(t,"stroke-width","2"),c(t,"d","M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"),c(r,"xmlns","http://www.w3.org/2000/svg"),c(r,"class","h-6 w-6"),c(r,"fill","none"),c(r,"viewBox","0 0 24 24"),c(r,"stroke","currentColor"),c(o,"class","btn btn-square"),c(n,"class","input-group"),c(e,"class","form-control")},m(l,b){w(l,e,b),p(e,n),p(n,a),p(n,s),p(n,o),p(o,r),p(r,t)},d(l){l&&i(e)}}}function Ge(m){let e,n=`<div class="$$form-control">
  <div class="$$input-group">
    <input type="text" placeholder="Search\u2026" class="$$input $$input-bordered" />
    <button class="$$btn $$btn-square">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    </button>
  </div>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function ze(m){let e,n=`<div className="$$form-control">
  <div className="$$input-group">
    <input type="text" placeholder="Search\u2026" className="$$input $$input-bordered" />
    <button className="$$btn $$btn-square">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    </button>
  </div>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function Oe(m){let e,n,a,s,o,r,t,l,b,h,_,g;return{c(){e=d("div"),n=d("div"),a=d("select"),s=d("option"),o=y("Pick category"),r=d("option"),t=y("T-shirts"),l=d("option"),b=y("Mugs"),h=S(),_=d("button"),g=y("Go"),this.h()},l(x){e=$(x,"DIV",{class:!0});var N=f(e);n=$(N,"DIV",{class:!0});var E=f(n);a=$(E,"SELECT",{class:!0});var T=f(a);s=$(T,"OPTION",{});var u=f(s);o=P(u,"Pick category"),u.forEach(i),r=$(T,"OPTION",{});var v=f(r);t=P(v,"T-shirts"),v.forEach(i),l=$(T,"OPTION",{});var B=f(l);b=P(B,"Mugs"),B.forEach(i),T.forEach(i),h=L(E),_=$(E,"BUTTON",{class:!0});var D=f(_);g=P(D,"Go"),D.forEach(i),E.forEach(i),N.forEach(i),this.h()},h(){s.disabled=!0,s.selected=!0,s.__value="Pick category",s.value=s.__value,r.__value="T-shirts",r.value=r.__value,l.__value="Mugs",l.value=l.__value,c(a,"class","select select-bordered"),c(_,"class","btn"),c(n,"class","input-group"),c(e,"class","form-control")},m(x,N){w(x,e,N),p(e,n),p(n,a),p(a,s),p(s,o),p(a,r),p(r,t),p(a,l),p(l,b),p(n,h),p(n,_),p(_,g)},d(x){x&&i(e)}}}function Ye(m){let e,n=`<div class="$$form-control">
  <div class="$$input-group">
    <select class="$$select $$select-bordered">
      <option disabled selected>Pick category</option>
      <option>T-shirts</option>
      <option>Mugs</option>
    </select>
    <button class="$$btn">Go</button>
  </div>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","html")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function je(m){let e,n=`<div className="$$form-control">
  <div className="$$input-group">
    <select className="$$select $$select-bordered">
      <option disabled selected>Pick category</option>
      <option>T-shirts</option>
      <option>Mugs</option>
    </select>
    <button className="$$btn">Go</button>
  </div>
</div>`,a,s,o,r;return{c(){e=d("pre"),a=y(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var l=f(e);a=P(l,n),l.forEach(i),this.h()},h(){c(e,"slot","react")},m(t,l){w(t,e,l),p(e,a),o||(r=I(s=k.call(null,e,{to:m[0]})),o=!0)},p(t,l){s&&A(s.update)&&l&1&&s.update.call(null,{to:t[0]})},d(t){t&&i(e),o=!1,r()}}}function qe(m){let e,n,a,s,o,r,t,l,b,h,_,g,x,N,E,T;return e=new Ne({props:{data:[{type:"component",class:"input-group",desc:"Container for grouping elements"},{type:"modifier",class:"input-group-lg",desc:"Large size for input-group wrapper"},{type:"modifier",class:"input-group-md",desc:"Medium (default) size for input-group wrapper"},{type:"modifier",class:"input-group-sm",desc:"Small size for input-group wrapper"},{type:"modifier",class:"input-group-xs",desc:"Extra small size for input-group wrapper"},{type:"modifier",class:"input-group-vertical",desc:"Vertical direction for input-group items"}]}}),a=new X({props:{title:"Group label and text input horizontally",$$slots:{react:[Te],html:[Pe],default:[ye]},$$scope:{ctx:m}}}),o=new X({props:{title:"Group text input and label horizontally",$$slots:{react:[Le],html:[Se],default:[we]},$$scope:{ctx:m}}}),t=new X({props:{title:"label on both sides",$$slots:{react:[ke],html:[Ae],default:[Ie]},$$scope:{ctx:m}}}),b=new X({props:{title:"Group label and text input vertically",$$slots:{react:[Me],html:[De],default:[Be]},$$scope:{ctx:m}}}),_=new X({props:{title:"Sizes",$$slots:{react:[Re],html:[Ce],default:[Ue]},$$scope:{ctx:m}}}),x=new X({props:{title:"Group text input and button",$$slots:{react:[ze],html:[Ge],default:[Ve]},$$scope:{ctx:m}}}),E=new X({props:{title:"Group select and button",$$slots:{react:[je],html:[Ye],default:[Oe]},$$scope:{ctx:m}}}),{c(){V(e.$$.fragment),n=S(),V(a.$$.fragment),s=S(),V(o.$$.fragment),r=S(),V(t.$$.fragment),l=S(),V(b.$$.fragment),h=S(),V(_.$$.fragment),g=S(),V(x.$$.fragment),N=S(),V(E.$$.fragment)},l(u){G(e.$$.fragment,u),n=L(u),G(a.$$.fragment,u),s=L(u),G(o.$$.fragment,u),r=L(u),G(t.$$.fragment,u),l=L(u),G(b.$$.fragment,u),h=L(u),G(_.$$.fragment,u),g=L(u),G(x.$$.fragment,u),N=L(u),G(E.$$.fragment,u)},m(u,v){z(e,u,v),w(u,n,v),z(a,u,v),w(u,s,v),z(o,u,v),w(u,r,v),z(t,u,v),w(u,l,v),z(b,u,v),w(u,h,v),z(_,u,v),w(u,g,v),z(x,u,v),w(u,N,v),z(E,u,v),T=!0},p(u,v){const B={};v&5&&(B.$$scope={dirty:v,ctx:u}),a.$set(B);const D={};v&5&&(D.$$scope={dirty:v,ctx:u}),o.$set(D);const C={};v&5&&(C.$$scope={dirty:v,ctx:u}),t.$set(C);const F={};v&5&&(F.$$scope={dirty:v,ctx:u}),b.$set(F);const R={};v&5&&(R.$$scope={dirty:v,ctx:u}),_.$set(R);const M={};v&5&&(M.$$scope={dirty:v,ctx:u}),x.$set(M);const q={};v&5&&(q.$$scope={dirty:v,ctx:u}),E.$set(q)},i(u){T||(O(e.$$.fragment,u),O(a.$$.fragment,u),O(o.$$.fragment,u),O(t.$$.fragment,u),O(b.$$.fragment,u),O(_.$$.fragment,u),O(x.$$.fragment,u),O(E.$$.fragment,u),T=!0)},o(u){Y(e.$$.fragment,u),Y(a.$$.fragment,u),Y(o.$$.fragment,u),Y(t.$$.fragment,u),Y(b.$$.fragment,u),Y(_.$$.fragment,u),Y(x.$$.fragment,u),Y(E.$$.fragment,u),T=!1},d(u){j(e,u),u&&i(n),j(a,u),u&&i(s),j(o,u),u&&i(r),j(t,u),u&&i(l),j(b,u),u&&i(h),j(_,u),u&&i(g),j(x,u),u&&i(N),j(E,u)}}}function Xe(m){let e,n;const a=[m[1],me];let s={$$slots:{default:[qe]},$$scope:{ctx:m}};for(let o=0;o<a.length;o+=1)s=le(s,a[o]);return e=new Ee({props:s}),{c(){V(e.$$.fragment)},l(o){G(e.$$.fragment,o)},m(o,r){z(e,o,r),n=!0},p(o,[r]){const t=r&2?be(a,[r&2&&ce(o[1]),r&0&&ce(me)]):{};r&5&&(t.$$scope={dirty:r,ctx:o}),e.$set(t)},i(o){n||(O(e.$$.fragment,o),n=!0)},o(o){Y(e.$$.fragment,o),n=!1},d(o){j(e,o)}}}const me={title:"Input group",desc:"Input group puts an input next to a text or a button.",published:!0};function Fe(m,e,n){let a;return ge(m,xe,s=>n(0,a=s)),m.$$set=s=>{n(1,e=le(le({},e),de(s)))},e=de(e),[a,e]}class at extends he{constructor(e){super();_e(this,e,Fe,Xe,ve,{})}}export{at as default,me as metadata};
