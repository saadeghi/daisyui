import{S as Pa,i as Ra,s as Da,C as ma,w as V,x as z,y as C,z as Ia,A as Sa,q as k,o as B,B as q,K as Va,ag as wa,k as N,m as A,g as x,d as b,e as n,t as v,c as f,a as m,h,b as u,F as r,a9 as L,W as P}from"../../chunks/vendor-c5cb7521.js";import{M as za}from"../../chunks/_markdown-2bb6eb92.js";import{p as Ca,C as ka,a as aa,r as R}from"../../chunks/actions-9cbde582.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-37bcce46.js";import"../../chunks/index-c392802f.js";import"../../chunks/SEO-ab6f9e0c.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-2898e6eb.js";function Ba(_){let a,c,$,l,s,i,t,e,E;return{c(){a=n("div"),c=n("a"),$=v("Tab 1"),l=N(),s=n("a"),i=v("Tab 2"),t=N(),e=n("a"),E=v("Tab 3"),this.h()},l(T){a=f(T,"DIV",{class:!0});var d=m(a);c=f(d,"A",{class:!0});var g=m(c);$=h(g,"Tab 1"),g.forEach(b),l=A(d),s=f(d,"A",{class:!0});var o=m(s);i=h(o,"Tab 2"),o.forEach(b),t=A(d),e=f(d,"A",{class:!0});var p=m(e);E=h(p,"Tab 3"),p.forEach(b),d.forEach(b),this.h()},h(){u(c,"class","tab"),u(s,"class","tab tab-active"),u(e,"class","tab"),u(a,"class","tabs")},m(T,d){x(T,a,d),r(a,c),r(c,$),r(a,l),r(a,s),r(s,i),r(a,t),r(a,e),r(e,E)},d(T){T&&b(a)}}}function qa(_){let a,c=`<div class="$$tabs">
  <a class="$$tab">Tab 1</a> 
  <a class="$$tab $$tab-active">Tab 2</a> 
  <a class="$$tab">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","html")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Fa(_){let a,c=`<div className="$$tabs">
  <a className="$$tab">Tab 1</a> 
  <a className="$$tab $$tab-active">Tab 2</a> 
  <a className="$$tab">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","react")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ma(_){let a,c,$,l,s,i,t,e,E;return{c(){a=n("div"),c=n("a"),$=v("Tab 1"),l=N(),s=n("a"),i=v("Tab 2"),t=N(),e=n("a"),E=v("Tab 3"),this.h()},l(T){a=f(T,"DIV",{class:!0});var d=m(a);c=f(d,"A",{class:!0});var g=m(c);$=h(g,"Tab 1"),g.forEach(b),l=A(d),s=f(d,"A",{class:!0});var o=m(s);i=h(o,"Tab 2"),o.forEach(b),t=A(d),e=f(d,"A",{class:!0});var p=m(e);E=h(p,"Tab 3"),p.forEach(b),d.forEach(b),this.h()},h(){u(c,"class","tab tab-bordered"),u(s,"class","tab tab-bordered tab-active"),u(e,"class","tab tab-bordered"),u(a,"class","tabs")},m(T,d){x(T,a,d),r(a,c),r(c,$),r(a,l),r(a,s),r(s,i),r(a,t),r(a,e),r(e,E)},d(T){T&&b(a)}}}function ja(_){let a,c=`<div class="$$tabs">
  <a class="$$tab $$tab-bordered">Tab 1</a> 
  <a class="$$tab $$tab-bordered $$tab-active">Tab 2</a> 
  <a class="$$tab $$tab-bordered">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","html")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ka(_){let a,c=`<div className="$$tabs">
  <a className="$$tab $$tab-bordered">Tab 1</a> 
  <a className="$$tab $$tab-bordered $$tab-active">Tab 2</a> 
  <a className="$$tab $$tab-bordered">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","react")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Wa(_){let a,c,$,l,s,i,t,e,E;return{c(){a=n("div"),c=n("a"),$=v("Tab 1"),l=N(),s=n("a"),i=v("Tab 2"),t=N(),e=n("a"),E=v("Tab 3"),this.h()},l(T){a=f(T,"DIV",{class:!0});var d=m(a);c=f(d,"A",{class:!0});var g=m(c);$=h(g,"Tab 1"),g.forEach(b),l=A(d),s=f(d,"A",{class:!0});var o=m(s);i=h(o,"Tab 2"),o.forEach(b),t=A(d),e=f(d,"A",{class:!0});var p=m(e);E=h(p,"Tab 3"),p.forEach(b),d.forEach(b),this.h()},h(){u(c,"class","tab tab-lifted"),u(s,"class","tab tab-lifted tab-active"),u(e,"class","tab tab-lifted"),u(a,"class","tabs")},m(T,d){x(T,a,d),r(a,c),r(c,$),r(a,l),r(a,s),r(s,i),r(a,t),r(a,e),r(e,E)},d(T){T&&b(a)}}}function Ga(_){let a,c=`<div class="$$tabs">
  <a class="$$tab $$tab-lifted">Tab 1</a> 
  <a class="$$tab $$tab-lifted $$tab-active">Tab 2</a> 
  <a class="$$tab $$tab-lifted">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","html")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ha(_){let a,c=`<div className="$$tabs">
  <a className="$$tab $$tab-lifted">Tab 1</a> 
  <a className="$$tab $$tab-lifted $$tab-active">Tab 2</a> 
  <a className="$$tab $$tab-lifted">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","react")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ja(_){let a,c,$,l,s,i,t,e,E;return{c(){a=n("div"),c=n("a"),$=v("Tab 1"),l=N(),s=n("a"),i=v("Tab 2"),t=N(),e=n("a"),E=v("Tab 3"),this.h()},l(T){a=f(T,"DIV",{class:!0});var d=m(a);c=f(d,"A",{class:!0});var g=m(c);$=h(g,"Tab 1"),g.forEach(b),l=A(d),s=f(d,"A",{class:!0});var o=m(s);i=h(o,"Tab 2"),o.forEach(b),t=A(d),e=f(d,"A",{class:!0});var p=m(e);E=h(p,"Tab 3"),p.forEach(b),d.forEach(b),this.h()},h(){u(c,"class","tab"),u(s,"class","tab tab-active"),u(e,"class","tab"),u(a,"class","tabs tabs-boxed")},m(T,d){x(T,a,d),r(a,c),r(c,$),r(a,l),r(a,s),r(s,i),r(a,t),r(a,e),r(e,E)},d(T){T&&b(a)}}}function Oa(_){let a,c=`<div class="$$tabs tabs-boxed">
  <a class="$$tab">Tab 1</a> 
  <a class="$$tab $$tab-active">Tab 2</a> 
  <a class="$$tab">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","html")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Qa(_){let a,c=`<div className="$$tabs tabs-boxed">
  <a className="$$tab">Tab 1</a> 
  <a className="$$tab $$tab-active">Tab 2</a> 
  <a className="$$tab">Tab 3</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","react")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ua(_){let a,c,$,l,s,i,t,e,E,T,d,g,o,p,F,D,M,j,I,ta,ea,y,K,sa,la,W,ca,ra,G,$a,oa,S,H,ia,ba,J,da,na,O,fa;return{c(){a=n("div"),c=n("div"),$=n("a"),l=v("Tiny"),s=N(),i=n("a"),t=v("Tiny"),e=N(),E=n("a"),T=v("Tiny"),d=N(),g=n("div"),o=n("a"),p=v("Small"),F=N(),D=n("a"),M=v("Small"),j=N(),I=n("a"),ta=v("Small"),ea=N(),y=n("div"),K=n("a"),sa=v("Normal"),la=N(),W=n("a"),ca=v("Normal"),ra=N(),G=n("a"),$a=v("Normal"),oa=N(),S=n("div"),H=n("a"),ia=v("Large"),ba=N(),J=n("a"),da=v("Large"),na=N(),O=n("a"),fa=v("Large"),this.h()},l(Z){a=f(Z,"DIV",{class:!0});var w=m(a);c=f(w,"DIV",{class:!0});var Q=m(c);$=f(Q,"A",{class:!0});var ua=m($);l=h(ua,"Tiny"),ua.forEach(b),s=A(Q),i=f(Q,"A",{class:!0});var pa=m(i);t=h(pa,"Tiny"),pa.forEach(b),e=A(Q),E=f(Q,"A",{class:!0});var _a=m(E);T=h(_a,"Tiny"),_a.forEach(b),Q.forEach(b),d=A(w),g=f(w,"DIV",{class:!0});var U=m(g);o=f(U,"A",{class:!0});var va=m(o);p=h(va,"Small"),va.forEach(b),F=A(U),D=f(U,"A",{class:!0});var ha=m(D);M=h(ha,"Small"),ha.forEach(b),j=A(U),I=f(U,"A",{class:!0});var Ta=m(I);ta=h(Ta,"Small"),Ta.forEach(b),U.forEach(b),ea=A(w),y=f(w,"DIV",{class:!0});var X=m(y);K=f(X,"A",{class:!0});var Ea=m(K);sa=h(Ea,"Normal"),Ea.forEach(b),la=A(X),W=f(X,"A",{class:!0});var ga=m(W);ca=h(ga,"Normal"),ga.forEach(b),ra=A(X),G=f(X,"A",{class:!0});var Na=m(G);$a=h(Na,"Normal"),Na.forEach(b),X.forEach(b),oa=A(w),S=f(w,"DIV",{class:!0});var Y=m(S);H=f(Y,"A",{class:!0});var Aa=m(H);ia=h(Aa,"Large"),Aa.forEach(b),ba=A(Y),J=f(Y,"A",{class:!0});var xa=m(J);da=h(xa,"Large"),xa.forEach(b),na=A(Y),O=f(Y,"A",{class:!0});var ya=m(O);fa=h(ya,"Large"),ya.forEach(b),Y.forEach(b),w.forEach(b),this.h()},h(){u($,"class","tab tab-xs tab-lifted"),u(i,"class","tab tab-xs tab-lifted tab-active"),u(E,"class","tab tab-xs tab-lifted"),u(c,"class","tabs"),u(o,"class","tab tab-sm tab-lifted"),u(D,"class","tab tab-sm tab-lifted tab-active"),u(I,"class","tab tab-sm tab-lifted"),u(g,"class","tabs"),u(K,"class","tab tab-lifted"),u(W,"class","tab tab-lifted tab-active"),u(G,"class","tab tab-lifted"),u(y,"class","tabs"),u(H,"class","tab tab-lg tab-lifted"),u(J,"class","tab tab-lg tab-lifted tab-active"),u(O,"class","tab tab-lg tab-lifted"),u(S,"class","tabs"),u(a,"class","flex flex-col items-center gap-6")},m(Z,w){x(Z,a,w),r(a,c),r(c,$),r($,l),r(c,s),r(c,i),r(i,t),r(c,e),r(c,E),r(E,T),r(a,d),r(a,g),r(g,o),r(o,p),r(g,F),r(g,D),r(D,M),r(g,j),r(g,I),r(I,ta),r(a,ea),r(a,y),r(y,K),r(K,sa),r(y,la),r(y,W),r(W,ca),r(y,ra),r(y,G),r(G,$a),r(a,oa),r(a,S),r(S,H),r(H,ia),r(S,ba),r(S,J),r(J,da),r(S,na),r(S,O),r(O,fa)},d(Z){Z&&b(a)}}}function Xa(_){let a,c=`<!-- xs -->
<div class="$$tabs">
  <a class="$$tab $$tab-xs $$tab-lifted">Tiny</a> 
  <a class="$$tab $$tab-xs $$tab-lifted $$tab-active">Tiny</a> 
  <a class="$$tab $$tab-xs $$tab-lifted">Tiny</a>
</div>
<!-- sm -->
<div class="$$tabs">
  <a class="$$tab $$tab-sm $$tab-lifted">Small</a> 
  <a class="$$tab $$tab-sm $$tab-lifted $$tab-active">Small</a> 
  <a class="$$tab $$tab-sm $$tab-lifted">Small</a>
</div>
<!-- md -->
<div class="$$tabs">
  <a class="$$tab $$tab-lifted">Normal</a> 
  <a class="$$tab $$tab-lifted $$tab-active">Normal</a> 
  <a class="$$tab $$tab-lifted">Normal</a>
</div>
<!-- lg -->
<div class="$$tabs">
  <a class="$$tab $$tab-lg $$tab-lifted">Large</a> 
  <a class="$$tab $$tab-lg $$tab-lifted $$tab-active">Large</a> 
  <a class="$$tab $$tab-lg $$tab-lifted">Large</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","html")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Ya(_){let a,c=`<!-- xs -->
<div className="$$tabs">
  <a className="$$tab $$tab-xs $$tab-lifted">Tiny</a> 
  <a className="$$tab $$tab-xs $$tab-lifted $$tab-active">Tiny</a> 
  <a className="$$tab $$tab-xs $$tab-lifted">Tiny</a>
</div>
<!-- sm -->
<div className="$$tabs">
  <a className="$$tab $$tab-sm $$tab-lifted">Small</a> 
  <a className="$$tab $$tab-sm $$tab-lifted $$tab-active">Small</a> 
  <a className="$$tab $$tab-sm $$tab-lifted">Small</a>
</div>
<!-- md -->
<div className="$$tabs">
  <a className="$$tab $$tab-lifted">Normal</a> 
  <a className="$$tab $$tab-lifted $$tab-active">Normal</a> 
  <a className="$$tab $$tab-lifted">Normal</a>
</div>
<!-- lg -->
<div className="$$tabs">
  <a className="$$tab $$tab-lg $$tab-lifted">Large</a> 
  <a className="$$tab $$tab-lg $$tab-lifted $$tab-active">Large</a> 
  <a className="$$tab $$tab-lg $$tab-lifted">Large</a>
</div>`,$,l,s,i;return{c(){a=n("pre"),$=v(c),this.h()},l(t){a=f(t,"PRE",{slot:!0});var e=m(a);$=h(e,c),e.forEach(b),this.h()},h(){u(a,"slot","react")},m(t,e){x(t,a,e),r(a,$),s||(i=L(l=R.call(null,a,{to:_[0]})),s=!0)},p(t,e){l&&P(l.update)&&e&1&&l.update.call(null,{to:t[0]})},d(t){t&&b(a),s=!1,i()}}}function Za(_){let a,c,$,l,s,i,t,e,E,T,d,g;return a=new ka({props:{data:[{type:"component",class:"tabs",desc:"Container of tab items"},{type:"component",class:"tab",desc:"A tab item"},{type:"modifier",class:"tab-active",desc:"For the active tab"},{type:"modifier",class:"tab-bordered",desc:"Adds bottom border to tab item"},{type:"modifier",class:"tab-lifted",desc:"Adds lifted style to tab item"},{type:"modifier",class:"tabs-boxed",desc:"Adds a box style to tabs container"},{type:"responsive",class:"tab-xs",desc:"Shows tab in extra small size"},{type:"responsive",class:"tab-sm",desc:"Shows tab in small size"},{type:"responsive",class:"tab-md",desc:"Shows tab in medium (default) size"},{type:"responsive",class:"tab-lg",desc:"Shows tab in large size"}]}}),$=new aa({props:{title:"Tabs",$$slots:{react:[Fa],html:[qa],default:[Ba]},$$scope:{ctx:_}}}),s=new aa({props:{title:"Bordered",$$slots:{react:[Ka],html:[ja],default:[Ma]},$$scope:{ctx:_}}}),t=new aa({props:{title:"Lifted",$$slots:{react:[Ha],html:[Ga],default:[Wa]},$$scope:{ctx:_}}}),E=new aa({props:{title:"Boxed",$$slots:{react:[Qa],html:[Oa],default:[Ja]},$$scope:{ctx:_}}}),d=new aa({props:{title:"Sizes",$$slots:{react:[Ya],html:[Xa],default:[Ua]},$$scope:{ctx:_}}}),{c(){V(a.$$.fragment),c=N(),V($.$$.fragment),l=N(),V(s.$$.fragment),i=N(),V(t.$$.fragment),e=N(),V(E.$$.fragment),T=N(),V(d.$$.fragment)},l(o){z(a.$$.fragment,o),c=A(o),z($.$$.fragment,o),l=A(o),z(s.$$.fragment,o),i=A(o),z(t.$$.fragment,o),e=A(o),z(E.$$.fragment,o),T=A(o),z(d.$$.fragment,o)},m(o,p){C(a,o,p),x(o,c,p),C($,o,p),x(o,l,p),C(s,o,p),x(o,i,p),C(t,o,p),x(o,e,p),C(E,o,p),x(o,T,p),C(d,o,p),g=!0},p(o,p){const F={};p&5&&(F.$$scope={dirty:p,ctx:o}),$.$set(F);const D={};p&5&&(D.$$scope={dirty:p,ctx:o}),s.$set(D);const M={};p&5&&(M.$$scope={dirty:p,ctx:o}),t.$set(M);const j={};p&5&&(j.$$scope={dirty:p,ctx:o}),E.$set(j);const I={};p&5&&(I.$$scope={dirty:p,ctx:o}),d.$set(I)},i(o){g||(k(a.$$.fragment,o),k($.$$.fragment,o),k(s.$$.fragment,o),k(t.$$.fragment,o),k(E.$$.fragment,o),k(d.$$.fragment,o),g=!0)},o(o){B(a.$$.fragment,o),B($.$$.fragment,o),B(s.$$.fragment,o),B(t.$$.fragment,o),B(E.$$.fragment,o),B(d.$$.fragment,o),g=!1},d(o){q(a,o),o&&b(c),q($,o),o&&b(l),q(s,o),o&&b(i),q(t,o),o&&b(e),q(E,o),o&&b(T),q(d,o)}}}function at(_){let a,c;const $=[_[1],La];let l={$$slots:{default:[Za]},$$scope:{ctx:_}};for(let s=0;s<$.length;s+=1)l=ma(l,$[s]);return a=new za({props:l}),{c(){V(a.$$.fragment)},l(s){z(a.$$.fragment,s)},m(s,i){C(a,s,i),c=!0},p(s,[i]){const t=i&2?Ia($,[i&2&&Sa(s[1]),i&0&&Sa(La)]):{};i&5&&(t.$$scope={dirty:i,ctx:s}),a.$set(t)},i(s){c||(k(a.$$.fragment,s),c=!0)},o(s){B(a.$$.fragment,s),c=!1},d(s){q(a,s)}}}const La={title:"Tabs",desc:"Tabs can be used to show a list of links in a tabbed format.",published:!0};function tt(_,a,c){let $;return Va(_,Ca,l=>c(0,$=l)),_.$$set=l=>{c(1,a=ma(ma({},a),wa(l)))},a=wa(a),[$,a]}class dt extends Pa{constructor(a){super();Ra(this,a,tt,at,Da,{})}}export{dt as default,La as metadata};
