import{S as X,i as Z,s as tt,e as c,t as S,k as R,w as M,c as r,a as u,h as b,d as l,m as k,x as O,g as N,H as o,y as z,q as F,o as G,B as K,v as st,f as P,b as h,j as U}from"../../chunks/vendor-1f04da3c.js";import{C as et,a as Q}from"../../chunks/ClassTable-d5f58326.js";import"../../chunks/preload-helper-ec9aa979.js";function nt(x){let t,e;return{c(){t=c("span"),e=c("span"),this.h()},l(n){t=r(n,"SPAN",{class:!0});var s=u(t);e=r(s,"SPAN",{style:!0}),u(e).forEach(l),s.forEach(l),this.h()},h(){P(e,"--value",x[0]),h(t,"class","countdown")},m(n,s){N(n,t,s),o(t,e)},p(n,s){s&1&&P(e,"--value",n[0])},d(n){n&&l(t)}}}function at(x){let t,e=`<span class="countdown">
  <span style="--value:${x[0]};"></span>
</span>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<span class="countdown">
  <span style="--value:${s[0]};"></span>
</span>`)&&U(n,e)},d(s){s&&l(t)}}}function lt(x){let t,e;return{c(){t=c("span"),e=c("span"),this.h()},l(n){t=r(n,"SPAN",{class:!0});var s=u(t);e=r(s,"SPAN",{style:!0}),u(e).forEach(l),s.forEach(l),this.h()},h(){P(e,"--value",x[0]),h(t,"class","countdown font-mono text-6xl")},m(n,s){N(n,t,s),o(t,e)},p(n,s){s&1&&P(e,"--value",n[0])},d(n){n&&l(t)}}}function ot(x){let t,e=`<span class="countdown font-mono text-6xl">
  <span style="--value:${x[0]};"></span>
</span>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<span class="countdown font-mono text-6xl">
  <span style="--value:${s[0]};"></span>
</span>`)&&U(n,e)},d(s){s&&l(t)}}}function pt(x){let t,e,n,s,p,w,v;return{c(){t=c("span"),e=c("span"),n=S(`h
  `),s=c("span"),p=S(`m
  `),w=c("span"),v=S("s"),this.h()},l(d){t=r(d,"SPAN",{class:!0});var m=u(t);e=r(m,"SPAN",{style:!0}),u(e).forEach(l),n=b(m,`h
  `),s=r(m,"SPAN",{style:!0}),u(s).forEach(l),p=b(m,`m
  `),w=r(m,"SPAN",{style:!0}),u(w).forEach(l),v=b(m,"s"),m.forEach(l),this.h()},h(){P(e,"--value","10"),P(s,"--value","24"),P(w,"--value",x[0]),h(t,"class","font-mono text-2xl countdown")},m(d,m){N(d,t,m),o(t,e),o(t,n),o(t,s),o(t,p),o(t,w),o(t,v)},p(d,m){m&1&&P(w,"--value",d[0])},d(d){d&&l(t)}}}function ct(x){let t,e=`<span class="font-mono text-2xl countdown">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${x[0]};"></span>s
</span>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<span class="font-mono text-2xl countdown">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${s[0]};"></span>s
</span>`)&&U(n,e)},d(s){s&&l(t)}}}function rt(x){let t,e,n,s,p,w;return{c(){t=c("span"),e=c("span"),n=S(`:
  `),s=c("span"),p=S(`:
  `),w=c("span"),this.h()},l(v){t=r(v,"SPAN",{class:!0});var d=u(t);e=r(d,"SPAN",{style:!0}),u(e).forEach(l),n=b(d,`:
  `),s=r(d,"SPAN",{style:!0}),u(s).forEach(l),p=b(d,`:
  `),w=r(d,"SPAN",{style:!0}),u(w).forEach(l),d.forEach(l),this.h()},h(){P(e,"--value","10"),P(s,"--value","24"),P(w,"--value",x[0]),h(t,"class","font-mono text-2xl countdown")},m(v,d){N(v,t,d),o(t,e),o(t,n),o(t,s),o(t,p),o(t,w)},p(v,d){d&1&&P(w,"--value",v[0])},d(v){v&&l(t)}}}function ut(x){let t,e=`<span class="font-mono text-2xl countdown">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${x[0]};"></span>
</span>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<span class="font-mono text-2xl countdown">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${s[0]};"></span>
</span>`)&&U(n,e)},d(s){s&&l(t)}}}function ft(x){let t,e,n,s,p,w,v,d,m,L,D,g,E,V,I,T,_,A,y,q;return{c(){t=c("div"),e=c("div"),n=c("span"),s=c("span"),p=S(`
    days`),w=R(),v=c("div"),d=c("span"),m=c("span"),L=S(`
    hours`),D=R(),g=c("div"),E=c("span"),V=c("span"),I=S(`
    minutes`),T=R(),_=c("div"),A=c("span"),y=c("span"),q=S(`
    sec`),this.h()},l($){t=r($,"DIV",{class:!0});var i=u(t);e=r(i,"DIV",{});var a=u(e);n=r(a,"SPAN",{class:!0});var f=u(n);s=r(f,"SPAN",{style:!0}),u(s).forEach(l),f.forEach(l),p=b(a,`
    days`),a.forEach(l),w=k(i),v=r(i,"DIV",{});var C=u(v);d=r(C,"SPAN",{class:!0});var j=u(d);m=r(j,"SPAN",{style:!0}),u(m).forEach(l),j.forEach(l),L=b(C,`
    hours`),C.forEach(l),D=k(i),g=r(i,"DIV",{});var J=u(g);E=r(J,"SPAN",{class:!0});var B=u(E);V=r(B,"SPAN",{style:!0}),u(V).forEach(l),B.forEach(l),I=b(J,`
    minutes`),J.forEach(l),T=k(i),_=r(i,"DIV",{});var Y=u(_);A=r(Y,"SPAN",{class:!0});var H=u(A);y=r(H,"SPAN",{style:!0}),u(y).forEach(l),H.forEach(l),q=b(Y,`
    sec`),Y.forEach(l),i.forEach(l),this.h()},h(){P(s,"--value","15"),h(n,"class","font-mono text-4xl countdown"),P(m,"--value","10"),h(d,"class","font-mono text-4xl countdown"),P(V,"--value","24"),h(E,"class","font-mono text-4xl countdown"),P(y,"--value",x[0]),h(A,"class","font-mono text-4xl countdown"),h(t,"class","flex gap-5")},m($,i){N($,t,i),o(t,e),o(e,n),o(n,s),o(e,p),o(t,w),o(t,v),o(v,d),o(d,m),o(v,L),o(t,D),o(t,g),o(g,E),o(E,V),o(g,I),o(t,T),o(t,_),o(_,A),o(A,y),o(_,q)},p($,i){i&1&&P(y,"--value",$[0])},d($){$&&l(t)}}}function dt(x){let t,e=`<div class="flex gap-5">
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:${x[0]};"></span>
    </span>
    sec
  </div>
</div>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<div class="flex gap-5">
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="font-mono text-4xl countdown">
      <span style="--value:${s[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(n,e)},d(s){s&&l(t)}}}function it(x){let t,e,n,s,p,w,v,d,m,L,D,g,E,V,I,T,_,A,y,q;return{c(){t=c("div"),e=c("div"),n=c("span"),s=c("span"),p=S(`
    days`),w=R(),v=c("div"),d=c("span"),m=c("span"),L=S(`
    hours`),D=R(),g=c("div"),E=c("span"),V=c("span"),I=S(`
    min`),T=R(),_=c("div"),A=c("span"),y=c("span"),q=S(`
    sec`),this.h()},l($){t=r($,"DIV",{class:!0});var i=u(t);e=r(i,"DIV",{class:!0});var a=u(e);n=r(a,"SPAN",{class:!0});var f=u(n);s=r(f,"SPAN",{style:!0}),u(s).forEach(l),f.forEach(l),p=b(a,`
    days`),a.forEach(l),w=k(i),v=r(i,"DIV",{class:!0});var C=u(v);d=r(C,"SPAN",{class:!0});var j=u(d);m=r(j,"SPAN",{style:!0}),u(m).forEach(l),j.forEach(l),L=b(C,`
    hours`),C.forEach(l),D=k(i),g=r(i,"DIV",{class:!0});var J=u(g);E=r(J,"SPAN",{class:!0});var B=u(E);V=r(B,"SPAN",{style:!0}),u(V).forEach(l),B.forEach(l),I=b(J,`
    min`),J.forEach(l),T=k(i),_=r(i,"DIV",{class:!0});var Y=u(_);A=r(Y,"SPAN",{class:!0});var H=u(A);y=r(H,"SPAN",{style:!0}),u(y).forEach(l),H.forEach(l),q=b(Y,`
    sec`),Y.forEach(l),i.forEach(l),this.h()},h(){P(s,"--value","15"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col"),P(m,"--value","10"),h(d,"class","font-mono text-5xl countdown"),h(v,"class","flex flex-col"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(g,"class","flex flex-col"),P(y,"--value",x[0]),h(A,"class","font-mono text-5xl countdown"),h(_,"class","flex flex-col"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m($,i){N($,t,i),o(t,e),o(e,n),o(n,s),o(e,p),o(t,w),o(t,v),o(v,d),o(d,m),o(v,L),o(t,D),o(t,g),o(g,E),o(E,V),o(g,I),o(t,T),o(t,_),o(_,A),o(A,y),o(_,q)},p($,i){i&1&&P(y,"--value",$[0])},d($){$&&l(t)}}}function vt(x){let t,e=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:${x[0]};"></span>
    </span>
    sec
  </div>
</div>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="font-mono text-5xl countdown">
      <span style="--value:${s[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(n,e)},d(s){s&&l(t)}}}function mt(x){let t,e,n,s,p,w,v,d,m,L,D,g,E,V,I,T,_,A,y,q;return{c(){t=c("div"),e=c("div"),n=c("span"),s=c("span"),p=S(`
    days`),w=R(),v=c("div"),d=c("span"),m=c("span"),L=S(`
    hours`),D=R(),g=c("div"),E=c("span"),V=c("span"),I=S(`
    min`),T=R(),_=c("div"),A=c("span"),y=c("span"),q=S(`
    sec`),this.h()},l($){t=r($,"DIV",{class:!0});var i=u(t);e=r(i,"DIV",{class:!0});var a=u(e);n=r(a,"SPAN",{class:!0});var f=u(n);s=r(f,"SPAN",{style:!0}),u(s).forEach(l),f.forEach(l),p=b(a,`
    days`),a.forEach(l),w=k(i),v=r(i,"DIV",{class:!0});var C=u(v);d=r(C,"SPAN",{class:!0});var j=u(d);m=r(j,"SPAN",{style:!0}),u(m).forEach(l),j.forEach(l),L=b(C,`
    hours`),C.forEach(l),D=k(i),g=r(i,"DIV",{class:!0});var J=u(g);E=r(J,"SPAN",{class:!0});var B=u(E);V=r(B,"SPAN",{style:!0}),u(V).forEach(l),B.forEach(l),I=b(J,`
    min`),J.forEach(l),T=k(i),_=r(i,"DIV",{class:!0});var Y=u(_);A=r(Y,"SPAN",{class:!0});var H=u(A);y=r(H,"SPAN",{style:!0}),u(y).forEach(l),H.forEach(l),q=b(Y,`
    sec`),Y.forEach(l),i.forEach(l),this.h()},h(){P(s,"--value","15"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(m,"--value","10"),h(d,"class","font-mono text-5xl countdown"),h(v,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(g,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(y,"--value",x[0]),h(A,"class","font-mono text-5xl countdown"),h(_,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m($,i){N($,t,i),o(t,e),o(e,n),o(n,s),o(e,p),o(t,w),o(t,v),o(v,d),o(d,m),o(v,L),o(t,D),o(t,g),o(g,E),o(E,V),o(g,I),o(t,T),o(t,_),o(_,A),o(A,y),o(_,q)},p($,i){i&1&&P(y,"--value",$[0])},d($){$&&l(t)}}}function xt(x){let t,e=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:${x[0]};"></span>
    </span>
    sec
  </div>
</div>`,n;return{c(){t=c("pre"),n=S(e),this.h()},l(s){t=r(s,"PRE",{slot:!0});var p=u(t);n=b(p,e),p.forEach(l),this.h()},h(){h(t,"slot","html")},m(s,p){N(s,t,p),o(t,n)},p(s,p){p&1&&e!==(e=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="font-mono text-5xl countdown">
      <span style="--value:${s[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(n,e)},d(s){s&&l(t)}}}function ht(x){let t,e,n,s,p,w,v,d,m,L,D,g,E,V,I,T,_,A,y,q,$,i;return v=new et({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),m=new Q({props:{title:"Countdown",$$slots:{html:[at],default:[nt]},$$scope:{ctx:x}}}),D=new Q({props:{title:"Large text",$$slots:{html:[ot],default:[lt]},$$scope:{ctx:x}}}),E=new Q({props:{title:"Clock countdown",$$slots:{html:[ct],default:[pt]},$$scope:{ctx:x}}}),I=new Q({props:{title:"Clock countdown with colons",$$slots:{html:[ut],default:[rt]},$$scope:{ctx:x}}}),_=new Q({props:{title:"Large text with labels",$$slots:{html:[dt],default:[ft]},$$scope:{ctx:x}}}),y=new Q({props:{title:"Large text with labels under",$$slots:{html:[vt],default:[it]},$$scope:{ctx:x}}}),$=new Q({props:{title:"In boxes",$$slots:{html:[xt],default:[mt]},$$scope:{ctx:x}}}),{c(){t=c("p"),e=S("You need to change to "),n=c("code"),s=S("--value"),p=S(" CSS variable using JS. Value must be a number between 0 and 99"),w=R(),M(v.$$.fragment),d=R(),M(m.$$.fragment),L=R(),M(D.$$.fragment),g=R(),M(E.$$.fragment),V=R(),M(I.$$.fragment),T=R(),M(_.$$.fragment),A=R(),M(y.$$.fragment),q=R(),M($.$$.fragment)},l(a){t=r(a,"P",{});var f=u(t);e=b(f,"You need to change to "),n=r(f,"CODE",{});var C=u(n);s=b(C,"--value"),C.forEach(l),p=b(f," CSS variable using JS. Value must be a number between 0 and 99"),f.forEach(l),w=k(a),O(v.$$.fragment,a),d=k(a),O(m.$$.fragment,a),L=k(a),O(D.$$.fragment,a),g=k(a),O(E.$$.fragment,a),V=k(a),O(I.$$.fragment,a),T=k(a),O(_.$$.fragment,a),A=k(a),O(y.$$.fragment,a),q=k(a),O($.$$.fragment,a)},m(a,f){N(a,t,f),o(t,e),o(t,n),o(n,s),o(t,p),N(a,w,f),z(v,a,f),N(a,d,f),z(m,a,f),N(a,L,f),z(D,a,f),N(a,g,f),z(E,a,f),N(a,V,f),z(I,a,f),N(a,T,f),z(_,a,f),N(a,A,f),z(y,a,f),N(a,q,f),z($,a,f),i=!0},p(a,[f]){const C={};f&5&&(C.$$scope={dirty:f,ctx:a}),m.$set(C);const j={};f&5&&(j.$$scope={dirty:f,ctx:a}),D.$set(j);const J={};f&5&&(J.$$scope={dirty:f,ctx:a}),E.$set(J);const B={};f&5&&(B.$$scope={dirty:f,ctx:a}),I.$set(B);const Y={};f&5&&(Y.$$scope={dirty:f,ctx:a}),_.$set(Y);const H={};f&5&&(H.$$scope={dirty:f,ctx:a}),y.$set(H);const W={};f&5&&(W.$$scope={dirty:f,ctx:a}),$.$set(W)},i(a){i||(F(v.$$.fragment,a),F(m.$$.fragment,a),F(D.$$.fragment,a),F(E.$$.fragment,a),F(I.$$.fragment,a),F(_.$$.fragment,a),F(y.$$.fragment,a),F($.$$.fragment,a),i=!0)},o(a){G(v.$$.fragment,a),G(m.$$.fragment,a),G(D.$$.fragment,a),G(E.$$.fragment,a),G(I.$$.fragment,a),G(_.$$.fragment,a),G(y.$$.fragment,a),G($.$$.fragment,a),i=!1},d(a){a&&l(t),a&&l(w),K(v,a),a&&l(d),K(m,a),a&&l(L),K(D,a),a&&l(g),K(E,a),a&&l(V),K(I,a),a&&l(T),K(_,a),a&&l(A),K(y,a),a&&l(q),K($,a)}}}const yt={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers",published:!0};function $t(x,t,e){let n=59;function s(){n>0?(e(0,n--,n),setTimeout(s,1e3)):(e(0,n=59),setTimeout(s,1e3))}return st(()=>{s()}),[n]}class gt extends X{constructor(t){super();Z(this,t,$t,ht,tt,{})}}export{gt as default,yt as metadata};
