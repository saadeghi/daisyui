import{S as ia,i as ra,s as oa,C as aa,w as Q,x as F,y as L,z as ca,A as ea,q as U,o as W,B as Y,K as da,ag as sa,k as V,m as x,g,d as r,e as n,c as u,a as m,O as M,b as v,H as p,t as C,h as T,a9 as P,Q as G}from"../../chunks/vendor-40028f80.js";import{M as va}from"../../chunks/_markdown-3fc30925.js";import{p as na,C as ua,a as Z,r as R}from"../../chunks/actions-83c730fd.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-77aabc03.js";import"../../chunks/index-a5651a84.js";import"../../chunks/SEO-62457e65.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-1e4be253.js";function pa(_){let a,o,s,i;return{c(){a=n("div"),o=n("div"),s=n("img"),this.h()},l(l){a=u(l,"DIV",{class:!0});var d=m(a);o=u(d,"DIV",{class:!0});var t=m(o);s=u(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 rounded bg-base-300"),v(a,"class","avatar")},m(l,d){g(l,a,d),p(a,o),p(o,s)},d(l){l&&r(a)}}}function ma(_){let a,o=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function fa(_){let a,o=`<div className="$$avatar">
  <div className="w-24 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function $a(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A,k,N,I,S,D;return{c(){a=n("div"),o=n("div"),s=n("img"),l=V(),d=n("div"),t=n("div"),e=n("img"),b=V(),h=n("div"),E=n("div"),w=n("img"),k=V(),N=n("div"),I=n("div"),S=n("img"),this.h()},l($){a=u($,"DIV",{class:!0});var c=m(a);o=u(c,"DIV",{class:!0});var f=m(o);s=u(f,"IMG",{src:!0,alt:!0}),f.forEach(r),c.forEach(r),l=x($),d=u($,"DIV",{class:!0});var q=m(d);t=u(q,"DIV",{class:!0});var K=m(t);e=u(K,"IMG",{src:!0,alt:!0}),K.forEach(r),q.forEach(r),b=x($),h=u($,"DIV",{class:!0});var O=m(h);E=u(O,"DIV",{class:!0});var J=m(E);w=u(J,"IMG",{src:!0,alt:!0}),J.forEach(r),O.forEach(r),k=x($),N=u($,"DIV",{class:!0});var X=m(N);I=u(X,"DIV",{class:!0});var z=m(I);S=u(z,"IMG",{src:!0,alt:!0}),z.forEach(r),X.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 rounded bg-base-300"),v(a,"class","avatar"),M(e.src,j="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(e,"src",j),v(e,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-16 rounded bg-base-300"),v(d,"class","avatar"),M(w.src,A="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(w,"src",A),v(w,"alt","Tailwind-CSS-Avatar-component"),v(E,"class","w-12 rounded bg-base-300"),v(h,"class","avatar"),M(S.src,D="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(S,"src",D),v(S,"alt","Tailwind-CSS-Avatar-component"),v(I,"class","w-8 rounded bg-base-300"),v(N,"class","avatar")},m($,c){g($,a,c),p(a,o),p(o,s),g($,l,c),g($,d,c),p(d,t),p(t,e),g($,b,c),g($,h,c),p(h,E),p(E,w),g($,k,c),g($,N,c),p(N,I),p(I,S)},d($){$&&r(a),$&&r(l),$&&r(d),$&&r(b),$&&r(h),$&&r(k),$&&r(N)}}}function _a(_){let a,o=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function ga(_){let a,o=`<div className="$$avatar">
  <div className="w-32 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-20 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-16 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-8 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function ha(_){let a,o,s,i,l,d,t,e,j;return{c(){a=n("div"),o=n("div"),s=n("img"),l=V(),d=n("div"),t=n("div"),e=n("img"),this.h()},l(b){a=u(b,"DIV",{class:!0});var h=m(a);o=u(h,"DIV",{class:!0});var E=m(o);s=u(E,"IMG",{src:!0,alt:!0}),E.forEach(r),h.forEach(r),l=x(b),d=u(b,"DIV",{class:!0});var w=m(d);t=u(w,"DIV",{class:!0});var A=m(t);e=u(A,"IMG",{src:!0,alt:!0}),A.forEach(r),w.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 rounded-xl bg-base-300"),v(a,"class","avatar"),M(e.src,j="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(e,"src",j),v(e,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 rounded-full bg-base-300"),v(d,"class","avatar")},m(b,h){g(b,a,h),p(a,o),p(o,s),g(b,l,h),g(b,d,h),p(d,t),p(t,e)},d(b){b&&r(a),b&&r(l),b&&r(d)}}}function ba(_){let a,o=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function wa(_){let a,o=`<div className="$$avatar">
  <div className="w-24 rounded-xl">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ea(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A;return{c(){a=n("div"),o=n("div"),s=n("img"),l=V(),d=n("div"),t=n("div"),e=n("img"),b=V(),h=n("div"),E=n("div"),w=n("img"),this.h()},l(k){a=u(k,"DIV",{class:!0});var N=m(a);o=u(N,"DIV",{class:!0});var I=m(o);s=u(I,"IMG",{src:!0,alt:!0}),I.forEach(r),N.forEach(r),l=x(k),d=u(k,"DIV",{class:!0});var S=m(d);t=u(S,"DIV",{class:!0});var D=m(t);e=u(D,"IMG",{src:!0,alt:!0}),D.forEach(r),S.forEach(r),b=x(k),h=u(k,"DIV",{class:!0});var $=m(h);E=u($,"DIV",{class:!0});var c=m(E);w=u(c,"IMG",{src:!0,alt:!0}),c.forEach(r),$.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 mask mask-squircle bg-base-300"),v(a,"class","avatar"),M(e.src,j="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(e,"src",j),v(e,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 mask mask-hexagon bg-base-300"),v(d,"class","avatar"),M(w.src,A="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(w,"src",A),v(w,"alt","Tailwind-CSS-Avatar-component"),v(E,"class","w-24 mask mask-triangle bg-base-300"),v(h,"class","avatar")},m(k,N){g(k,a,N),p(a,o),p(o,s),g(k,l,N),g(k,d,N),p(d,t),p(t,e),g(k,b,N),g(k,h,N),p(h,E),p(E,w)},d(k){k&&r(a),k&&r(l),k&&r(d),k&&r(b),k&&r(h)}}}function ka(_){let a,o=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ia(_){let a,o=`<div className="$$avatar">
  <div className="w-24 $$mask $$mask-squircle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 $$mask $$mask-hexagon">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div className="$$avatar">
  <div className="w-24 $$mask $$mask-triangle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function ja(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A,k,N,I,S,D,$;return{c(){a=n("div"),o=n("div"),s=n("div"),i=n("img"),d=V(),t=n("div"),e=n("div"),j=n("img"),h=V(),E=n("div"),w=n("div"),A=n("img"),N=V(),I=n("div"),S=n("div"),D=n("img"),this.h()},l(c){a=u(c,"DIV",{class:!0});var f=m(a);o=u(f,"DIV",{class:!0});var q=m(o);s=u(q,"DIV",{class:!0});var K=m(s);i=u(K,"IMG",{src:!0,alt:!0}),K.forEach(r),q.forEach(r),d=x(f),t=u(f,"DIV",{class:!0});var O=m(t);e=u(O,"DIV",{class:!0});var J=m(e);j=u(J,"IMG",{src:!0,alt:!0}),J.forEach(r),O.forEach(r),h=x(f),E=u(f,"DIV",{class:!0});var X=m(E);w=u(X,"DIV",{class:!0});var z=m(w);A=u(z,"IMG",{src:!0,alt:!0}),z.forEach(r),X.forEach(r),N=x(f),I=u(f,"DIV",{class:!0});var B=m(I);S=u(B,"DIV",{class:!0});var H=m(S);D=u(H,"IMG",{src:!0,alt:!0}),H.forEach(r),B.forEach(r),f.forEach(r),this.h()},h(){M(i.src,l="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(i,"src",l),v(i,"alt","Tailwind-CSS-Avatar-component"),v(s,"class","w-12 bg-base-300"),v(o,"class","avatar"),M(j.src,b="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(j,"src",b),v(j,"alt","Tailwind-CSS-Avatar-component"),v(e,"class","w-12 bg-base-300"),v(t,"class","avatar"),M(A.src,k="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(A,"src",k),v(A,"alt","Tailwind-CSS-Avatar-component"),v(w,"class","w-12 bg-base-300"),v(E,"class","avatar"),M(D.src,$="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(D,"src",$),v(D,"alt","Tailwind-CSS-Avatar-component"),v(S,"class","w-12 bg-base-300"),v(I,"class","avatar"),v(a,"class","avatar-group -space-x-6")},m(c,f){g(c,a,f),p(a,o),p(o,s),p(s,i),p(a,d),p(a,t),p(t,e),p(e,j),p(a,h),p(a,E),p(E,w),p(w,A),p(a,N),p(a,I),p(I,S),p(S,D)},d(c){c&&r(a)}}}function Na(_){let a,o=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Sa(_){let a,o=`<div className="$$avatar-group -space-x-6">
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Aa(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A,k,N,I,S,D,$;return{c(){a=n("div"),o=n("div"),s=n("div"),i=n("img"),d=V(),t=n("div"),e=n("div"),j=n("img"),h=V(),E=n("div"),w=n("div"),A=n("img"),N=V(),I=n("div"),S=n("div"),D=n("span"),$=C("+99"),this.h()},l(c){a=u(c,"DIV",{class:!0});var f=m(a);o=u(f,"DIV",{class:!0});var q=m(o);s=u(q,"DIV",{class:!0});var K=m(s);i=u(K,"IMG",{src:!0,alt:!0}),K.forEach(r),q.forEach(r),d=x(f),t=u(f,"DIV",{class:!0});var O=m(t);e=u(O,"DIV",{class:!0});var J=m(e);j=u(J,"IMG",{src:!0,alt:!0}),J.forEach(r),O.forEach(r),h=x(f),E=u(f,"DIV",{class:!0});var X=m(E);w=u(X,"DIV",{class:!0});var z=m(w);A=u(z,"IMG",{src:!0,alt:!0}),z.forEach(r),X.forEach(r),N=x(f),I=u(f,"DIV",{class:!0});var B=m(I);S=u(B,"DIV",{class:!0});var H=m(S);D=u(H,"SPAN",{});var y=m(D);$=T(y,"+99"),y.forEach(r),H.forEach(r),B.forEach(r),f.forEach(r),this.h()},h(){M(i.src,l="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(i,"src",l),v(i,"alt","Tailwind-CSS-Avatar-component"),v(s,"class","w-12 bg-base-300"),v(o,"class","avatar"),M(j.src,b="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(j,"src",b),v(j,"alt","Tailwind-CSS-Avatar-component"),v(e,"class","w-12 bg-base-300"),v(t,"class","avatar"),M(A.src,k="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(A,"src",k),v(A,"alt","Tailwind-CSS-Avatar-component"),v(w,"class","w-12 bg-base-300"),v(E,"class","avatar"),v(S,"class","w-12 bg-neutral-focus text-neutral-content"),v(I,"class","avatar placeholder"),v(a,"class","avatar-group -space-x-6")},m(c,f){g(c,a,f),p(a,o),p(o,s),p(s,i),p(a,d),p(a,t),p(t,e),p(e,j),p(a,h),p(a,E),p(E,w),p(w,A),p(a,N),p(a,I),p(I,S),p(S,D),p(D,$)},d(c){c&&r(a)}}}function Da(_){let a,o=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Va(_){let a,o=`<div className="$$avatar-group -space-x-6">
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar">
    <div className="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div className="$$avatar $$placeholder">
    <div className="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function xa(_){let a,o,s,i;return{c(){a=n("div"),o=n("div"),s=n("img"),this.h()},l(l){a=u(l,"DIV",{class:!0});var d=m(a);o=u(d,"DIV",{class:!0});var t=m(o);s=u(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"),v(a,"class","avatar")},m(l,d){g(l,a,d),p(a,o),p(o,s)},d(l){l&&r(a)}}}function Ca(_){let a,o=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ta(_){let a,o=`<div className="$$avatar">
  <div className="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ma(_){let a,o,s,i,l,d,t,e,j;return{c(){a=n("div"),o=n("div"),s=n("img"),l=V(),d=n("div"),t=n("div"),e=n("img"),this.h()},l(b){a=u(b,"DIV",{class:!0});var h=m(a);o=u(h,"DIV",{class:!0});var E=m(o);s=u(E,"IMG",{src:!0,alt:!0}),E.forEach(r),h.forEach(r),l=x(b),d=u(b,"DIV",{class:!0});var w=m(d);t=u(w,"DIV",{class:!0});var A=m(t);e=u(A,"IMG",{src:!0,alt:!0}),A.forEach(r),w.forEach(r),this.h()},h(){M(s.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(s,"src",i),v(s,"alt","Tailwind-CSS-Avatar-component"),v(o,"class","w-24 rounded-full bg-base-300"),v(a,"class","avatar online"),M(e.src,j="/images/stock/photo-1534528741775-53994a69daeb.jpg")||v(e,"src",j),v(e,"alt","Tailwind-CSS-Avatar-component"),v(t,"class","w-24 rounded-full bg-base-300"),v(d,"class","avatar offline")},m(b,h){g(b,a,h),p(a,o),p(o,s),g(b,l,h),g(b,d,h),p(d,t),p(t,e)},d(b){b&&r(a),b&&r(l),b&&r(d)}}}function Pa(_){let a,o=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ga(_){let a,o=`<div className="$$avatar $$online">
  <div className="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div className="$$avatar $$offline">
  <div className="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ra(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A,k,N,I,S,D;return{c(){a=n("div"),o=n("div"),s=n("span"),i=C("K"),l=V(),d=n("div"),t=n("div"),e=n("span"),j=C("JO"),b=V(),h=n("div"),E=n("div"),w=n("span"),A=C("MX"),k=V(),N=n("div"),I=n("div"),S=n("span"),D=C("AA"),this.h()},l($){a=u($,"DIV",{class:!0});var c=m(a);o=u(c,"DIV",{class:!0});var f=m(o);s=u(f,"SPAN",{class:!0});var q=m(s);i=T(q,"K"),q.forEach(r),f.forEach(r),c.forEach(r),l=x($),d=u($,"DIV",{class:!0});var K=m(d);t=u(K,"DIV",{class:!0});var O=m(t);e=u(O,"SPAN",{class:!0});var J=m(e);j=T(J,"JO"),J.forEach(r),O.forEach(r),K.forEach(r),b=x($),h=u($,"DIV",{class:!0});var X=m(h);E=u(X,"DIV",{class:!0});var z=m(E);w=u(z,"SPAN",{});var B=m(w);A=T(B,"MX"),B.forEach(r),z.forEach(r),X.forEach(r),k=x($),N=u($,"DIV",{class:!0});var H=m(N);I=u(H,"DIV",{class:!0});var y=m(I);S=u(y,"SPAN",{class:!0});var ta=m(S);D=T(ta,"AA"),ta.forEach(r),y.forEach(r),H.forEach(r),this.h()},h(){v(s,"class","text-3xl"),v(o,"class","bg-neutral-focus text-neutral-content rounded-full w-24"),v(a,"class","avatar placeholder"),v(e,"class","text-xl"),v(t,"class","bg-neutral-focus text-neutral-content rounded-full w-16"),v(d,"class","avatar online placeholder"),v(E,"class","bg-neutral-focus text-neutral-content rounded-full w-12"),v(h,"class","avatar placeholder"),v(S,"class","text-xs"),v(I,"class","bg-neutral-focus text-neutral-content rounded-full w-8"),v(N,"class","avatar placeholder")},m($,c){g($,a,c),p(a,o),p(o,s),p(s,i),g($,l,c),g($,d,c),p(d,t),p(t,e),p(e,j),g($,b,c),g($,h,c),p(h,E),p(E,w),p(w,A),g($,k,c),g($,N,c),p(N,I),p(I,S),p(S,D)},d($){$&&r(a),$&&r(l),$&&r(d),$&&r(b),$&&r(h),$&&r(k),$&&r(N)}}}function qa(_){let a,o=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","html")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Ka(_){let a,o=`<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span className="text-3xl">K</span>
  </div>
</div> 
<div className="$$avatar $$online $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span className="text-xl">JO</span>
  </div>
</div> 
<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div className="$$avatar $$placeholder">
  <div className="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span className="text-xs">AA</span>
  </div>
</div>`,s,i,l,d;return{c(){a=n("pre"),s=C(o),this.h()},l(t){a=u(t,"PRE",{slot:!0});var e=m(a);s=T(e,o),e.forEach(r),this.h()},h(){v(a,"slot","react")},m(t,e){g(t,a,e),p(a,s),l||(d=P(i=R.call(null,a,{to:_[0]})),l=!0)},p(t,e){i&&G(i.update)&&e&1&&i.update.call(null,{to:t[0]})},d(t){t&&r(a),l=!1,d()}}}function Oa(_){let a,o,s,i,l,d,t,e,j,b,h,E,w,A,k,N,I,S,D,$;return a=new ua({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as offline indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),s=new Z({props:{title:"Avatar",$$slots:{react:[fa],html:[ma],default:[pa]},$$scope:{ctx:_}}}),l=new Z({props:{title:"Avatar in custom sizes",$$slots:{react:[ga],html:[_a],default:[$a]},$$scope:{ctx:_}}}),t=new Z({props:{title:"Avatar rounded",$$slots:{react:[wa],html:[ba],default:[ha]},$$scope:{ctx:_}}}),j=new Z({props:{title:"Avatar with mask",$$slots:{react:[Ia],html:[ka],default:[Ea]},$$scope:{ctx:_}}}),h=new Z({props:{title:"Avatar group",$$slots:{react:[Sa],html:[Na],default:[ja]},$$scope:{ctx:_}}}),w=new Z({props:{title:"Avatar group with counter",$$slots:{react:[Va],html:[Da],default:[Aa]},$$scope:{ctx:_}}}),k=new Z({props:{title:"Avatar with ring",$$slots:{react:[Ta],html:[Ca],default:[xa]},$$scope:{ctx:_}}}),I=new Z({props:{title:"Avatar with presence indicator",$$slots:{react:[Ga],html:[Pa],default:[Ma]},$$scope:{ctx:_}}}),D=new Z({props:{title:"Avatar placeholder",$$slots:{react:[Ka],html:[qa],default:[Ra]},$$scope:{ctx:_}}}),{c(){Q(a.$$.fragment),o=V(),Q(s.$$.fragment),i=V(),Q(l.$$.fragment),d=V(),Q(t.$$.fragment),e=V(),Q(j.$$.fragment),b=V(),Q(h.$$.fragment),E=V(),Q(w.$$.fragment),A=V(),Q(k.$$.fragment),N=V(),Q(I.$$.fragment),S=V(),Q(D.$$.fragment)},l(c){F(a.$$.fragment,c),o=x(c),F(s.$$.fragment,c),i=x(c),F(l.$$.fragment,c),d=x(c),F(t.$$.fragment,c),e=x(c),F(j.$$.fragment,c),b=x(c),F(h.$$.fragment,c),E=x(c),F(w.$$.fragment,c),A=x(c),F(k.$$.fragment,c),N=x(c),F(I.$$.fragment,c),S=x(c),F(D.$$.fragment,c)},m(c,f){L(a,c,f),g(c,o,f),L(s,c,f),g(c,i,f),L(l,c,f),g(c,d,f),L(t,c,f),g(c,e,f),L(j,c,f),g(c,b,f),L(h,c,f),g(c,E,f),L(w,c,f),g(c,A,f),L(k,c,f),g(c,N,f),L(I,c,f),g(c,S,f),L(D,c,f),$=!0},p(c,f){const q={};f&5&&(q.$$scope={dirty:f,ctx:c}),s.$set(q);const K={};f&5&&(K.$$scope={dirty:f,ctx:c}),l.$set(K);const O={};f&5&&(O.$$scope={dirty:f,ctx:c}),t.$set(O);const J={};f&5&&(J.$$scope={dirty:f,ctx:c}),j.$set(J);const X={};f&5&&(X.$$scope={dirty:f,ctx:c}),h.$set(X);const z={};f&5&&(z.$$scope={dirty:f,ctx:c}),w.$set(z);const B={};f&5&&(B.$$scope={dirty:f,ctx:c}),k.$set(B);const H={};f&5&&(H.$$scope={dirty:f,ctx:c}),I.$set(H);const y={};f&5&&(y.$$scope={dirty:f,ctx:c}),D.$set(y)},i(c){$||(U(a.$$.fragment,c),U(s.$$.fragment,c),U(l.$$.fragment,c),U(t.$$.fragment,c),U(j.$$.fragment,c),U(h.$$.fragment,c),U(w.$$.fragment,c),U(k.$$.fragment,c),U(I.$$.fragment,c),U(D.$$.fragment,c),$=!0)},o(c){W(a.$$.fragment,c),W(s.$$.fragment,c),W(l.$$.fragment,c),W(t.$$.fragment,c),W(j.$$.fragment,c),W(h.$$.fragment,c),W(w.$$.fragment,c),W(k.$$.fragment,c),W(I.$$.fragment,c),W(D.$$.fragment,c),$=!1},d(c){Y(a,c),c&&r(o),Y(s,c),c&&r(i),Y(l,c),c&&r(d),Y(t,c),c&&r(e),Y(j,c),c&&r(b),Y(h,c),c&&r(E),Y(w,c),c&&r(A),Y(k,c),c&&r(N),Y(I,c),c&&r(S),Y(D,c)}}}function Ja(_){let a,o;const s=[_[1],la];let i={$$slots:{default:[Oa]},$$scope:{ctx:_}};for(let l=0;l<s.length;l+=1)i=aa(i,s[l]);return a=new va({props:i}),{c(){Q(a.$$.fragment)},l(l){F(a.$$.fragment,l)},m(l,d){L(a,l,d),o=!0},p(l,[d]){const t=d&2?ca(s,[d&2&&ea(l[1]),d&0&&ea(la)]):{};d&5&&(t.$$scope={dirty:d,ctx:l}),a.$set(t)},i(l){o||(U(a.$$.fragment,l),o=!0)},o(l){W(a.$$.fragment,l),o=!1},d(l){Y(a,l)}}}const la={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0};function Xa(_,a,o){let s;return da(_,na,i=>o(0,s=i)),_.$$set=i=>{o(1,a=aa(aa({},a),sa(i)))},a=sa(a),[s,a]}class Za extends ia{constructor(a){super();ra(this,a,Xa,Ja,oa,{})}}export{Za as default,la as metadata};
