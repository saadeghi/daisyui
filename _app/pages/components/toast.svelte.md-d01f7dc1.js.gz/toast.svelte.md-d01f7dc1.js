import{S as ie,i as oe,s as ne,C as J,w as k,x as z,y as T,z as de,A as ae,q,o as x,B as j,K as ce,ag as le,k as R,m as C,g as b,d as o,e as c,t as S,c as v,a as f,h as A,b as E,F as n,a9 as F,W as K}from"../../chunks/vendor-c5cb7521.js";import{M as ve}from"../../chunks/_markdown-b55fa7fc.js";import{p as fe,C as ue,a as B,r as W}from"../../chunks/actions-1c40038a.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-f13053c6.js";import"../../chunks/index-6071c35a.js";import"../../chunks/SEO-69607f84.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-fb721027.js";function pe(g){let e,a,l,i,r,u;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New message arrived."),this.h()},l(s){e=v(s,"DIV",{class:!0});var t=f(e);a=v(t,"DIV",{class:!0});var p=f(a);l=v(p,"DIV",{class:!0});var $=f(l);i=v($,"DIV",{});var D=f(i);r=v(D,"SPAN",{});var h=f(r);u=A(h,"New message arrived."),h.forEach(o),D.forEach(o),$.forEach(o),p.forEach(o),t.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(a,"class","toast absolute"),E(e,"class","w-full h-64 relative")},m(s,t){b(s,e,t),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u)},d(s){s&&o(e)}}}function $e(g){let e,a=`<div class="$$toast">
  <div class="$$alert $$alert-info">
    <div>
      <span>New message arrived.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function he(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-top toast-start absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function _e(g){let e,a=`<div class="$$toast $$toast-top $$toast-start">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function me(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-top toast-center absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Ee(g){let e,a=`<div class="$$toast $$toast-top $$toast-center">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function ge(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-top toast-end absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function De(g){let e,a=`<div class="$$toast $$toast-top $$toast-end">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function Ie(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-start toast-middle absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Ve(g){let e,a=`<div class="$$toast $$toast-start $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function we(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-center toast-middle absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Ne(g){let e,a=`<div class="$$toast $$toast-center $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function Me(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-end toast-middle absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Pe(g){let e,a=`<div class="$$toast $$toast-end $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function ye(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-start absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function be(g){let e,a=`<div class="$$toast $$toast-start">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function Se(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-center absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Ae(g){let e,a=`<div class="$$toast $$toast-center">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function Re(g){let e,a,l,i,r,u,s,t,p,$,D;return{c(){e=c("div"),a=c("div"),l=c("div"),i=c("div"),r=c("span"),u=S("New mail arrived."),s=R(),t=c("div"),p=c("div"),$=c("span"),D=S("Message sent successfully."),this.h()},l(h){e=v(h,"DIV",{class:!0});var _=f(e);a=v(_,"DIV",{class:!0});var m=f(a);l=v(m,"DIV",{class:!0});var V=f(l);i=v(V,"DIV",{});var M=f(i);r=v(M,"SPAN",{});var w=f(r);u=A(w,"New mail arrived."),w.forEach(o),M.forEach(o),V.forEach(o),s=C(m),t=v(m,"DIV",{class:!0});var P=f(t);p=v(P,"DIV",{});var N=f(p);$=v(N,"SPAN",{});var y=f($);D=A(y,"Message sent successfully."),y.forEach(o),N.forEach(o),P.forEach(o),m.forEach(o),_.forEach(o),this.h()},h(){E(l,"class","alert alert-info"),E(t,"class","alert alert-success"),E(a,"class","toast toast-end absolute"),E(e,"class","w-full h-64 relative")},m(h,_){b(h,e,_),n(e,a),n(a,l),n(l,i),n(i,r),n(r,u),n(a,s),n(a,t),n(t,p),n(p,$),n($,D)},d(h){h&&o(e)}}}function Ce(g){let e,a=`<div class="$$toast $$toast-end">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,i,r,u;return{c(){e=c("pre"),l=S(a),this.h()},l(s){e=v(s,"PRE",{slot:!0});var t=f(e);l=A(t,a),t.forEach(o),this.h()},h(){E(e,"slot","html")},m(s,t){b(s,e,t),n(e,l),r||(u=F(i=W.call(null,e,{to:g[0]})),r=!0)},p(s,t){i&&K(i.update)&&t&1&&i.update.call(null,{to:s[0]})},d(s){s&&o(e),r=!1,u()}}}function ke(g){let e,a,l,i,r,u,s,t,p,$,D,h,_,m,V,M,w,P,N,y,G,H;return e=new ue({props:{data:[{type:"component",class:"toast",desc:"Container element that sticks to the corner of page"},{type:"responsive",class:"toast-start",desc:"align horizontally to the left"},{type:"responsive",class:"toast-center",desc:"align horizontally to the center"},{type:"responsive",class:"toast-end",desc:"align horizontally to the right (default)"},{type:"responsive",class:"toast-top",desc:"align vertically to top"},{type:"responsive",class:"toast-middle",desc:"align vertically to middle"},{type:"responsive",class:"toast-bottom",desc:"align vertically to bottom (default)"}]}}),l=new B({props:{title:"toast with alert inside",$$slots:{html:[$e],default:[pe]},$$scope:{ctx:g}}}),r=new B({props:{title:"toast-top toast-start",$$slots:{html:[_e],default:[he]},$$scope:{ctx:g}}}),s=new B({props:{title:"toast-top toast-center",$$slots:{html:[Ee],default:[me]},$$scope:{ctx:g}}}),p=new B({props:{title:"toast-top toast-end",$$slots:{html:[De],default:[ge]},$$scope:{ctx:g}}}),D=new B({props:{title:"toast-start toast-middle",$$slots:{html:[Ve],default:[Ie]},$$scope:{ctx:g}}}),_=new B({props:{title:"toast-center toast-middle",$$slots:{html:[Ne],default:[we]},$$scope:{ctx:g}}}),V=new B({props:{title:"toast-end toast-middle",$$slots:{html:[Pe],default:[Me]},$$scope:{ctx:g}}}),w=new B({props:{title:"toast-start toast-bottom (default)",$$slots:{html:[be],default:[ye]},$$scope:{ctx:g}}}),N=new B({props:{title:"toast-center toast-bottom (default)",$$slots:{html:[Ae],default:[Se]},$$scope:{ctx:g}}}),G=new B({props:{title:"toast-end (default) toast-bottom (default)",$$slots:{html:[Ce],default:[Re]},$$scope:{ctx:g}}}),{c(){k(e.$$.fragment),a=R(),k(l.$$.fragment),i=R(),k(r.$$.fragment),u=R(),k(s.$$.fragment),t=R(),k(p.$$.fragment),$=R(),k(D.$$.fragment),h=R(),k(_.$$.fragment),m=R(),k(V.$$.fragment),M=R(),k(w.$$.fragment),P=R(),k(N.$$.fragment),y=R(),k(G.$$.fragment)},l(d){z(e.$$.fragment,d),a=C(d),z(l.$$.fragment,d),i=C(d),z(r.$$.fragment,d),u=C(d),z(s.$$.fragment,d),t=C(d),z(p.$$.fragment,d),$=C(d),z(D.$$.fragment,d),h=C(d),z(_.$$.fragment,d),m=C(d),z(V.$$.fragment,d),M=C(d),z(w.$$.fragment,d),P=C(d),z(N.$$.fragment,d),y=C(d),z(G.$$.fragment,d)},m(d,I){T(e,d,I),b(d,a,I),T(l,d,I),b(d,i,I),T(r,d,I),b(d,u,I),T(s,d,I),b(d,t,I),T(p,d,I),b(d,$,I),T(D,d,I),b(d,h,I),T(_,d,I),b(d,m,I),T(V,d,I),b(d,M,I),T(w,d,I),b(d,P,I),T(N,d,I),b(d,y,I),T(G,d,I),H=!0},p(d,I){const L={};I&5&&(L.$$scope={dirty:I,ctx:d}),l.$set(L);const O={};I&5&&(O.$$scope={dirty:I,ctx:d}),r.$set(O);const Q={};I&5&&(Q.$$scope={dirty:I,ctx:d}),s.$set(Q);const U={};I&5&&(U.$$scope={dirty:I,ctx:d}),p.$set(U);const X={};I&5&&(X.$$scope={dirty:I,ctx:d}),D.$set(X);const Y={};I&5&&(Y.$$scope={dirty:I,ctx:d}),_.$set(Y);const Z={};I&5&&(Z.$$scope={dirty:I,ctx:d}),V.$set(Z);const ee={};I&5&&(ee.$$scope={dirty:I,ctx:d}),w.$set(ee);const te={};I&5&&(te.$$scope={dirty:I,ctx:d}),N.$set(te);const se={};I&5&&(se.$$scope={dirty:I,ctx:d}),G.$set(se)},i(d){H||(q(e.$$.fragment,d),q(l.$$.fragment,d),q(r.$$.fragment,d),q(s.$$.fragment,d),q(p.$$.fragment,d),q(D.$$.fragment,d),q(_.$$.fragment,d),q(V.$$.fragment,d),q(w.$$.fragment,d),q(N.$$.fragment,d),q(G.$$.fragment,d),H=!0)},o(d){x(e.$$.fragment,d),x(l.$$.fragment,d),x(r.$$.fragment,d),x(s.$$.fragment,d),x(p.$$.fragment,d),x(D.$$.fragment,d),x(_.$$.fragment,d),x(V.$$.fragment,d),x(w.$$.fragment,d),x(N.$$.fragment,d),x(G.$$.fragment,d),H=!1},d(d){j(e,d),d&&o(a),j(l,d),d&&o(i),j(r,d),d&&o(u),j(s,d),d&&o(t),j(p,d),d&&o($),j(D,d),d&&o(h),j(_,d),d&&o(m),j(V,d),d&&o(M),j(w,d),d&&o(P),j(N,d),d&&o(y),j(G,d)}}}function ze(g){let e,a;const l=[g[1],re];let i={$$slots:{default:[ke]},$$scope:{ctx:g}};for(let r=0;r<l.length;r+=1)i=J(i,l[r]);return e=new ve({props:i}),{c(){k(e.$$.fragment)},l(r){z(e.$$.fragment,r)},m(r,u){T(e,r,u),a=!0},p(r,[u]){const s=u&2?de(l,[u&2&&ae(r[1]),u&0&&ae(re)]):{};u&5&&(s.$$scope={dirty:u,ctx:r}),e.$set(s)},i(r){a||(q(e.$$.fragment,r),a=!0)},o(r){x(e.$$.fragment,r),a=!1},d(r){j(e,r)}}}const re={title:"Toast",desc:"Toast is a wrapper to stack elements, positioned on the corner of page.",published:!1};function Te(g,e,a){let l;return ce(g,fe,i=>a(0,l=i)),g.$$set=i=>{a(1,e=J(J({},e),le(i)))},e=le(e),[l,e]}class Je extends ie{constructor(e){super();oe(this,e,Te,ze,ne,{})}}export{Je as default,re as metadata};
