import{S as Me,i as ze,s as xe,w as Z,k as I,x as ee,m as b,y as se,g as N,q as ae,o as te,B as le,d as m,J as Te,e as t,c as l,a as n,N as V,b as s,H as a,t as Q,h as U,a0 as re,P as ce}from"../../chunks/vendor-3cc82a89.js";import{C as ke,a as ie,r as me,p as Fe}from"../../chunks/actions-5947a762.js";import"../../chunks/preload-helper-ec9aa979.js";function Pe(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Burger"),s(o,"class","carousel-item"),V(i.src,p="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB")||s(i,"src",p),s(i,"alt","Burger"),s(d,"class","carousel-item"),V($.src,q="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6")||s($,"src",q),s($,"alt","Burger"),s(D,"class","carousel-item"),V(w.src,H="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693")||s(w,"src",H),s(w,"alt","Burger"),s(E,"class","carousel-item"),V(_.src,j="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7")||s(_,"src",j),s(_,"alt","Burger"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Burger"),s(h,"class","carousel-item"),V(B.src,T="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A")||s(B,"src",T),s(B,"alt","Burger"),s(S,"class","carousel-item"),s(e,"class","carousel rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function ye(F){let e,o=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094" alt="Burger">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A" alt="Burger">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function je(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Pizza"),s(o,"class","carousel-item"),V(i.src,p="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB")||s(i,"src",p),s(i,"alt","Pizza"),s(d,"class","carousel-item"),V($.src,q="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6")||s($,"src",q),s($,"alt","Pizza"),s(D,"class","carousel-item"),V(w.src,H="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693")||s(w,"src",H),s(w,"alt","Pizza"),s(E,"class","carousel-item"),V(_.src,j="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7")||s(_,"src",j),s(_,"alt","Pizza"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Pizza"),s(h,"class","carousel-item"),V(B.src,T="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A")||s(B,"src",T),s(B,"alt","Pizza"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-center rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Re(F){let e,o=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094" alt="Pizza">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A" alt="Pizza">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function qe(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Drink"),s(o,"class","carousel-item"),V(i.src,p="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB")||s(i,"src",p),s(i,"alt","Drink"),s(d,"class","carousel-item"),V($.src,q="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6")||s($,"src",q),s($,"alt","Drink"),s(D,"class","carousel-item"),V(w.src,H="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693")||s(w,"src",H),s(w,"alt","Drink"),s(E,"class","carousel-item"),V(_.src,j="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7")||s(_,"src",j),s(_,"alt","Drink"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Drink"),s(h,"class","carousel-item"),V(B.src,T="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A")||s(B,"src",T),s(B,"alt","Drink"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-end rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function He(F){let e,o=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094" alt="Drink">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A" alt="Drink">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Je(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS carousel component"),s(o,"class","w-full carousel-item"),V(i.src,p="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(i,"src",p),s(i,"class","w-full"),s(i,"alt","Tailwind CSS carousel component"),s(d,"class","w-full carousel-item"),V($.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s($,"src",q),s($,"class","w-full"),s($,"alt","Tailwind CSS carousel component"),s(D,"class","w-full carousel-item"),V(w.src,H="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",H),s(w,"class","w-full"),s(w,"alt","Tailwind CSS carousel component"),s(E,"class","w-full carousel-item"),V(_.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s(_,"src",j),s(_,"class","w-full"),s(_,"alt","Tailwind CSS carousel component"),s(g,"class","w-full carousel-item"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"class","w-full"),s(C,"alt","Tailwind CSS carousel component"),s(h,"class","w-full carousel-item"),V(B.src,T="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",T),s(B,"class","w-full"),s(B,"alt","Tailwind CSS carousel component"),s(S,"class","w-full carousel-item"),s(e,"class","w-64 carousel rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Ne(F){let e,o=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full" alt="Tailwind CSS Carousel component">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Ke(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Tailwind Image slider"),s(o,"class","carousel-item h-full"),V(i.src,p="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(i,"src",p),s(i,"alt","Tailwind Image slider"),s(d,"class","carousel-item h-full"),V($.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s($,"src",q),s($,"alt","Tailwind Image slider"),s(D,"class","carousel-item h-full"),V(w.src,H="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",H),s(w,"alt","Tailwind Image slider"),s(E,"class","carousel-item h-full"),V(_.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s(_,"src",j),s(_,"alt","Tailwind Image slider"),s(g,"class","carousel-item h-full"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"alt","Tailwind Image slider"),s(h,"class","carousel-item h-full"),V(B.src,T="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",T),s(B,"alt","Tailwind Image slider"),s(S,"class","carousel-item h-full"),s(e,"class","h-96 carousel carousel-vertical rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Le(F){let e,o=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094">
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Oe(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS Image slider"),s(o,"class","w-1/2 carousel-item"),V(i.src,p="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(i,"src",p),s(i,"class","w-full"),s(i,"alt","Tailwind CSS Image slider"),s(d,"class","w-1/2 carousel-item"),V($.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s($,"src",q),s($,"class","w-full"),s($,"alt","Tailwind CSS Image slider"),s(D,"class","w-1/2 carousel-item"),V(w.src,H="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",H),s(w,"class","w-full"),s(w,"alt","Tailwind CSS Image slider"),s(E,"class","w-1/2 carousel-item"),V(_.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s(_,"src",j),s(_,"class","w-full"),s(_,"alt","Tailwind CSS Image slider"),s(g,"class","w-1/2 carousel-item"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"class","w-full"),s(C,"alt","Tailwind CSS Image slider"),s(h,"class","w-1/2 carousel-item"),V(B.src,T="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",T),s(B,"class","w-full"),s(B,"alt","Tailwind CSS Image slider"),s(S,"class","w-1/2 carousel-item"),s(e,"class","w-96 carousel rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Qe(F){let e,o=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full">
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Ue(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("img"),c=I(),h=t("div"),C=t("img"),z=I(),S=t("div"),B=t("img"),this.h()},l(A){e=l(A,"DIV",{class:!0});var r=n(e);o=l(r,"DIV",{class:!0});var k=n(o);u=l(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),v=b(r),d=l(r,"DIV",{class:!0});var J=n(d);i=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),x=b(r),D=l(r,"DIV",{class:!0});var K=n(D);$=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(m),G=b(r),E=l(r,"DIV",{class:!0});var L=n(E);w=l(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var R=n(g);_=l(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(r),h=l(r,"DIV",{class:!0});var y=n(h);C=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),z=b(r),S=l(r,"DIV",{class:!0});var O=n(S);B=l(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),r.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","rounded-box"),s(u,"alt","Tailwind CSS component"),s(o,"class","carousel-item"),V(i.src,p="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB")||s(i,"src",p),s(i,"class","rounded-box"),s(i,"alt","Tailwind CSS component"),s(d,"class","carousel-item"),V($.src,q="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6")||s($,"src",q),s($,"class","rounded-box"),s($,"alt","Tailwind CSS component"),s(D,"class","carousel-item"),V(w.src,H="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693")||s(w,"src",H),s(w,"class","rounded-box"),s(w,"alt","Tailwind CSS component"),s(E,"class","carousel-item"),V(_.src,j="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7")||s(_,"src",j),s(_,"class","rounded-box"),s(_,"alt","Tailwind CSS component"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094")||s(C,"src",P),s(C,"class","rounded-box"),s(C,"alt","Tailwind CSS component"),s(h,"class","carousel-item"),V(B.src,T="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A")||s(B,"src",T),s(B,"class","rounded-box"),s(B,"alt","Tailwind CSS component"),s(S,"class","carousel-item"),s(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(A,r){N(A,e,r),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),a(e,M),a(e,g),a(g,_),a(e,c),a(e,h),a(h,C),a(e,z),a(e,S),a(S,B)},d(A){A&&m(e)}}}function We(F){let e,o=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094" class="rounded-box">
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A" class="rounded-box">
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Xe(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T,A;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("img"),x=I(),D=t("div"),$=t("img"),G=I(),E=t("div"),w=t("img"),M=I(),g=t("div"),_=t("a"),j=Q("1"),c=I(),h=t("a"),C=Q("2"),P=I(),z=t("a"),S=Q("3"),B=I(),T=t("a"),A=Q("4"),this.h()},l(r){e=l(r,"DIV",{class:!0});var k=n(e);o=l(k,"DIV",{id:!0,class:!0});var J=n(o);u=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),v=b(k),d=l(k,"DIV",{id:!0,class:!0});var K=n(d);i=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(m),x=b(k),D=l(k,"DIV",{id:!0,class:!0});var L=n(D);$=l(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),G=b(k),E=l(k,"DIV",{id:!0,class:!0});var R=n(E);w=l(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),k.forEach(m),M=b(r),g=l(r,"DIV",{class:!0});var y=n(g);_=l(y,"A",{href:!0,class:!0});var O=n(_);j=U(O,"1"),O.forEach(m),c=b(y),h=l(y,"A",{href:!0,class:!0});var oe=n(h);C=U(oe,"2"),oe.forEach(m),P=b(y),z=l(y,"A",{href:!0,class:!0});var W=n(z);S=U(W,"3"),W.forEach(m),B=b(y),T=l(y,"A",{href:!0,class:!0});var X=n(T);A=U(X,"4"),X.forEach(m),y.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image gallery"),s(o,"id","item1"),s(o,"class","w-full carousel-item"),V(i.src,p="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||s(i,"src",p),s(i,"class","w-full"),s(i,"alt","Tailwind CSS image gallery"),s(d,"id","item2"),s(d,"class","w-full carousel-item"),V($.src,q="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||s($,"src",q),s($,"class","w-full"),s($,"alt","Tailwind CSS image gallery"),s(D,"id","item3"),s(D,"class","w-full carousel-item"),V(w.src,H="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||s(w,"src",H),s(w,"class","w-full"),s(w,"alt","Tailwind CSS image gallery"),s(E,"id","item4"),s(E,"class","w-full carousel-item"),s(e,"class","w-full carousel"),s(_,"href","#item1"),s(_,"class","$$btn $$btn-xs"),s(h,"href","#item2"),s(h,"class","$$btn $$btn-xs"),s(z,"href","#item3"),s(z,"class","$$btn $$btn-xs"),s(T,"href","#item4"),s(T,"class","$$btn $$btn-xs"),s(g,"class","flex justify-center w-full py-2 gap-2")},m(r,k){N(r,e,k),a(e,o),a(o,u),a(e,v),a(e,d),a(d,i),a(e,x),a(e,D),a(D,$),a(e,G),a(e,E),a(E,w),N(r,M,k),N(r,g,k),a(g,_),a(_,j),a(g,c),a(g,h),a(h,C),a(g,P),a(g,z),a(z,S),a(g,B),a(g,T),a(T,A)},d(r){r&&m(e),r&&m(M),r&&m(g)}}}function Ye(F){let e,o=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full">
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full">
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full">
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full">
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function Ze(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j,c,h,C,P,z,S,B,T,A,r,k,J,K,L,R,y,O,oe,W,X,we,De,ue,Ee;return{c(){e=t("div"),o=t("div"),u=t("img"),v=I(),d=t("div"),i=t("a"),p=Q("\u276E"),x=I(),D=t("a"),$=Q("\u276F"),q=I(),G=t("div"),E=t("img"),H=I(),M=t("div"),g=t("a"),_=Q("\u276E"),j=I(),c=t("a"),h=Q("\u276F"),C=I(),P=t("div"),z=t("img"),B=I(),T=t("div"),A=t("a"),r=Q("\u276E"),k=I(),J=t("a"),K=Q("\u276F"),L=I(),R=t("div"),y=t("img"),oe=I(),W=t("div"),X=t("a"),we=Q("\u276E"),De=I(),ue=t("a"),Ee=Q("\u276F"),this.h()},l(he){e=l(he,"DIV",{class:!0});var Y=n(e);o=l(Y,"DIV",{id:!0,class:!0});var de=n(o);u=l(de,"IMG",{src:!0,class:!0,alt:!0}),v=b(de),d=l(de,"DIV",{class:!0});var pe=n(d);i=l(pe,"A",{href:!0,class:!0});var Ie=n(i);p=U(Ie,"\u276E"),Ie.forEach(m),x=b(pe),D=l(pe,"A",{href:!0,class:!0});var be=n(D);$=U(be,"\u276F"),be.forEach(m),pe.forEach(m),de.forEach(m),q=b(Y),G=l(Y,"DIV",{id:!0,class:!0});var ne=n(G);E=l(ne,"IMG",{src:!0,class:!0,alt:!0}),H=b(ne),M=l(ne,"DIV",{class:!0});var ve=n(M);g=l(ve,"A",{href:!0,class:!0});var Ce=n(g);_=U(Ce,"\u276E"),Ce.forEach(m),j=b(ve),c=l(ve,"A",{href:!0,class:!0});var Be=n(c);h=U(Be,"\u276F"),Be.forEach(m),ve.forEach(m),ne.forEach(m),C=b(Y),P=l(Y,"DIV",{id:!0,class:!0});var fe=n(P);z=l(fe,"IMG",{src:!0,class:!0,alt:!0}),B=b(fe),T=l(fe,"DIV",{class:!0});var ge=n(T);A=l(ge,"A",{href:!0,class:!0});var Se=n(A);r=U(Se,"\u276E"),Se.forEach(m),k=b(ge),J=l(ge,"A",{href:!0,class:!0});var Ve=n(J);K=U(Ve,"\u276F"),Ve.forEach(m),ge.forEach(m),fe.forEach(m),L=b(Y),R=l(Y,"DIV",{id:!0,class:!0});var $e=n(R);y=l($e,"IMG",{src:!0,class:!0,alt:!0}),oe=b($e),W=l($e,"DIV",{class:!0});var _e=n(W);X=l(_e,"A",{href:!0,class:!0});var Ae=n(X);we=U(Ae,"\u276E"),Ae.forEach(m),De=b(_e),ue=l(_e,"A",{href:!0,class:!0});var Ge=n(ue);Ee=U(Ge,"\u276F"),Ge.forEach(m),_e.forEach(m),$e.forEach(m),Y.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image slide"),s(i,"href","#slide4"),s(i,"class","btn btn-circle"),s(D,"href","#slide2"),s(D,"class","btn btn-circle"),s(d,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(o,"id","slide1"),s(o,"class","relative w-full carousel-item"),V(E.src,w="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||s(E,"src",w),s(E,"class","w-full"),s(E,"alt","Tailwind CSS image slide"),s(g,"href","#slide1"),s(g,"class","btn btn-circle"),s(c,"href","#slide3"),s(c,"class","btn btn-circle"),s(M,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(G,"id","slide2"),s(G,"class","relative w-full carousel-item"),V(z.src,S="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||s(z,"src",S),s(z,"class","w-full"),s(z,"alt","Tailwind CSS image slide"),s(A,"href","#slide2"),s(A,"class","btn btn-circle"),s(J,"href","#slide4"),s(J,"class","btn btn-circle"),s(T,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(P,"id","slide3"),s(P,"class","relative w-full carousel-item"),V(y.src,O="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||s(y,"src",O),s(y,"class","w-full"),s(y,"alt","Tailwind CSS image slide"),s(X,"href","#slide3"),s(X,"class","btn btn-circle"),s(ue,"href","#slide1"),s(ue,"class","btn btn-circle"),s(W,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(R,"id","slide4"),s(R,"class","relative w-full carousel-item"),s(e,"class","w-full carousel")},m(he,Y){N(he,e,Y),a(e,o),a(o,u),a(o,v),a(o,d),a(d,i),a(i,p),a(d,x),a(d,D),a(D,$),a(e,q),a(e,G),a(G,E),a(G,H),a(G,M),a(M,g),a(g,_),a(M,j),a(M,c),a(c,h),a(e,C),a(e,P),a(P,z),a(P,B),a(P,T),a(T,A),a(A,r),a(T,k),a(T,J),a(J,K),a(e,L),a(e,R),a(R,y),a(R,oe),a(R,W),a(W,X),a(X,we),a(W,De),a(W,ue),a(ue,Ee)},d(he){he&&m(e)}}}function es(F){let e,o=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,u,f,v,d;return{c(){e=t("pre"),u=Q(o),this.h()},l(i){e=l(i,"PRE",{slot:!0});var p=n(e);u=U(p,o),p.forEach(m),this.h()},h(){s(e,"slot","html")},m(i,p){N(i,e,p),a(e,u),v||(d=re(f=me.call(null,e,{to:F[0]})),v=!0)},p(i,p){f&&ce(f.update)&&p&1&&f.update.call(null,{to:i[0]})},d(i){i&&m(e),v=!1,d()}}}function ss(F){let e,o,u,f,v,d,i,p,x,D,$,q,G,E,w,H,M,g,_,j;return e=new ke({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),u=new ie({props:{title:"Snap to start (default)",$$slots:{html:[ye],default:[Pe]},$$scope:{ctx:F}}}),v=new ie({props:{title:"Snap to center",$$slots:{html:[Re],default:[je]},$$scope:{ctx:F}}}),i=new ie({props:{title:"Snap to end",$$slots:{html:[He],default:[qe]},$$scope:{ctx:F}}}),x=new ie({props:{title:"Carousel with full width items",$$slots:{html:[Ne],default:[Je]},$$scope:{ctx:F}}}),$=new ie({props:{title:"Vertical carousel",$$slots:{html:[Le],default:[Ke]},$$scope:{ctx:F}}}),G=new ie({props:{title:"Carousel with half width items",$$slots:{html:[Qe],default:[Oe]},$$scope:{ctx:F}}}),w=new ie({props:{title:"Full-bleed carousel",$$slots:{html:[We],default:[Ue]},$$scope:{ctx:F}}}),M=new ie({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[Ye],default:[Xe]},$$scope:{ctx:F}}}),_=new ie({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[es],default:[Ze]},$$scope:{ctx:F}}}),{c(){Z(e.$$.fragment),o=I(),Z(u.$$.fragment),f=I(),Z(v.$$.fragment),d=I(),Z(i.$$.fragment),p=I(),Z(x.$$.fragment),D=I(),Z($.$$.fragment),q=I(),Z(G.$$.fragment),E=I(),Z(w.$$.fragment),H=I(),Z(M.$$.fragment),g=I(),Z(_.$$.fragment)},l(c){ee(e.$$.fragment,c),o=b(c),ee(u.$$.fragment,c),f=b(c),ee(v.$$.fragment,c),d=b(c),ee(i.$$.fragment,c),p=b(c),ee(x.$$.fragment,c),D=b(c),ee($.$$.fragment,c),q=b(c),ee(G.$$.fragment,c),E=b(c),ee(w.$$.fragment,c),H=b(c),ee(M.$$.fragment,c),g=b(c),ee(_.$$.fragment,c)},m(c,h){se(e,c,h),N(c,o,h),se(u,c,h),N(c,f,h),se(v,c,h),N(c,d,h),se(i,c,h),N(c,p,h),se(x,c,h),N(c,D,h),se($,c,h),N(c,q,h),se(G,c,h),N(c,E,h),se(w,c,h),N(c,H,h),se(M,c,h),N(c,g,h),se(_,c,h),j=!0},p(c,[h]){const C={};h&3&&(C.$$scope={dirty:h,ctx:c}),u.$set(C);const P={};h&3&&(P.$$scope={dirty:h,ctx:c}),v.$set(P);const z={};h&3&&(z.$$scope={dirty:h,ctx:c}),i.$set(z);const S={};h&3&&(S.$$scope={dirty:h,ctx:c}),x.$set(S);const B={};h&3&&(B.$$scope={dirty:h,ctx:c}),$.$set(B);const T={};h&3&&(T.$$scope={dirty:h,ctx:c}),G.$set(T);const A={};h&3&&(A.$$scope={dirty:h,ctx:c}),w.$set(A);const r={};h&3&&(r.$$scope={dirty:h,ctx:c}),M.$set(r);const k={};h&3&&(k.$$scope={dirty:h,ctx:c}),_.$set(k)},i(c){j||(ae(e.$$.fragment,c),ae(u.$$.fragment,c),ae(v.$$.fragment,c),ae(i.$$.fragment,c),ae(x.$$.fragment,c),ae($.$$.fragment,c),ae(G.$$.fragment,c),ae(w.$$.fragment,c),ae(M.$$.fragment,c),ae(_.$$.fragment,c),j=!0)},o(c){te(e.$$.fragment,c),te(u.$$.fragment,c),te(v.$$.fragment,c),te(i.$$.fragment,c),te(x.$$.fragment,c),te($.$$.fragment,c),te(G.$$.fragment,c),te(w.$$.fragment,c),te(M.$$.fragment,c),te(_.$$.fragment,c),j=!1},d(c){le(e,c),c&&m(o),le(u,c),c&&m(f),le(v,c),c&&m(d),le(i,c),c&&m(p),le(x,c),c&&m(D),le($,c),c&&m(q),le(G,c),c&&m(E),le(w,c),c&&m(H),le(M,c),c&&m(g),le(_,c)}}}const rs={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function as(F,e,o){let u;return Te(F,Fe,f=>o(0,u=f)),[u]}class cs extends Me{constructor(e){super();ze(this,e,as,ss,xe,{})}}export{cs as default,rs as metadata};
