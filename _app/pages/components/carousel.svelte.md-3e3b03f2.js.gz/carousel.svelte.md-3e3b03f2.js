import{S as ye,i as Be,s as Ae,C as Ee,w as X,x as Y,y as Z,z as je,A as ze,q as ee,o as te,B as le,K as Re,ag as Pe,k as E,m as D,g as W,d as m,e as a,c,a as f,O as C,b as t,F as l,t as N,h as Q,a9 as re,W as ie}from"../../chunks/vendor-c5cb7521.js";import{M as qe}from"../../chunks/_markdown-faa27caf.js";import{p as Fe,C as Ke,a as ce,r as me}from"../../chunks/actions-663bceda.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-cd3e4e08.js";import"../../chunks/index-144c9fbc.js";import"../../chunks/SEO-bf9550d7.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-0196a404.js";function Oe(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/400/300/arch")||t(o,"src",p),t(o,"alt","Burger"),t(u,"class","carousel-item"),C(s.src,h="https://placeimg.com/400/300/arch")||t(s,"src",h),t(s,"alt","Burger"),t(d,"class","carousel-item"),C(_.src,F="https://placeimg.com/400/300/arch")||t(_,"src",F),t(_,"alt","Burger"),t(I,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||t(w,"src",K),t(w,"alt","Burger"),t(b,"class","carousel-item"),C($.src,R="https://placeimg.com/400/300/arch")||t($,"src",R),t($,"alt","Burger"),t(g,"class","carousel-item"),C(S.src,A="https://placeimg.com/400/300/arch")||t(S,"src",A),t(S,"alt","Burger"),t(n,"class","carousel-item"),C(V.src,y="https://placeimg.com/400/300/arch")||t(V,"src",y),t(V,"alt","Burger"),t(M,"class","carousel-item"),t(e,"class","carousel rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function We(k){let e,u=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function He(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/400/300/arch")||t(o,"src",p),t(o,"alt","Pizza"),t(u,"class","carousel-item"),C(s.src,h="https://placeimg.com/400/300/arch")||t(s,"src",h),t(s,"alt","Pizza"),t(d,"class","carousel-item"),C(_.src,F="https://placeimg.com/400/300/arch")||t(_,"src",F),t(_,"alt","Pizza"),t(I,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||t(w,"src",K),t(w,"alt","Pizza"),t(b,"class","carousel-item"),C($.src,R="https://placeimg.com/400/300/arch")||t($,"src",R),t($,"alt","Pizza"),t(g,"class","carousel-item"),C(S.src,A="https://placeimg.com/400/300/arch")||t(S,"src",A),t(S,"alt","Pizza"),t(n,"class","carousel-item"),C(V.src,y="https://placeimg.com/400/300/arch")||t(V,"src",y),t(V,"alt","Pizza"),t(M,"class","carousel-item"),t(e,"class","carousel carousel-center rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function Je(k){let e,u=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function Le(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/400/300/arch")||t(o,"src",p),t(o,"alt","Drink"),t(u,"class","carousel-item"),C(s.src,h="https://placeimg.com/400/300/arch")||t(s,"src",h),t(s,"alt","Drink"),t(d,"class","carousel-item"),C(_.src,F="https://placeimg.com/400/300/arch")||t(_,"src",F),t(_,"alt","Drink"),t(I,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||t(w,"src",K),t(w,"alt","Drink"),t(b,"class","carousel-item"),C($.src,R="https://placeimg.com/400/300/arch")||t($,"src",R),t($,"alt","Drink"),t(g,"class","carousel-item"),C(S.src,A="https://placeimg.com/400/300/arch")||t(S,"src",A),t(S,"alt","Drink"),t(n,"class","carousel-item"),C(V.src,y="https://placeimg.com/400/300/arch")||t(V,"src",y),t(V,"alt","Drink"),t(M,"class","carousel-item"),t(e,"class","carousel carousel-end rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function Ne(k){let e,u=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function Qe(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,class:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/256/400/arch")||t(o,"src",p),t(o,"class","w-full"),t(o,"alt","Tailwind CSS carousel component"),t(u,"class","w-full carousel-item"),C(s.src,h="https://placeimg.com/256/400/arch")||t(s,"src",h),t(s,"class","w-full"),t(s,"alt","Tailwind CSS carousel component"),t(d,"class","w-full carousel-item"),C(_.src,F="https://placeimg.com/256/400/arch")||t(_,"src",F),t(_,"class","w-full"),t(_,"alt","Tailwind CSS carousel component"),t(I,"class","w-full carousel-item"),C(w.src,K="https://placeimg.com/256/400/arch")||t(w,"src",K),t(w,"class","w-full"),t(w,"alt","Tailwind CSS carousel component"),t(b,"class","w-full carousel-item"),C($.src,R="https://placeimg.com/256/400/arch")||t($,"src",R),t($,"class","w-full"),t($,"alt","Tailwind CSS carousel component"),t(g,"class","w-full carousel-item"),C(S.src,A="https://placeimg.com/256/400/arch")||t(S,"src",A),t(S,"class","w-full"),t(S,"alt","Tailwind CSS carousel component"),t(n,"class","w-full carousel-item"),C(V.src,y="https://placeimg.com/256/400/arch")||t(V,"src",y),t(V,"class","w-full"),t(V,"alt","Tailwind CSS carousel component"),t(M,"class","w-full carousel-item"),t(e,"class","w-64 carousel rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function Ue(k){let e,u=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function Xe(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/256/400/arch")||t(o,"src",p),t(o,"alt","Tailwind Image slider"),t(u,"class","carousel-item h-full"),C(s.src,h="https://placeimg.com/256/400/arch")||t(s,"src",h),t(s,"alt","Tailwind Image slider"),t(d,"class","carousel-item h-full"),C(_.src,F="https://placeimg.com/256/400/arch")||t(_,"src",F),t(_,"alt","Tailwind Image slider"),t(I,"class","carousel-item h-full"),C(w.src,K="https://placeimg.com/256/400/arch")||t(w,"src",K),t(w,"alt","Tailwind Image slider"),t(b,"class","carousel-item h-full"),C($.src,R="https://placeimg.com/256/400/arch")||t($,"src",R),t($,"alt","Tailwind Image slider"),t(g,"class","carousel-item h-full"),C(S.src,A="https://placeimg.com/256/400/arch")||t(S,"src",A),t(S,"alt","Tailwind Image slider"),t(n,"class","carousel-item h-full"),C(V.src,y="https://placeimg.com/256/400/arch")||t(V,"src",y),t(V,"alt","Tailwind Image slider"),t(M,"class","carousel-item h-full"),t(e,"class","h-96 carousel carousel-vertical rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function Ye(k){let e,u=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function Ze(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,class:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/256/400/arch")||t(o,"src",p),t(o,"class","w-full"),t(o,"alt","Tailwind CSS Image slider"),t(u,"class","w-1/2 carousel-item"),C(s.src,h="https://placeimg.com/256/400/arch")||t(s,"src",h),t(s,"class","w-full"),t(s,"alt","Tailwind CSS Image slider"),t(d,"class","w-1/2 carousel-item"),C(_.src,F="https://placeimg.com/256/400/arch")||t(_,"src",F),t(_,"class","w-full"),t(_,"alt","Tailwind CSS Image slider"),t(I,"class","w-1/2 carousel-item"),C(w.src,K="https://placeimg.com/256/400/arch")||t(w,"src",K),t(w,"class","w-full"),t(w,"alt","Tailwind CSS Image slider"),t(b,"class","w-1/2 carousel-item"),C($.src,R="https://placeimg.com/256/400/arch")||t($,"src",R),t($,"class","w-full"),t($,"alt","Tailwind CSS Image slider"),t(g,"class","w-1/2 carousel-item"),C(S.src,A="https://placeimg.com/256/400/arch")||t(S,"src",A),t(S,"class","w-full"),t(S,"alt","Tailwind CSS Image slider"),t(n,"class","w-1/2 carousel-item"),C(V.src,y="https://placeimg.com/256/400/arch")||t(V,"src",y),t(V,"class","w-full"),t(V,"alt","Tailwind CSS Image slider"),t(M,"class","w-1/2 carousel-item"),t(e,"class","w-96 carousel rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function et(k){let e,u=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function tt(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("img"),i=E(),n=a("div"),S=a("img"),z=E(),M=a("div"),V=a("img"),this.h()},l(G){e=c(G,"DIV",{class:!0});var r=f(e);u=c(r,"DIV",{class:!0});var B=f(u);o=c(B,"IMG",{src:!0,class:!0,alt:!0}),B.forEach(m),v=D(r),d=c(r,"DIV",{class:!0});var O=f(d);s=c(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=D(r),I=c(r,"DIV",{class:!0});var H=f(I);_=c(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),x=D(r),b=c(r,"DIV",{class:!0});var J=f(b);w=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var q=f(g);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),i=D(r),n=c(r,"DIV",{class:!0});var j=f(n);S=c(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=D(r),M=c(r,"DIV",{class:!0});var L=f(M);V=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),r.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/250/180/arch")||t(o,"src",p),t(o,"class","rounded-box"),t(o,"alt","Tailwind CSS component"),t(u,"class","carousel-item"),C(s.src,h="https://placeimg.com/250/180/arch")||t(s,"src",h),t(s,"class","rounded-box"),t(s,"alt","Tailwind CSS component"),t(d,"class","carousel-item"),C(_.src,F="https://placeimg.com/250/180/arch")||t(_,"src",F),t(_,"class","rounded-box"),t(_,"alt","Tailwind CSS component"),t(I,"class","carousel-item"),C(w.src,K="https://placeimg.com/250/180/arch")||t(w,"src",K),t(w,"class","rounded-box"),t(w,"alt","Tailwind CSS component"),t(b,"class","carousel-item"),C($.src,R="https://placeimg.com/250/180/arch")||t($,"src",R),t($,"class","rounded-box"),t($,"alt","Tailwind CSS component"),t(g,"class","carousel-item"),C(S.src,A="https://placeimg.com/250/180/arch")||t(S,"src",A),t(S,"class","rounded-box"),t(S,"alt","Tailwind CSS component"),t(n,"class","carousel-item"),C(V.src,y="https://placeimg.com/250/180/arch")||t(V,"src",y),t(V,"class","rounded-box"),t(V,"alt","Tailwind CSS component"),t(M,"class","carousel-item"),t(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(G,r){W(G,e,r),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),l(e,T),l(e,g),l(g,$),l(e,i),l(e,n),l(n,S),l(e,z),l(e,M),l(M,V)},d(G){G&&m(e)}}}function lt(k){let e,u=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function st(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y,G;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("img"),P=E(),I=a("div"),_=a("img"),x=E(),b=a("div"),w=a("img"),T=E(),g=a("div"),$=a("a"),R=N("1"),i=E(),n=a("a"),S=N("2"),A=E(),z=a("a"),M=N("3"),V=E(),y=a("a"),G=N("4"),this.h()},l(r){e=c(r,"DIV",{class:!0});var B=f(e);u=c(B,"DIV",{id:!0,class:!0});var O=f(u);o=c(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),v=D(B),d=c(B,"DIV",{id:!0,class:!0});var H=f(d);s=c(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),P=D(B),I=c(B,"DIV",{id:!0,class:!0});var J=f(I);_=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),x=D(B),b=c(B,"DIV",{id:!0,class:!0});var q=f(b);w=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),B.forEach(m),T=D(r),g=c(r,"DIV",{class:!0});var j=f(g);$=c(j,"A",{href:!0,class:!0});var L=f($);R=Q(L,"1"),L.forEach(m),i=D(j),n=c(j,"A",{href:!0,class:!0});var ue=f(n);S=Q(ue,"2"),ue.forEach(m),A=D(j),z=c(j,"A",{href:!0,class:!0});var U=f(z);M=Q(U,"3"),U.forEach(m),V=D(j),y=c(j,"A",{href:!0,class:!0});var se=f(y);G=Q(se,"4"),se.forEach(m),j.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/800/200/arch")||t(o,"src",p),t(o,"class","w-full"),t(o,"alt","Tailwind CSS image gallery"),t(u,"id","item1"),t(u,"class","w-full carousel-item"),C(s.src,h="https://placeimg.com/800/200/arch")||t(s,"src",h),t(s,"class","w-full"),t(s,"alt","Tailwind CSS image gallery"),t(d,"id","item2"),t(d,"class","w-full carousel-item"),C(_.src,F="https://placeimg.com/800/200/arch")||t(_,"src",F),t(_,"class","w-full"),t(_,"alt","Tailwind CSS image gallery"),t(I,"id","item3"),t(I,"class","w-full carousel-item"),C(w.src,K="https://placeimg.com/800/200/arch")||t(w,"src",K),t(w,"class","w-full"),t(w,"alt","Tailwind CSS image gallery"),t(b,"id","item4"),t(b,"class","w-full carousel-item"),t(e,"class","w-full carousel"),t($,"href","#item1"),t($,"class","btn btn-xs"),t(n,"href","#item2"),t(n,"class","btn btn-xs"),t(z,"href","#item3"),t(z,"class","btn btn-xs"),t(y,"href","#item4"),t(y,"class","btn btn-xs"),t(g,"class","flex justify-center w-full py-2 gap-2")},m(r,B){W(r,e,B),l(e,u),l(u,o),l(e,v),l(e,d),l(d,s),l(e,P),l(e,I),l(I,_),l(e,x),l(e,b),l(b,w),W(r,T,B),W(r,g,B),l(g,$),l($,R),l(g,i),l(g,n),l(n,S),l(g,A),l(g,z),l(z,M),l(g,V),l(g,y),l(y,G)},d(r){r&&m(e),r&&m(T),r&&m(g)}}}function at(k){let e,u=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function ct(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R,i,n,S,A,z,M,V,y,G,r,B,O,H,J,q,j,L,ue,U,se,we,Ie,oe,be;return{c(){e=a("div"),u=a("div"),o=a("img"),v=E(),d=a("div"),s=a("a"),h=N("\u276E"),P=E(),I=a("a"),_=N("\u276F"),F=E(),x=a("div"),b=a("img"),K=E(),T=a("div"),g=a("a"),$=N("\u276E"),R=E(),i=a("a"),n=N("\u276F"),S=E(),A=a("div"),z=a("img"),V=E(),y=a("div"),G=a("a"),r=N("\u276E"),B=E(),O=a("a"),H=N("\u276F"),J=E(),q=a("div"),j=a("img"),ue=E(),U=a("div"),se=a("a"),we=N("\u276E"),Ie=E(),oe=a("a"),be=N("\u276F"),this.h()},l(de){e=c(de,"DIV",{class:!0});var ae=f(e);u=c(ae,"DIV",{id:!0,class:!0});var ne=f(u);o=c(ne,"IMG",{src:!0,class:!0,alt:!0}),v=D(ne),d=c(ne,"DIV",{class:!0});var ve=f(d);s=c(ve,"A",{href:!0,class:!0});var De=f(s);h=Q(De,"\u276E"),De.forEach(m),P=D(ve),I=c(ve,"A",{href:!0,class:!0});var Se=f(I);_=Q(Se,"\u276F"),Se.forEach(m),ve.forEach(m),ne.forEach(m),F=D(ae),x=c(ae,"DIV",{id:!0,class:!0});var he=f(x);b=c(he,"IMG",{src:!0,class:!0,alt:!0}),K=D(he),T=c(he,"DIV",{class:!0});var fe=f(T);g=c(fe,"A",{href:!0,class:!0});var Ve=f(g);$=Q(Ve,"\u276E"),Ve.forEach(m),R=D(fe),i=c(fe,"A",{href:!0,class:!0});var Me=f(i);n=Q(Me,"\u276F"),Me.forEach(m),fe.forEach(m),he.forEach(m),S=D(ae),A=c(ae,"DIV",{id:!0,class:!0});var pe=f(A);z=c(pe,"IMG",{src:!0,class:!0,alt:!0}),V=D(pe),y=c(pe,"DIV",{class:!0});var ge=f(y);G=c(ge,"A",{href:!0,class:!0});var Ce=f(G);r=Q(Ce,"\u276E"),Ce.forEach(m),B=D(ge),O=c(ge,"A",{href:!0,class:!0});var Ge=f(O);H=Q(Ge,"\u276F"),Ge.forEach(m),ge.forEach(m),pe.forEach(m),J=D(ae),q=c(ae,"DIV",{id:!0,class:!0});var _e=f(q);j=c(_e,"IMG",{src:!0,class:!0,alt:!0}),ue=D(_e),U=c(_e,"DIV",{class:!0});var $e=f(U);se=c($e,"A",{href:!0,class:!0});var xe=f(se);we=Q(xe,"\u276E"),xe.forEach(m),Ie=D($e),oe=c($e,"A",{href:!0,class:!0});var Te=f(oe);be=Q(Te,"\u276F"),Te.forEach(m),$e.forEach(m),_e.forEach(m),ae.forEach(m),this.h()},h(){C(o.src,p="https://placeimg.com/800/200/arch")||t(o,"src",p),t(o,"class","w-full"),t(o,"alt","Tailwind CSS image slide"),t(s,"href","#slide4"),t(s,"class","btn btn-circle"),t(I,"href","#slide2"),t(I,"class","btn btn-circle"),t(d,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),t(u,"id","slide1"),t(u,"class","relative w-full carousel-item"),C(b.src,w="https://placeimg.com/800/200/arch")||t(b,"src",w),t(b,"class","w-full"),t(b,"alt","Tailwind CSS image slide"),t(g,"href","#slide1"),t(g,"class","btn btn-circle"),t(i,"href","#slide3"),t(i,"class","btn btn-circle"),t(T,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),t(x,"id","slide2"),t(x,"class","relative w-full carousel-item"),C(z.src,M="https://placeimg.com/800/200/arch")||t(z,"src",M),t(z,"class","w-full"),t(z,"alt","Tailwind CSS image slide"),t(G,"href","#slide2"),t(G,"class","btn btn-circle"),t(O,"href","#slide4"),t(O,"class","btn btn-circle"),t(y,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),t(A,"id","slide3"),t(A,"class","relative w-full carousel-item"),C(j.src,L="https://placeimg.com/800/200/arch")||t(j,"src",L),t(j,"class","w-full"),t(j,"alt","Tailwind CSS image slide"),t(se,"href","#slide3"),t(se,"class","btn btn-circle"),t(oe,"href","#slide1"),t(oe,"class","btn btn-circle"),t(U,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),t(q,"id","slide4"),t(q,"class","relative w-full carousel-item"),t(e,"class","w-full carousel")},m(de,ae){W(de,e,ae),l(e,u),l(u,o),l(u,v),l(u,d),l(d,s),l(s,h),l(d,P),l(d,I),l(I,_),l(e,F),l(e,x),l(x,b),l(x,K),l(x,T),l(T,g),l(g,$),l(T,R),l(T,i),l(i,n),l(e,S),l(e,A),l(A,z),l(A,V),l(A,y),l(y,G),l(G,r),l(y,B),l(y,O),l(O,H),l(e,J),l(e,q),l(q,j),l(q,ue),l(q,U),l(U,se),l(se,we),l(U,Ie),l(U,oe),l(oe,be)},d(de){de&&m(e)}}}function rt(k){let e,u=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,o,p,v,d;return{c(){e=a("pre"),o=N(u),this.h()},l(s){e=c(s,"PRE",{slot:!0});var h=f(e);o=Q(h,u),h.forEach(m),this.h()},h(){t(e,"slot","html")},m(s,h){W(s,e,h),l(e,o),v||(d=re(p=me.call(null,e,{to:k[0]})),v=!0)},p(s,h){p&&ie(p.update)&&h&1&&p.update.call(null,{to:s[0]})},d(s){s&&m(e),v=!1,d()}}}function it(k){let e,u,o,p,v,d,s,h,P,I,_,F,x,b,w,K,T,g,$,R;return e=new Ke({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),o=new ce({props:{title:"Snap to start (default)",$$slots:{html:[We],default:[Oe]},$$scope:{ctx:k}}}),v=new ce({props:{title:"Snap to center",$$slots:{html:[Je],default:[He]},$$scope:{ctx:k}}}),s=new ce({props:{title:"Snap to end",$$slots:{html:[Ne],default:[Le]},$$scope:{ctx:k}}}),P=new ce({props:{title:"Carousel with full width items",$$slots:{html:[Ue],default:[Qe]},$$scope:{ctx:k}}}),_=new ce({props:{title:"Vertical carousel",$$slots:{html:[Ye],default:[Xe]},$$scope:{ctx:k}}}),x=new ce({props:{title:"Carousel with half width items",$$slots:{html:[et],default:[Ze]},$$scope:{ctx:k}}}),w=new ce({props:{title:"Full-bleed carousel",$$slots:{html:[lt],default:[tt]},$$scope:{ctx:k}}}),T=new ce({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[at],default:[st]},$$scope:{ctx:k}}}),$=new ce({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[rt],default:[ct]},$$scope:{ctx:k}}}),{c(){X(e.$$.fragment),u=E(),X(o.$$.fragment),p=E(),X(v.$$.fragment),d=E(),X(s.$$.fragment),h=E(),X(P.$$.fragment),I=E(),X(_.$$.fragment),F=E(),X(x.$$.fragment),b=E(),X(w.$$.fragment),K=E(),X(T.$$.fragment),g=E(),X($.$$.fragment)},l(i){Y(e.$$.fragment,i),u=D(i),Y(o.$$.fragment,i),p=D(i),Y(v.$$.fragment,i),d=D(i),Y(s.$$.fragment,i),h=D(i),Y(P.$$.fragment,i),I=D(i),Y(_.$$.fragment,i),F=D(i),Y(x.$$.fragment,i),b=D(i),Y(w.$$.fragment,i),K=D(i),Y(T.$$.fragment,i),g=D(i),Y($.$$.fragment,i)},m(i,n){Z(e,i,n),W(i,u,n),Z(o,i,n),W(i,p,n),Z(v,i,n),W(i,d,n),Z(s,i,n),W(i,h,n),Z(P,i,n),W(i,I,n),Z(_,i,n),W(i,F,n),Z(x,i,n),W(i,b,n),Z(w,i,n),W(i,K,n),Z(T,i,n),W(i,g,n),Z($,i,n),R=!0},p(i,n){const S={};n&5&&(S.$$scope={dirty:n,ctx:i}),o.$set(S);const A={};n&5&&(A.$$scope={dirty:n,ctx:i}),v.$set(A);const z={};n&5&&(z.$$scope={dirty:n,ctx:i}),s.$set(z);const M={};n&5&&(M.$$scope={dirty:n,ctx:i}),P.$set(M);const V={};n&5&&(V.$$scope={dirty:n,ctx:i}),_.$set(V);const y={};n&5&&(y.$$scope={dirty:n,ctx:i}),x.$set(y);const G={};n&5&&(G.$$scope={dirty:n,ctx:i}),w.$set(G);const r={};n&5&&(r.$$scope={dirty:n,ctx:i}),T.$set(r);const B={};n&5&&(B.$$scope={dirty:n,ctx:i}),$.$set(B)},i(i){R||(ee(e.$$.fragment,i),ee(o.$$.fragment,i),ee(v.$$.fragment,i),ee(s.$$.fragment,i),ee(P.$$.fragment,i),ee(_.$$.fragment,i),ee(x.$$.fragment,i),ee(w.$$.fragment,i),ee(T.$$.fragment,i),ee($.$$.fragment,i),R=!0)},o(i){te(e.$$.fragment,i),te(o.$$.fragment,i),te(v.$$.fragment,i),te(s.$$.fragment,i),te(P.$$.fragment,i),te(_.$$.fragment,i),te(x.$$.fragment,i),te(w.$$.fragment,i),te(T.$$.fragment,i),te($.$$.fragment,i),R=!1},d(i){le(e,i),i&&m(u),le(o,i),i&&m(p),le(v,i),i&&m(d),le(s,i),i&&m(h),le(P,i),i&&m(I),le(_,i),i&&m(F),le(x,i),i&&m(b),le(w,i),i&&m(K),le(T,i),i&&m(g),le($,i)}}}function mt(k){let e,u;const o=[k[1],ke];let p={$$slots:{default:[it]},$$scope:{ctx:k}};for(let v=0;v<o.length;v+=1)p=Ee(p,o[v]);return e=new qe({props:p}),{c(){X(e.$$.fragment)},l(v){Y(e.$$.fragment,v)},m(v,d){Z(e,v,d),u=!0},p(v,[d]){const s=d&2?je(o,[d&2&&ze(v[1]),d&0&&ze(ke)]):{};d&5&&(s.$$scope={dirty:d,ctx:v}),e.$set(s)},i(v){u||(ee(e.$$.fragment,v),u=!0)},o(v){te(e.$$.fragment,v),u=!1},d(v){le(e,v)}}}const ke={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function ot(k,e,u){let o;return Re(k,Fe,p=>u(0,o=p)),k.$$set=p=>{u(1,e=Ee(Ee({},e),Pe(p)))},e=Pe(e),[o,e]}class $t extends ye{constructor(e){super();Be(this,e,ot,mt,Ae,{})}}export{$t as default,ke as metadata};
