import{S as Ft,i as Tt,s as Kt,w as nt,k as p,x as ut,m as _,y as ht,g as Y,q as ft,o as mt,B as pt,d as a,e as r,t as h,c as v,a as l,h as f,b as e,H as t,K as wt,F as ct,G as ot,L as jt}from"../../chunks/vendor-6c3f1da5.js";import{C as Ut,a as _t}from"../../chunks/ClassTable-04fdfe88.js";import"../../chunks/preload-helper-ec9aa979.js";function Pt(O){let s,i,o,c,n,g,b,P,E,x;return{c(){s=r("div"),i=r("div"),o=r("div"),c=h("Total Page Views"),n=p(),g=r("div"),b=h("89,400"),P=p(),E=r("div"),x=h("21% more than last month"),this.h()},l(N){s=v(N,"DIV",{class:!0});var $=l(s);i=v($,"DIV",{class:!0});var m=l(i);o=v(m,"DIV",{class:!0});var T=l(o);c=f(T,"Total Page Views"),T.forEach(a),n=_(m),g=v(m,"DIV",{class:!0});var M=l(g);b=f(M,"89,400"),M.forEach(a),P=_(m),E=v(m,"DIV",{class:!0});var w=l(E);x=f(w,"21% more than last month"),w.forEach(a),m.forEach(a),$.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(g,"class","stat-value"),e(E,"class","stat-desc"),e(i,"class","stat"),e(s,"class","shadow stats")},m(N,$){Y(N,s,$),t(s,i),t(i,o),t(o,c),t(i,n),t(i,g),t(g,b),t(i,P),t(i,E),t(E,x)},d(N){N&&a(s)}}}function Jt(O){let s,i=`<div class="shadow stats">
  
  <div class="stat">
    <div class="stat-title">Total Page Views</div>
    <div class="stat-value">89,400</div>
    <div class="stat-desc">21% more than last month</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function zt(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C,K,J,A,L,y,j,D,k,q,G,H,U,W,tt,Z,S,st,Q,X;return{c(){s=r("div"),i=r("div"),o=r("div"),c=ct("svg"),n=ct("path"),g=p(),b=r("div"),P=h("Total Likes"),E=p(),x=r("div"),N=h("25.6K"),$=p(),m=r("div"),T=h("21% more than last month"),M=p(),w=r("div"),d=r("div"),u=ct("svg"),I=ct("path"),z=p(),R=r("div"),V=h("Page Views"),B=p(),F=r("div"),C=h("2.6M"),K=p(),J=r("div"),A=h("21% more than last month"),L=p(),y=r("div"),j=r("div"),D=r("div"),k=r("div"),q=r("img"),H=p(),U=r("div"),W=h("86%"),tt=p(),Z=r("div"),S=h("Tasks done"),st=p(),Q=r("div"),X=h("31 tasks remaining"),this.h()},l(et){s=v(et,"DIV",{class:!0});var at=l(s);i=v(at,"DIV",{class:!0});var lt=l(i);o=v(lt,"DIV",{class:!0});var $t=l(o);c=ot($t,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Et=l(c);n=ot(Et,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),l(n).forEach(a),Et.forEach(a),$t.forEach(a),g=_(lt),b=v(lt,"DIV",{class:!0});var gt=l(b);P=f(gt,"Total Likes"),gt.forEach(a),E=_(lt),x=v(lt,"DIV",{class:!0});var it=l(x);N=f(it,"25.6K"),it.forEach(a),$=_(lt),m=v(lt,"DIV",{class:!0});var Vt=l(m);T=f(Vt,"21% more than last month"),Vt.forEach(a),lt.forEach(a),M=_(at),w=v(at,"DIV",{class:!0});var dt=l(w);d=v(dt,"DIV",{class:!0});var Dt=l(d);u=ot(Dt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var It=l(u);I=ot(It,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),l(I).forEach(a),It.forEach(a),Dt.forEach(a),z=_(dt),R=v(dt,"DIV",{class:!0});var kt=l(R);V=f(kt,"Page Views"),kt.forEach(a),B=_(dt),F=v(dt,"DIV",{class:!0});var rt=l(F);C=f(rt,"2.6M"),rt.forEach(a),K=_(dt),J=v(dt,"DIV",{class:!0});var bt=l(J);A=f(bt,"21% more than last month"),bt.forEach(a),dt.forEach(a),L=_(at),y=v(at,"DIV",{class:!0});var vt=l(y);j=v(vt,"DIV",{class:!0});var xt=l(j);D=v(xt,"DIV",{class:!0});var yt=l(D);k=v(yt,"DIV",{class:!0});var Nt=l(k);q=v(Nt,"IMG",{src:!0}),Nt.forEach(a),yt.forEach(a),xt.forEach(a),H=_(vt),U=v(vt,"DIV",{class:!0});var Mt=l(U);W=f(Mt,"86%"),Mt.forEach(a),tt=_(vt),Z=v(vt,"DIV",{class:!0});var Rt=l(Z);S=f(Rt,"Tasks done"),Rt.forEach(a),st=_(vt),Q=v(vt,"DIV",{class:!0});var Bt=l(Q);X=f(Bt,"31 tasks remaining"),Bt.forEach(a),vt.forEach(a),at.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"),e(c,"xmlns","http://www.w3.org/2000/svg"),e(c,"fill","none"),e(c,"viewBox","0 0 24 24"),e(c,"class","inline-block w-8 h-8 stroke-current"),e(o,"class","stat-figure text-primary"),e(b,"class","stat-title"),e(x,"class","stat-value text-primary"),e(m,"class","stat-desc"),e(i,"class","stat"),e(I,"stroke-linecap","round"),e(I,"stroke-linejoin","round"),e(I,"stroke-width","2"),e(I,"d","M13 10V3L4 14h7v7l9-11h-7z"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(R,"class","stat-title"),e(F,"class","stat-value text-secondary"),e(J,"class","stat-desc"),e(w,"class","stat"),jt(q.src,G="https://api.lorem.space/image/face?w=128&h=128")||e(q,"src",G),e(k,"class","w-16 rounded-full"),e(D,"class","avatar online"),e(j,"class","stat-figure text-secondary"),e(U,"class","stat-value"),e(Z,"class","stat-title"),e(Q,"class","stat-desc text-secondary"),e(y,"class","stat"),e(s,"class","shadow stats")},m(et,at){Y(et,s,at),t(s,i),t(i,o),t(o,c),t(c,n),t(i,g),t(i,b),t(b,P),t(i,E),t(i,x),t(x,N),t(i,$),t(i,m),t(m,T),t(s,M),t(s,w),t(w,d),t(d,u),t(u,I),t(w,z),t(w,R),t(R,V),t(w,B),t(w,F),t(F,C),t(w,K),t(w,J),t(J,A),t(s,L),t(s,y),t(y,j),t(j,D),t(D,k),t(k,q),t(y,H),t(y,U),t(U,W),t(y,tt),t(y,Z),t(Z,S),t(y,st),t(y,Q),t(Q,X)},d(et){et&&a(s)}}}function Lt(O){let s,i=`<div class="shadow stats">
  
  <div class="stat">
    <div class="stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="stat-title">Total Likes</div>
    <div class="stat-value text-primary">25.6K</div>
    <div class="stat-desc">21% more than last month</div>
  </div>
  
  <div class="stat">
    <div class="stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="stat-title">Page Views</div>
    <div class="stat-value text-secondary">2.6M</div>
    <div class="stat-desc">21% more than last month</div>
  </div>
  
  <div class="stat">
    <div class="stat-figure text-secondary">
      <div class="avatar online">
        <div class="w-16 rounded-full">
          <img src="https://api.lorem.space/image/face?w=128&h=128">
        </div>
      </div>
    </div>
    <div class="stat-value">86%</div>
    <div class="stat-title">Tasks done</div>
    <div class="stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function St(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C,K,J,A,L,y,j,D,k,q,G,H,U,W,tt,Z,S,st;return{c(){s=r("div"),i=r("div"),o=r("div"),c=ct("svg"),n=ct("path"),g=p(),b=r("div"),P=h("Downloads"),E=p(),x=r("div"),N=h("31K"),$=p(),m=r("div"),T=h("Jan 1st - Feb 1st"),M=p(),w=r("div"),d=r("div"),u=ct("svg"),I=ct("path"),z=p(),R=r("div"),V=h("New Users"),B=p(),F=r("div"),C=h("4,200"),K=p(),J=r("div"),A=h("\u2197\uFE0E 400 (22%)"),L=p(),y=r("div"),j=r("div"),D=ct("svg"),k=ct("path"),q=p(),G=r("div"),H=h("New Registers"),U=p(),W=r("div"),tt=h("1,200"),Z=p(),S=r("div"),st=h("\u2198\uFE0E 90 (14%)"),this.h()},l(Q){s=v(Q,"DIV",{class:!0});var X=l(s);i=v(X,"DIV",{class:!0});var et=l(i);o=v(et,"DIV",{class:!0});var at=l(o);c=ot(at,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var lt=l(c);n=ot(lt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),l(n).forEach(a),lt.forEach(a),at.forEach(a),g=_(et),b=v(et,"DIV",{class:!0});var $t=l(b);P=f($t,"Downloads"),$t.forEach(a),E=_(et),x=v(et,"DIV",{class:!0});var Et=l(x);N=f(Et,"31K"),Et.forEach(a),$=_(et),m=v(et,"DIV",{class:!0});var gt=l(m);T=f(gt,"Jan 1st - Feb 1st"),gt.forEach(a),et.forEach(a),M=_(X),w=v(X,"DIV",{class:!0});var it=l(w);d=v(it,"DIV",{class:!0});var Vt=l(d);u=ot(Vt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var dt=l(u);I=ot(dt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),l(I).forEach(a),dt.forEach(a),Vt.forEach(a),z=_(it),R=v(it,"DIV",{class:!0});var Dt=l(R);V=f(Dt,"New Users"),Dt.forEach(a),B=_(it),F=v(it,"DIV",{class:!0});var It=l(F);C=f(It,"4,200"),It.forEach(a),K=_(it),J=v(it,"DIV",{class:!0});var kt=l(J);A=f(kt,"\u2197\uFE0E 400 (22%)"),kt.forEach(a),it.forEach(a),L=_(X),y=v(X,"DIV",{class:!0});var rt=l(y);j=v(rt,"DIV",{class:!0});var bt=l(j);D=ot(bt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var vt=l(D);k=ot(vt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),l(k).forEach(a),vt.forEach(a),bt.forEach(a),q=_(rt),G=v(rt,"DIV",{class:!0});var xt=l(G);H=f(xt,"New Registers"),xt.forEach(a),U=_(rt),W=v(rt,"DIV",{class:!0});var yt=l(W);tt=f(yt,"1,200"),yt.forEach(a),Z=_(rt),S=v(rt,"DIV",{class:!0});var Nt=l(S);st=f(Nt,"\u2198\uFE0E 90 (14%)"),Nt.forEach(a),rt.forEach(a),X.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),e(c,"xmlns","http://www.w3.org/2000/svg"),e(c,"fill","none"),e(c,"viewBox","0 0 24 24"),e(c,"class","inline-block w-8 h-8 stroke-current"),e(o,"class","stat-figure text-secondary"),e(b,"class","stat-title"),e(x,"class","stat-value"),e(m,"class","stat-desc"),e(i,"class","stat"),e(I,"stroke-linecap","round"),e(I,"stroke-linejoin","round"),e(I,"stroke-width","2"),e(I,"d","M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(R,"class","stat-title"),e(F,"class","stat-value"),e(J,"class","stat-desc"),e(w,"class","stat"),e(k,"stroke-linecap","round"),e(k,"stroke-linejoin","round"),e(k,"stroke-width","2"),e(k,"d","M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"),e(D,"xmlns","http://www.w3.org/2000/svg"),e(D,"fill","none"),e(D,"viewBox","0 0 24 24"),e(D,"class","inline-block w-8 h-8 stroke-current"),e(j,"class","stat-figure text-secondary"),e(G,"class","stat-title"),e(W,"class","stat-value"),e(S,"class","stat-desc"),e(y,"class","stat"),e(s,"class","shadow stats")},m(Q,X){Y(Q,s,X),t(s,i),t(i,o),t(o,c),t(c,n),t(i,g),t(i,b),t(b,P),t(i,E),t(i,x),t(x,N),t(i,$),t(i,m),t(m,T),t(s,M),t(s,w),t(w,d),t(d,u),t(u,I),t(w,z),t(w,R),t(R,V),t(w,B),t(w,F),t(F,C),t(w,K),t(w,J),t(J,A),t(s,L),t(s,y),t(y,j),t(j,D),t(D,k),t(y,q),t(y,G),t(G,H),t(y,U),t(y,W),t(W,tt),t(y,Z),t(y,S),t(S,st)},d(Q){Q&&a(s)}}}function Ct(O){let s,i=`<div class="shadow stats">
  
  <div class="stat">
    <div class="stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="stat-title">Downloads</div>
    <div class="stat-value">31K</div>
    <div class="stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="stat">
    <div class="stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="stat-title">New Users</div>
    <div class="stat-value">4,200</div>
    <div class="stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="stat">
    <div class="stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="stat-title">New Registers</div>
    <div class="stat-value">1,200</div>
    <div class="stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function At(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C,K,J,A,L,y;return{c(){s=r("div"),i=r("div"),o=r("div"),c=h("Downloads"),n=p(),g=r("div"),b=h("31K"),P=p(),E=r("div"),x=h("From January 1st to February 1st"),N=p(),$=r("div"),m=r("div"),T=h("Users"),M=p(),w=r("div"),d=h("4,200"),u=p(),I=r("div"),z=h("\u2197\uFE0E 40 (2%)"),R=p(),V=r("div"),B=r("div"),F=h("New Registers"),C=p(),K=r("div"),J=h("1,200"),A=p(),L=r("div"),y=h("\u2198\uFE0E 90 (14%)"),this.h()},l(j){s=v(j,"DIV",{class:!0});var D=l(s);i=v(D,"DIV",{class:!0});var k=l(i);o=v(k,"DIV",{class:!0});var q=l(o);c=f(q,"Downloads"),q.forEach(a),n=_(k),g=v(k,"DIV",{class:!0});var G=l(g);b=f(G,"31K"),G.forEach(a),P=_(k),E=v(k,"DIV",{class:!0});var H=l(E);x=f(H,"From January 1st to February 1st"),H.forEach(a),k.forEach(a),N=_(D),$=v(D,"DIV",{class:!0});var U=l($);m=v(U,"DIV",{class:!0});var W=l(m);T=f(W,"Users"),W.forEach(a),M=_(U),w=v(U,"DIV",{class:!0});var tt=l(w);d=f(tt,"4,200"),tt.forEach(a),u=_(U),I=v(U,"DIV",{class:!0});var Z=l(I);z=f(Z,"\u2197\uFE0E 40 (2%)"),Z.forEach(a),U.forEach(a),R=_(D),V=v(D,"DIV",{class:!0});var S=l(V);B=v(S,"DIV",{class:!0});var st=l(B);F=f(st,"New Registers"),st.forEach(a),C=_(S),K=v(S,"DIV",{class:!0});var Q=l(K);J=f(Q,"1,200"),Q.forEach(a),A=_(S),L=v(S,"DIV",{class:!0});var X=l(L);y=f(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),S.forEach(a),D.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(g,"class","stat-value"),e(E,"class","stat-desc"),e(i,"class","stat place-items-center"),e(m,"class","stat-title"),e(w,"class","stat-value text-secondary"),e(I,"class","stat-desc text-secondary"),e($,"class","stat place-items-center"),e(B,"class","stat-title"),e(K,"class","stat-value"),e(L,"class","stat-desc"),e(V,"class","stat place-items-center"),e(s,"class","shadow stats")},m(j,D){Y(j,s,D),t(s,i),t(i,o),t(o,c),t(i,n),t(i,g),t(g,b),t(i,P),t(i,E),t(E,x),t(s,N),t(s,$),t($,m),t(m,T),t($,M),t($,w),t(w,d),t($,u),t($,I),t(I,z),t(s,R),t(s,V),t(V,B),t(B,F),t(V,C),t(V,K),t(K,J),t(V,A),t(V,L),t(L,y)},d(j){j&&a(s)}}}function Ot(O){let s,i=`<div class="shadow stats">
  
  <div class="stat place-items-center">
    <div class="stat-title">Downloads</div>
    <div class="stat-value">31K</div>
    <div class="stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="stat place-items-center">
    <div class="stat-title">Users</div>
    <div class="stat-value text-secondary">4,200</div>
    <div class="stat-desc text-secondary">\u2197\uFE0E 40 (2%)</div>
  </div>
  
  <div class="stat place-items-center">
    <div class="stat-title">New Registers</div>
    <div class="stat-value">1,200</div>
    <div class="stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function Wt(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C,K,J,A,L,y;return{c(){s=r("div"),i=r("div"),o=r("div"),c=h("Downloads"),n=p(),g=r("div"),b=h("31K"),P=p(),E=r("div"),x=h("Jan 1st - Feb 1st"),N=p(),$=r("div"),m=r("div"),T=h("New Users"),M=p(),w=r("div"),d=h("4,200"),u=p(),I=r("div"),z=h("\u2197\uFE0E 400 (22%)"),R=p(),V=r("div"),B=r("div"),F=h("New Registers"),C=p(),K=r("div"),J=h("1,200"),A=p(),L=r("div"),y=h("\u2198\uFE0E 90 (14%)"),this.h()},l(j){s=v(j,"DIV",{class:!0});var D=l(s);i=v(D,"DIV",{class:!0});var k=l(i);o=v(k,"DIV",{class:!0});var q=l(o);c=f(q,"Downloads"),q.forEach(a),n=_(k),g=v(k,"DIV",{class:!0});var G=l(g);b=f(G,"31K"),G.forEach(a),P=_(k),E=v(k,"DIV",{class:!0});var H=l(E);x=f(H,"Jan 1st - Feb 1st"),H.forEach(a),k.forEach(a),N=_(D),$=v(D,"DIV",{class:!0});var U=l($);m=v(U,"DIV",{class:!0});var W=l(m);T=f(W,"New Users"),W.forEach(a),M=_(U),w=v(U,"DIV",{class:!0});var tt=l(w);d=f(tt,"4,200"),tt.forEach(a),u=_(U),I=v(U,"DIV",{class:!0});var Z=l(I);z=f(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),U.forEach(a),R=_(D),V=v(D,"DIV",{class:!0});var S=l(V);B=v(S,"DIV",{class:!0});var st=l(B);F=f(st,"New Registers"),st.forEach(a),C=_(S),K=v(S,"DIV",{class:!0});var Q=l(K);J=f(Q,"1,200"),Q.forEach(a),A=_(S),L=v(S,"DIV",{class:!0});var X=l(L);y=f(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),S.forEach(a),D.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(g,"class","stat-value"),e(E,"class","stat-desc"),e(i,"class","stat"),e(m,"class","stat-title"),e(w,"class","stat-value"),e(I,"class","stat-desc"),e($,"class","stat"),e(B,"class","stat-title"),e(K,"class","stat-value"),e(L,"class","stat-desc"),e(V,"class","stat"),e(s,"class","shadow stats stats-vertical")},m(j,D){Y(j,s,D),t(s,i),t(i,o),t(o,c),t(i,n),t(i,g),t(g,b),t(i,P),t(i,E),t(E,x),t(s,N),t(s,$),t($,m),t(m,T),t($,M),t($,w),t(w,d),t($,u),t($,I),t(I,z),t(s,R),t(s,V),t(V,B),t(B,F),t(V,C),t(V,K),t(K,J),t(V,A),t(V,L),t(L,y)},d(j){j&&a(s)}}}function qt(O){let s,i=`<div class="shadow stats stats-vertical">
  
  <div class="stat">
    <div class="stat-title">Downloads</div>
    <div class="stat-value">31K</div>
    <div class="stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="stat">
    <div class="stat-title">New Users</div>
    <div class="stat-value">4,200</div>
    <div class="stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="stat">
    <div class="stat-title">New Registers</div>
    <div class="stat-value">1,200</div>
    <div class="stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function Gt(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C,K,J,A,L,y;return{c(){s=r("div"),i=r("div"),o=r("div"),c=h("Downloads"),n=p(),g=r("div"),b=h("31K"),P=p(),E=r("div"),x=h("Jan 1st - Feb 1st"),N=p(),$=r("div"),m=r("div"),T=h("New Users"),M=p(),w=r("div"),d=h("4,200"),u=p(),I=r("div"),z=h("\u2197\uFE0E 400 (22%)"),R=p(),V=r("div"),B=r("div"),F=h("New Registers"),C=p(),K=r("div"),J=h("1,200"),A=p(),L=r("div"),y=h("\u2198\uFE0E 90 (14%)"),this.h()},l(j){s=v(j,"DIV",{class:!0});var D=l(s);i=v(D,"DIV",{class:!0});var k=l(i);o=v(k,"DIV",{class:!0});var q=l(o);c=f(q,"Downloads"),q.forEach(a),n=_(k),g=v(k,"DIV",{class:!0});var G=l(g);b=f(G,"31K"),G.forEach(a),P=_(k),E=v(k,"DIV",{class:!0});var H=l(E);x=f(H,"Jan 1st - Feb 1st"),H.forEach(a),k.forEach(a),N=_(D),$=v(D,"DIV",{class:!0});var U=l($);m=v(U,"DIV",{class:!0});var W=l(m);T=f(W,"New Users"),W.forEach(a),M=_(U),w=v(U,"DIV",{class:!0});var tt=l(w);d=f(tt,"4,200"),tt.forEach(a),u=_(U),I=v(U,"DIV",{class:!0});var Z=l(I);z=f(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),U.forEach(a),R=_(D),V=v(D,"DIV",{class:!0});var S=l(V);B=v(S,"DIV",{class:!0});var st=l(B);F=f(st,"New Registers"),st.forEach(a),C=_(S),K=v(S,"DIV",{class:!0});var Q=l(K);J=f(Q,"1,200"),Q.forEach(a),A=_(S),L=v(S,"DIV",{class:!0});var X=l(L);y=f(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),S.forEach(a),D.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(g,"class","stat-value"),e(E,"class","stat-desc"),e(i,"class","stat"),e(m,"class","stat-title"),e(w,"class","stat-value"),e(I,"class","stat-desc"),e($,"class","stat"),e(B,"class","stat-title"),e(K,"class","stat-value"),e(L,"class","stat-desc"),e(V,"class","stat"),e(s,"class","shadow stats stats-vertical lg:stats-horizontal")},m(j,D){Y(j,s,D),t(s,i),t(i,o),t(o,c),t(i,n),t(i,g),t(g,b),t(i,P),t(i,E),t(E,x),t(s,N),t(s,$),t($,m),t(m,T),t($,M),t($,w),t(w,d),t($,u),t($,I),t(I,z),t(s,R),t(s,V),t(V,B),t(B,F),t(V,C),t(V,K),t(K,J),t(V,A),t(V,L),t(L,y)},d(j){j&&a(s)}}}function Ht(O){let s,i=`<div class="shadow stats stats-vertical lg:stats-horizontal">
  
  <div class="stat">
    <div class="stat-title">Downloads</div>
    <div class="stat-value">31K</div>
    <div class="stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="stat">
    <div class="stat-title">New Users</div>
    <div class="stat-value">4,200</div>
    <div class="stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="stat">
    <div class="stat-title">New Registers</div>
    <div class="stat-value">1,200</div>
    <div class="stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function Qt(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w,d,u,I,z,R,V,B,F,C;return{c(){s=r("div"),i=r("div"),o=r("div"),c=h("Account balance"),n=p(),g=r("div"),b=h("$89,400"),P=p(),E=r("div"),x=r("button"),N=h("Add funds"),$=p(),m=r("div"),T=r("div"),M=h("Current balance"),w=p(),d=r("div"),u=h("$89,400"),I=p(),z=r("div"),R=r("button"),V=h("Withdrawal"),B=p(),F=r("button"),C=h("deposit"),this.h()},l(K){s=v(K,"DIV",{class:!0});var J=l(s);i=v(J,"DIV",{class:!0});var A=l(i);o=v(A,"DIV",{class:!0});var L=l(o);c=f(L,"Account balance"),L.forEach(a),n=_(A),g=v(A,"DIV",{class:!0});var y=l(g);b=f(y,"$89,400"),y.forEach(a),P=_(A),E=v(A,"DIV",{class:!0});var j=l(E);x=v(j,"BUTTON",{class:!0});var D=l(x);N=f(D,"Add funds"),D.forEach(a),j.forEach(a),A.forEach(a),$=_(J),m=v(J,"DIV",{class:!0});var k=l(m);T=v(k,"DIV",{class:!0});var q=l(T);M=f(q,"Current balance"),q.forEach(a),w=_(k),d=v(k,"DIV",{class:!0});var G=l(d);u=f(G,"$89,400"),G.forEach(a),I=_(k),z=v(k,"DIV",{class:!0});var H=l(z);R=v(H,"BUTTON",{class:!0});var U=l(R);V=f(U,"Withdrawal"),U.forEach(a),B=_(H),F=v(H,"BUTTON",{class:!0});var W=l(F);C=f(W,"deposit"),W.forEach(a),H.forEach(a),k.forEach(a),J.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(g,"class","stat-value"),e(x,"class","btn btn-sm btn-success"),e(E,"class","stat-actions"),e(i,"class","stat"),e(T,"class","stat-title"),e(d,"class","stat-value"),e(R,"class","btn btn-sm"),e(F,"class","btn btn-sm"),e(z,"class","stat-actions"),e(m,"class","stat"),e(s,"class","stats bg-primary text-primary-content")},m(K,J){Y(K,s,J),t(s,i),t(i,o),t(o,c),t(i,n),t(i,g),t(g,b),t(i,P),t(i,E),t(E,x),t(x,N),t(s,$),t(s,m),t(m,T),t(T,M),t(m,w),t(m,d),t(d,u),t(m,I),t(m,z),t(z,R),t(R,V),t(z,B),t(z,F),t(F,C)},d(K){K&&a(s)}}}function Xt(O){let s,i=`<div class="stats bg-primary text-primary-content">
  
  <div class="stat">
    <div class="stat-title">Account balance</div>
    <div class="stat-value">$89,400</div>
    <div class="stat-actions">
      <button class="btn btn-sm btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="stat">
    <div class="stat-title">Current balance</div>
    <div class="stat-value">$89,400</div>
    <div class="stat-actions">
      <button class="btn btn-sm">Withdrawal</button> 
      <button class="btn btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,o;return{c(){s=r("pre"),o=h(i),this.h()},l(c){s=v(c,"PRE",{slot:!0});var n=l(s);o=f(n,i),n.forEach(a),this.h()},h(){e(s,"slot","html")},m(c,n){Y(c,s,n),t(s,o)},p:wt,d(c){c&&a(s)}}}function Yt(O){let s,i,o,c,n,g,b,P,E,x,N,$,m,T,M,w;return s=new Ut({props:{data:[{type:"component",class:"stats",desc:"Conainer ot multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),o=new _t({props:{title:"Stat",$$slots:{html:[Jt],default:[Pt]},$$scope:{ctx:O}}}),n=new _t({props:{title:"Stat with icons or image",$$slots:{html:[Lt],default:[zt]},$$scope:{ctx:O}}}),b=new _t({props:{title:"Stat",$$slots:{html:[Ct],default:[St]},$$scope:{ctx:O}}}),E=new _t({props:{title:"Centered items",$$slots:{html:[Ot],default:[At]},$$scope:{ctx:O}}}),N=new _t({props:{title:"Vertical",$$slots:{html:[qt],default:[Wt]},$$scope:{ctx:O}}}),m=new _t({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{html:[Ht],default:[Gt]},$$scope:{ctx:O}}}),M=new _t({props:{title:"With custom colors and button",$$slots:{html:[Xt],default:[Qt]},$$scope:{ctx:O}}}),{c(){nt(s.$$.fragment),i=p(),nt(o.$$.fragment),c=p(),nt(n.$$.fragment),g=p(),nt(b.$$.fragment),P=p(),nt(E.$$.fragment),x=p(),nt(N.$$.fragment),$=p(),nt(m.$$.fragment),T=p(),nt(M.$$.fragment)},l(d){ut(s.$$.fragment,d),i=_(d),ut(o.$$.fragment,d),c=_(d),ut(n.$$.fragment,d),g=_(d),ut(b.$$.fragment,d),P=_(d),ut(E.$$.fragment,d),x=_(d),ut(N.$$.fragment,d),$=_(d),ut(m.$$.fragment,d),T=_(d),ut(M.$$.fragment,d)},m(d,u){ht(s,d,u),Y(d,i,u),ht(o,d,u),Y(d,c,u),ht(n,d,u),Y(d,g,u),ht(b,d,u),Y(d,P,u),ht(E,d,u),Y(d,x,u),ht(N,d,u),Y(d,$,u),ht(m,d,u),Y(d,T,u),ht(M,d,u),w=!0},p(d,[u]){const I={};u&1&&(I.$$scope={dirty:u,ctx:d}),o.$set(I);const z={};u&1&&(z.$$scope={dirty:u,ctx:d}),n.$set(z);const R={};u&1&&(R.$$scope={dirty:u,ctx:d}),b.$set(R);const V={};u&1&&(V.$$scope={dirty:u,ctx:d}),E.$set(V);const B={};u&1&&(B.$$scope={dirty:u,ctx:d}),N.$set(B);const F={};u&1&&(F.$$scope={dirty:u,ctx:d}),m.$set(F);const C={};u&1&&(C.$$scope={dirty:u,ctx:d}),M.$set(C)},i(d){w||(ft(s.$$.fragment,d),ft(o.$$.fragment,d),ft(n.$$.fragment,d),ft(b.$$.fragment,d),ft(E.$$.fragment,d),ft(N.$$.fragment,d),ft(m.$$.fragment,d),ft(M.$$.fragment,d),w=!0)},o(d){mt(s.$$.fragment,d),mt(o.$$.fragment,d),mt(n.$$.fragment,d),mt(b.$$.fragment,d),mt(E.$$.fragment,d),mt(N.$$.fragment,d),mt(m.$$.fragment,d),mt(M.$$.fragment,d),w=!1},d(d){pt(s,d),d&&a(i),pt(o,d),d&&a(c),pt(n,d),d&&a(g),pt(b,d),d&&a(P),pt(E,d),d&&a(x),pt(N,d),d&&a($),pt(m,d),d&&a(T),pt(M,d)}}}const es={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0};class as extends Ft{constructor(s){super();Tt(this,s,null,Yt,Kt,{})}}export{as as default,es as metadata};
