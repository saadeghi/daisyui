import{S as y,i as aa,s as sa,w as B,k as M,x as H,m as T,y as j,g as w,q as F,o as L,B as Q,d as e,e as v,c as o,a as m,N as G,b as l,H as d,t as K,h as O,M as W}from"../../chunks/vendor-a11792f1.js";import{C as ea,a as U}from"../../chunks/ClassTable-b67380d7.js";import"../../chunks/preload-helper-ec9aa979.js";function ta(C){let a,i,t,c;return{c(){a=v("div"),i=v("div"),t=v("img"),this.h()},l(r){a=o(r,"DIV",{class:!0});var f=m(a);i=o(f,"DIV",{class:!0});var p=m(i);t=o(p,"IMG",{src:!0,alt:!0}),p.forEach(e),f.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=75101")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 rounded bg-base-300"),l(a,"class","avatar")},m(r,f){w(r,a,f),d(a,i),d(i,t)},d(r){r&&e(a)}}}function la(C){let a,i=`<div class="avatar">
  <div class="w-24 rounded">
    <img src="https://api.lorem.space/image/face?hash=92048">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function ra(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A,I,D,b,V,x;return{c(){a=v("div"),i=v("div"),t=v("img"),r=M(),f=v("div"),p=v("div"),_=v("img"),g=M(),h=v("div"),E=v("div"),$=v("img"),I=M(),D=v("div"),b=v("div"),V=v("img"),this.h()},l(u){a=o(u,"DIV",{class:!0});var s=m(a);i=o(s,"DIV",{class:!0});var n=m(i);t=o(n,"IMG",{src:!0,alt:!0}),n.forEach(e),s.forEach(e),r=T(u),f=o(u,"DIV",{class:!0});var k=m(f);p=o(k,"DIV",{class:!0});var P=m(p);_=o(P,"IMG",{src:!0,alt:!0}),P.forEach(e),k.forEach(e),g=T(u),h=o(u,"DIV",{class:!0});var R=m(h);E=o(R,"DIV",{class:!0});var N=m(E);$=o(N,"IMG",{src:!0,alt:!0}),N.forEach(e),R.forEach(e),I=T(u),D=o(u,"DIV",{class:!0});var q=m(D);b=o(q,"DIV",{class:!0});var J=m(b);V=o(J,"IMG",{src:!0,alt:!0}),J.forEach(e),q.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=71470")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 rounded bg-base-300"),l(a,"class","avatar"),G(_.src,S="https://api.lorem.space/image/face?hash=88712")||l(_,"src",S),l(_,"alt","Tailwind-CSS-Avatar-component"),l(p,"class","w-16 rounded bg-base-300"),l(f,"class","avatar"),G($.src,A="https://api.lorem.space/image/face?hash=15164")||l($,"src",A),l($,"alt","Tailwind-CSS-Avatar-component"),l(E,"class","w-12 rounded bg-base-300"),l(h,"class","avatar"),G(V.src,x="https://api.lorem.space/image/face?hash=79498")||l(V,"src",x),l(V,"alt","Tailwind-CSS-Avatar-component"),l(b,"class","w-8 rounded bg-base-300"),l(D,"class","avatar")},m(u,s){w(u,a,s),d(a,i),d(i,t),w(u,r,s),w(u,f,s),d(f,p),d(p,_),w(u,g,s),w(u,h,s),d(h,E),d(E,$),w(u,I,s),w(u,D,s),d(D,b),d(b,V)},d(u){u&&e(a),u&&e(r),u&&e(f),u&&e(g),u&&e(h),u&&e(I),u&&e(D)}}}function ia(C){let a,i=`<div class="avatar">
  <div class="w-32 rounded">
    <img src="https://api.lorem.space/image/face?hash=88560">
  </div>
</div>
<div class="avatar">
  <div class="w-20 rounded">
    <img src="https://api.lorem.space/image/face?hash=80245" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>
<div class="avatar">
  <div class="w-16 rounded">
    <img src="https://api.lorem.space/image/face?hash=77703" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>
<div class="avatar">
  <div class="w-8 rounded">
    <img src="https://api.lorem.space/image/face?hash=33791" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function ca(C){let a,i,t,c,r,f,p,_,S;return{c(){a=v("div"),i=v("div"),t=v("img"),r=M(),f=v("div"),p=v("div"),_=v("img"),this.h()},l(g){a=o(g,"DIV",{class:!0});var h=m(a);i=o(h,"DIV",{class:!0});var E=m(i);t=o(E,"IMG",{src:!0,alt:!0}),E.forEach(e),h.forEach(e),r=T(g),f=o(g,"DIV",{class:!0});var $=m(f);p=o($,"DIV",{class:!0});var A=m(p);_=o(A,"IMG",{src:!0,alt:!0}),A.forEach(e),$.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=71060")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 rounded-xl bg-base-300"),l(a,"class","avatar"),G(_.src,S="https://api.lorem.space/image/face?hash=70084")||l(_,"src",S),l(_,"alt","Tailwind-CSS-Avatar-component"),l(p,"class","w-24 rounded-full bg-base-300"),l(f,"class","avatar")},m(g,h){w(g,a,h),d(a,i),d(i,t),w(g,r,h),w(g,f,h),d(f,p),d(p,_)},d(g){g&&e(a),g&&e(r),g&&e(f)}}}function va(C){let a,i=`<div class="avatar">
  <div class="w-24 rounded-xl">
    <img src="https://api.lorem.space/image/face?hash=64318">
  </div>
</div>
<div class="avatar">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=92310">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function oa(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A;return{c(){a=v("div"),i=v("div"),t=v("img"),r=M(),f=v("div"),p=v("div"),_=v("img"),g=M(),h=v("div"),E=v("div"),$=v("img"),this.h()},l(I){a=o(I,"DIV",{class:!0});var D=m(a);i=o(D,"DIV",{class:!0});var b=m(i);t=o(b,"IMG",{src:!0,alt:!0}),b.forEach(e),D.forEach(e),r=T(I),f=o(I,"DIV",{class:!0});var V=m(f);p=o(V,"DIV",{class:!0});var x=m(p);_=o(x,"IMG",{src:!0,alt:!0}),x.forEach(e),V.forEach(e),g=T(I),h=o(I,"DIV",{class:!0});var u=m(h);E=o(u,"DIV",{class:!0});var s=m(E);$=o(s,"IMG",{src:!0,alt:!0}),s.forEach(e),u.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=8877")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 mask mask-squircle bg-base-300"),l(a,"class","avatar"),G(_.src,S="https://api.lorem.space/image/face?hash=79960")||l(_,"src",S),l(_,"alt","Tailwind-CSS-Avatar-component"),l(p,"class","w-24 mask mask-hexagon bg-base-300"),l(f,"class","avatar"),G($.src,A="https://api.lorem.space/image/face?hash=70860")||l($,"src",A),l($,"alt","Tailwind-CSS-Avatar-component"),l(E,"class","w-24 mask mask-triangle bg-base-300"),l(h,"class","avatar")},m(I,D){w(I,a,D),d(a,i),d(i,t),w(I,r,D),w(I,f,D),d(f,p),d(p,_),w(I,g,D),w(I,h,D),d(h,E),d(E,$)},d(I){I&&e(a),I&&e(r),I&&e(f),I&&e(g),I&&e(h)}}}function da(C){let a,i=`<div class="avatar">
  <div class="w-24 mask mask-squircle">
    <img src="https://api.lorem.space/image/face?hash=47449">
  </div>
</div>
<div class="avatar">
  <div class="w-24 mask mask-hexagon">
    <img src="https://api.lorem.space/image/face?hash=55350">
  </div>
</div>
<div class="avatar">
  <div class="w-24 mask mask-triangle">
    <img src="https://api.lorem.space/image/face?hash=60857">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function na(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A,I,D,b,V,x,u;return{c(){a=v("div"),i=v("div"),t=v("div"),c=v("img"),f=M(),p=v("div"),_=v("div"),S=v("img"),h=M(),E=v("div"),$=v("div"),A=v("img"),D=M(),b=v("div"),V=v("div"),x=v("img"),this.h()},l(s){a=o(s,"DIV",{class:!0});var n=m(a);i=o(n,"DIV",{class:!0});var k=m(i);t=o(k,"DIV",{class:!0});var P=m(t);c=o(P,"IMG",{src:!0,alt:!0}),P.forEach(e),k.forEach(e),f=T(n),p=o(n,"DIV",{class:!0});var R=m(p);_=o(R,"DIV",{class:!0});var N=m(_);S=o(N,"IMG",{src:!0,alt:!0}),N.forEach(e),R.forEach(e),h=T(n),E=o(n,"DIV",{class:!0});var q=m(E);$=o(q,"DIV",{class:!0});var J=m($);A=o(J,"IMG",{src:!0,alt:!0}),J.forEach(e),q.forEach(e),D=T(n),b=o(n,"DIV",{class:!0});var X=m(b);V=o(X,"DIV",{class:!0});var z=m(V);x=o(z,"IMG",{src:!0,alt:!0}),z.forEach(e),X.forEach(e),n.forEach(e),this.h()},h(){G(c.src,r="https://api.lorem.space/image/face?hash=11722")||l(c,"src",r),l(c,"alt","Tailwind-CSS-Avatar-component"),l(t,"class","w-12 bg-base-300"),l(i,"class","avatar"),G(S.src,g="https://api.lorem.space/image/face?hash=75704")||l(S,"src",g),l(S,"alt","Tailwind-CSS-Avatar-component"),l(_,"class","w-12 bg-base-300"),l(p,"class","avatar"),G(A.src,I="https://api.lorem.space/image/face?hash=86780")||l(A,"src",I),l(A,"alt","Tailwind-CSS-Avatar-component"),l($,"class","w-12 bg-base-300"),l(E,"class","avatar"),G(x.src,u="https://api.lorem.space/image/face?hash=92365")||l(x,"src",u),l(x,"alt","Tailwind-CSS-Avatar-component"),l(V,"class","w-12 bg-base-300"),l(b,"class","avatar"),l(a,"class","avatar-group -space-x-6")},m(s,n){w(s,a,n),d(a,i),d(i,t),d(t,c),d(a,f),d(a,p),d(p,_),d(_,S),d(a,h),d(a,E),d(E,$),d($,A),d(a,D),d(a,b),d(b,V),d(V,x)},d(s){s&&e(a)}}}function ma(C){let a,i=`<div class="avatar-group -space-x-6">
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=53273">
    </div>
  </div>
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=91831">
    </div>
  </div>
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=27312">
    </div>
  </div>
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=26448">
    </div>
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function pa(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A,I,D,b,V,x,u;return{c(){a=v("div"),i=v("div"),t=v("div"),c=v("img"),f=M(),p=v("div"),_=v("div"),S=v("img"),h=M(),E=v("div"),$=v("div"),A=v("img"),D=M(),b=v("div"),V=v("div"),x=v("span"),u=K("+99"),this.h()},l(s){a=o(s,"DIV",{class:!0});var n=m(a);i=o(n,"DIV",{class:!0});var k=m(i);t=o(k,"DIV",{class:!0});var P=m(t);c=o(P,"IMG",{src:!0,alt:!0}),P.forEach(e),k.forEach(e),f=T(n),p=o(n,"DIV",{class:!0});var R=m(p);_=o(R,"DIV",{class:!0});var N=m(_);S=o(N,"IMG",{src:!0,alt:!0}),N.forEach(e),R.forEach(e),h=T(n),E=o(n,"DIV",{class:!0});var q=m(E);$=o(q,"DIV",{class:!0});var J=m($);A=o(J,"IMG",{src:!0,alt:!0}),J.forEach(e),q.forEach(e),D=T(n),b=o(n,"DIV",{class:!0});var X=m(b);V=o(X,"DIV",{class:!0});var z=m(V);x=o(z,"SPAN",{});var Y=m(x);u=O(Y,"+99"),Y.forEach(e),z.forEach(e),X.forEach(e),n.forEach(e),this.h()},h(){G(c.src,r="https://api.lorem.space/image/face?hash=71251")||l(c,"src",r),l(c,"alt","Tailwind-CSS-Avatar-component"),l(t,"class","w-12 bg-base-300"),l(i,"class","avatar"),G(S.src,g="https://api.lorem.space/image/face?hash=58372")||l(S,"src",g),l(S,"alt","Tailwind-CSS-Avatar-component"),l(_,"class","w-12 bg-base-300"),l(p,"class","avatar"),G(A.src,I="https://api.lorem.space/image/face?hash=26576")||l(A,"src",I),l(A,"alt","Tailwind-CSS-Avatar-component"),l($,"class","w-12 bg-base-300"),l(E,"class","avatar"),l(V,"class","w-12 bg-neutral-focus text-neutral-content"),l(b,"class","avatar placeholder"),l(a,"class","avatar-group -space-x-6")},m(s,n){w(s,a,n),d(a,i),d(i,t),d(t,c),d(a,f),d(a,p),d(p,_),d(_,S),d(a,h),d(a,E),d(E,$),d($,A),d(a,D),d(a,b),d(b,V),d(V,x),d(x,u)},d(s){s&&e(a)}}}function fa(C){let a,i=`<div class="avatar-group -space-x-6">
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=4818">
    </div>
  </div>
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=40311">
    </div>
  </div>
  <div class="avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=84348">
    </div>
  </div>
  <div class="avatar placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function ua(C){let a,i,t,c;return{c(){a=v("div"),i=v("div"),t=v("img"),this.h()},l(r){a=o(r,"DIV",{class:!0});var f=m(a);i=o(f,"DIV",{class:!0});var p=m(i);t=o(p,"IMG",{src:!0,alt:!0}),p.forEach(e),f.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=558")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"),l(a,"class","avatar")},m(r,f){w(r,a,f),d(a,i),d(i,t)},d(r){r&&e(a)}}}function ha(C){let a,i=`<div class="avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="https://api.lorem.space/image/face?hash=3174">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function _a(C){let a,i,t,c,r,f,p,_,S;return{c(){a=v("div"),i=v("div"),t=v("img"),r=M(),f=v("div"),p=v("div"),_=v("img"),this.h()},l(g){a=o(g,"DIV",{class:!0});var h=m(a);i=o(h,"DIV",{class:!0});var E=m(i);t=o(E,"IMG",{src:!0,alt:!0}),E.forEach(e),h.forEach(e),r=T(g),f=o(g,"DIV",{class:!0});var $=m(f);p=o($,"DIV",{class:!0});var A=m(p);_=o(A,"IMG",{src:!0,alt:!0}),A.forEach(e),$.forEach(e),this.h()},h(){G(t.src,c="https://api.lorem.space/image/face?hash=67053")||l(t,"src",c),l(t,"alt","Tailwind-CSS-Avatar-component"),l(i,"class","w-24 rounded-full bg-base-300"),l(a,"class","avatar online"),G(_.src,S="https://api.lorem.space/image/face?hash=92699")||l(_,"src",S),l(_,"alt","Tailwind-CSS-Avatar-component"),l(p,"class","w-24 rounded-full bg-base-300"),l(f,"class","avatar offline")},m(g,h){w(g,a,h),d(a,i),d(i,t),w(g,r,h),w(g,f,h),d(f,p),d(p,_)},d(g){g&&e(a),g&&e(r),g&&e(f)}}}function ga(C){let a,i=`<div class="avatar online">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=28212">
  </div>
</div>
<div class="avatar offline">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=40361">
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function $a(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A,I,D,b,V,x;return{c(){a=v("div"),i=v("div"),t=v("span"),c=K("K"),r=M(),f=v("div"),p=v("div"),_=v("span"),S=K("JO"),g=M(),h=v("div"),E=v("div"),$=v("span"),A=K("MX"),I=M(),D=v("div"),b=v("div"),V=v("span"),x=K("AA"),this.h()},l(u){a=o(u,"DIV",{class:!0});var s=m(a);i=o(s,"DIV",{class:!0});var n=m(i);t=o(n,"SPAN",{class:!0});var k=m(t);c=O(k,"K"),k.forEach(e),n.forEach(e),s.forEach(e),r=T(u),f=o(u,"DIV",{class:!0});var P=m(f);p=o(P,"DIV",{class:!0});var R=m(p);_=o(R,"SPAN",{class:!0});var N=m(_);S=O(N,"JO"),N.forEach(e),R.forEach(e),P.forEach(e),g=T(u),h=o(u,"DIV",{class:!0});var q=m(h);E=o(q,"DIV",{class:!0});var J=m(E);$=o(J,"SPAN",{});var X=m($);A=O(X,"MX"),X.forEach(e),J.forEach(e),q.forEach(e),I=T(u),D=o(u,"DIV",{class:!0});var z=m(D);b=o(z,"DIV",{class:!0});var Y=m(b);V=o(Y,"SPAN",{class:!0});var Z=m(V);x=O(Z,"AA"),Z.forEach(e),Y.forEach(e),z.forEach(e),this.h()},h(){l(t,"class","text-3xl"),l(i,"class","bg-neutral-focus text-neutral-content rounded-full w-24"),l(a,"class","avatar placeholder"),l(_,"class","text-xl"),l(p,"class","bg-neutral-focus text-neutral-content rounded-full w-16"),l(f,"class","avatar online placeholder"),l(E,"class","bg-neutral-focus text-neutral-content rounded-full w-12"),l(h,"class","avatar placeholder"),l(V,"class","text-xs"),l(b,"class","bg-neutral-focus text-neutral-content rounded-full w-8"),l(D,"class","avatar placeholder")},m(u,s){w(u,a,s),d(a,i),d(i,t),d(t,c),w(u,r,s),w(u,f,s),d(f,p),d(p,_),d(_,S),w(u,g,s),w(u,h,s),d(h,E),d(E,$),d($,A),w(u,I,s),w(u,D,s),d(D,b),d(b,V),d(V,x)},d(u){u&&e(a),u&&e(r),u&&e(f),u&&e(g),u&&e(h),u&&e(I),u&&e(D)}}}function wa(C){let a,i=`<div class="avatar placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="avatar online placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="avatar placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="avatar placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,t;return{c(){a=v("pre"),t=K(i),this.h()},l(c){a=o(c,"PRE",{slot:!0});var r=m(a);t=O(r,i),r.forEach(e),this.h()},h(){l(a,"slot","html")},m(c,r){w(c,a,r),d(a,t)},p:W,d(c){c&&e(a)}}}function Ea(C){let a,i,t,c,r,f,p,_,S,g,h,E,$,A,I,D,b,V,x,u;return a=new ea({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as online indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),t=new U({props:{title:"Avatar",$$slots:{html:[la],default:[ta]},$$scope:{ctx:C}}}),r=new U({props:{title:"Avatar in custom sizes",$$slots:{html:[ia],default:[ra]},$$scope:{ctx:C}}}),p=new U({props:{title:"Avatar rounded",$$slots:{html:[va],default:[ca]},$$scope:{ctx:C}}}),S=new U({props:{title:"Avatar with mask",$$slots:{html:[da],default:[oa]},$$scope:{ctx:C}}}),h=new U({props:{title:"Avatar group",$$slots:{html:[ma],default:[na]},$$scope:{ctx:C}}}),$=new U({props:{title:"Avatar group with counter",$$slots:{html:[fa],default:[pa]},$$scope:{ctx:C}}}),I=new U({props:{title:"Avatar with ring",$$slots:{html:[ha],default:[ua]},$$scope:{ctx:C}}}),b=new U({props:{title:"Avatar with presence indicator",$$slots:{html:[ga],default:[_a]},$$scope:{ctx:C}}}),x=new U({props:{title:"Avatar placeholder",$$slots:{html:[wa],default:[$a]},$$scope:{ctx:C}}}),{c(){B(a.$$.fragment),i=M(),B(t.$$.fragment),c=M(),B(r.$$.fragment),f=M(),B(p.$$.fragment),_=M(),B(S.$$.fragment),g=M(),B(h.$$.fragment),E=M(),B($.$$.fragment),A=M(),B(I.$$.fragment),D=M(),B(b.$$.fragment),V=M(),B(x.$$.fragment)},l(s){H(a.$$.fragment,s),i=T(s),H(t.$$.fragment,s),c=T(s),H(r.$$.fragment,s),f=T(s),H(p.$$.fragment,s),_=T(s),H(S.$$.fragment,s),g=T(s),H(h.$$.fragment,s),E=T(s),H($.$$.fragment,s),A=T(s),H(I.$$.fragment,s),D=T(s),H(b.$$.fragment,s),V=T(s),H(x.$$.fragment,s)},m(s,n){j(a,s,n),w(s,i,n),j(t,s,n),w(s,c,n),j(r,s,n),w(s,f,n),j(p,s,n),w(s,_,n),j(S,s,n),w(s,g,n),j(h,s,n),w(s,E,n),j($,s,n),w(s,A,n),j(I,s,n),w(s,D,n),j(b,s,n),w(s,V,n),j(x,s,n),u=!0},p(s,[n]){const k={};n&1&&(k.$$scope={dirty:n,ctx:s}),t.$set(k);const P={};n&1&&(P.$$scope={dirty:n,ctx:s}),r.$set(P);const R={};n&1&&(R.$$scope={dirty:n,ctx:s}),p.$set(R);const N={};n&1&&(N.$$scope={dirty:n,ctx:s}),S.$set(N);const q={};n&1&&(q.$$scope={dirty:n,ctx:s}),h.$set(q);const J={};n&1&&(J.$$scope={dirty:n,ctx:s}),$.$set(J);const X={};n&1&&(X.$$scope={dirty:n,ctx:s}),I.$set(X);const z={};n&1&&(z.$$scope={dirty:n,ctx:s}),b.$set(z);const Y={};n&1&&(Y.$$scope={dirty:n,ctx:s}),x.$set(Y)},i(s){u||(F(a.$$.fragment,s),F(t.$$.fragment,s),F(r.$$.fragment,s),F(p.$$.fragment,s),F(S.$$.fragment,s),F(h.$$.fragment,s),F($.$$.fragment,s),F(I.$$.fragment,s),F(b.$$.fragment,s),F(x.$$.fragment,s),u=!0)},o(s){L(a.$$.fragment,s),L(t.$$.fragment,s),L(r.$$.fragment,s),L(p.$$.fragment,s),L(S.$$.fragment,s),L(h.$$.fragment,s),L($.$$.fragment,s),L(I.$$.fragment,s),L(b.$$.fragment,s),L(x.$$.fragment,s),u=!1},d(s){Q(a,s),s&&e(i),Q(t,s),s&&e(c),Q(r,s),s&&e(f),Q(p,s),s&&e(_),Q(S,s),s&&e(g),Q(h,s),s&&e(E),Q($,s),s&&e(A),Q(I,s),s&&e(D),Q(b,s),s&&e(V),Q(x,s)}}}const Da={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0};class Va extends y{constructor(a){super();aa(this,a,null,Ea,sa,{})}}export{Va as default,Da as metadata};
