import{S as ge,i as we,s as _e,C as Kt,w as ft,x as gt,y as wt,z as xe,A as be,q as _t,o as xt,B as Et,K as Ee,ag as me,k,m as L,g as B,d as l,e as d,t as _,c as u,a as o,h as x,b as s,F as e,a9 as nt,Q as ot,H as tt,I as et,O as fe}from"../../chunks/vendor-3400f70d.js";import{M as Ie}from"../../chunks/_markdown-67d63dce.js";import{p as ke,C as Le,a as Bt,r as rt}from"../../chunks/actions-eaadde27.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-9d3028b9.js";import"../../chunks/index-6a176716.js";import"../../chunks/SEO-9eab56fe.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-6efc3be4.js";function Ne(p){let t,v,c;return{c(){t=d("div"),v=d("a"),c=_("daisyUI"),this.h()},l(i){t=u(i,"DIV",{class:!0});var r=o(t);v=u(r,"A",{class:!0});var h=o(v);c=x(h,"daisyUI"),h.forEach(l),r.forEach(l),this.h()},h(){s(v,"class","btn btn-ghost normal-case text-xl"),s(t,"class","navbar bg-base-100 shadow-xl rounded-box")},m(i,r){B(i,t,r),e(t,v),e(v,c)},d(i){i&&l(t)}}}function Me(p){let t,v=`<div class="$$navbar bg-base-100">
  <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function ye(p){let t,v=`<div className="$$navbar bg-base-100">
  <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ue(p){let t,v,c,i,r,h,a,n,f;return{c(){t=d("div"),v=d("div"),c=d("a"),i=_("daisyUI"),r=k(),h=d("div"),a=d("button"),n=tt("svg"),f=tt("path"),this.h()},l(E){t=u(E,"DIV",{class:!0});var I=o(t);v=u(I,"DIV",{class:!0});var g=o(v);c=u(g,"A",{class:!0});var b=o(c);i=x(b,"daisyUI"),b.forEach(l),g.forEach(l),r=L(I),h=u(I,"DIV",{class:!0});var y=o(h);a=u(y,"BUTTON",{class:!0});var N=o(a);n=et(N,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var w=o(n);f=et(w,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(f).forEach(l),w.forEach(l),N.forEach(l),y.forEach(l),I.forEach(l),this.h()},h(){s(c,"class","btn btn-ghost normal-case text-xl"),s(v,"class","flex-1"),s(f,"stroke-linecap","round"),s(f,"stroke-linejoin","round"),s(f,"stroke-width","2"),s(f,"d","M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"),s(n,"xmlns","http://www.w3.org/2000/svg"),s(n,"fill","none"),s(n,"viewBox","0 0 24 24"),s(n,"class","inline-block w-5 h-5 stroke-current"),s(a,"class","btn btn-square btn-ghost"),s(h,"class","flex-none"),s(t,"class","navbar bg-base-100 shadow-xl rounded-box")},m(E,I){B(E,t,I),e(t,v),e(v,c),e(c,i),e(t,r),e(t,h),e(h,a),e(a,n),e(n,f)},d(E){E&&l(t)}}}function Be(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="flex-1">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="flex-none">
    <button class="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-5 h-5 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"></path></svg>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ae(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="flex-1">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="flex-none">
    <button className="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-5 h-5 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"></path></svg>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ve(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y;return{c(){t=d("div"),v=d("div"),c=d("button"),i=tt("svg"),r=tt("path"),h=k(),a=d("div"),n=d("a"),f=_("daisyUI"),E=k(),I=d("div"),g=d("button"),b=tt("svg"),y=tt("path"),this.h()},l(N){t=u(N,"DIV",{class:!0});var w=o(t);v=u(w,"DIV",{class:!0});var M=o(v);c=u(M,"BUTTON",{class:!0});var U=o(c);i=et(U,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var A=o(i);r=et(A,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(r).forEach(l),A.forEach(l),U.forEach(l),M.forEach(l),h=L(w),a=u(w,"DIV",{class:!0});var S=o(a);n=u(S,"A",{class:!0});var $=o(n);f=x($,"daisyUI"),$.forEach(l),S.forEach(l),E=L(w),I=u(w,"DIV",{class:!0});var m=o(I);g=u(m,"BUTTON",{class:!0});var H=o(g);b=et(H,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var j=o(b);y=et(j,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(y).forEach(l),j.forEach(l),H.forEach(l),m.forEach(l),w.forEach(l),this.h()},h(){s(r,"stroke-linecap","round"),s(r,"stroke-linejoin","round"),s(r,"stroke-width","2"),s(r,"d","M4 6h16M4 12h16M4 18h16"),s(i,"xmlns","http://www.w3.org/2000/svg"),s(i,"fill","none"),s(i,"viewBox","0 0 24 24"),s(i,"class","inline-block w-5 h-5 stroke-current"),s(c,"class","btn btn-square btn-ghost"),s(v,"class","flex-none"),s(n,"class","btn btn-ghost normal-case text-xl"),s(a,"class","flex-1"),s(y,"stroke-linecap","round"),s(y,"stroke-linejoin","round"),s(y,"stroke-width","2"),s(y,"d","M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"),s(b,"xmlns","http://www.w3.org/2000/svg"),s(b,"fill","none"),s(b,"viewBox","0 0 24 24"),s(b,"class","inline-block w-5 h-5 stroke-current"),s(g,"class","btn btn-square btn-ghost"),s(I,"class","flex-none"),s(t,"class","navbar bg-base-100 shadow-xl rounded-box")},m(N,w){B(N,t,w),e(t,v),e(v,c),e(c,i),e(i,r),e(t,h),e(t,a),e(a,n),e(n,f),e(t,E),e(t,I),e(I,g),e(g,b),e(b,y)},d(N){N&&l(t)}}}function Pe(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="flex-none">
    <button class="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-5 h-5 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
    </button>
  </div>
  <div class="flex-1">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="flex-none">
    <button class="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-5 h-5 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"></path></svg>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Se(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="flex-none">
    <button className="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-5 h-5 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
    </button>
  </div>
  <div className="flex-1">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="flex-none">
    <button className="$$btn $$btn-square $$btn-ghost">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-5 h-5 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"></path></svg>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function je(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S,$,m,H,j,z,G,D,V,T;return{c(){t=d("div"),v=d("div"),c=d("a"),i=_("daisyUI"),r=k(),h=d("div"),a=d("ul"),n=d("li"),f=d("a"),E=_("Item 1"),I=k(),g=d("li"),b=d("a"),y=_(`Parent
          `),N=tt("svg"),w=tt("path"),M=k(),U=d("ul"),A=d("li"),S=d("a"),$=_("Submenu 1"),m=k(),H=d("li"),j=d("a"),z=_("Submenu 2"),G=k(),D=d("li"),V=d("a"),T=_("Item 3"),this.h()},l(C){t=u(C,"DIV",{class:!0});var P=o(t);v=u(P,"DIV",{class:!0});var W=o(v);c=u(W,"A",{class:!0});var Y=o(c);i=x(Y,"daisyUI"),Y.forEach(l),W.forEach(l),r=L(P),h=u(P,"DIV",{class:!0});var Z=o(h);a=u(Z,"UL",{class:!0});var q=o(a);n=u(q,"LI",{});var R=o(n);f=u(R,"A",{});var K=o(f);E=x(K,"Item 1"),K.forEach(l),R.forEach(l),I=L(q),g=u(q,"LI",{tabindex:!0});var Q=o(g);b=u(Q,"A",{});var J=o(b);y=x(J,`Parent
          `),N=et(J,"svg",{class:!0,xmlns:!0,width:!0,height:!0,viewBox:!0});var it=o(N);w=et(it,"path",{d:!0}),o(w).forEach(l),it.forEach(l),J.forEach(l),M=L(Q),U=u(Q,"UL",{class:!0});var O=o(U);A=u(O,"LI",{});var F=o(A);S=u(F,"A",{});var ct=o(S);$=x(ct,"Submenu 1"),ct.forEach(l),F.forEach(l),m=L(O),H=u(O,"LI",{});var X=o(H);j=u(X,"A",{});var at=o(j);z=x(at,"Submenu 2"),at.forEach(l),X.forEach(l),O.forEach(l),Q.forEach(l),G=L(q),D=u(q,"LI",{});var lt=o(D);V=u(lt,"A",{});var st=o(V);T=x(st,"Item 3"),st.forEach(l),lt.forEach(l),q.forEach(l),Z.forEach(l),P.forEach(l),this.h()},h(){s(c,"class","btn btn-ghost normal-case text-xl"),s(v,"class","flex-1"),s(w,"d","M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"),s(N,"class","fill-current"),s(N,"xmlns","http://www.w3.org/2000/svg"),s(N,"width","20"),s(N,"height","20"),s(N,"viewBox","0 0 24 24"),s(U,"class","p-2 bg-base-100"),s(g,"tabindex","0"),s(a,"class","menu menu-horizontal px-1 bg-base-100"),s(h,"class","flex-none"),s(t,"class","navbar bg-base-100 mb-32 shadow-xl rounded-box")},m(C,P){B(C,t,P),e(t,v),e(v,c),e(c,i),e(t,r),e(t,h),e(h,a),e(a,n),e(n,f),e(f,E),e(a,I),e(a,g),e(g,b),e(b,y),e(b,N),e(N,w),e(g,M),e(g,U),e(U,A),e(A,S),e(S,$),e(U,m),e(U,H),e(H,j),e(j,z),e(a,G),e(a,D),e(D,V),e(V,T)},d(C){C&&l(t)}}}function De(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="flex-1">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="flex-none">
    <ul class="$$menu $$menu-horizontal px-1">
      <li><a>Item 1</a></li>
      <li tabindex="0">
        <a>
          Parent
          <svg class="fill-current" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/></svg>
        </a>
        <ul class="p-2 bg-base-100">
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
        </ul>
      </li>
      <li><a>Item 3</a></li>
    </ul>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function ze(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="flex-1">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="flex-none">
    <ul className="$$menu $$menu-horizontal px-1">
      <li><a>Item 1</a></li>
      <li tabIndex={0}>
        <a>
          Parent
          <svg className="fill-current" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/></svg>
        </a>
        <ul className="p-2 bg-base-100">
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
        </ul>
      </li>
      <li><a>Item 3</a></li>
    </ul>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ce(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S,$,m,H,j,z,G,D,V,T;return{c(){t=d("div"),v=d("div"),c=d("a"),i=_("daisyUI"),r=k(),h=d("div"),a=d("div"),n=d("input"),f=k(),E=d("div"),I=d("label"),g=d("div"),b=d("img"),N=k(),w=d("ul"),M=d("li"),U=d("a"),A=_(`Profile
            `),S=d("span"),$=_("New"),m=k(),H=d("li"),j=d("a"),z=_("Settings"),G=k(),D=d("li"),V=d("a"),T=_("Logout"),this.h()},l(C){t=u(C,"DIV",{class:!0});var P=o(t);v=u(P,"DIV",{class:!0});var W=o(v);c=u(W,"A",{class:!0});var Y=o(c);i=x(Y,"daisyUI"),Y.forEach(l),W.forEach(l),r=L(P),h=u(P,"DIV",{class:!0});var Z=o(h);a=u(Z,"DIV",{class:!0});var q=o(a);n=u(q,"INPUT",{type:!0,placeholder:!0,class:!0}),q.forEach(l),f=L(Z),E=u(Z,"DIV",{class:!0});var R=o(E);I=u(R,"LABEL",{tabindex:!0,class:!0});var K=o(I);g=u(K,"DIV",{class:!0});var Q=o(g);b=u(Q,"IMG",{src:!0}),Q.forEach(l),K.forEach(l),N=L(R),w=u(R,"UL",{tabindex:!0,class:!0});var J=o(w);M=u(J,"LI",{});var it=o(M);U=u(it,"A",{class:!0});var O=o(U);A=x(O,`Profile
            `),S=u(O,"SPAN",{class:!0});var F=o(S);$=x(F,"New"),F.forEach(l),O.forEach(l),it.forEach(l),m=L(J),H=u(J,"LI",{});var ct=o(H);j=u(ct,"A",{});var X=o(j);z=x(X,"Settings"),X.forEach(l),ct.forEach(l),G=L(J),D=u(J,"LI",{});var at=o(D);V=u(at,"A",{});var lt=o(V);T=x(lt,"Logout"),lt.forEach(l),at.forEach(l),J.forEach(l),R.forEach(l),Z.forEach(l),P.forEach(l),this.h()},h(){s(c,"class","btn btn-ghost normal-case text-xl"),s(v,"class","flex-1"),s(n,"type","text"),s(n,"placeholder","Search"),s(n,"class","input input-bordered"),s(a,"class","form-control"),fe(b.src,y="https://placeimg.com/80/80/people")||s(b,"src",y),s(g,"class","w-10 rounded-full"),s(I,"tabindex","0"),s(I,"class","btn btn-ghost btn-circle avatar"),s(S,"class","badge"),s(U,"class","justify-between"),s(w,"tabindex","0"),s(w,"class","mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52"),s(E,"class","dropdown dropdown-end"),s(h,"class","flex-none gap-2"),s(t,"class","navbar bg-base-100 mb-32 shadow-xl rounded-box")},m(C,P){B(C,t,P),e(t,v),e(v,c),e(c,i),e(t,r),e(t,h),e(h,a),e(a,n),e(h,f),e(h,E),e(E,I),e(I,g),e(g,b),e(E,N),e(E,w),e(w,M),e(M,U),e(U,A),e(U,S),e(S,$),e(w,m),e(w,H),e(H,j),e(j,z),e(w,G),e(w,D),e(D,V),e(V,T)},d(C){C&&l(t)}}}function Re(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="flex-1">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="flex-none gap-2">
    <div class="$$form-control">
      <input type="text" placeholder="Search" class="$$input $$input-bordered" />
    </div>
    <div class="$$dropdown $$dropdown-end">
      <label tabindex="0" class="btn btn-ghost btn-circle avatar">
        <div class="w-10 rounded-full">
          <img src="https://placeimg.com/80/80/people" />
        </div>
      </label>
      <ul tabindex="0" class="mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52">
        <li>
          <a class="justify-between">
            Profile
            <span class="$$badge">New</span>
          </a>
        </li>
        <li><a>Settings</a></li>
        <li><a>Logout</a></li>
      </ul>
    </div>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function He(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="flex-1">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="flex-none gap-2">
    <div className="$$form-control">
      <input type="text" placeholder="Search" className="$$input $$input-bordered" />
    </div>
    <div className="$$dropdown $$dropdown-end">
      <label tabIndex={0} className="btn btn-ghost btn-circle avatar">
        <div className="w-10 rounded-full">
          <img src="https://placeimg.com/80/80/people" />
        </div>
      </label>
      <ul tabIndex={0} className="mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52">
        <li>
          <a className="justify-between">
            Profile
            <span className="$$badge">New</span>
          </a>
        </li>
        <li><a>Settings</a></li>
        <li><a>Logout</a></li>
      </ul>
    </div>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Te(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S,$,m,H,j,z,G,D,V,T,C,P,W,Y,Z,q,R,K,Q,J,it,O,F,ct,X,at,lt,st;return{c(){t=d("div"),v=d("div"),c=d("a"),i=_("daisyUI"),r=k(),h=d("div"),a=d("div"),n=d("label"),f=d("div"),E=tt("svg"),I=tt("path"),g=k(),b=d("span"),y=_("8"),N=k(),w=d("div"),M=d("div"),U=d("span"),A=_("8 Items"),S=k(),$=d("span"),m=_("Subtotal: $999"),H=k(),j=d("div"),z=d("button"),G=_("View cart"),D=k(),V=d("div"),T=d("label"),C=d("div"),P=d("img"),Y=k(),Z=d("ul"),q=d("li"),R=d("a"),K=_(`Profile
            `),Q=d("span"),J=_("New"),it=k(),O=d("li"),F=d("a"),ct=_("Settings"),X=k(),at=d("li"),lt=d("a"),st=_("Logout"),this.h()},l(ut){t=u(ut,"DIV",{class:!0});var dt=o(t);v=u(dt,"DIV",{class:!0});var Lt=o(v);c=u(Lt,"A",{class:!0});var mt=o(c);i=x(mt,"daisyUI"),mt.forEach(l),Lt.forEach(l),r=L(dt),h=u(dt,"DIV",{class:!0});var vt=o(h);a=u(vt,"DIV",{class:!0});var ht=o(a);n=u(ht,"LABEL",{tabindex:!0,class:!0});var Nt=o(n);f=u(Nt,"DIV",{class:!0});var $t=o(f);E=et($t,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var pt=o(E);I=et(pt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(I).forEach(l),pt.forEach(l),g=L($t),b=u($t,"SPAN",{class:!0});var At=o(b);y=x(At,"8"),At.forEach(l),$t.forEach(l),Nt.forEach(l),N=L(ht),w=u(ht,"DIV",{tabindex:!0,class:!0});var Dt=o(w);M=u(Dt,"DIV",{class:!0});var It=o(M);U=u(It,"SPAN",{class:!0});var Mt=o(U);A=x(Mt,"8 Items"),Mt.forEach(l),S=L(It),$=u(It,"SPAN",{class:!0});var yt=o($);m=x(yt,"Subtotal: $999"),yt.forEach(l),H=L(It),j=u(It,"DIV",{class:!0});var zt=o(j);z=u(zt,"BUTTON",{class:!0});var Vt=o(z);G=x(Vt,"View cart"),Vt.forEach(l),zt.forEach(l),It.forEach(l),Dt.forEach(l),ht.forEach(l),D=L(vt),V=u(vt,"DIV",{class:!0});var bt=o(V);T=u(bt,"LABEL",{tabindex:!0,class:!0});var Pt=o(T);C=u(Pt,"DIV",{class:!0});var St=o(C);P=u(St,"IMG",{src:!0}),St.forEach(l),Pt.forEach(l),Y=L(bt),Z=u(bt,"UL",{tabindex:!0,class:!0});var Ut=o(Z);q=u(Ut,"LI",{});var Ht=o(q);R=u(Ht,"A",{class:!0});var kt=o(R);K=x(kt,`Profile
            `),Q=u(kt,"SPAN",{class:!0});var Tt=o(Q);J=x(Tt,"New"),Tt.forEach(l),kt.forEach(l),Ht.forEach(l),it=L(Ut),O=u(Ut,"LI",{});var qt=o(O);F=u(qt,"A",{});var jt=o(F);ct=x(jt,"Settings"),jt.forEach(l),qt.forEach(l),X=L(Ut),at=u(Ut,"LI",{});var Ct=o(at);lt=u(Ct,"A",{});var Zt=o(lt);st=x(Zt,"Logout"),Zt.forEach(l),Ct.forEach(l),Ut.forEach(l),bt.forEach(l),vt.forEach(l),dt.forEach(l),this.h()},h(){s(c,"class","btn btn-ghost normal-case text-xl"),s(v,"class","flex-1"),s(I,"stroke-linecap","round"),s(I,"stroke-linejoin","round"),s(I,"stroke-width","2"),s(I,"d","M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"),s(E,"xmlns","http://www.w3.org/2000/svg"),s(E,"class","h-5 w-5"),s(E,"fill","none"),s(E,"viewBox","0 0 24 24"),s(E,"stroke","currentColor"),s(b,"class","badge badge-sm indicator-item"),s(f,"class","indicator"),s(n,"tabindex","0"),s(n,"class","btn btn-ghost btn-circle"),s(U,"class","font-bold text-lg"),s($,"class","text-info"),s(z,"class","btn btn-primary btn-block"),s(j,"class","card-actions"),s(M,"class","card-body"),s(w,"tabindex","0"),s(w,"class","mt-3 card card-compact w-52 dropdown-content bg-base-100 shadow"),s(a,"class","dropdown dropdown-end"),fe(P.src,W="https://placeimg.com/80/80/people")||s(P,"src",W),s(C,"class","w-10 rounded-full"),s(T,"tabindex","0"),s(T,"class","btn btn-ghost btn-circle avatar"),s(Q,"class","badge"),s(R,"class","justify-between"),s(Z,"tabindex","0"),s(Z,"class","mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52"),s(V,"class","dropdown dropdown-end"),s(h,"class","flex-none"),s(t,"class","navbar bg-base-100 mb-40 shadow-xl rounded-box")},m(ut,dt){B(ut,t,dt),e(t,v),e(v,c),e(c,i),e(t,r),e(t,h),e(h,a),e(a,n),e(n,f),e(f,E),e(E,I),e(f,g),e(f,b),e(b,y),e(a,N),e(a,w),e(w,M),e(M,U),e(U,A),e(M,S),e(M,$),e($,m),e(M,H),e(M,j),e(j,z),e(z,G),e(h,D),e(h,V),e(V,T),e(T,C),e(C,P),e(V,Y),e(V,Z),e(Z,q),e(q,R),e(R,K),e(R,Q),e(Q,J),e(Z,it),e(Z,O),e(O,F),e(F,ct),e(Z,X),e(Z,at),e(at,lt),e(lt,st)},d(ut){ut&&l(t)}}}function qe(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="flex-1">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="flex-none">
    <div class="$$dropdown $$dropdown-end">
      <label tabindex="0" class="$$btn $$btn-ghost $$btn-circle">
        <div class="$$indicator">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          <span class="$$badge $$badge-sm $$indicator-item">8</span>
        </div>
      </label>
      <div tabindex="0" class="mt-3 $$card $$card-compact $$dropdown-content w-52 bg-base-100 shadow">
        <div class="$$card-body">
          <span class="font-bold text-lg">8 Items</span>
          <span class="text-info">Subtotal: $999</span>
          <div class="$$card-actions">
            <button class="$$btn $$btn-primary $$btn-block">View cart</button>
          </div>
        </div>
      </div>
    </div>
    <div class="$$dropdown $$dropdown-end">
      <label tabindex="0" class="$$btn $$btn-ghost $$btn-circle $$avatar">
        <div class="w-10 rounded-full">
          <img src="https://placeimg.com/80/80/people" />
        </div>
      </label>
      <ul tabindex="0" class="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li>
          <a class="justify-between">
            Profile
            <span class="$$badge">New</span>
          </a>
        </li>
        <li><a>Settings</a></li>
        <li><a>Logout</a></li>
      </ul>
    </div>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ze(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="flex-1">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="flex-none">
    <div className="$$dropdown $$dropdown-end">
      <label tabIndex={0} className="$$btn $$btn-ghost $$btn-circle">
        <div className="$$indicator">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          <span className="$$badge $$badge-sm $$indicator-item">8</span>
        </div>
      </label>
      <div tabIndex={0} className="mt-3 $$card $$card-compact $$dropdown-content w-52 bg-base-100 shadow">
        <div className="$$card-body">
          <span className="font-bold text-lg">8 Items</span>
          <span className="text-info">Subtotal: $999</span>
          <div className="$$card-actions">
            <button className="$$btn $$btn-primary $$btn-block">View cart</button>
          </div>
        </div>
      </div>
    </div>
    <div className="$$dropdown $$dropdown-end">
      <label tabIndex={0} className="$$btn $$btn-ghost $$btn-circle $$avatar">
        <div className="w-10 rounded-full">
          <img src="https://placeimg.com/80/80/people" />
        </div>
      </label>
      <ul tabIndex={0} className="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li>
          <a className="justify-between">
            Profile
            <span className="$$badge">New</span>
          </a>
        </li>
        <li><a>Settings</a></li>
        <li><a>Logout</a></li>
      </ul>
    </div>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function We(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S,$,m,H,j,z,G,D,V,T,C,P,W,Y,Z,q;return{c(){t=d("div"),v=d("div"),c=d("div"),i=d("label"),r=tt("svg"),h=tt("path"),a=k(),n=d("ul"),f=d("li"),E=d("a"),I=_("Homepage"),g=k(),b=d("li"),y=d("a"),N=_("Portfolio"),w=k(),M=d("li"),U=d("a"),A=_("About"),S=k(),$=d("div"),m=d("a"),H=_("daisyUI"),j=k(),z=d("div"),G=d("button"),D=tt("svg"),V=tt("path"),T=k(),C=d("button"),P=d("div"),W=tt("svg"),Y=tt("path"),Z=k(),q=d("span"),this.h()},l(R){t=u(R,"DIV",{class:!0});var K=o(t);v=u(K,"DIV",{class:!0});var Q=o(v);c=u(Q,"DIV",{class:!0});var J=o(c);i=u(J,"LABEL",{tabindex:!0,class:!0});var it=o(i);r=et(it,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var O=o(r);h=et(O,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(h).forEach(l),O.forEach(l),it.forEach(l),a=L(J),n=u(J,"UL",{tabindex:!0,class:!0});var F=o(n);f=u(F,"LI",{});var ct=o(f);E=u(ct,"A",{});var X=o(E);I=x(X,"Homepage"),X.forEach(l),ct.forEach(l),g=L(F),b=u(F,"LI",{});var at=o(b);y=u(at,"A",{});var lt=o(y);N=x(lt,"Portfolio"),lt.forEach(l),at.forEach(l),w=L(F),M=u(F,"LI",{});var st=o(M);U=u(st,"A",{});var ut=o(U);A=x(ut,"About"),ut.forEach(l),st.forEach(l),F.forEach(l),J.forEach(l),Q.forEach(l),S=L(K),$=u(K,"DIV",{class:!0});var dt=o($);m=u(dt,"A",{class:!0});var Lt=o(m);H=x(Lt,"daisyUI"),Lt.forEach(l),dt.forEach(l),j=L(K),z=u(K,"DIV",{class:!0});var mt=o(z);G=u(mt,"BUTTON",{class:!0});var vt=o(G);D=et(vt,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var ht=o(D);V=et(ht,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(V).forEach(l),ht.forEach(l),vt.forEach(l),T=L(mt),C=u(mt,"BUTTON",{class:!0});var Nt=o(C);P=u(Nt,"DIV",{class:!0});var $t=o(P);W=et($t,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var pt=o(W);Y=et(pt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(Y).forEach(l),pt.forEach(l),Z=L($t),q=u($t,"SPAN",{class:!0}),o(q).forEach(l),$t.forEach(l),Nt.forEach(l),mt.forEach(l),K.forEach(l),this.h()},h(){s(h,"stroke-linecap","round"),s(h,"stroke-linejoin","round"),s(h,"stroke-width","2"),s(h,"d","M4 6h16M4 12h16M4 18h7"),s(r,"xmlns","http://www.w3.org/2000/svg"),s(r,"class","h-5 w-5"),s(r,"fill","none"),s(r,"viewBox","0 0 24 24"),s(r,"stroke","currentColor"),s(i,"tabindex","0"),s(i,"class","btn btn-ghost btn-circle"),s(n,"tabindex","0"),s(n,"class","mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52"),s(c,"class","dropdown"),s(v,"class","navbar-start"),s(m,"class","btn btn-ghost normal-case text-xl"),s($,"class","navbar-center"),s(V,"stroke-linecap","round"),s(V,"stroke-linejoin","round"),s(V,"stroke-width","2"),s(V,"d","M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"),s(D,"xmlns","http://www.w3.org/2000/svg"),s(D,"class","h-5 w-5"),s(D,"fill","none"),s(D,"viewBox","0 0 24 24"),s(D,"stroke","currentColor"),s(G,"class","btn btn-ghost btn-circle"),s(Y,"stroke-linecap","round"),s(Y,"stroke-linejoin","round"),s(Y,"stroke-width","2"),s(Y,"d","M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"),s(W,"xmlns","http://www.w3.org/2000/svg"),s(W,"class","h-5 w-5"),s(W,"fill","none"),s(W,"viewBox","0 0 24 24"),s(W,"stroke","currentColor"),s(q,"class","badge badge-xs badge-primary indicator-item"),s(P,"class","indicator"),s(C,"class","btn btn-ghost btn-circle"),s(z,"class","navbar-end"),s(t,"class","navbar bg-base-100 mb-40 shadow-xl rounded-box")},m(R,K){B(R,t,K),e(t,v),e(v,c),e(c,i),e(i,r),e(r,h),e(c,a),e(c,n),e(n,f),e(f,E),e(E,I),e(n,g),e(n,b),e(b,y),e(y,N),e(n,w),e(n,M),e(M,U),e(U,A),e(t,S),e(t,$),e($,m),e(m,H),e(t,j),e(t,z),e(z,G),e(G,D),e(D,V),e(z,T),e(z,C),e(C,P),e(P,W),e(W,Y),e(P,Z),e(P,q)},d(R){R&&l(t)}}}function Oe(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="$$navbar-start">
    <div class="$$dropdown">
      <label tabindex="0" class="$$btn $$btn-ghost $$btn-circle">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7" /></svg>
      </label>
      <ul tabindex="0" class="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li><a>Homepage</a></li>
        <li><a>Portfolio</a></li>
        <li><a>About</a></li>
      </ul>
    </div>
  </div>
  <div class="$$navbar-center">
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="$$navbar-end">
    <button class="$$btn $$btn-ghost $$btn-circle">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    </button>
    <button class="$$btn $$btn-ghost $$btn-circle">
      <div class="$$indicator">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
        <span class="$$badge $$badge-xs $$badge-primary $$indicator-item"></span>
      </div>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ge(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="$$navbar-start">
    <div className="$$dropdown">
      <label tabIndex={0} className="$$btn $$btn-ghost $$btn-circle">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h7" /></svg>
      </label>
      <ul tabIndex={0} className="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li><a>Homepage</a></li>
        <li><a>Portfolio</a></li>
        <li><a>About</a></li>
      </ul>
    </div>
  </div>
  <div className="$$navbar-center">
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="$$navbar-end">
    <button className="$$btn $$btn-ghost $$btn-circle">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    </button>
    <button className="$$btn $$btn-ghost $$btn-circle">
      <div className="$$indicator">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
        <span className="$$badge $$badge-xs $$badge-primary $$indicator-item"></span>
      </div>
    </button>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Fe(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S,$,m,H,j,z,G,D,V,T,C,P,W,Y,Z,q,R,K,Q,J,it,O,F,ct,X,at,lt,st,ut,dt,Lt,mt,vt,ht,Nt,$t,pt,At,Dt,It,Mt,yt,zt;return{c(){t=d("div"),v=d("div"),c=d("div"),i=d("label"),r=tt("svg"),h=tt("path"),a=k(),n=d("ul"),f=d("li"),E=d("a"),I=_("Item 1"),g=k(),b=d("li"),y=d("a"),N=_(`Parent
            `),w=tt("svg"),M=tt("path"),U=k(),A=d("ul"),S=d("li"),$=d("a"),m=_("Submenu 1"),H=k(),j=d("li"),z=d("a"),G=_("Submenu 2"),D=k(),V=d("li"),T=d("a"),C=_("Item 3"),P=k(),W=d("a"),Y=_("daisyUI"),Z=k(),q=d("div"),R=d("ul"),K=d("li"),Q=d("a"),J=_("Item 1"),it=k(),O=d("li"),F=d("a"),ct=_(`Parent
          `),X=tt("svg"),at=tt("path"),lt=k(),st=d("ul"),ut=d("li"),dt=d("a"),Lt=_("Submenu 1"),mt=k(),vt=d("li"),ht=d("a"),Nt=_("Submenu 2"),$t=k(),pt=d("li"),At=d("a"),Dt=_("Item 3"),It=k(),Mt=d("div"),yt=d("a"),zt=_("Get started"),this.h()},l(Vt){t=u(Vt,"DIV",{class:!0});var bt=o(t);v=u(bt,"DIV",{class:!0});var Pt=o(v);c=u(Pt,"DIV",{class:!0});var St=o(c);i=u(St,"LABEL",{tabindex:!0,class:!0});var Ut=o(i);r=et(Ut,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var Ht=o(r);h=et(Ht,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(h).forEach(l),Ht.forEach(l),Ut.forEach(l),a=L(St),n=u(St,"UL",{tabindex:!0,class:!0});var kt=o(n);f=u(kt,"LI",{});var Tt=o(f);E=u(Tt,"A",{});var qt=o(E);I=x(qt,"Item 1"),qt.forEach(l),Tt.forEach(l),g=L(kt),b=u(kt,"LI",{tabindex:!0});var jt=o(b);y=u(jt,"A",{class:!0});var Ct=o(y);N=x(Ct,`Parent
            `),w=et(Ct,"svg",{class:!0,xmlns:!0,width:!0,height:!0,viewBox:!0});var Zt=o(w);M=et(Zt,"path",{d:!0}),o(M).forEach(l),Zt.forEach(l),Ct.forEach(l),U=L(jt),A=u(jt,"UL",{class:!0});var Wt=o(A);S=u(Wt,"LI",{});var Qt=o(S);$=u(Qt,"A",{});var Jt=o($);m=x(Jt,"Submenu 1"),Jt.forEach(l),Qt.forEach(l),H=L(Wt),j=u(Wt,"LI",{});var Xt=o(j);z=u(Xt,"A",{});var Yt=o(z);G=x(Yt,"Submenu 2"),Yt.forEach(l),Xt.forEach(l),Wt.forEach(l),jt.forEach(l),D=L(kt),V=u(kt,"LI",{});var te=o(V);T=u(te,"A",{});var ee=o(T);C=x(ee,"Item 3"),ee.forEach(l),te.forEach(l),kt.forEach(l),St.forEach(l),P=L(Pt),W=u(Pt,"A",{class:!0});var ae=o(W);Y=x(ae,"daisyUI"),ae.forEach(l),Pt.forEach(l),Z=L(bt),q=u(bt,"DIV",{class:!0});var le=o(q);R=u(le,"UL",{class:!0});var Rt=o(R);K=u(Rt,"LI",{});var se=o(K);Q=u(se,"A",{});var ne=o(Q);J=x(ne,"Item 1"),ne.forEach(l),se.forEach(l),it=L(Rt),O=u(Rt,"LI",{tabindex:!0});var Ot=o(O);F=u(Ot,"A",{});var Ft=o(F);ct=x(Ft,`Parent
          `),X=et(Ft,"svg",{class:!0,xmlns:!0,width:!0,height:!0,viewBox:!0});var oe=o(X);at=et(oe,"path",{d:!0}),o(at).forEach(l),oe.forEach(l),Ft.forEach(l),lt=L(Ot),st=u(Ot,"UL",{class:!0});var Gt=o(st);ut=u(Gt,"LI",{});var re=o(ut);dt=u(re,"A",{});var ie=o(dt);Lt=x(ie,"Submenu 1"),ie.forEach(l),re.forEach(l),mt=L(Gt),vt=u(Gt,"LI",{});var ce=o(vt);ht=u(ce,"A",{});var de=o(ht);Nt=x(de,"Submenu 2"),de.forEach(l),ce.forEach(l),Gt.forEach(l),Ot.forEach(l),$t=L(Rt),pt=u(Rt,"LI",{});var ue=o(pt);At=u(ue,"A",{});var ve=o(At);Dt=x(ve,"Item 3"),ve.forEach(l),ue.forEach(l),Rt.forEach(l),le.forEach(l),It=L(bt),Mt=u(bt,"DIV",{class:!0});var he=o(Mt);yt=u(he,"A",{class:!0});var $e=o(yt);zt=x($e,"Get started"),$e.forEach(l),he.forEach(l),bt.forEach(l),this.h()},h(){s(h,"stroke-linecap","round"),s(h,"stroke-linejoin","round"),s(h,"stroke-width","2"),s(h,"d","M4 6h16M4 12h8m-8 6h16"),s(r,"xmlns","http://www.w3.org/2000/svg"),s(r,"class","h-5 w-5"),s(r,"fill","none"),s(r,"viewBox","0 0 24 24"),s(r,"stroke","currentColor"),s(i,"tabindex","0"),s(i,"class","btn btn-ghost lg:hidden"),s(M,"d","M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"),s(w,"class","fill-current"),s(w,"xmlns","http://www.w3.org/2000/svg"),s(w,"width","24"),s(w,"height","24"),s(w,"viewBox","0 0 24 24"),s(y,"class","justify-between"),s(A,"class","p-2 bg-base-100"),s(b,"tabindex","0"),s(n,"tabindex","0"),s(n,"class","mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52"),s(c,"class","dropdown"),s(W,"class","btn btn-ghost normal-case text-xl"),s(v,"class","navbar-start"),s(at,"d","M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"),s(X,"class","fill-current"),s(X,"xmlns","http://www.w3.org/2000/svg"),s(X,"width","20"),s(X,"height","20"),s(X,"viewBox","0 0 24 24"),s(st,"class","p-2 bg-base-100"),s(O,"tabindex","0"),s(R,"class","menu menu-horizontal px-1"),s(q,"class","navbar-center hidden lg:flex"),s(yt,"class","btn"),s(Mt,"class","navbar-end"),s(t,"class","navbar bg-base-100 mb-32 shadow-xl rounded-box")},m(Vt,bt){B(Vt,t,bt),e(t,v),e(v,c),e(c,i),e(i,r),e(r,h),e(c,a),e(c,n),e(n,f),e(f,E),e(E,I),e(n,g),e(n,b),e(b,y),e(y,N),e(y,w),e(w,M),e(b,U),e(b,A),e(A,S),e(S,$),e($,m),e(A,H),e(A,j),e(j,z),e(z,G),e(n,D),e(n,V),e(V,T),e(T,C),e(v,P),e(v,W),e(W,Y),e(t,Z),e(t,q),e(q,R),e(R,K),e(K,Q),e(Q,J),e(R,it),e(R,O),e(O,F),e(F,ct),e(F,X),e(X,at),e(O,lt),e(O,st),e(st,ut),e(ut,dt),e(dt,Lt),e(st,mt),e(st,vt),e(vt,ht),e(ht,Nt),e(R,$t),e(R,pt),e(pt,At),e(At,Dt),e(t,It),e(t,Mt),e(Mt,yt),e(yt,zt)},d(Vt){Vt&&l(t)}}}function Ke(p){let t,v=`<div class="$$navbar bg-base-100">
  <div class="$$navbar-start">
    <div class="$$dropdown">
      <label tabindex="0" class="$$btn $$btn-ghost lg:hidden">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16" /></svg>
      </label>
      <ul tabindex="0" class="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li><a>Item 1</a></li>
        <li tabindex="0">
          <a class="justify-between">
            Parent
            <svg class="fill-current" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"/></svg>
          </a>
          <ul class="p-2">
            <li><a>Submenu 1</a></li>
            <li><a>Submenu 2</a></li>
          </ul>
        </li>
        <li><a>Item 3</a></li>
      </ul>
    </div>
    <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div class="$$navbar-center hidden lg:flex">
    <ul class="$$menu $$menu-horizontal px-1">
      <li><a>Item 1</a></li>
      <li tabindex="0">
        <a>
          Parent
          <svg class="fill-current" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/></svg>
        </a>
        <ul class="p-2">
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
        </ul>
      </li>
      <li><a>Item 3</a></li>
    </ul>
  </div>
  <div class="$$navbar-end">
    <a class="$$btn">Get started</a>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Qe(p){let t,v=`<div className="$$navbar bg-base-100">
  <div className="$$navbar-start">
    <div className="$$dropdown">
      <label tabIndex={0} className="$$btn $$btn-ghost lg:hidden">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h8m-8 6h16" /></svg>
      </label>
      <ul tabIndex={0} className="$$menu $$menu-compact $$dropdown-content mt-3 p-2 shadow bg-base-100 rounded-box w-52">
        <li><a>Item 1</a></li>
        <li tabIndex={0}>
          <a className="justify-between">
            Parent
            <svg className="fill-current" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"/></svg>
          </a>
          <ul className="p-2">
            <li><a>Submenu 1</a></li>
            <li><a>Submenu 2</a></li>
          </ul>
        </li>
        <li><a>Item 3</a></li>
      </ul>
    </div>
    <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
  </div>
  <div className="$$navbar-center hidden lg:flex">
    <ul className="$$menu $$menu-horizontal px-1">
      <li><a>Item 1</a></li>
      <li tabIndex={0}>
        <a>
          Parent
          <svg className="fill-current" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/></svg>
        </a>
        <ul className="p-2">
          <li><a>Submenu 1</a></li>
          <li><a>Submenu 2</a></li>
        </ul>
      </li>
      <li><a>Item 3</a></li>
    </ul>
  </div>
  <div className="$$navbar-end">
    <a className="$$btn">Get started</a>
  </div>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Je(p){let t,v,c,i,r,h,a,n,f,E,I;return{c(){t=d("div"),v=d("a"),c=_("daisyUI"),i=k(),r=d("div"),h=d("a"),a=_("daisyUI"),n=k(),f=d("div"),E=d("a"),I=_("daisyUI"),this.h()},l(g){t=u(g,"DIV",{class:!0});var b=o(t);v=u(b,"A",{class:!0});var y=o(v);c=x(y,"daisyUI"),y.forEach(l),b.forEach(l),i=L(g),r=u(g,"DIV",{class:!0});var N=o(r);h=u(N,"A",{class:!0});var w=o(h);a=x(w,"daisyUI"),w.forEach(l),N.forEach(l),n=L(g),f=u(g,"DIV",{class:!0});var M=o(f);E=u(M,"A",{class:!0});var U=o(E);I=x(U,"daisyUI"),U.forEach(l),M.forEach(l),this.h()},h(){s(v,"class","btn btn-ghost normal-case text-xl"),s(t,"class","navbar bg-neutral text-neutral-content shadow-xl rounded-box"),s(h,"class","btn btn-ghost normal-case text-xl"),s(r,"class","navbar bg-base-300 shadow-xl rounded-box"),s(E,"class","btn btn-ghost normal-case text-xl"),s(f,"class","navbar bg-primary text-primary-content shadow-xl rounded-box")},m(g,b){B(g,t,b),e(t,v),e(v,c),B(g,i,b),B(g,r,b),e(r,h),e(h,a),B(g,n,b),B(g,f,b),e(f,E),e(E,I)},d(g){g&&l(t),g&&l(i),g&&l(r),g&&l(n),g&&l(f)}}}function Xe(p){let t,v=`<div class="$$navbar bg-neutral text-neutral-content">
  <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>
<div class="$$navbar bg-base-300">
  <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>
<div class="$$navbar bg-primary text-primary-content">
  <a class="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","html")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function Ye(p){let t,v=`<div className="$$navbar bg-neutral text-neutral-content">
  <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>
<div className="$$navbar bg-base-300">
  <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>
<div className="$$navbar bg-primary text-primary-content">
  <a className="$$btn $$btn-ghost normal-case text-xl">daisyUI</a>
</div>`,c,i,r,h;return{c(){t=d("pre"),c=_(v),this.h()},l(a){t=u(a,"PRE",{slot:!0});var n=o(t);c=x(n,v),n.forEach(l),this.h()},h(){s(t,"slot","react")},m(a,n){B(a,t,n),e(t,c),r||(h=nt(i=rt.call(null,t,{to:p[0]})),r=!0)},p(a,n){i&&ot(i.update)&&n&1&&i.update.call(null,{to:a[0]})},d(a){a&&l(t),r=!1,h()}}}function ta(p){let t,v,c,i,r,h,a,n,f,E,I,g,b,y,N,w,M,U,A,S;return t=new Le({props:{data:[{type:"component",class:"navbar",desc:"Container element"},{type:"component",class:"navbar-start",desc:"Child element, fills 50% of width to be on start"},{type:"component",class:"navbar-center",desc:"Child element, fills remaining space to be on center"},{type:"component",class:"navbar-end",desc:"Child element, fills 50% of width to be on end"}]}}),c=new Bt({props:{title:"Navbar with title only",$$slots:{react:[ye],html:[Me],default:[Ne]},$$scope:{ctx:p}}}),r=new Bt({props:{title:"Navbar with title and icon",$$slots:{react:[Ae],html:[Be],default:[Ue]},$$scope:{ctx:p}}}),a=new Bt({props:{title:"Navbar with icon at start and end",$$slots:{react:[Se],html:[Pe],default:[Ve]},$$scope:{ctx:p}}}),f=new Bt({props:{title:"Navbar with menu and submenu",$$slots:{react:[ze],html:[De],default:[je]},$$scope:{ctx:p}}}),I=new Bt({props:{title:"Navbar with search input and dropdown",$$slots:{react:[He],html:[Re],default:[Ce]},$$scope:{ctx:p}}}),b=new Bt({props:{title:"Navbar with icon, indicator and dropdown",$$slots:{react:[Ze],html:[qe],default:[Te]},$$scope:{ctx:p}}}),N=new Bt({props:{title:"Navbar with dropdown, center logo and icon",$$slots:{react:[Ge],html:[Oe],default:[We]},$$scope:{ctx:p}}}),M=new Bt({props:{title:"responsive (dropdown menu on small screen, center menu on large screen)",desc:"Resize screen to see changes",$$slots:{react:[Qe],html:[Ke],default:[Fe]},$$scope:{ctx:p}}}),A=new Bt({props:{title:"Navbar with colors",$$slots:{react:[Ye],html:[Xe],default:[Je]},$$scope:{ctx:p}}}),{c(){ft(t.$$.fragment),v=k(),ft(c.$$.fragment),i=k(),ft(r.$$.fragment),h=k(),ft(a.$$.fragment),n=k(),ft(f.$$.fragment),E=k(),ft(I.$$.fragment),g=k(),ft(b.$$.fragment),y=k(),ft(N.$$.fragment),w=k(),ft(M.$$.fragment),U=k(),ft(A.$$.fragment)},l($){gt(t.$$.fragment,$),v=L($),gt(c.$$.fragment,$),i=L($),gt(r.$$.fragment,$),h=L($),gt(a.$$.fragment,$),n=L($),gt(f.$$.fragment,$),E=L($),gt(I.$$.fragment,$),g=L($),gt(b.$$.fragment,$),y=L($),gt(N.$$.fragment,$),w=L($),gt(M.$$.fragment,$),U=L($),gt(A.$$.fragment,$)},m($,m){wt(t,$,m),B($,v,m),wt(c,$,m),B($,i,m),wt(r,$,m),B($,h,m),wt(a,$,m),B($,n,m),wt(f,$,m),B($,E,m),wt(I,$,m),B($,g,m),wt(b,$,m),B($,y,m),wt(N,$,m),B($,w,m),wt(M,$,m),B($,U,m),wt(A,$,m),S=!0},p($,m){const H={};m&5&&(H.$$scope={dirty:m,ctx:$}),c.$set(H);const j={};m&5&&(j.$$scope={dirty:m,ctx:$}),r.$set(j);const z={};m&5&&(z.$$scope={dirty:m,ctx:$}),a.$set(z);const G={};m&5&&(G.$$scope={dirty:m,ctx:$}),f.$set(G);const D={};m&5&&(D.$$scope={dirty:m,ctx:$}),I.$set(D);const V={};m&5&&(V.$$scope={dirty:m,ctx:$}),b.$set(V);const T={};m&5&&(T.$$scope={dirty:m,ctx:$}),N.$set(T);const C={};m&5&&(C.$$scope={dirty:m,ctx:$}),M.$set(C);const P={};m&5&&(P.$$scope={dirty:m,ctx:$}),A.$set(P)},i($){S||(_t(t.$$.fragment,$),_t(c.$$.fragment,$),_t(r.$$.fragment,$),_t(a.$$.fragment,$),_t(f.$$.fragment,$),_t(I.$$.fragment,$),_t(b.$$.fragment,$),_t(N.$$.fragment,$),_t(M.$$.fragment,$),_t(A.$$.fragment,$),S=!0)},o($){xt(t.$$.fragment,$),xt(c.$$.fragment,$),xt(r.$$.fragment,$),xt(a.$$.fragment,$),xt(f.$$.fragment,$),xt(I.$$.fragment,$),xt(b.$$.fragment,$),xt(N.$$.fragment,$),xt(M.$$.fragment,$),xt(A.$$.fragment,$),S=!1},d($){Et(t,$),$&&l(v),Et(c,$),$&&l(i),Et(r,$),$&&l(h),Et(a,$),$&&l(n),Et(f,$),$&&l(E),Et(I,$),$&&l(g),Et(b,$),$&&l(y),Et(N,$),$&&l(w),Et(M,$),$&&l(U),Et(A,$)}}}function ea(p){let t,v;const c=[p[1],pe];let i={$$slots:{default:[ta]},$$scope:{ctx:p}};for(let r=0;r<c.length;r+=1)i=Kt(i,c[r]);return t=new Ie({props:i}),{c(){ft(t.$$.fragment)},l(r){gt(t.$$.fragment,r)},m(r,h){wt(t,r,h),v=!0},p(r,[h]){const a=h&2?xe(c,[h&2&&be(r[1]),h&0&&be(pe)]):{};h&5&&(a.$$scope={dirty:h,ctx:r}),t.$set(a)},i(r){v||(_t(t.$$.fragment,r),v=!0)},o(r){xt(t.$$.fragment,r),v=!1},d(r){Et(t,r)}}}const pe={title:"Navbar",desc:"Navbar is used to show a navigation bar on the top of the page.",published:!0};function aa(p,t,v){let c;return Ee(p,ke,i=>v(0,c=i)),p.$$set=i=>{v(1,t=Kt(Kt({},t),me(i)))},t=me(t),[c,t]}class va extends ge{constructor(t){super();we(this,t,aa,ea,_e,{})}}export{va as default,pe as metadata};
