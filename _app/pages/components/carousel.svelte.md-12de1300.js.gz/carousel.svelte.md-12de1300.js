import{S as ye,i as ke,s as Be,C as Ee,w as ee,x as le,y as te,z as Re,A as Te,q as se,o as ae,B as ce,K as je,ag as ze,k as E,m as N,g as B,d as m,e as c,c as r,a as p,O as C,b as l,F as s,t as W,h as H,a9 as U,W as X}from"../../chunks/vendor-c5cb7521.js";import{M as Ae}from"../../chunks/_markdown-2bb6eb92.js";import{p as qe,C as Fe,a as me,r as Y}from"../../chunks/actions-9cbde582.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-37bcce46.js";import"../../chunks/index-c392802f.js";import"../../chunks/SEO-ab6f9e0c.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-2898e6eb.js";function Ke(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/400/300/arch")||l(i,"src",h),l(i,"alt","Burger"),l(u,"class","carousel-item"),C(t.src,a="https://placeimg.com/400/300/arch")||l(t,"src",a),l(t,"alt","Burger"),l(v,"class","carousel-item"),C($.src,F="https://placeimg.com/400/300/arch")||l($,"src",F),l($,"alt","Burger"),l(b,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||l(w,"src",K),l(w,"alt","Burger"),l(I,"class","carousel-item"),C(_.src,A="https://placeimg.com/400/300/arch")||l(_,"src",A),l(_,"alt","Burger"),l(g,"class","carousel-item"),C(S.src,R="https://placeimg.com/400/300/arch")||l(S,"src",R),l(S,"alt","Burger"),l(f,"class","carousel-item"),C(D.src,y="https://placeimg.com/400/300/arch")||l(D,"src",y),l(D,"alt","Burger"),l(V,"class","carousel-item"),l(e,"class","carousel rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function Oe(x){let e,u=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function We(x){let e,u=`<div className="$$carousel rounded-box">
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Burger" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function He(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/400/300/arch")||l(i,"src",h),l(i,"alt","Pizza"),l(u,"class","carousel-item"),C(t.src,a="https://placeimg.com/400/300/arch")||l(t,"src",a),l(t,"alt","Pizza"),l(v,"class","carousel-item"),C($.src,F="https://placeimg.com/400/300/arch")||l($,"src",F),l($,"alt","Pizza"),l(b,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||l(w,"src",K),l(w,"alt","Pizza"),l(I,"class","carousel-item"),C(_.src,A="https://placeimg.com/400/300/arch")||l(_,"src",A),l(_,"alt","Pizza"),l(g,"class","carousel-item"),C(S.src,R="https://placeimg.com/400/300/arch")||l(S,"src",R),l(S,"alt","Pizza"),l(f,"class","carousel-item"),C(D.src,y="https://placeimg.com/400/300/arch")||l(D,"src",y),l(D,"alt","Pizza"),l(V,"class","carousel-item"),l(e,"class","carousel carousel-center rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function Je(x){let e,u=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function Le(x){let e,u=`<div className="$$carousel $$carousel-center rounded-box">
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Pizza" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function Qe(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/400/300/arch")||l(i,"src",h),l(i,"alt","Drink"),l(u,"class","carousel-item"),C(t.src,a="https://placeimg.com/400/300/arch")||l(t,"src",a),l(t,"alt","Drink"),l(v,"class","carousel-item"),C($.src,F="https://placeimg.com/400/300/arch")||l($,"src",F),l($,"alt","Drink"),l(b,"class","carousel-item"),C(w.src,K="https://placeimg.com/400/300/arch")||l(w,"src",K),l(w,"alt","Drink"),l(I,"class","carousel-item"),C(_.src,A="https://placeimg.com/400/300/arch")||l(_,"src",A),l(_,"alt","Drink"),l(g,"class","carousel-item"),C(S.src,R="https://placeimg.com/400/300/arch")||l(S,"src",R),l(S,"alt","Drink"),l(f,"class","carousel-item"),C(D.src,y="https://placeimg.com/400/300/arch")||l(D,"src",y),l(D,"alt","Drink"),l(V,"class","carousel-item"),l(e,"class","carousel carousel-end rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function Ue(x){let e,u=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function Xe(x){let e,u=`<div className="$$carousel $$carousel-end rounded-box">
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/400/300/arch" alt="Drink" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function Ye(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,class:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/256/400/arch")||l(i,"src",h),l(i,"class","w-full"),l(i,"alt","Tailwind CSS carousel component"),l(u,"class","w-full carousel-item"),C(t.src,a="https://placeimg.com/256/400/arch")||l(t,"src",a),l(t,"class","w-full"),l(t,"alt","Tailwind CSS carousel component"),l(v,"class","w-full carousel-item"),C($.src,F="https://placeimg.com/256/400/arch")||l($,"src",F),l($,"class","w-full"),l($,"alt","Tailwind CSS carousel component"),l(b,"class","w-full carousel-item"),C(w.src,K="https://placeimg.com/256/400/arch")||l(w,"src",K),l(w,"class","w-full"),l(w,"alt","Tailwind CSS carousel component"),l(I,"class","w-full carousel-item"),C(_.src,A="https://placeimg.com/256/400/arch")||l(_,"src",A),l(_,"class","w-full"),l(_,"alt","Tailwind CSS carousel component"),l(g,"class","w-full carousel-item"),C(S.src,R="https://placeimg.com/256/400/arch")||l(S,"src",R),l(S,"class","w-full"),l(S,"alt","Tailwind CSS carousel component"),l(f,"class","w-full carousel-item"),C(D.src,y="https://placeimg.com/256/400/arch")||l(D,"src",y),l(D,"class","w-full"),l(D,"alt","Tailwind CSS carousel component"),l(V,"class","w-full carousel-item"),l(e,"class","w-64 carousel rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function Ze(x){let e,u=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function el(x){let e,u=`<div className="w-64 $$carousel rounded-box">
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="https://placeimg.com/256/400/arch" className="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function ll(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/256/400/arch")||l(i,"src",h),l(i,"alt","Tailwind Image slider"),l(u,"class","carousel-item h-full"),C(t.src,a="https://placeimg.com/256/400/arch")||l(t,"src",a),l(t,"alt","Tailwind Image slider"),l(v,"class","carousel-item h-full"),C($.src,F="https://placeimg.com/256/400/arch")||l($,"src",F),l($,"alt","Tailwind Image slider"),l(b,"class","carousel-item h-full"),C(w.src,K="https://placeimg.com/256/400/arch")||l(w,"src",K),l(w,"alt","Tailwind Image slider"),l(I,"class","carousel-item h-full"),C(_.src,A="https://placeimg.com/256/400/arch")||l(_,"src",A),l(_,"alt","Tailwind Image slider"),l(g,"class","carousel-item h-full"),C(S.src,R="https://placeimg.com/256/400/arch")||l(S,"src",R),l(S,"alt","Tailwind Image slider"),l(f,"class","carousel-item h-full"),C(D.src,y="https://placeimg.com/256/400/arch")||l(D,"src",y),l(D,"alt","Tailwind Image slider"),l(V,"class","carousel-item h-full"),l(e,"class","h-96 carousel carousel-vertical rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function tl(x){let e,u=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function sl(x){let e,u=`<div className="h-96 $$carousel $$carousel-vertical rounded-box">
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="https://placeimg.com/256/400/arch" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function al(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,class:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/256/400/arch")||l(i,"src",h),l(i,"class","w-full"),l(i,"alt","Tailwind CSS Image slider"),l(u,"class","w-1/2 carousel-item"),C(t.src,a="https://placeimg.com/256/400/arch")||l(t,"src",a),l(t,"class","w-full"),l(t,"alt","Tailwind CSS Image slider"),l(v,"class","w-1/2 carousel-item"),C($.src,F="https://placeimg.com/256/400/arch")||l($,"src",F),l($,"class","w-full"),l($,"alt","Tailwind CSS Image slider"),l(b,"class","w-1/2 carousel-item"),C(w.src,K="https://placeimg.com/256/400/arch")||l(w,"src",K),l(w,"class","w-full"),l(w,"alt","Tailwind CSS Image slider"),l(I,"class","w-1/2 carousel-item"),C(_.src,A="https://placeimg.com/256/400/arch")||l(_,"src",A),l(_,"class","w-full"),l(_,"alt","Tailwind CSS Image slider"),l(g,"class","w-1/2 carousel-item"),C(S.src,R="https://placeimg.com/256/400/arch")||l(S,"src",R),l(S,"class","w-full"),l(S,"alt","Tailwind CSS Image slider"),l(f,"class","w-1/2 carousel-item"),C(D.src,y="https://placeimg.com/256/400/arch")||l(D,"src",y),l(D,"class","w-full"),l(D,"alt","Tailwind CSS Image slider"),l(V,"class","w-1/2 carousel-item"),l(e,"class","w-96 carousel rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function cl(x){let e,u=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" class="w-full" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function rl(x){let e,u=`<div className="$$carousel rounded-box w-96">
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="https://placeimg.com/256/400/arch" className="w-full" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function il(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("img"),n=E(),f=c("div"),S=c("img"),z=E(),V=c("div"),D=c("img"),this.h()},l(M){e=r(M,"DIV",{class:!0});var o=p(e);u=r(o,"DIV",{class:!0});var k=p(u);i=r(k,"IMG",{src:!0,class:!0,alt:!0}),k.forEach(m),d=N(o),v=r(o,"DIV",{class:!0});var O=p(v);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),P=N(o),b=r(o,"DIV",{class:!0});var J=p(b);$=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),G=N(o),I=r(o,"DIV",{class:!0});var L=p(I);w=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var q=p(g);_=r(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),n=N(o),f=r(o,"DIV",{class:!0});var j=p(f);S=r(j,"IMG",{src:!0,class:!0,alt:!0}),j.forEach(m),z=N(o),V=r(o,"DIV",{class:!0});var Q=p(V);D=r(Q,"IMG",{src:!0,class:!0,alt:!0}),Q.forEach(m),o.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/250/180/arch")||l(i,"src",h),l(i,"class","rounded-box"),l(i,"alt","Tailwind CSS component"),l(u,"class","carousel-item"),C(t.src,a="https://placeimg.com/250/180/arch")||l(t,"src",a),l(t,"class","rounded-box"),l(t,"alt","Tailwind CSS component"),l(v,"class","carousel-item"),C($.src,F="https://placeimg.com/250/180/arch")||l($,"src",F),l($,"class","rounded-box"),l($,"alt","Tailwind CSS component"),l(b,"class","carousel-item"),C(w.src,K="https://placeimg.com/250/180/arch")||l(w,"src",K),l(w,"class","rounded-box"),l(w,"alt","Tailwind CSS component"),l(I,"class","carousel-item"),C(_.src,A="https://placeimg.com/250/180/arch")||l(_,"src",A),l(_,"class","rounded-box"),l(_,"alt","Tailwind CSS component"),l(g,"class","carousel-item"),C(S.src,R="https://placeimg.com/250/180/arch")||l(S,"src",R),l(S,"class","rounded-box"),l(S,"alt","Tailwind CSS component"),l(f,"class","carousel-item"),C(D.src,y="https://placeimg.com/250/180/arch")||l(D,"src",y),l(D,"class","rounded-box"),l(D,"alt","Tailwind CSS component"),l(V,"class","carousel-item"),l(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(M,o){B(M,e,o),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),s(e,T),s(e,g),s(g,_),s(e,n),s(e,f),s(f,S),s(e,z),s(e,V),s(V,D)},d(M){M&&m(e)}}}function ml(x){let e,u=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" class="rounded-box" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function ol(x){let e,u=`<div className="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="https://placeimg.com/250/180/arch" className="rounded-box" />
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function ul(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y,M;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("img"),P=E(),b=c("div"),$=c("img"),G=E(),I=c("div"),w=c("img"),T=E(),g=c("div"),_=c("a"),A=W("1"),n=E(),f=c("a"),S=W("2"),R=E(),z=c("a"),V=W("3"),D=E(),y=c("a"),M=W("4"),this.h()},l(o){e=r(o,"DIV",{class:!0});var k=p(e);u=r(k,"DIV",{id:!0,class:!0});var O=p(u);i=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),d=N(k),v=r(k,"DIV",{id:!0,class:!0});var J=p(v);t=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),P=N(k),b=r(k,"DIV",{id:!0,class:!0});var L=p(b);$=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),G=N(k),I=r(k,"DIV",{id:!0,class:!0});var q=p(I);w=r(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(m),k.forEach(m),T=N(o),g=r(o,"DIV",{class:!0});var j=p(g);_=r(j,"A",{href:!0,class:!0});var Q=p(_);A=H(Q,"1"),Q.forEach(m),n=N(j),f=r(j,"A",{href:!0,class:!0});var ue=p(f);S=H(ue,"2"),ue.forEach(m),R=N(j),z=r(j,"A",{href:!0,class:!0});var Z=p(z);V=H(Z,"3"),Z.forEach(m),D=N(j),y=r(j,"A",{href:!0,class:!0});var re=p(y);M=H(re,"4"),re.forEach(m),j.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/800/200/arch")||l(i,"src",h),l(i,"class","w-full"),l(i,"alt","Tailwind CSS image gallery"),l(u,"id","item1"),l(u,"class","w-full carousel-item"),C(t.src,a="https://placeimg.com/800/200/arch")||l(t,"src",a),l(t,"class","w-full"),l(t,"alt","Tailwind CSS image gallery"),l(v,"id","item2"),l(v,"class","w-full carousel-item"),C($.src,F="https://placeimg.com/800/200/arch")||l($,"src",F),l($,"class","w-full"),l($,"alt","Tailwind CSS image gallery"),l(b,"id","item3"),l(b,"class","w-full carousel-item"),C(w.src,K="https://placeimg.com/800/200/arch")||l(w,"src",K),l(w,"class","w-full"),l(w,"alt","Tailwind CSS image gallery"),l(I,"id","item4"),l(I,"class","w-full carousel-item"),l(e,"class","w-full carousel"),l(_,"href","#item1"),l(_,"class","btn btn-xs"),l(f,"href","#item2"),l(f,"class","btn btn-xs"),l(z,"href","#item3"),l(z,"class","btn btn-xs"),l(y,"href","#item4"),l(y,"class","btn btn-xs"),l(g,"class","flex justify-center w-full py-2 gap-2")},m(o,k){B(o,e,k),s(e,u),s(u,i),s(e,d),s(e,v),s(v,t),s(e,P),s(e,b),s(b,$),s(e,G),s(e,I),s(I,w),B(o,T,k),B(o,g,k),s(g,_),s(_,A),s(g,n),s(g,f),s(f,S),s(g,R),s(g,z),s(z,V),s(g,D),s(g,y),s(y,M)},d(o){o&&m(e),o&&m(T),o&&m(g)}}}function dl(x){let e,u=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function vl(x){let e,u=`<div className="$$carousel w-full">
  <div id="item1" className="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
  </div> 
  <div id="item2" className="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
  </div> 
  <div id="item3" className="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
  </div> 
  <div id="item4" className="$$carousel-item w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
  </div>
</div> 
<div className="flex justify-center w-full py-2 gap-2">
  <a href="#item1" className="$$btn $$btn-xs">1</a> 
  <a href="#item2" className="$$btn $$btn-xs">2</a> 
  <a href="#item3" className="$$btn $$btn-xs">3</a> 
  <a href="#item4" className="$$btn $$btn-xs">4</a>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function nl(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A,n,f,S,R,z,V,D,y,M,o,k,O,J,L,q,j,Q,ue,Z,re,we,be,oe,Ie;return{c(){e=c("div"),u=c("div"),i=c("img"),d=E(),v=c("div"),t=c("a"),a=W("\u276E"),P=E(),b=c("a"),$=W("\u276F"),F=E(),G=c("div"),I=c("img"),K=E(),T=c("div"),g=c("a"),_=W("\u276E"),A=E(),n=c("a"),f=W("\u276F"),S=E(),R=c("div"),z=c("img"),D=E(),y=c("div"),M=c("a"),o=W("\u276E"),k=E(),O=c("a"),J=W("\u276F"),L=E(),q=c("div"),j=c("img"),ue=E(),Z=c("div"),re=c("a"),we=W("\u276E"),be=E(),oe=c("a"),Ie=W("\u276F"),this.h()},l(de){e=r(de,"DIV",{class:!0});var ie=p(e);u=r(ie,"DIV",{id:!0,class:!0});var ve=p(u);i=r(ve,"IMG",{src:!0,class:!0,alt:!0}),d=N(ve),v=r(ve,"DIV",{class:!0});var ne=p(v);t=r(ne,"A",{href:!0,class:!0});var Ne=p(t);a=H(Ne,"\u276E"),Ne.forEach(m),P=N(ne),b=r(ne,"A",{href:!0,class:!0});var Se=p(b);$=H(Se,"\u276F"),Se.forEach(m),ne.forEach(m),ve.forEach(m),F=N(ie),G=r(ie,"DIV",{id:!0,class:!0});var he=p(G);I=r(he,"IMG",{src:!0,class:!0,alt:!0}),K=N(he),T=r(he,"DIV",{class:!0});var pe=p(T);g=r(pe,"A",{href:!0,class:!0});var De=p(g);_=H(De,"\u276E"),De.forEach(m),A=N(pe),n=r(pe,"A",{href:!0,class:!0});var xe=p(n);f=H(xe,"\u276F"),xe.forEach(m),pe.forEach(m),he.forEach(m),S=N(ie),R=r(ie,"DIV",{id:!0,class:!0});var fe=p(R);z=r(fe,"IMG",{src:!0,class:!0,alt:!0}),D=N(fe),y=r(fe,"DIV",{class:!0});var ge=p(y);M=r(ge,"A",{href:!0,class:!0});var Ve=p(M);o=H(Ve,"\u276E"),Ve.forEach(m),k=N(ge),O=r(ge,"A",{href:!0,class:!0});var Ce=p(O);J=H(Ce,"\u276F"),Ce.forEach(m),ge.forEach(m),fe.forEach(m),L=N(ie),q=r(ie,"DIV",{id:!0,class:!0});var $e=p(q);j=r($e,"IMG",{src:!0,class:!0,alt:!0}),ue=N($e),Z=r($e,"DIV",{class:!0});var _e=p(Z);re=r(_e,"A",{href:!0,class:!0});var Me=p(re);we=H(Me,"\u276E"),Me.forEach(m),be=N(_e),oe=r(_e,"A",{href:!0,class:!0});var Ge=p(oe);Ie=H(Ge,"\u276F"),Ge.forEach(m),_e.forEach(m),$e.forEach(m),ie.forEach(m),this.h()},h(){C(i.src,h="https://placeimg.com/800/200/arch")||l(i,"src",h),l(i,"class","w-full"),l(i,"alt","Tailwind CSS image slide"),l(t,"href","#slide4"),l(t,"class","btn btn-circle"),l(b,"href","#slide2"),l(b,"class","btn btn-circle"),l(v,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),l(u,"id","slide1"),l(u,"class","relative w-full carousel-item"),C(I.src,w="https://placeimg.com/800/200/arch")||l(I,"src",w),l(I,"class","w-full"),l(I,"alt","Tailwind CSS image slide"),l(g,"href","#slide1"),l(g,"class","btn btn-circle"),l(n,"href","#slide3"),l(n,"class","btn btn-circle"),l(T,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),l(G,"id","slide2"),l(G,"class","relative w-full carousel-item"),C(z.src,V="https://placeimg.com/800/200/arch")||l(z,"src",V),l(z,"class","w-full"),l(z,"alt","Tailwind CSS image slide"),l(M,"href","#slide2"),l(M,"class","btn btn-circle"),l(O,"href","#slide4"),l(O,"class","btn btn-circle"),l(y,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),l(R,"id","slide3"),l(R,"class","relative w-full carousel-item"),C(j.src,Q="https://placeimg.com/800/200/arch")||l(j,"src",Q),l(j,"class","w-full"),l(j,"alt","Tailwind CSS image slide"),l(re,"href","#slide3"),l(re,"class","btn btn-circle"),l(oe,"href","#slide1"),l(oe,"class","btn btn-circle"),l(Z,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),l(q,"id","slide4"),l(q,"class","relative w-full carousel-item"),l(e,"class","w-full carousel")},m(de,ie){B(de,e,ie),s(e,u),s(u,i),s(u,d),s(u,v),s(v,t),s(t,a),s(v,P),s(v,b),s(b,$),s(e,F),s(e,G),s(G,I),s(G,K),s(G,T),s(T,g),s(g,_),s(T,A),s(T,n),s(n,f),s(e,S),s(e,R),s(R,z),s(R,D),s(R,y),s(y,M),s(M,o),s(y,k),s(y,O),s(O,J),s(e,L),s(e,q),s(q,j),s(q,ue),s(q,Z),s(Z,re),s(re,we),s(Z,be),s(Z,oe),s(oe,Ie)},d(de){de&&m(e)}}}function hl(x){let e,u=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","html")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function pl(x){let e,u=`<div className="$$carousel w-full">
  <div id="slide1" className="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" className="btn btn-circle">\u276E</a> 
      <a href="#slide2" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" className="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" className="btn btn-circle">\u276E</a> 
      <a href="#slide3" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" className="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" className="btn btn-circle">\u276E</a> 
      <a href="#slide4" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" className="$$carousel-item relative w-full">
    <img src="https://placeimg.com/800/200/arch" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" className="btn btn-circle">\u276E</a> 
      <a href="#slide1" className="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,i,h,d,v;return{c(){e=c("pre"),i=W(u),this.h()},l(t){e=r(t,"PRE",{slot:!0});var a=p(e);i=H(a,u),a.forEach(m),this.h()},h(){l(e,"slot","react")},m(t,a){B(t,e,a),s(e,i),d||(v=U(h=Y.call(null,e,{to:x[0]})),d=!0)},p(t,a){h&&X(h.update)&&a&1&&h.update.call(null,{to:t[0]})},d(t){t&&m(e),d=!1,v()}}}function fl(x){let e,u,i,h,d,v,t,a,P,b,$,F,G,I,w,K,T,g,_,A;return e=new Fe({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),i=new me({props:{title:"Snap to start (default)",$$slots:{react:[We],html:[Oe],default:[Ke]},$$scope:{ctx:x}}}),d=new me({props:{title:"Snap to center",$$slots:{react:[Le],html:[Je],default:[He]},$$scope:{ctx:x}}}),t=new me({props:{title:"Snap to end",$$slots:{react:[Xe],html:[Ue],default:[Qe]},$$scope:{ctx:x}}}),P=new me({props:{title:"Carousel with full width items",$$slots:{react:[el],html:[Ze],default:[Ye]},$$scope:{ctx:x}}}),$=new me({props:{title:"Vertical carousel",$$slots:{react:[sl],html:[tl],default:[ll]},$$scope:{ctx:x}}}),G=new me({props:{title:"Carousel with half width items",$$slots:{react:[rl],html:[cl],default:[al]},$$scope:{ctx:x}}}),w=new me({props:{title:"Full-bleed carousel",$$slots:{react:[ol],html:[ml],default:[il]},$$scope:{ctx:x}}}),T=new me({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{react:[vl],html:[dl],default:[ul]},$$scope:{ctx:x}}}),_=new me({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{react:[pl],html:[hl],default:[nl]},$$scope:{ctx:x}}}),{c(){ee(e.$$.fragment),u=E(),ee(i.$$.fragment),h=E(),ee(d.$$.fragment),v=E(),ee(t.$$.fragment),a=E(),ee(P.$$.fragment),b=E(),ee($.$$.fragment),F=E(),ee(G.$$.fragment),I=E(),ee(w.$$.fragment),K=E(),ee(T.$$.fragment),g=E(),ee(_.$$.fragment)},l(n){le(e.$$.fragment,n),u=N(n),le(i.$$.fragment,n),h=N(n),le(d.$$.fragment,n),v=N(n),le(t.$$.fragment,n),a=N(n),le(P.$$.fragment,n),b=N(n),le($.$$.fragment,n),F=N(n),le(G.$$.fragment,n),I=N(n),le(w.$$.fragment,n),K=N(n),le(T.$$.fragment,n),g=N(n),le(_.$$.fragment,n)},m(n,f){te(e,n,f),B(n,u,f),te(i,n,f),B(n,h,f),te(d,n,f),B(n,v,f),te(t,n,f),B(n,a,f),te(P,n,f),B(n,b,f),te($,n,f),B(n,F,f),te(G,n,f),B(n,I,f),te(w,n,f),B(n,K,f),te(T,n,f),B(n,g,f),te(_,n,f),A=!0},p(n,f){const S={};f&5&&(S.$$scope={dirty:f,ctx:n}),i.$set(S);const R={};f&5&&(R.$$scope={dirty:f,ctx:n}),d.$set(R);const z={};f&5&&(z.$$scope={dirty:f,ctx:n}),t.$set(z);const V={};f&5&&(V.$$scope={dirty:f,ctx:n}),P.$set(V);const D={};f&5&&(D.$$scope={dirty:f,ctx:n}),$.$set(D);const y={};f&5&&(y.$$scope={dirty:f,ctx:n}),G.$set(y);const M={};f&5&&(M.$$scope={dirty:f,ctx:n}),w.$set(M);const o={};f&5&&(o.$$scope={dirty:f,ctx:n}),T.$set(o);const k={};f&5&&(k.$$scope={dirty:f,ctx:n}),_.$set(k)},i(n){A||(se(e.$$.fragment,n),se(i.$$.fragment,n),se(d.$$.fragment,n),se(t.$$.fragment,n),se(P.$$.fragment,n),se($.$$.fragment,n),se(G.$$.fragment,n),se(w.$$.fragment,n),se(T.$$.fragment,n),se(_.$$.fragment,n),A=!0)},o(n){ae(e.$$.fragment,n),ae(i.$$.fragment,n),ae(d.$$.fragment,n),ae(t.$$.fragment,n),ae(P.$$.fragment,n),ae($.$$.fragment,n),ae(G.$$.fragment,n),ae(w.$$.fragment,n),ae(T.$$.fragment,n),ae(_.$$.fragment,n),A=!1},d(n){ce(e,n),n&&m(u),ce(i,n),n&&m(h),ce(d,n),n&&m(v),ce(t,n),n&&m(a),ce(P,n),n&&m(b),ce($,n),n&&m(F),ce(G,n),n&&m(I),ce(w,n),n&&m(K),ce(T,n),n&&m(g),ce(_,n)}}}function gl(x){let e,u;const i=[x[1],Pe];let h={$$slots:{default:[fl]},$$scope:{ctx:x}};for(let d=0;d<i.length;d+=1)h=Ee(h,i[d]);return e=new Ae({props:h}),{c(){ee(e.$$.fragment)},l(d){le(e.$$.fragment,d)},m(d,v){te(e,d,v),u=!0},p(d,[v]){const t=v&2?Re(i,[v&2&&Te(d[1]),v&0&&Te(Pe)]):{};v&5&&(t.$$scope={dirty:v,ctx:d}),e.$set(t)},i(d){u||(se(e.$$.fragment,d),u=!0)},o(d){ae(e.$$.fragment,d),u=!1},d(d){ce(e,d)}}}const Pe={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function $l(x,e,u){let i;return je(x,qe,h=>u(0,i=h)),x.$$set=h=>{u(1,e=Ee(Ee({},e),ze(h)))},e=ze(e),[i,e]}class Vl extends ye{constructor(e){super();ke(this,e,$l,gl,Be,{})}}export{Vl as default,Pe as metadata};
