import{S as Oi,i as Ji,s as Wi,w as Ll,k as d,x as Vl,m as o,y as Gl,g as Ot,q as Fl,o as Nl,B as Ml,d as e,J as Ki,e as a,t as s,c as l,a as r,h as n,b as E,H as t,a1 as Hr,P as wr,N as ao}from"../../chunks/vendor-1fc5b034.js";import{C as Qi,a as Sr,r as Cr,p as Ui}from"../../chunks/actions-a46bfef7.js";import"../../chunks/preload-helper-ec9aa979.js";function qi(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=d(),i=a("th"),T=s("Name"),N=d(),x=a("th"),q=s("Job"),Z=d(),R=a("th"),lt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),rt=s("1"),M=d(),H=a("td"),j=s("Cy Ganderton"),ht=d(),W=a("td"),m=s("Quality Control Specialist"),I=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),X=a("th"),$t=s("2"),tt=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),$=a("tr"),J=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),ut=d(),Q=a("td"),nt=s("Tax Accountant"),_t=d(),Y=a("td"),U=s("Red"),this.h()},l(F){c=l(F,"DIV",{class:!0});var et=r(c);f=l(et,"TABLE",{class:!0});var at=r(f);_=l(at,"THEAD",{});var kt=r(_);h=l(kt,"TR",{});var g=r(h);p=l(g,"TH",{}),r(p).forEach(e),y=o(g),i=l(g,"TH",{});var Tt=r(i);T=n(Tt,"Name"),Tt.forEach(e),N=o(g),x=l(g,"TH",{});var Et=r(x);q=n(Et,"Job"),Et.forEach(e),Z=o(g),R=l(g,"TH",{});var Rt=r(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(at),u=l(at,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);rt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);j=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),W=l(w,"TD",{});var pt=r(W);m=n(pt,"Quality Control Specialist"),pt.forEach(e),I=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{});var C=r(b);X=l(C,"TH",{});var V=r(X);$t=n(V,"2"),V.forEach(e),tt=o(C),z=l(C,"TD",{});var It=r(z);yt=n(It,"Hart Hagerty"),It.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),$=l(P,"TR",{});var S=r($);J=l(S,"TH",{});var Nt=r(J);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),_t=o(S),Y=l(S,"TD",{});var zt=r(Y);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),at.forEach(e),et.forEach(e),this.h()},h(){E(f,"class","table w-full"),E(c,"class","overflow-x-auto w-full")},m(F,et){Ot(F,c,et),t(c,f),t(f,_),t(_,h),t(h,p),t(h,y),t(h,i),t(i,T),t(h,N),t(h,x),t(x,q),t(h,Z),t(h,R),t(R,lt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,rt),t(D,M),t(D,H),t(H,j),t(D,ht),t(D,W),t(W,m),t(D,I),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,X),t(X,$t),t(b,tt),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,$),t($,J),t(J,ft),t($,Ht),t($,K),t(K,B),t($,ut),t($,Q),t(Q,nt),t($,_t),t($,Y),t(Y,U)},d(F){F&&e(c)}}}function Yi(dt){let c,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function Zi(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=d(),i=a("th"),T=s("Name"),N=d(),x=a("th"),q=s("Job"),Z=d(),R=a("th"),lt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),rt=s("1"),M=d(),H=a("td"),j=s("Cy Ganderton"),ht=d(),W=a("td"),m=s("Quality Control Specialist"),I=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),X=a("th"),$t=s("2"),tt=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),$=a("tr"),J=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),ut=d(),Q=a("td"),nt=s("Tax Accountant"),_t=d(),Y=a("td"),U=s("Red"),this.h()},l(F){c=l(F,"DIV",{class:!0});var et=r(c);f=l(et,"TABLE",{class:!0});var at=r(f);_=l(at,"THEAD",{});var kt=r(_);h=l(kt,"TR",{});var g=r(h);p=l(g,"TH",{}),r(p).forEach(e),y=o(g),i=l(g,"TH",{});var Tt=r(i);T=n(Tt,"Name"),Tt.forEach(e),N=o(g),x=l(g,"TH",{});var Et=r(x);q=n(Et,"Job"),Et.forEach(e),Z=o(g),R=l(g,"TH",{});var Rt=r(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(at),u=l(at,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);rt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);j=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),W=l(w,"TD",{});var pt=r(W);m=n(pt,"Quality Control Specialist"),pt.forEach(e),I=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{class:!0});var C=r(b);X=l(C,"TH",{});var V=r(X);$t=n(V,"2"),V.forEach(e),tt=o(C),z=l(C,"TD",{});var It=r(z);yt=n(It,"Hart Hagerty"),It.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),$=l(P,"TR",{});var S=r($);J=l(S,"TH",{});var Nt=r(J);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),_t=o(S),Y=l(S,"TD",{});var zt=r(Y);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),at.forEach(e),et.forEach(e),this.h()},h(){E(b,"class","active"),E(f,"class","table w-full"),E(c,"class","overflow-x-auto w-full")},m(F,et){Ot(F,c,et),t(c,f),t(f,_),t(_,h),t(h,p),t(h,y),t(h,i),t(i,T),t(h,N),t(h,x),t(x,q),t(h,Z),t(h,R),t(R,lt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,rt),t(D,M),t(D,H),t(H,j),t(D,ht),t(D,W),t(W,m),t(D,I),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,X),t(X,$t),t(b,tt),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,$),t($,J),t(J,ft),t($,Ht),t($,K),t(K,B),t($,ut),t($,Q),t(Q,nt),t($,_t),t($,Y),t(Y,U)},d(F){F&&e(c)}}}function ji(dt){let c,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$active">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function Xi(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=d(),i=a("th"),T=s("Name"),N=d(),x=a("th"),q=s("Job"),Z=d(),R=a("th"),lt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),rt=s("1"),M=d(),H=a("td"),j=s("Cy Ganderton"),ht=d(),W=a("td"),m=s("Quality Control Specialist"),I=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),X=a("th"),$t=s("2"),tt=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),$=a("tr"),J=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),ut=d(),Q=a("td"),nt=s("Tax Accountant"),_t=d(),Y=a("td"),U=s("Red"),this.h()},l(F){c=l(F,"DIV",{class:!0});var et=r(c);f=l(et,"TABLE",{class:!0});var at=r(f);_=l(at,"THEAD",{});var kt=r(_);h=l(kt,"TR",{});var g=r(h);p=l(g,"TH",{}),r(p).forEach(e),y=o(g),i=l(g,"TH",{});var Tt=r(i);T=n(Tt,"Name"),Tt.forEach(e),N=o(g),x=l(g,"TH",{});var Et=r(x);q=n(Et,"Job"),Et.forEach(e),Z=o(g),R=l(g,"TH",{});var Rt=r(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(at),u=l(at,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);rt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);j=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),W=l(w,"TD",{});var pt=r(W);m=n(pt,"Quality Control Specialist"),pt.forEach(e),I=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{class:!0});var C=r(b);X=l(C,"TH",{});var V=r(X);$t=n(V,"2"),V.forEach(e),tt=o(C),z=l(C,"TD",{});var It=r(z);yt=n(It,"Hart Hagerty"),It.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),$=l(P,"TR",{});var S=r($);J=l(S,"TH",{});var Nt=r(J);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),_t=o(S),Y=l(S,"TD",{});var zt=r(Y);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),at.forEach(e),et.forEach(e),this.h()},h(){E(b,"class","hover"),E(f,"class","table w-full"),E(c,"class","overflow-x-auto w-full")},m(F,et){Ot(F,c,et),t(c,f),t(f,_),t(_,h),t(h,p),t(h,y),t(h,i),t(i,T),t(h,N),t(h,x),t(x,q),t(h,Z),t(h,R),t(R,lt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,rt),t(D,M),t(D,H),t(H,j),t(D,ht),t(D,W),t(W,m),t(D,I),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,X),t(X,$t),t(b,tt),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,$),t($,J),t(J,ft),t($,Ht),t($,K),t(K,B),t($,ut),t($,Q),t(Q,nt),t($,_t),t($,Y),t(Y,U)},d(F){F&&e(c)}}}function t1(dt){let c,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function e1(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=d(),i=a("th"),T=s("Name"),N=d(),x=a("th"),q=s("Job"),Z=d(),R=a("th"),lt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),rt=s("1"),M=d(),H=a("td"),j=s("Cy Ganderton"),ht=d(),W=a("td"),m=s("Quality Control Specialist"),I=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),X=a("th"),$t=s("2"),tt=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),$=a("tr"),J=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),ut=d(),Q=a("td"),nt=s("Tax Accountant"),_t=d(),Y=a("td"),U=s("Red"),this.h()},l(F){c=l(F,"DIV",{class:!0});var et=r(c);f=l(et,"TABLE",{class:!0});var at=r(f);_=l(at,"THEAD",{});var kt=r(_);h=l(kt,"TR",{});var g=r(h);p=l(g,"TH",{}),r(p).forEach(e),y=o(g),i=l(g,"TH",{});var Tt=r(i);T=n(Tt,"Name"),Tt.forEach(e),N=o(g),x=l(g,"TH",{});var Et=r(x);q=n(Et,"Job"),Et.forEach(e),Z=o(g),R=l(g,"TH",{});var Rt=r(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(at),u=l(at,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);rt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);j=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),W=l(w,"TD",{});var pt=r(W);m=n(pt,"Quality Control Specialist"),pt.forEach(e),I=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{});var C=r(b);X=l(C,"TH",{});var V=r(X);$t=n(V,"2"),V.forEach(e),tt=o(C),z=l(C,"TD",{});var It=r(z);yt=n(It,"Hart Hagerty"),It.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),$=l(P,"TR",{});var S=r($);J=l(S,"TH",{});var Nt=r(J);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),_t=o(S),Y=l(S,"TD",{});var zt=r(Y);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),at.forEach(e),et.forEach(e),this.h()},h(){E(f,"class","table table-zebra w-full"),E(c,"class","overflow-x-auto w-full")},m(F,et){Ot(F,c,et),t(c,f),t(f,_),t(_,h),t(h,p),t(h,y),t(h,i),t(i,T),t(h,N),t(h,x),t(x,q),t(h,Z),t(h,R),t(R,lt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,rt),t(D,M),t(D,H),t(H,j),t(D,ht),t(D,W),t(W,m),t(D,I),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,X),t(X,$t),t(b,tt),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,$),t($,J),t(J,ft),t($,Ht),t($,K),t(K,B),t($,ut),t($,Q),t(Q,nt),t($,_t),t($,Y),t(Y,U)},d(F){F&&e(c)}}}function a1(dt){let c,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-zebra w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function l1(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U,F,et,at,kt,g,Tt,Et,Rt,P,w,Vt,wt,pt,Gt,C,V,It,Ft,mt,S,Nt,Mt,bt,zt,cl,ze,il,vl,Oe,Ze,fl,va,Jt,fa,Je,ua,ul,Ct,oe,je,Xe,Be,zl,_l,Pe,ta,Tl,_a,ea,El,Ta,Le,pl,Ea,ml,aa,pa,bl,ma,xt,ba,Da,la,$a,Dl,Wt,We,ya,ga,Sa,Ha,Ve,Ge,ra,da,Na,$l,Ke,Fe,yl,gl,Dt,wa,Sl,Ne,Ca,Hl,wl,Me,Cl,Rl,Qe,kl,Il,Ue,oa,xl,Ra,ka,Kt,sa,Al,Ia,At,xa,Aa,Pl,Pa,Ba,Bl,La,Ma;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=a("label"),i=a("input"),T=d(),N=a("th"),x=s("Name"),q=d(),Z=a("th"),R=s("Job"),lt=d(),v=a("th"),u=s("Favorite Color"),D=d(),G=a("th"),rt=d(),M=a("tbody"),H=a("tr"),j=a("th"),ht=a("label"),W=a("input"),m=d(),I=a("td"),A=a("div"),ot=a("div"),st=a("div"),b=a("img"),$t=d(),tt=a("div"),z=a("div"),yt=s("Hart Hagerty"),ct=d(),O=a("div"),gt=s("United States"),it=d(),L=a("td"),St=s(`Zemlak, Daniel and Leannon
          `),vt=a("br"),$=d(),J=a("span"),ft=s("Desktop Support Technician"),Ht=d(),K=a("td"),B=s("Purple"),ut=d(),Q=a("th"),nt=a("button"),_t=s("details"),Y=d(),U=a("tr"),F=a("th"),et=a("label"),at=a("input"),kt=d(),g=a("td"),Tt=a("div"),Et=a("div"),Rt=a("div"),P=a("img"),Vt=d(),wt=a("div"),pt=a("div"),Gt=s("Brice Swyre"),C=d(),V=a("div"),It=s("China"),Ft=d(),mt=a("td"),S=s(`Carroll Group
          `),Nt=a("br"),Mt=d(),bt=a("span"),zt=s("Tax Accountant"),cl=d(),ze=a("td"),il=s("Red"),vl=d(),Oe=a("th"),Ze=a("button"),fl=s("details"),va=d(),Jt=a("tr"),fa=a("th"),Je=a("label"),ua=a("input"),ul=d(),Ct=a("td"),oe=a("div"),je=a("div"),Xe=a("div"),Be=a("img"),_l=d(),Pe=a("div"),ta=a("div"),Tl=s("Marjy Ferencz"),_a=d(),ea=a("div"),El=s("Russia"),Ta=d(),Le=a("td"),pl=s(`Rowe-Schoen
          `),Ea=a("br"),ml=d(),aa=a("span"),pa=s("Office Assistant I"),bl=d(),ma=a("td"),xt=s("Crimson"),ba=d(),Da=a("th"),la=a("button"),$a=s("details"),Dl=d(),Wt=a("tr"),We=a("th"),ya=a("label"),ga=a("input"),Sa=d(),Ha=a("td"),Ve=a("div"),Ge=a("div"),ra=a("div"),da=a("img"),$l=d(),Ke=a("div"),Fe=a("div"),yl=s("Yancy Tear"),gl=d(),Dt=a("div"),wa=s("Brazil"),Sl=d(),Ne=a("td"),Ca=s(`Wyman-Ledner
          `),Hl=a("br"),wl=d(),Me=a("span"),Cl=s("Community Outreach Specialist"),Rl=d(),Qe=a("td"),kl=s("Indigo"),Il=d(),Ue=a("th"),oa=a("button"),xl=s("details"),Ra=d(),ka=a("tfoot"),Kt=a("tr"),sa=a("th"),Al=d(),Ia=a("th"),At=s("Name"),xa=d(),Aa=a("th"),Pl=s("Job"),Pa=d(),Ba=a("th"),Bl=s("Favorite Color"),La=d(),Ma=a("th"),this.h()},l(Va){c=l(Va,"DIV",{class:!0});var na=r(c);f=l(na,"TABLE",{class:!0});var ha=r(f);_=l(ha,"THEAD",{});var Ol=r(_);h=l(Ol,"TR",{});var re=r(h);p=l(re,"TH",{});var Jl=r(p);y=l(Jl,"LABEL",{});var Wl=r(y);i=l(Wl,"INPUT",{type:!0,class:!0}),Wl.forEach(e),Jl.forEach(e),T=o(re),N=l(re,"TH",{});var za=r(N);x=n(za,"Name"),za.forEach(e),q=o(re),Z=l(re,"TH",{});var Kl=r(Z);R=n(Kl,"Job"),Kl.forEach(e),lt=o(re),v=l(re,"TH",{});var Ql=r(v);u=n(Ql,"Favorite Color"),Ql.forEach(e),D=o(re),G=l(re,"TH",{}),r(G).forEach(e),re.forEach(e),Ol.forEach(e),rt=o(ha),M=l(ha,"TBODY",{});var se=r(M);H=l(se,"TR",{});var ne=r(H);j=l(ne,"TH",{});var Ul=r(j);ht=l(Ul,"LABEL",{});var Pt=r(ht);W=l(Pt,"INPUT",{type:!0,class:!0}),Pt.forEach(e),Ul.forEach(e),m=o(ne),I=l(ne,"TD",{});var Oa=r(I);A=l(Oa,"DIV",{class:!0});var Ja=r(A);ot=l(Ja,"DIV",{class:!0});var ql=r(ot);st=l(ql,"DIV",{class:!0});var Wa=r(st);b=l(Wa,"IMG",{src:!0,alt:!0}),Wa.forEach(e),ql.forEach(e),$t=o(Ja),tt=l(Ja,"DIV",{});var Ka=r(tt);z=l(Ka,"DIV",{class:!0});var Yl=r(z);yt=n(Yl,"Hart Hagerty"),Yl.forEach(e),ct=o(Ka),O=l(Ka,"DIV",{class:!0});var Qa=r(O);gt=n(Qa,"United States"),Qa.forEach(e),Ka.forEach(e),Ja.forEach(e),Oa.forEach(e),it=o(ne),L=l(ne,"TD",{});var Ga=r(L);St=n(Ga,`Zemlak, Daniel and Leannon
          `),vt=l(Ga,"BR",{}),$=o(Ga),J=l(Ga,"SPAN",{class:!0});var Zl=r(J);ft=n(Zl,"Desktop Support Technician"),Zl.forEach(e),Ga.forEach(e),Ht=o(ne),K=l(ne,"TD",{});var Ua=r(K);B=n(Ua,"Purple"),Ua.forEach(e),ut=o(ne),Q=l(ne,"TH",{});var jl=r(Q);nt=l(jl,"BUTTON",{class:!0});var Xl=r(nt);_t=n(Xl,"details"),Xl.forEach(e),jl.forEach(e),ne.forEach(e),Y=o(se),U=l(se,"TR",{});var de=r(U);F=l(de,"TH",{});var tr=r(F);et=l(tr,"LABEL",{});var er=r(et);at=l(er,"INPUT",{type:!0,class:!0}),er.forEach(e),tr.forEach(e),kt=o(de),g=l(de,"TD",{});var qa=r(g);Tt=l(qa,"DIV",{class:!0});var Ya=r(Tt);Et=l(Ya,"DIV",{class:!0});var ar=r(Et);Rt=l(ar,"DIV",{class:!0});var Za=r(Rt);P=l(Za,"IMG",{src:!0,alt:!0}),Za.forEach(e),ar.forEach(e),Vt=o(Ya),wt=l(Ya,"DIV",{});var ja=r(wt);pt=l(ja,"DIV",{class:!0});var lr=r(pt);Gt=n(lr,"Brice Swyre"),lr.forEach(e),C=o(ja),V=l(ja,"DIV",{class:!0});var Bt=r(V);It=n(Bt,"China"),Bt.forEach(e),ja.forEach(e),Ya.forEach(e),qa.forEach(e),Ft=o(de),mt=l(de,"TD",{});var qe=r(mt);S=n(qe,`Carroll Group
          `),Nt=l(qe,"BR",{}),Mt=o(qe),bt=l(qe,"SPAN",{class:!0});var rr=r(bt);zt=n(rr,"Tax Accountant"),rr.forEach(e),qe.forEach(e),cl=o(de),ze=l(de,"TD",{});var dr=r(ze);il=n(dr,"Red"),dr.forEach(e),vl=o(de),Oe=l(de,"TH",{});var Xa=r(Oe);Ze=l(Xa,"BUTTON",{class:!0});var or=r(Ze);fl=n(or,"details"),or.forEach(e),Xa.forEach(e),de.forEach(e),va=o(se),Jt=l(se,"TR",{});var he=r(Jt);fa=l(he,"TH",{});var tl=r(fa);Je=l(tl,"LABEL",{});var sr=r(Je);ua=l(sr,"INPUT",{type:!0,class:!0}),sr.forEach(e),tl.forEach(e),ul=o(he),Ct=l(he,"TD",{});var nr=r(Ct);oe=l(nr,"DIV",{class:!0});var ca=r(oe);je=l(ca,"DIV",{class:!0});var hr=r(je);Xe=l(hr,"DIV",{class:!0});var cr=r(Xe);Be=l(cr,"IMG",{src:!0,alt:!0}),cr.forEach(e),hr.forEach(e),_l=o(ca),Pe=l(ca,"DIV",{});var ia=r(Pe);ta=l(ia,"DIV",{class:!0});var ir=r(ta);Tl=n(ir,"Marjy Ferencz"),ir.forEach(e),_a=o(ia),ea=l(ia,"DIV",{class:!0});var vr=r(ea);El=n(vr,"Russia"),vr.forEach(e),ia.forEach(e),ca.forEach(e),nr.forEach(e),Ta=o(he),Le=l(he,"TD",{});var Ye=r(Le);pl=n(Ye,`Rowe-Schoen
          `),Ea=l(Ye,"BR",{}),ml=o(Ye),aa=l(Ye,"SPAN",{class:!0});var fr=r(aa);pa=n(fr,"Office Assistant I"),fr.forEach(e),Ye.forEach(e),bl=o(he),ma=l(he,"TD",{});var ur=r(ma);xt=n(ur,"Crimson"),ur.forEach(e),ba=o(he),Da=l(he,"TH",{});var el=r(Da);la=l(el,"BUTTON",{class:!0});var _r=r(la);$a=n(_r,"details"),_r.forEach(e),el.forEach(e),he.forEach(e),Dl=o(se),Wt=l(se,"TR",{});var ce=r(Wt);We=l(ce,"TH",{});var Lt=r(We);ya=l(Lt,"LABEL",{});var al=r(ya);ga=l(al,"INPUT",{type:!0,class:!0}),al.forEach(e),Lt.forEach(e),Sa=o(ce),Ha=l(ce,"TD",{});var Tr=r(Ha);Ve=l(Tr,"DIV",{class:!0});var ll=r(Ve);Ge=l(ll,"DIV",{class:!0});var rl=r(Ge);ra=l(rl,"DIV",{class:!0});var Er=r(ra);da=l(Er,"IMG",{src:!0,alt:!0}),Er.forEach(e),rl.forEach(e),$l=o(ll),Ke=l(ll,"DIV",{});var dl=r(Ke);Fe=l(dl,"DIV",{class:!0});var ol=r(Fe);yl=n(ol,"Yancy Tear"),ol.forEach(e),gl=o(dl),Dt=l(dl,"DIV",{class:!0});var pr=r(Dt);wa=n(pr,"Brazil"),pr.forEach(e),dl.forEach(e),ll.forEach(e),Tr.forEach(e),Sl=o(ce),Ne=l(ce,"TD",{});var Fa=r(Ne);Ca=n(Fa,`Wyman-Ledner
          `),Hl=l(Fa,"BR",{}),wl=o(Fa),Me=l(Fa,"SPAN",{class:!0});var sl=r(Me);Cl=n(sl,"Community Outreach Specialist"),sl.forEach(e),Fa.forEach(e),Rl=o(ce),Qe=l(ce,"TD",{});var mr=r(Qe);kl=n(mr,"Indigo"),mr.forEach(e),Il=o(ce),Ue=l(ce,"TH",{});var br=r(Ue);oa=l(br,"BUTTON",{class:!0});var nl=r(oa);xl=n(nl,"details"),nl.forEach(e),br.forEach(e),ce.forEach(e),se.forEach(e),Ra=o(ha),ka=l(ha,"TFOOT",{});var Dr=r(ka);Kt=l(Dr,"TR",{});var ie=r(Kt);sa=l(ie,"TH",{}),r(sa).forEach(e),Al=o(ie),Ia=l(ie,"TH",{});var hl=r(Ia);At=n(hl,"Name"),hl.forEach(e),xa=o(ie),Aa=l(ie,"TH",{});var $r=r(Aa);Pl=n($r,"Job"),$r.forEach(e),Pa=o(ie),Ba=l(ie,"TH",{});var yr=r(Ba);Bl=n(yr,"Favorite Color"),yr.forEach(e),La=o(ie),Ma=l(ie,"TH",{}),r(Ma).forEach(e),ie.forEach(e),Dr.forEach(e),ha.forEach(e),na.forEach(e),this.h()},h(){E(i,"type","checkbox"),E(i,"class","checkbox"),E(W,"type","checkbox"),E(W,"class","checkbox"),ao(b.src,X="/tailwind-css-component-profile-2@56w.png")||E(b,"src",X),E(b,"alt","Avatar Tailwind CSS Component"),E(st,"class","w-12 h-12 mask mask-squircle"),E(ot,"class","avatar"),E(z,"class","font-bold"),E(O,"class","text-sm opacity-50"),E(A,"class","flex items-center space-x-3"),E(J,"class","badge badge-ghost badge-sm"),E(nt,"class","btn btn-ghost btn-xs"),E(at,"type","checkbox"),E(at,"class","checkbox"),ao(P.src,w="/tailwind-css-component-profile-3@56w.png")||E(P,"src",w),E(P,"alt","Avatar Tailwind CSS Component"),E(Rt,"class","w-12 h-12 mask mask-squircle"),E(Et,"class","avatar"),E(pt,"class","font-bold"),E(V,"class","text-sm opacity-50"),E(Tt,"class","flex items-center space-x-3"),E(bt,"class","badge badge-ghost badge-sm"),E(Ze,"class","btn btn-ghost btn-xs"),E(ua,"type","checkbox"),E(ua,"class","checkbox"),ao(Be.src,zl="/tailwind-css-component-profile-4@56w.png")||E(Be,"src",zl),E(Be,"alt","Avatar Tailwind CSS Component"),E(Xe,"class","w-12 h-12 mask mask-squircle"),E(je,"class","avatar"),E(ta,"class","font-bold"),E(ea,"class","text-sm opacity-50"),E(oe,"class","flex items-center space-x-3"),E(aa,"class","badge badge-ghost badge-sm"),E(la,"class","btn btn-ghost btn-xs"),E(ga,"type","checkbox"),E(ga,"class","checkbox"),ao(da.src,Na="/tailwind-css-component-profile-5@56w.png")||E(da,"src",Na),E(da,"alt","Avatar Tailwind CSS Component"),E(ra,"class","w-12 h-12 mask mask-squircle"),E(Ge,"class","avatar"),E(Fe,"class","font-bold"),E(Dt,"class","text-sm opacity-50"),E(Ve,"class","flex items-center space-x-3"),E(Me,"class","badge badge-ghost badge-sm"),E(oa,"class","btn btn-ghost btn-xs"),E(f,"class","table w-full"),E(c,"class","overflow-x-auto w-full")},m(Va,na){Ot(Va,c,na),t(c,f),t(f,_),t(_,h),t(h,p),t(p,y),t(y,i),t(h,T),t(h,N),t(N,x),t(h,q),t(h,Z),t(Z,R),t(h,lt),t(h,v),t(v,u),t(h,D),t(h,G),t(f,rt),t(f,M),t(M,H),t(H,j),t(j,ht),t(ht,W),t(H,m),t(H,I),t(I,A),t(A,ot),t(ot,st),t(st,b),t(A,$t),t(A,tt),t(tt,z),t(z,yt),t(tt,ct),t(tt,O),t(O,gt),t(H,it),t(H,L),t(L,St),t(L,vt),t(L,$),t(L,J),t(J,ft),t(H,Ht),t(H,K),t(K,B),t(H,ut),t(H,Q),t(Q,nt),t(nt,_t),t(M,Y),t(M,U),t(U,F),t(F,et),t(et,at),t(U,kt),t(U,g),t(g,Tt),t(Tt,Et),t(Et,Rt),t(Rt,P),t(Tt,Vt),t(Tt,wt),t(wt,pt),t(pt,Gt),t(wt,C),t(wt,V),t(V,It),t(U,Ft),t(U,mt),t(mt,S),t(mt,Nt),t(mt,Mt),t(mt,bt),t(bt,zt),t(U,cl),t(U,ze),t(ze,il),t(U,vl),t(U,Oe),t(Oe,Ze),t(Ze,fl),t(M,va),t(M,Jt),t(Jt,fa),t(fa,Je),t(Je,ua),t(Jt,ul),t(Jt,Ct),t(Ct,oe),t(oe,je),t(je,Xe),t(Xe,Be),t(oe,_l),t(oe,Pe),t(Pe,ta),t(ta,Tl),t(Pe,_a),t(Pe,ea),t(ea,El),t(Jt,Ta),t(Jt,Le),t(Le,pl),t(Le,Ea),t(Le,ml),t(Le,aa),t(aa,pa),t(Jt,bl),t(Jt,ma),t(ma,xt),t(Jt,ba),t(Jt,Da),t(Da,la),t(la,$a),t(M,Dl),t(M,Wt),t(Wt,We),t(We,ya),t(ya,ga),t(Wt,Sa),t(Wt,Ha),t(Ha,Ve),t(Ve,Ge),t(Ge,ra),t(ra,da),t(Ve,$l),t(Ve,Ke),t(Ke,Fe),t(Fe,yl),t(Ke,gl),t(Ke,Dt),t(Dt,wa),t(Wt,Sl),t(Wt,Ne),t(Ne,Ca),t(Ne,Hl),t(Ne,wl),t(Ne,Me),t(Me,Cl),t(Wt,Rl),t(Wt,Qe),t(Qe,kl),t(Wt,Il),t(Wt,Ue),t(Ue,oa),t(oa,xl),t(f,Ra),t(f,ka),t(ka,Kt),t(Kt,sa),t(Kt,Al),t(Kt,Ia),t(Ia,At),t(Kt,xa),t(Kt,Aa),t(Aa,Pl),t(Kt,Pa),t(Kt,Ba),t(Ba,Bl),t(Kt,La),t(Kt,Ma)},d(Va){Va&&e(c)}}}function r1(dt){let c,f=`<div class="overflow-x-auto w-full">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox">
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Hart Hagerty</div>
              <div class="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Brice Swyre</div>
              <div class="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Marjy Ferencz</div>
              <div class="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Yancy Tear</div>
              <div class="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function d1(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt,v,u,D,G,rt,M,H,j,ht,W,m,I,A,ot,st,b,X,$t,tt,z,yt,ct,O,gt,it,L,St,vt,$,J,ft,Ht,K,B,ut,Q,nt,_t,Y,U,F,et,at,kt,g,Tt,Et,Rt,P,w,Vt,wt,pt,Gt,C,V,It,Ft,mt,S,Nt,Mt,bt,zt,cl,ze,il,vl,Oe,Ze,fl,va,Jt,fa,Je,ua,ul,Ct,oe,je,Xe,Be,zl,_l,Pe,ta,Tl,_a,ea,El,Ta,Le,pl,Ea,ml,aa,pa,bl,ma,xt,ba,Da,la,$a,Dl,Wt,We,ya,ga,Sa,Ha,Ve,Ge,ra,da,Na,$l,Ke,Fe,yl,gl,Dt,wa,Sl,Ne,Ca,Hl,wl,Me,Cl,Rl,Qe,kl,Il,Ue,oa,xl,Ra,ka,Kt,sa,Al,Ia,At,xa,Aa,Pl,Pa,Ba,Bl,La,Ma,Va,na,ha,Ol,re,Jl,Wl,za,Kl,Ql,se,ne,Ul,Pt,Oa,Ja,ql,Wa,Ka,Yl,Qa,Ga,Zl,Ua,jl,Xl,de,tr,er,qa,Ya,ar,Za,ja,lr,Bt,qe,rr,dr,Xa,or,he,tl,sr,nr,ca,hr,cr,ia,ir,vr,Ye,fr,ur,el,_r,ce,Lt,al,Tr,ll,rl,Er,dl,ol,pr,Fa,sl,mr,br,nl,Dr,ie,hl,$r,yr,Rr,lo,ro,Qt,kr,oo,so,Ir,no,ho,xr,co,io,Ar,vo,fo,Pr,uo,_o,Br,To,Eo,Lr,po,mo,Ut,Vr,bo,Do,Gr,$o,yo,Fr,go,So,Nr,Ho,wo,Mr,Co,Ro,zr,ko,Io,Or,xo,Ao,qt,Jr,Po,Bo,Wr,Lo,Vo,Kr,Go,Fo,Qr,No,Mo,Ur,zo,Oo,qr,Jo,Wo,Yr,Ko,Qo,Yt,Zr,Uo,qo,jr,Yo,Zo,Xr,jo,Xo,td,ts,es,ed,as,ls,ad,rs,ds,ld,os,ss,Zt,rd,ns,hs,dd,cs,is,od,vs,fs,sd,us,_s,nd,Ts,Es,hd,ps,ms,cd,bs,Ds,jt,id,$s,ys,vd,gs,Ss,fd,Hs,ws,ud,Cs,Rs,_d,ks,Is,Td,xs,As,Ed,Ps,Bs,Xt,pd,Ls,Vs,md,Gs,Fs,bd,Ns,Ms,Dd,zs,Os,$d,Js,Ws,yd,Ks,Qs,gd,Us,qs,te,Sd,Ys,Zs,Hd,js,Xs,wd,tn,en,Cd,an,ln,Rd,rn,dn,kd,on,sn,Id,nn,hn,ee,xd,cn,vn,Ad,fn,un,Pd,_n,Tn,Bd,En,pn,Ld,mn,bn,Vd,Dn,$n,Gd,yn,gn,ae,Fd,Sn,Hn,Nd,wn,Cn,Md,Rn,kn,zd,In,xn,Od,An,Pn,Jd,Bn,Ln,Wd,Vn,Gn,Kd,le,to,Fn,Qd,Nn,Mn,Ud,zn,On,qd,Jn,Wn,Yd,Kn,Qn,Zd,Un,qn,jd,Yn;return{c(){c=a("div"),f=a("table"),_=a("thead"),h=a("tr"),p=a("th"),y=d(),i=a("th"),T=s("Name"),N=d(),x=a("th"),q=s("Job"),Z=d(),R=a("th"),lt=s("company"),v=d(),u=a("th"),D=s("location"),G=d(),rt=a("th"),M=s("Last Login"),H=d(),j=a("th"),ht=s("Favorite Color"),W=d(),m=a("tbody"),I=a("tr"),A=a("th"),ot=s("1"),st=d(),b=a("td"),X=s("Cy Ganderton"),$t=d(),tt=a("td"),z=s("Quality Control Specialist"),yt=d(),ct=a("td"),O=s("Littel, Schaden and Vandervort"),gt=d(),it=a("td"),L=s("Canada"),St=d(),vt=a("td"),$=s("12/16/2020"),J=d(),ft=a("td"),Ht=s("Blue"),K=d(),B=a("tr"),ut=a("th"),Q=s("2"),nt=d(),_t=a("td"),Y=s("Hart Hagerty"),U=d(),F=a("td"),et=s("Desktop Support Technician"),at=d(),kt=a("td"),g=s("Zemlak, Daniel and Leannon"),Tt=d(),Et=a("td"),Rt=s("United States"),P=d(),w=a("td"),Vt=s("12/5/2020"),wt=d(),pt=a("td"),Gt=s("Purple"),C=d(),V=a("tr"),It=a("th"),Ft=s("3"),mt=d(),S=a("td"),Nt=s("Brice Swyre"),Mt=d(),bt=a("td"),zt=s("Tax Accountant"),cl=d(),ze=a("td"),il=s("Carroll Group"),vl=d(),Oe=a("td"),Ze=s("China"),fl=d(),va=a("td"),Jt=s("8/15/2020"),fa=d(),Je=a("td"),ua=s("Red"),ul=d(),Ct=a("tr"),oe=a("th"),je=s("4"),Xe=d(),Be=a("td"),zl=s("Marjy Ferencz"),_l=d(),Pe=a("td"),ta=s("Office Assistant I"),Tl=d(),_a=a("td"),ea=s("Rowe-Schoen"),El=d(),Ta=a("td"),Le=s("Russia"),pl=d(),Ea=a("td"),ml=s("3/25/2021"),aa=d(),pa=a("td"),bl=s("Crimson"),ma=d(),xt=a("tr"),ba=a("th"),Da=s("5"),la=d(),$a=a("td"),Dl=s("Yancy Tear"),Wt=d(),We=a("td"),ya=s("Community Outreach Specialist"),ga=d(),Sa=a("td"),Ha=s("Wyman-Ledner"),Ve=d(),Ge=a("td"),ra=s("Brazil"),da=d(),Na=a("td"),$l=s("5/22/2020"),Ke=d(),Fe=a("td"),yl=s("Indigo"),gl=d(),Dt=a("tr"),wa=a("th"),Sl=s("6"),Ne=d(),Ca=a("td"),Hl=s("Irma Vasilik"),wl=d(),Me=a("td"),Cl=s("Editor"),Rl=d(),Qe=a("td"),kl=s("Wiza, Bins and Emard"),Il=d(),Ue=a("td"),oa=s("Venezuela"),xl=d(),Ra=a("td"),ka=s("12/8/2020"),Kt=d(),sa=a("td"),Al=s("Purple"),Ia=d(),At=a("tr"),xa=a("th"),Aa=s("7"),Pl=d(),Pa=a("td"),Ba=s("Meghann Durtnal"),Bl=d(),La=a("td"),Ma=s("Staff Accountant IV"),Va=d(),na=a("td"),ha=s("Schuster-Schimmel"),Ol=d(),re=a("td"),Jl=s("Philippines"),Wl=d(),za=a("td"),Kl=s("2/17/2021"),Ql=d(),se=a("td"),ne=s("Yellow"),Ul=d(),Pt=a("tr"),Oa=a("th"),Ja=s("8"),ql=d(),Wa=a("td"),Ka=s("Sammy Seston"),Yl=d(),Qa=a("td"),Ga=s("Accountant I"),Zl=d(),Ua=a("td"),jl=s("O'Hara, Welch and Keebler"),Xl=d(),de=a("td"),tr=s("Indonesia"),er=d(),qa=a("td"),Ya=s("5/23/2020"),ar=d(),Za=a("td"),ja=s("Crimson"),lr=d(),Bt=a("tr"),qe=a("th"),rr=s("9"),dr=d(),Xa=a("td"),or=s("Lesya Tinham"),he=d(),tl=a("td"),sr=s("Safety Technician IV"),nr=d(),ca=a("td"),hr=s("Turner-Kuhlman"),cr=d(),ia=a("td"),ir=s("Philippines"),vr=d(),Ye=a("td"),fr=s("2/21/2021"),ur=d(),el=a("td"),_r=s("Maroon"),ce=d(),Lt=a("tr"),al=a("th"),Tr=s("10"),ll=d(),rl=a("td"),Er=s("Zaneta Tewkesbury"),dl=d(),ol=a("td"),pr=s("VP Marketing"),Fa=d(),sl=a("td"),mr=s("Sauer LLC"),br=d(),nl=a("td"),Dr=s("Chad"),ie=d(),hl=a("td"),$r=s("6/23/2020"),yr=d(),Rr=a("td"),lo=s("Green"),ro=d(),Qt=a("tr"),kr=a("th"),oo=s("11"),so=d(),Ir=a("td"),no=s("Andy Tipple"),ho=d(),xr=a("td"),co=s("Librarian"),io=d(),Ar=a("td"),vo=s("Hilpert Group"),fo=d(),Pr=a("td"),uo=s("Poland"),_o=d(),Br=a("td"),To=s("7/9/2020"),Eo=d(),Lr=a("td"),po=s("Indigo"),mo=d(),Ut=a("tr"),Vr=a("th"),bo=s("12"),Do=d(),Gr=a("td"),$o=s("Sophi Biles"),yo=d(),Fr=a("td"),go=s("Recruiting Manager"),So=d(),Nr=a("td"),Ho=s("Gutmann Inc"),wo=d(),Mr=a("td"),Co=s("Indonesia"),Ro=d(),zr=a("td"),ko=s("2/12/2021"),Io=d(),Or=a("td"),xo=s("Maroon"),Ao=d(),qt=a("tr"),Jr=a("th"),Po=s("13"),Bo=d(),Wr=a("td"),Lo=s("Florida Garces"),Vo=d(),Kr=a("td"),Go=s("Web Developer IV"),Fo=d(),Qr=a("td"),No=s("Gaylord, Pacocha and Baumbach"),Mo=d(),Ur=a("td"),zo=s("Poland"),Oo=d(),qr=a("td"),Jo=s("5/31/2020"),Wo=d(),Yr=a("td"),Ko=s("Purple"),Qo=d(),Yt=a("tr"),Zr=a("th"),Uo=s("14"),qo=d(),jr=a("td"),Yo=s("Maribeth Popping"),Zo=d(),Xr=a("td"),jo=s("Analyst Programmer"),Xo=d(),td=a("td"),ts=s("Deckow-Pouros"),es=d(),ed=a("td"),as=s("Portugal"),ls=d(),ad=a("td"),rs=s("4/27/2021"),ds=d(),ld=a("td"),os=s("Aquamarine"),ss=d(),Zt=a("tr"),rd=a("th"),ns=s("15"),hs=d(),dd=a("td"),cs=s("Moritz Dryburgh"),is=d(),od=a("td"),vs=s("Dental Hygienist"),fs=d(),sd=a("td"),us=s("Schiller, Cole and Hackett"),_s=d(),nd=a("td"),Ts=s("Sri Lanka"),Es=d(),hd=a("td"),ps=s("8/8/2020"),ms=d(),cd=a("td"),bs=s("Crimson"),Ds=d(),jt=a("tr"),id=a("th"),$s=s("16"),ys=d(),vd=a("td"),gs=s("Reid Semiras"),Ss=d(),fd=a("td"),Hs=s("Teacher"),ws=d(),ud=a("td"),Cs=s("Sporer, Sipes and Rogahn"),Rs=d(),_d=a("td"),ks=s("Poland"),Is=d(),Td=a("td"),xs=s("7/30/2020"),As=d(),Ed=a("td"),Ps=s("Green"),Bs=d(),Xt=a("tr"),pd=a("th"),Ls=s("17"),Vs=d(),md=a("td"),Gs=s("Alec Lethby"),Fs=d(),bd=a("td"),Ns=s("Teacher"),Ms=d(),Dd=a("td"),zs=s("Reichel, Glover and Hamill"),Os=d(),$d=a("td"),Js=s("China"),Ws=d(),yd=a("td"),Ks=s("2/28/2021"),Qs=d(),gd=a("td"),Us=s("Khaki"),qs=d(),te=a("tr"),Sd=a("th"),Ys=s("18"),Zs=d(),Hd=a("td"),js=s("Aland Wilber"),Xs=d(),wd=a("td"),tn=s("Quality Control Specialist"),en=d(),Cd=a("td"),an=s("Kshlerin, Rogahn and Swaniawski"),ln=d(),Rd=a("td"),rn=s("Czech Republic"),dn=d(),kd=a("td"),on=s("9/29/2020"),sn=d(),Id=a("td"),nn=s("Purple"),hn=d(),ee=a("tr"),xd=a("th"),cn=s("19"),vn=d(),Ad=a("td"),fn=s("Teddie Duerden"),un=d(),Pd=a("td"),_n=s("Staff Accountant III"),Tn=d(),Bd=a("td"),En=s("Pouros, Ullrich and Windler"),pn=d(),Ld=a("td"),mn=s("France"),bn=d(),Vd=a("td"),Dn=s("10/27/2020"),$n=d(),Gd=a("td"),yn=s("Aquamarine"),gn=d(),ae=a("tr"),Fd=a("th"),Sn=s("20"),Hn=d(),Nd=a("td"),wn=s("Lorelei Blackstone"),Cn=d(),Md=a("td"),Rn=s("Data Coordinator"),kn=d(),zd=a("td"),In=s("Witting, Kutch and Greenfelder"),xn=d(),Od=a("td"),An=s("Kazakhstan"),Pn=d(),Jd=a("td"),Bn=s("6/3/2020"),Ln=d(),Wd=a("td"),Vn=s("Red"),Gn=d(),Kd=a("tfoot"),le=a("tr"),to=a("th"),Fn=d(),Qd=a("th"),Nn=s("Name"),Mn=d(),Ud=a("th"),zn=s("Job"),On=d(),qd=a("th"),Jn=s("company"),Wn=d(),Yd=a("th"),Kn=s("location"),Qn=d(),Zd=a("th"),Un=s("Last Login"),qn=d(),jd=a("th"),Yn=s("Favorite Color"),this.h()},l(Xd){c=l(Xd,"DIV",{class:!0});var eo=r(c);f=l(eo,"TABLE",{class:!0});var gr=r(f);_=l(gr,"THEAD",{});var Zn=r(_);h=l(Zn,"TR",{});var ve=r(h);p=l(ve,"TH",{}),r(p).forEach(e),y=o(ve),i=l(ve,"TH",{});var jn=r(i);T=n(jn,"Name"),jn.forEach(e),N=o(ve),x=l(ve,"TH",{});var Xn=r(x);q=n(Xn,"Job"),Xn.forEach(e),Z=o(ve),R=l(ve,"TH",{});var th=r(R);lt=n(th,"company"),th.forEach(e),v=o(ve),u=l(ve,"TH",{});var eh=r(u);D=n(eh,"location"),eh.forEach(e),G=o(ve),rt=l(ve,"TH",{});var ah=r(rt);M=n(ah,"Last Login"),ah.forEach(e),H=o(ve),j=l(ve,"TH",{});var lh=r(j);ht=n(lh,"Favorite Color"),lh.forEach(e),ve.forEach(e),Zn.forEach(e),W=o(gr),m=l(gr,"TBODY",{});var k=r(m);I=l(k,"TR",{});var fe=r(I);A=l(fe,"TH",{});var rh=r(A);ot=n(rh,"1"),rh.forEach(e),st=o(fe),b=l(fe,"TD",{});var dh=r(b);X=n(dh,"Cy Ganderton"),dh.forEach(e),$t=o(fe),tt=l(fe,"TD",{});var oh=r(tt);z=n(oh,"Quality Control Specialist"),oh.forEach(e),yt=o(fe),ct=l(fe,"TD",{});var sh=r(ct);O=n(sh,"Littel, Schaden and Vandervort"),sh.forEach(e),gt=o(fe),it=l(fe,"TD",{});var nh=r(it);L=n(nh,"Canada"),nh.forEach(e),St=o(fe),vt=l(fe,"TD",{});var hh=r(vt);$=n(hh,"12/16/2020"),hh.forEach(e),J=o(fe),ft=l(fe,"TD",{});var ch=r(ft);Ht=n(ch,"Blue"),ch.forEach(e),fe.forEach(e),K=o(k),B=l(k,"TR",{});var ue=r(B);ut=l(ue,"TH",{});var ih=r(ut);Q=n(ih,"2"),ih.forEach(e),nt=o(ue),_t=l(ue,"TD",{});var vh=r(_t);Y=n(vh,"Hart Hagerty"),vh.forEach(e),U=o(ue),F=l(ue,"TD",{});var fh=r(F);et=n(fh,"Desktop Support Technician"),fh.forEach(e),at=o(ue),kt=l(ue,"TD",{});var uh=r(kt);g=n(uh,"Zemlak, Daniel and Leannon"),uh.forEach(e),Tt=o(ue),Et=l(ue,"TD",{});var _h=r(Et);Rt=n(_h,"United States"),_h.forEach(e),P=o(ue),w=l(ue,"TD",{});var Th=r(w);Vt=n(Th,"12/5/2020"),Th.forEach(e),wt=o(ue),pt=l(ue,"TD",{});var Eh=r(pt);Gt=n(Eh,"Purple"),Eh.forEach(e),ue.forEach(e),C=o(k),V=l(k,"TR",{});var _e=r(V);It=l(_e,"TH",{});var ph=r(It);Ft=n(ph,"3"),ph.forEach(e),mt=o(_e),S=l(_e,"TD",{});var mh=r(S);Nt=n(mh,"Brice Swyre"),mh.forEach(e),Mt=o(_e),bt=l(_e,"TD",{});var bh=r(bt);zt=n(bh,"Tax Accountant"),bh.forEach(e),cl=o(_e),ze=l(_e,"TD",{});var Dh=r(ze);il=n(Dh,"Carroll Group"),Dh.forEach(e),vl=o(_e),Oe=l(_e,"TD",{});var $h=r(Oe);Ze=n($h,"China"),$h.forEach(e),fl=o(_e),va=l(_e,"TD",{});var yh=r(va);Jt=n(yh,"8/15/2020"),yh.forEach(e),fa=o(_e),Je=l(_e,"TD",{});var gh=r(Je);ua=n(gh,"Red"),gh.forEach(e),_e.forEach(e),ul=o(k),Ct=l(k,"TR",{});var Te=r(Ct);oe=l(Te,"TH",{});var Sh=r(oe);je=n(Sh,"4"),Sh.forEach(e),Xe=o(Te),Be=l(Te,"TD",{});var Hh=r(Be);zl=n(Hh,"Marjy Ferencz"),Hh.forEach(e),_l=o(Te),Pe=l(Te,"TD",{});var wh=r(Pe);ta=n(wh,"Office Assistant I"),wh.forEach(e),Tl=o(Te),_a=l(Te,"TD",{});var Ch=r(_a);ea=n(Ch,"Rowe-Schoen"),Ch.forEach(e),El=o(Te),Ta=l(Te,"TD",{});var Rh=r(Ta);Le=n(Rh,"Russia"),Rh.forEach(e),pl=o(Te),Ea=l(Te,"TD",{});var kh=r(Ea);ml=n(kh,"3/25/2021"),kh.forEach(e),aa=o(Te),pa=l(Te,"TD",{});var Ih=r(pa);bl=n(Ih,"Crimson"),Ih.forEach(e),Te.forEach(e),ma=o(k),xt=l(k,"TR",{});var Ee=r(xt);ba=l(Ee,"TH",{});var xh=r(ba);Da=n(xh,"5"),xh.forEach(e),la=o(Ee),$a=l(Ee,"TD",{});var Ah=r($a);Dl=n(Ah,"Yancy Tear"),Ah.forEach(e),Wt=o(Ee),We=l(Ee,"TD",{});var Ph=r(We);ya=n(Ph,"Community Outreach Specialist"),Ph.forEach(e),ga=o(Ee),Sa=l(Ee,"TD",{});var Bh=r(Sa);Ha=n(Bh,"Wyman-Ledner"),Bh.forEach(e),Ve=o(Ee),Ge=l(Ee,"TD",{});var Lh=r(Ge);ra=n(Lh,"Brazil"),Lh.forEach(e),da=o(Ee),Na=l(Ee,"TD",{});var Vh=r(Na);$l=n(Vh,"5/22/2020"),Vh.forEach(e),Ke=o(Ee),Fe=l(Ee,"TD",{});var Gh=r(Fe);yl=n(Gh,"Indigo"),Gh.forEach(e),Ee.forEach(e),gl=o(k),Dt=l(k,"TR",{});var pe=r(Dt);wa=l(pe,"TH",{});var Fh=r(wa);Sl=n(Fh,"6"),Fh.forEach(e),Ne=o(pe),Ca=l(pe,"TD",{});var Nh=r(Ca);Hl=n(Nh,"Irma Vasilik"),Nh.forEach(e),wl=o(pe),Me=l(pe,"TD",{});var Mh=r(Me);Cl=n(Mh,"Editor"),Mh.forEach(e),Rl=o(pe),Qe=l(pe,"TD",{});var zh=r(Qe);kl=n(zh,"Wiza, Bins and Emard"),zh.forEach(e),Il=o(pe),Ue=l(pe,"TD",{});var Oh=r(Ue);oa=n(Oh,"Venezuela"),Oh.forEach(e),xl=o(pe),Ra=l(pe,"TD",{});var Jh=r(Ra);ka=n(Jh,"12/8/2020"),Jh.forEach(e),Kt=o(pe),sa=l(pe,"TD",{});var Wh=r(sa);Al=n(Wh,"Purple"),Wh.forEach(e),pe.forEach(e),Ia=o(k),At=l(k,"TR",{});var me=r(At);xa=l(me,"TH",{});var Kh=r(xa);Aa=n(Kh,"7"),Kh.forEach(e),Pl=o(me),Pa=l(me,"TD",{});var Qh=r(Pa);Ba=n(Qh,"Meghann Durtnal"),Qh.forEach(e),Bl=o(me),La=l(me,"TD",{});var Uh=r(La);Ma=n(Uh,"Staff Accountant IV"),Uh.forEach(e),Va=o(me),na=l(me,"TD",{});var qh=r(na);ha=n(qh,"Schuster-Schimmel"),qh.forEach(e),Ol=o(me),re=l(me,"TD",{});var Yh=r(re);Jl=n(Yh,"Philippines"),Yh.forEach(e),Wl=o(me),za=l(me,"TD",{});var Zh=r(za);Kl=n(Zh,"2/17/2021"),Zh.forEach(e),Ql=o(me),se=l(me,"TD",{});var jh=r(se);ne=n(jh,"Yellow"),jh.forEach(e),me.forEach(e),Ul=o(k),Pt=l(k,"TR",{});var be=r(Pt);Oa=l(be,"TH",{});var Xh=r(Oa);Ja=n(Xh,"8"),Xh.forEach(e),ql=o(be),Wa=l(be,"TD",{});var tc=r(Wa);Ka=n(tc,"Sammy Seston"),tc.forEach(e),Yl=o(be),Qa=l(be,"TD",{});var ec=r(Qa);Ga=n(ec,"Accountant I"),ec.forEach(e),Zl=o(be),Ua=l(be,"TD",{});var ac=r(Ua);jl=n(ac,"O'Hara, Welch and Keebler"),ac.forEach(e),Xl=o(be),de=l(be,"TD",{});var lc=r(de);tr=n(lc,"Indonesia"),lc.forEach(e),er=o(be),qa=l(be,"TD",{});var rc=r(qa);Ya=n(rc,"5/23/2020"),rc.forEach(e),ar=o(be),Za=l(be,"TD",{});var dc=r(Za);ja=n(dc,"Crimson"),dc.forEach(e),be.forEach(e),lr=o(k),Bt=l(k,"TR",{});var De=r(Bt);qe=l(De,"TH",{});var oc=r(qe);rr=n(oc,"9"),oc.forEach(e),dr=o(De),Xa=l(De,"TD",{});var sc=r(Xa);or=n(sc,"Lesya Tinham"),sc.forEach(e),he=o(De),tl=l(De,"TD",{});var nc=r(tl);sr=n(nc,"Safety Technician IV"),nc.forEach(e),nr=o(De),ca=l(De,"TD",{});var hc=r(ca);hr=n(hc,"Turner-Kuhlman"),hc.forEach(e),cr=o(De),ia=l(De,"TD",{});var cc=r(ia);ir=n(cc,"Philippines"),cc.forEach(e),vr=o(De),Ye=l(De,"TD",{});var ic=r(Ye);fr=n(ic,"2/21/2021"),ic.forEach(e),ur=o(De),el=l(De,"TD",{});var vc=r(el);_r=n(vc,"Maroon"),vc.forEach(e),De.forEach(e),ce=o(k),Lt=l(k,"TR",{});var $e=r(Lt);al=l($e,"TH",{});var fc=r(al);Tr=n(fc,"10"),fc.forEach(e),ll=o($e),rl=l($e,"TD",{});var uc=r(rl);Er=n(uc,"Zaneta Tewkesbury"),uc.forEach(e),dl=o($e),ol=l($e,"TD",{});var _c=r(ol);pr=n(_c,"VP Marketing"),_c.forEach(e),Fa=o($e),sl=l($e,"TD",{});var Tc=r(sl);mr=n(Tc,"Sauer LLC"),Tc.forEach(e),br=o($e),nl=l($e,"TD",{});var Ec=r(nl);Dr=n(Ec,"Chad"),Ec.forEach(e),ie=o($e),hl=l($e,"TD",{});var pc=r(hl);$r=n(pc,"6/23/2020"),pc.forEach(e),yr=o($e),Rr=l($e,"TD",{});var mc=r(Rr);lo=n(mc,"Green"),mc.forEach(e),$e.forEach(e),ro=o(k),Qt=l(k,"TR",{});var ye=r(Qt);kr=l(ye,"TH",{});var bc=r(kr);oo=n(bc,"11"),bc.forEach(e),so=o(ye),Ir=l(ye,"TD",{});var Dc=r(Ir);no=n(Dc,"Andy Tipple"),Dc.forEach(e),ho=o(ye),xr=l(ye,"TD",{});var $c=r(xr);co=n($c,"Librarian"),$c.forEach(e),io=o(ye),Ar=l(ye,"TD",{});var yc=r(Ar);vo=n(yc,"Hilpert Group"),yc.forEach(e),fo=o(ye),Pr=l(ye,"TD",{});var gc=r(Pr);uo=n(gc,"Poland"),gc.forEach(e),_o=o(ye),Br=l(ye,"TD",{});var Sc=r(Br);To=n(Sc,"7/9/2020"),Sc.forEach(e),Eo=o(ye),Lr=l(ye,"TD",{});var Hc=r(Lr);po=n(Hc,"Indigo"),Hc.forEach(e),ye.forEach(e),mo=o(k),Ut=l(k,"TR",{});var ge=r(Ut);Vr=l(ge,"TH",{});var wc=r(Vr);bo=n(wc,"12"),wc.forEach(e),Do=o(ge),Gr=l(ge,"TD",{});var Cc=r(Gr);$o=n(Cc,"Sophi Biles"),Cc.forEach(e),yo=o(ge),Fr=l(ge,"TD",{});var Rc=r(Fr);go=n(Rc,"Recruiting Manager"),Rc.forEach(e),So=o(ge),Nr=l(ge,"TD",{});var kc=r(Nr);Ho=n(kc,"Gutmann Inc"),kc.forEach(e),wo=o(ge),Mr=l(ge,"TD",{});var Ic=r(Mr);Co=n(Ic,"Indonesia"),Ic.forEach(e),Ro=o(ge),zr=l(ge,"TD",{});var xc=r(zr);ko=n(xc,"2/12/2021"),xc.forEach(e),Io=o(ge),Or=l(ge,"TD",{});var Ac=r(Or);xo=n(Ac,"Maroon"),Ac.forEach(e),ge.forEach(e),Ao=o(k),qt=l(k,"TR",{});var Se=r(qt);Jr=l(Se,"TH",{});var Pc=r(Jr);Po=n(Pc,"13"),Pc.forEach(e),Bo=o(Se),Wr=l(Se,"TD",{});var Bc=r(Wr);Lo=n(Bc,"Florida Garces"),Bc.forEach(e),Vo=o(Se),Kr=l(Se,"TD",{});var Lc=r(Kr);Go=n(Lc,"Web Developer IV"),Lc.forEach(e),Fo=o(Se),Qr=l(Se,"TD",{});var Vc=r(Qr);No=n(Vc,"Gaylord, Pacocha and Baumbach"),Vc.forEach(e),Mo=o(Se),Ur=l(Se,"TD",{});var Gc=r(Ur);zo=n(Gc,"Poland"),Gc.forEach(e),Oo=o(Se),qr=l(Se,"TD",{});var Fc=r(qr);Jo=n(Fc,"5/31/2020"),Fc.forEach(e),Wo=o(Se),Yr=l(Se,"TD",{});var Nc=r(Yr);Ko=n(Nc,"Purple"),Nc.forEach(e),Se.forEach(e),Qo=o(k),Yt=l(k,"TR",{});var He=r(Yt);Zr=l(He,"TH",{});var Mc=r(Zr);Uo=n(Mc,"14"),Mc.forEach(e),qo=o(He),jr=l(He,"TD",{});var zc=r(jr);Yo=n(zc,"Maribeth Popping"),zc.forEach(e),Zo=o(He),Xr=l(He,"TD",{});var Oc=r(Xr);jo=n(Oc,"Analyst Programmer"),Oc.forEach(e),Xo=o(He),td=l(He,"TD",{});var Jc=r(td);ts=n(Jc,"Deckow-Pouros"),Jc.forEach(e),es=o(He),ed=l(He,"TD",{});var Wc=r(ed);as=n(Wc,"Portugal"),Wc.forEach(e),ls=o(He),ad=l(He,"TD",{});var Kc=r(ad);rs=n(Kc,"4/27/2021"),Kc.forEach(e),ds=o(He),ld=l(He,"TD",{});var Qc=r(ld);os=n(Qc,"Aquamarine"),Qc.forEach(e),He.forEach(e),ss=o(k),Zt=l(k,"TR",{});var we=r(Zt);rd=l(we,"TH",{});var Uc=r(rd);ns=n(Uc,"15"),Uc.forEach(e),hs=o(we),dd=l(we,"TD",{});var qc=r(dd);cs=n(qc,"Moritz Dryburgh"),qc.forEach(e),is=o(we),od=l(we,"TD",{});var Yc=r(od);vs=n(Yc,"Dental Hygienist"),Yc.forEach(e),fs=o(we),sd=l(we,"TD",{});var Zc=r(sd);us=n(Zc,"Schiller, Cole and Hackett"),Zc.forEach(e),_s=o(we),nd=l(we,"TD",{});var jc=r(nd);Ts=n(jc,"Sri Lanka"),jc.forEach(e),Es=o(we),hd=l(we,"TD",{});var Xc=r(hd);ps=n(Xc,"8/8/2020"),Xc.forEach(e),ms=o(we),cd=l(we,"TD",{});var ti=r(cd);bs=n(ti,"Crimson"),ti.forEach(e),we.forEach(e),Ds=o(k),jt=l(k,"TR",{});var Ce=r(jt);id=l(Ce,"TH",{});var ei=r(id);$s=n(ei,"16"),ei.forEach(e),ys=o(Ce),vd=l(Ce,"TD",{});var ai=r(vd);gs=n(ai,"Reid Semiras"),ai.forEach(e),Ss=o(Ce),fd=l(Ce,"TD",{});var li=r(fd);Hs=n(li,"Teacher"),li.forEach(e),ws=o(Ce),ud=l(Ce,"TD",{});var ri=r(ud);Cs=n(ri,"Sporer, Sipes and Rogahn"),ri.forEach(e),Rs=o(Ce),_d=l(Ce,"TD",{});var di=r(_d);ks=n(di,"Poland"),di.forEach(e),Is=o(Ce),Td=l(Ce,"TD",{});var oi=r(Td);xs=n(oi,"7/30/2020"),oi.forEach(e),As=o(Ce),Ed=l(Ce,"TD",{});var si=r(Ed);Ps=n(si,"Green"),si.forEach(e),Ce.forEach(e),Bs=o(k),Xt=l(k,"TR",{});var Re=r(Xt);pd=l(Re,"TH",{});var ni=r(pd);Ls=n(ni,"17"),ni.forEach(e),Vs=o(Re),md=l(Re,"TD",{});var hi=r(md);Gs=n(hi,"Alec Lethby"),hi.forEach(e),Fs=o(Re),bd=l(Re,"TD",{});var ci=r(bd);Ns=n(ci,"Teacher"),ci.forEach(e),Ms=o(Re),Dd=l(Re,"TD",{});var ii=r(Dd);zs=n(ii,"Reichel, Glover and Hamill"),ii.forEach(e),Os=o(Re),$d=l(Re,"TD",{});var vi=r($d);Js=n(vi,"China"),vi.forEach(e),Ws=o(Re),yd=l(Re,"TD",{});var fi=r(yd);Ks=n(fi,"2/28/2021"),fi.forEach(e),Qs=o(Re),gd=l(Re,"TD",{});var ui=r(gd);Us=n(ui,"Khaki"),ui.forEach(e),Re.forEach(e),qs=o(k),te=l(k,"TR",{});var ke=r(te);Sd=l(ke,"TH",{});var _i=r(Sd);Ys=n(_i,"18"),_i.forEach(e),Zs=o(ke),Hd=l(ke,"TD",{});var Ti=r(Hd);js=n(Ti,"Aland Wilber"),Ti.forEach(e),Xs=o(ke),wd=l(ke,"TD",{});var Ei=r(wd);tn=n(Ei,"Quality Control Specialist"),Ei.forEach(e),en=o(ke),Cd=l(ke,"TD",{});var pi=r(Cd);an=n(pi,"Kshlerin, Rogahn and Swaniawski"),pi.forEach(e),ln=o(ke),Rd=l(ke,"TD",{});var mi=r(Rd);rn=n(mi,"Czech Republic"),mi.forEach(e),dn=o(ke),kd=l(ke,"TD",{});var bi=r(kd);on=n(bi,"9/29/2020"),bi.forEach(e),sn=o(ke),Id=l(ke,"TD",{});var Di=r(Id);nn=n(Di,"Purple"),Di.forEach(e),ke.forEach(e),hn=o(k),ee=l(k,"TR",{});var Ie=r(ee);xd=l(Ie,"TH",{});var $i=r(xd);cn=n($i,"19"),$i.forEach(e),vn=o(Ie),Ad=l(Ie,"TD",{});var yi=r(Ad);fn=n(yi,"Teddie Duerden"),yi.forEach(e),un=o(Ie),Pd=l(Ie,"TD",{});var gi=r(Pd);_n=n(gi,"Staff Accountant III"),gi.forEach(e),Tn=o(Ie),Bd=l(Ie,"TD",{});var Si=r(Bd);En=n(Si,"Pouros, Ullrich and Windler"),Si.forEach(e),pn=o(Ie),Ld=l(Ie,"TD",{});var Hi=r(Ld);mn=n(Hi,"France"),Hi.forEach(e),bn=o(Ie),Vd=l(Ie,"TD",{});var wi=r(Vd);Dn=n(wi,"10/27/2020"),wi.forEach(e),$n=o(Ie),Gd=l(Ie,"TD",{});var Ci=r(Gd);yn=n(Ci,"Aquamarine"),Ci.forEach(e),Ie.forEach(e),gn=o(k),ae=l(k,"TR",{});var xe=r(ae);Fd=l(xe,"TH",{});var Ri=r(Fd);Sn=n(Ri,"20"),Ri.forEach(e),Hn=o(xe),Nd=l(xe,"TD",{});var ki=r(Nd);wn=n(ki,"Lorelei Blackstone"),ki.forEach(e),Cn=o(xe),Md=l(xe,"TD",{});var Ii=r(Md);Rn=n(Ii,"Data Coordinator"),Ii.forEach(e),kn=o(xe),zd=l(xe,"TD",{});var xi=r(zd);In=n(xi,"Witting, Kutch and Greenfelder"),xi.forEach(e),xn=o(xe),Od=l(xe,"TD",{});var Ai=r(Od);An=n(Ai,"Kazakhstan"),Ai.forEach(e),Pn=o(xe),Jd=l(xe,"TD",{});var Pi=r(Jd);Bn=n(Pi,"6/3/2020"),Pi.forEach(e),Ln=o(xe),Wd=l(xe,"TD",{});var Bi=r(Wd);Vn=n(Bi,"Red"),Bi.forEach(e),xe.forEach(e),k.forEach(e),Gn=o(gr),Kd=l(gr,"TFOOT",{});var Li=r(Kd);le=l(Li,"TR",{});var Ae=r(le);to=l(Ae,"TH",{}),r(to).forEach(e),Fn=o(Ae),Qd=l(Ae,"TH",{});var Vi=r(Qd);Nn=n(Vi,"Name"),Vi.forEach(e),Mn=o(Ae),Ud=l(Ae,"TH",{});var Gi=r(Ud);zn=n(Gi,"Job"),Gi.forEach(e),On=o(Ae),qd=l(Ae,"TH",{});var Fi=r(qd);Jn=n(Fi,"company"),Fi.forEach(e),Wn=o(Ae),Yd=l(Ae,"TH",{});var Ni=r(Yd);Kn=n(Ni,"location"),Ni.forEach(e),Qn=o(Ae),Zd=l(Ae,"TH",{});var Mi=r(Zd);Un=n(Mi,"Last Login"),Mi.forEach(e),qn=o(Ae),jd=l(Ae,"TH",{});var zi=r(jd);Yn=n(zi,"Favorite Color"),zi.forEach(e),Ae.forEach(e),Li.forEach(e),gr.forEach(e),eo.forEach(e),this.h()},h(){E(f,"class","table table-compact w-full"),E(c,"class","overflow-x-auto")},m(Xd,eo){Ot(Xd,c,eo),t(c,f),t(f,_),t(_,h),t(h,p),t(h,y),t(h,i),t(i,T),t(h,N),t(h,x),t(x,q),t(h,Z),t(h,R),t(R,lt),t(h,v),t(h,u),t(u,D),t(h,G),t(h,rt),t(rt,M),t(h,H),t(h,j),t(j,ht),t(f,W),t(f,m),t(m,I),t(I,A),t(A,ot),t(I,st),t(I,b),t(b,X),t(I,$t),t(I,tt),t(tt,z),t(I,yt),t(I,ct),t(ct,O),t(I,gt),t(I,it),t(it,L),t(I,St),t(I,vt),t(vt,$),t(I,J),t(I,ft),t(ft,Ht),t(m,K),t(m,B),t(B,ut),t(ut,Q),t(B,nt),t(B,_t),t(_t,Y),t(B,U),t(B,F),t(F,et),t(B,at),t(B,kt),t(kt,g),t(B,Tt),t(B,Et),t(Et,Rt),t(B,P),t(B,w),t(w,Vt),t(B,wt),t(B,pt),t(pt,Gt),t(m,C),t(m,V),t(V,It),t(It,Ft),t(V,mt),t(V,S),t(S,Nt),t(V,Mt),t(V,bt),t(bt,zt),t(V,cl),t(V,ze),t(ze,il),t(V,vl),t(V,Oe),t(Oe,Ze),t(V,fl),t(V,va),t(va,Jt),t(V,fa),t(V,Je),t(Je,ua),t(m,ul),t(m,Ct),t(Ct,oe),t(oe,je),t(Ct,Xe),t(Ct,Be),t(Be,zl),t(Ct,_l),t(Ct,Pe),t(Pe,ta),t(Ct,Tl),t(Ct,_a),t(_a,ea),t(Ct,El),t(Ct,Ta),t(Ta,Le),t(Ct,pl),t(Ct,Ea),t(Ea,ml),t(Ct,aa),t(Ct,pa),t(pa,bl),t(m,ma),t(m,xt),t(xt,ba),t(ba,Da),t(xt,la),t(xt,$a),t($a,Dl),t(xt,Wt),t(xt,We),t(We,ya),t(xt,ga),t(xt,Sa),t(Sa,Ha),t(xt,Ve),t(xt,Ge),t(Ge,ra),t(xt,da),t(xt,Na),t(Na,$l),t(xt,Ke),t(xt,Fe),t(Fe,yl),t(m,gl),t(m,Dt),t(Dt,wa),t(wa,Sl),t(Dt,Ne),t(Dt,Ca),t(Ca,Hl),t(Dt,wl),t(Dt,Me),t(Me,Cl),t(Dt,Rl),t(Dt,Qe),t(Qe,kl),t(Dt,Il),t(Dt,Ue),t(Ue,oa),t(Dt,xl),t(Dt,Ra),t(Ra,ka),t(Dt,Kt),t(Dt,sa),t(sa,Al),t(m,Ia),t(m,At),t(At,xa),t(xa,Aa),t(At,Pl),t(At,Pa),t(Pa,Ba),t(At,Bl),t(At,La),t(La,Ma),t(At,Va),t(At,na),t(na,ha),t(At,Ol),t(At,re),t(re,Jl),t(At,Wl),t(At,za),t(za,Kl),t(At,Ql),t(At,se),t(se,ne),t(m,Ul),t(m,Pt),t(Pt,Oa),t(Oa,Ja),t(Pt,ql),t(Pt,Wa),t(Wa,Ka),t(Pt,Yl),t(Pt,Qa),t(Qa,Ga),t(Pt,Zl),t(Pt,Ua),t(Ua,jl),t(Pt,Xl),t(Pt,de),t(de,tr),t(Pt,er),t(Pt,qa),t(qa,Ya),t(Pt,ar),t(Pt,Za),t(Za,ja),t(m,lr),t(m,Bt),t(Bt,qe),t(qe,rr),t(Bt,dr),t(Bt,Xa),t(Xa,or),t(Bt,he),t(Bt,tl),t(tl,sr),t(Bt,nr),t(Bt,ca),t(ca,hr),t(Bt,cr),t(Bt,ia),t(ia,ir),t(Bt,vr),t(Bt,Ye),t(Ye,fr),t(Bt,ur),t(Bt,el),t(el,_r),t(m,ce),t(m,Lt),t(Lt,al),t(al,Tr),t(Lt,ll),t(Lt,rl),t(rl,Er),t(Lt,dl),t(Lt,ol),t(ol,pr),t(Lt,Fa),t(Lt,sl),t(sl,mr),t(Lt,br),t(Lt,nl),t(nl,Dr),t(Lt,ie),t(Lt,hl),t(hl,$r),t(Lt,yr),t(Lt,Rr),t(Rr,lo),t(m,ro),t(m,Qt),t(Qt,kr),t(kr,oo),t(Qt,so),t(Qt,Ir),t(Ir,no),t(Qt,ho),t(Qt,xr),t(xr,co),t(Qt,io),t(Qt,Ar),t(Ar,vo),t(Qt,fo),t(Qt,Pr),t(Pr,uo),t(Qt,_o),t(Qt,Br),t(Br,To),t(Qt,Eo),t(Qt,Lr),t(Lr,po),t(m,mo),t(m,Ut),t(Ut,Vr),t(Vr,bo),t(Ut,Do),t(Ut,Gr),t(Gr,$o),t(Ut,yo),t(Ut,Fr),t(Fr,go),t(Ut,So),t(Ut,Nr),t(Nr,Ho),t(Ut,wo),t(Ut,Mr),t(Mr,Co),t(Ut,Ro),t(Ut,zr),t(zr,ko),t(Ut,Io),t(Ut,Or),t(Or,xo),t(m,Ao),t(m,qt),t(qt,Jr),t(Jr,Po),t(qt,Bo),t(qt,Wr),t(Wr,Lo),t(qt,Vo),t(qt,Kr),t(Kr,Go),t(qt,Fo),t(qt,Qr),t(Qr,No),t(qt,Mo),t(qt,Ur),t(Ur,zo),t(qt,Oo),t(qt,qr),t(qr,Jo),t(qt,Wo),t(qt,Yr),t(Yr,Ko),t(m,Qo),t(m,Yt),t(Yt,Zr),t(Zr,Uo),t(Yt,qo),t(Yt,jr),t(jr,Yo),t(Yt,Zo),t(Yt,Xr),t(Xr,jo),t(Yt,Xo),t(Yt,td),t(td,ts),t(Yt,es),t(Yt,ed),t(ed,as),t(Yt,ls),t(Yt,ad),t(ad,rs),t(Yt,ds),t(Yt,ld),t(ld,os),t(m,ss),t(m,Zt),t(Zt,rd),t(rd,ns),t(Zt,hs),t(Zt,dd),t(dd,cs),t(Zt,is),t(Zt,od),t(od,vs),t(Zt,fs),t(Zt,sd),t(sd,us),t(Zt,_s),t(Zt,nd),t(nd,Ts),t(Zt,Es),t(Zt,hd),t(hd,ps),t(Zt,ms),t(Zt,cd),t(cd,bs),t(m,Ds),t(m,jt),t(jt,id),t(id,$s),t(jt,ys),t(jt,vd),t(vd,gs),t(jt,Ss),t(jt,fd),t(fd,Hs),t(jt,ws),t(jt,ud),t(ud,Cs),t(jt,Rs),t(jt,_d),t(_d,ks),t(jt,Is),t(jt,Td),t(Td,xs),t(jt,As),t(jt,Ed),t(Ed,Ps),t(m,Bs),t(m,Xt),t(Xt,pd),t(pd,Ls),t(Xt,Vs),t(Xt,md),t(md,Gs),t(Xt,Fs),t(Xt,bd),t(bd,Ns),t(Xt,Ms),t(Xt,Dd),t(Dd,zs),t(Xt,Os),t(Xt,$d),t($d,Js),t(Xt,Ws),t(Xt,yd),t(yd,Ks),t(Xt,Qs),t(Xt,gd),t(gd,Us),t(m,qs),t(m,te),t(te,Sd),t(Sd,Ys),t(te,Zs),t(te,Hd),t(Hd,js),t(te,Xs),t(te,wd),t(wd,tn),t(te,en),t(te,Cd),t(Cd,an),t(te,ln),t(te,Rd),t(Rd,rn),t(te,dn),t(te,kd),t(kd,on),t(te,sn),t(te,Id),t(Id,nn),t(m,hn),t(m,ee),t(ee,xd),t(xd,cn),t(ee,vn),t(ee,Ad),t(Ad,fn),t(ee,un),t(ee,Pd),t(Pd,_n),t(ee,Tn),t(ee,Bd),t(Bd,En),t(ee,pn),t(ee,Ld),t(Ld,mn),t(ee,bn),t(ee,Vd),t(Vd,Dn),t(ee,$n),t(ee,Gd),t(Gd,yn),t(m,gn),t(m,ae),t(ae,Fd),t(Fd,Sn),t(ae,Hn),t(ae,Nd),t(Nd,wn),t(ae,Cn),t(ae,Md),t(Md,Rn),t(ae,kn),t(ae,zd),t(zd,In),t(ae,xn),t(ae,Od),t(Od,An),t(ae,Pn),t(ae,Jd),t(Jd,Bn),t(ae,Ln),t(ae,Wd),t(Wd,Vn),t(f,Gn),t(f,Kd),t(Kd,le),t(le,to),t(le,Fn),t(le,Qd),t(Qd,Nn),t(le,Mn),t(le,Ud),t(Ud,zn),t(le,On),t(le,qd),t(qd,Jn),t(le,Wn),t(le,Yd),t(Yd,Kn),t(le,Qn),t(le,Zd),t(Zd,Un),t(le,qn),t(le,jd),t(jd,Yn)},d(Xd){Xd&&e(c)}}}function o1(dt){let c,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-compact w-full">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,_,h,p,y;return{c(){c=a("pre"),_=s(f),this.h()},l(i){c=l(i,"PRE",{slot:!0});var T=r(c);_=n(T,f),T.forEach(e),this.h()},h(){E(c,"slot","html")},m(i,T){Ot(i,c,T),t(c,_),p||(y=Hr(h=Cr.call(null,c,{to:dt[0]})),p=!0)},p(i,T){h&&wr(h.update)&&T&1&&h.update.call(null,{to:i[0]})},d(i){i&&e(c),p=!1,y()}}}function s1(dt){let c,f,_,h,p,y,i,T,N,x,q,Z,R,lt;return c=new Qi({props:{data:[{type:"component",class:"table",desc:"For <table> element"},{type:"modifier",class:"table-zebra",desc:"For the active tab"},{type:"modifier",class:"active",desc:"For <tr> to highlight current row"},{type:"modifier",class:"hover",desc:"For <tr> to highlight current row on hover"},{type:"responsive",class:"table-normal",desc:"Normal paddings"},{type:"responsive",class:"table-compact",desc:"Compact paddings"}]}}),_=new Sr({props:{title:"Table",$$slots:{html:[Yi],default:[qi]},$$scope:{ctx:dt}}}),p=new Sr({props:{title:"Table with an active row",$$slots:{html:[ji],default:[Zi]},$$scope:{ctx:dt}}}),i=new Sr({props:{title:"Table with a row that highlights on hover",$$slots:{html:[t1],default:[Xi]},$$scope:{ctx:dt}}}),N=new Sr({props:{title:"Zebra",$$slots:{html:[a1],default:[e1]},$$scope:{ctx:dt}}}),q=new Sr({props:{title:"Table with visual elements",$$slots:{html:[r1],default:[l1]},$$scope:{ctx:dt}}}),R=new Sr({props:{title:"Compact table",$$slots:{html:[o1],default:[d1]},$$scope:{ctx:dt}}}),{c(){Ll(c.$$.fragment),f=d(),Ll(_.$$.fragment),h=d(),Ll(p.$$.fragment),y=d(),Ll(i.$$.fragment),T=d(),Ll(N.$$.fragment),x=d(),Ll(q.$$.fragment),Z=d(),Ll(R.$$.fragment)},l(v){Vl(c.$$.fragment,v),f=o(v),Vl(_.$$.fragment,v),h=o(v),Vl(p.$$.fragment,v),y=o(v),Vl(i.$$.fragment,v),T=o(v),Vl(N.$$.fragment,v),x=o(v),Vl(q.$$.fragment,v),Z=o(v),Vl(R.$$.fragment,v)},m(v,u){Gl(c,v,u),Ot(v,f,u),Gl(_,v,u),Ot(v,h,u),Gl(p,v,u),Ot(v,y,u),Gl(i,v,u),Ot(v,T,u),Gl(N,v,u),Ot(v,x,u),Gl(q,v,u),Ot(v,Z,u),Gl(R,v,u),lt=!0},p(v,[u]){const D={};u&3&&(D.$$scope={dirty:u,ctx:v}),_.$set(D);const G={};u&3&&(G.$$scope={dirty:u,ctx:v}),p.$set(G);const rt={};u&3&&(rt.$$scope={dirty:u,ctx:v}),i.$set(rt);const M={};u&3&&(M.$$scope={dirty:u,ctx:v}),N.$set(M);const H={};u&3&&(H.$$scope={dirty:u,ctx:v}),q.$set(H);const j={};u&3&&(j.$$scope={dirty:u,ctx:v}),R.$set(j)},i(v){lt||(Fl(c.$$.fragment,v),Fl(_.$$.fragment,v),Fl(p.$$.fragment,v),Fl(i.$$.fragment,v),Fl(N.$$.fragment,v),Fl(q.$$.fragment,v),Fl(R.$$.fragment,v),lt=!0)},o(v){Nl(c.$$.fragment,v),Nl(_.$$.fragment,v),Nl(p.$$.fragment,v),Nl(i.$$.fragment,v),Nl(N.$$.fragment,v),Nl(q.$$.fragment,v),Nl(R.$$.fragment,v),lt=!1},d(v){Ml(c,v),v&&e(f),Ml(_,v),v&&e(h),Ml(p,v),v&&e(y),Ml(i,v),v&&e(T),Ml(N,v),v&&e(x),Ml(q,v),v&&e(Z),Ml(R,v)}}}const v1={title:"Table",desc:"Table can be used to show a list of data in a table format.",published:!0};function n1(dt,c,f){let _;return Ki(dt,Ui,h=>f(0,_=h)),[_]}class f1 extends Oi{constructor(c){super();Ji(this,c,n1,s1,Wi,{})}}export{f1 as default,v1 as metadata};
