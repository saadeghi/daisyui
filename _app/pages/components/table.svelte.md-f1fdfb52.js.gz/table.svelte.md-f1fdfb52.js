import{S as Qi,i as qi,s as Ui,C as Zn,w as fd,x as ud,y as pd,z as Yi,A as Ji,q as _d,o as md,B as Td,K as Zi,ag as Wi,k as r,m as o,g as Dt,d as e,e as a,t as s,c as d,a as l,h as n,b as E,F as t,a9 as Me,Q as Oe,O as ao}from"../../chunks/vendor-3400f70d.js";import{M as ji}from"../../chunks/_markdown-0aba8325.js";import{p as Xi,C as tv,a as Hl,r as Je}from"../../chunks/actions-bb6d9301.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-1a8b7daa.js";import"../../chunks/index-2aac554d.js";import"../../chunks/SEO-dc8deace.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-11002da1.js";function ev(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=r(),i=a("th"),v=s("Name"),z=r(),I=a("th"),Y=s("Job"),j=r(),R=a("th"),lt=s("Favorite Color"),_=r(),m=a("tbody"),D=a("tr"),V=a("th"),rt=s("1"),M=r(),S=a("td"),X=s("Cy Ganderton"),ht=r(),K=a("td"),b=s("Quality Control Specialist"),P=r(),A=a("td"),ot=s("Blue"),st=r(),$=a("tr"),tt=a("th"),yt=s("2"),et=r(),O=a("td"),gt=s("Hart Hagerty"),ct=r(),J=a("td"),wt=s("Desktop Support Technician"),it=r(),L=a("td"),St=s("Purple"),vt=r(),y=a("tr"),W=a("th"),ft=s("3"),Ct=r(),Q=a("td"),N=s("Brice Swyre"),ut=r(),q=a("td"),nt=s("Tax Accountant"),pt=r(),Z=a("td"),U=s("Red"),this.h()},l(F){h=d(F,"DIV",{class:!0});var at=l(h);f=d(at,"TABLE",{class:!0});var dt=l(f);p=d(dt,"THEAD",{});var xt=l(p);c=d(xt,"TR",{});var g=l(c);u=d(g,"TH",{}),l(u).forEach(e),T=o(g),i=d(g,"TH",{});var _t=l(i);v=n(_t,"Name"),_t.forEach(e),z=o(g),I=d(g,"TH",{});var mt=l(I);Y=n(mt,"Job"),mt.forEach(e),j=o(g),R=d(g,"TH",{});var Rt=l(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),xt.forEach(e),_=o(dt),m=d(dt,"TBODY",{});var B=l(m);D=d(B,"TR",{});var C=l(D);V=d(C,"TH",{});var Gt=l(V);rt=n(Gt,"1"),Gt.forEach(e),M=o(C),S=d(C,"TD",{});var Ht=l(S);X=n(Ht,"Cy Ganderton"),Ht.forEach(e),ht=o(C),K=d(C,"TD",{});var Tt=l(K);b=n(Tt,"Quality Control Specialist"),Tt.forEach(e),P=o(C),A=d(C,"TD",{});var Vt=l(A);ot=n(Vt,"Blue"),Vt.forEach(e),C.forEach(e),st=o(B),$=d(B,"TR",{});var k=l($);tt=d(k,"TH",{});var G=l(tt);yt=n(G,"2"),G.forEach(e),et=o(k),O=d(k,"TD",{});var Pt=l(O);gt=n(Pt,"Hart Hagerty"),Pt.forEach(e),ct=o(k),J=d(k,"TD",{});var Ft=l(J);wt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(k),L=d(k,"TD",{});var Et=l(L);St=n(Et,"Purple"),Et.forEach(e),k.forEach(e),vt=o(B),y=d(B,"TR",{});var w=l(y);W=d(w,"TH",{});var zt=l(W);ft=n(zt,"3"),zt.forEach(e),Ct=o(w),Q=d(w,"TD",{});var Mt=l(Q);N=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(w),q=d(w,"TD",{});var bt=l(q);nt=n(bt,"Tax Accountant"),bt.forEach(e),pt=o(w),Z=d(w,"TD",{});var Ot=l(Z);U=n(Ot,"Red"),Ot.forEach(e),w.forEach(e),B.forEach(e),dt.forEach(e),at.forEach(e),this.h()},h(){E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Dt(F,h,at),t(h,f),t(f,p),t(p,c),t(c,u),t(c,T),t(c,i),t(i,v),t(c,z),t(c,I),t(I,Y),t(c,j),t(c,R),t(R,lt),t(f,_),t(f,m),t(m,D),t(D,V),t(V,rt),t(D,M),t(D,S),t(S,X),t(D,ht),t(D,K),t(K,b),t(D,P),t(D,A),t(A,ot),t(m,st),t(m,$),t($,tt),t(tt,yt),t($,et),t($,O),t(O,gt),t($,ct),t($,J),t(J,wt),t($,it),t($,L),t(L,St),t(m,vt),t(m,y),t(y,W),t(W,ft),t(y,Ct),t(y,Q),t(Q,N),t(y,ut),t(y,q),t(q,nt),t(y,pt),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function av(H){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function dv(H){let h,f=`<div className="overflow-x-auto">
  <table className="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function lv(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=r(),i=a("th"),v=s("Name"),z=r(),I=a("th"),Y=s("Job"),j=r(),R=a("th"),lt=s("Favorite Color"),_=r(),m=a("tbody"),D=a("tr"),V=a("th"),rt=s("1"),M=r(),S=a("td"),X=s("Cy Ganderton"),ht=r(),K=a("td"),b=s("Quality Control Specialist"),P=r(),A=a("td"),ot=s("Blue"),st=r(),$=a("tr"),tt=a("th"),yt=s("2"),et=r(),O=a("td"),gt=s("Hart Hagerty"),ct=r(),J=a("td"),wt=s("Desktop Support Technician"),it=r(),L=a("td"),St=s("Purple"),vt=r(),y=a("tr"),W=a("th"),ft=s("3"),Ct=r(),Q=a("td"),N=s("Brice Swyre"),ut=r(),q=a("td"),nt=s("Tax Accountant"),pt=r(),Z=a("td"),U=s("Red"),this.h()},l(F){h=d(F,"DIV",{class:!0});var at=l(h);f=d(at,"TABLE",{class:!0});var dt=l(f);p=d(dt,"THEAD",{});var xt=l(p);c=d(xt,"TR",{});var g=l(c);u=d(g,"TH",{}),l(u).forEach(e),T=o(g),i=d(g,"TH",{});var _t=l(i);v=n(_t,"Name"),_t.forEach(e),z=o(g),I=d(g,"TH",{});var mt=l(I);Y=n(mt,"Job"),mt.forEach(e),j=o(g),R=d(g,"TH",{});var Rt=l(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),xt.forEach(e),_=o(dt),m=d(dt,"TBODY",{});var B=l(m);D=d(B,"TR",{});var C=l(D);V=d(C,"TH",{});var Gt=l(V);rt=n(Gt,"1"),Gt.forEach(e),M=o(C),S=d(C,"TD",{});var Ht=l(S);X=n(Ht,"Cy Ganderton"),Ht.forEach(e),ht=o(C),K=d(C,"TD",{});var Tt=l(K);b=n(Tt,"Quality Control Specialist"),Tt.forEach(e),P=o(C),A=d(C,"TD",{});var Vt=l(A);ot=n(Vt,"Blue"),Vt.forEach(e),C.forEach(e),st=o(B),$=d(B,"TR",{class:!0});var k=l($);tt=d(k,"TH",{});var G=l(tt);yt=n(G,"2"),G.forEach(e),et=o(k),O=d(k,"TD",{});var Pt=l(O);gt=n(Pt,"Hart Hagerty"),Pt.forEach(e),ct=o(k),J=d(k,"TD",{});var Ft=l(J);wt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(k),L=d(k,"TD",{});var Et=l(L);St=n(Et,"Purple"),Et.forEach(e),k.forEach(e),vt=o(B),y=d(B,"TR",{});var w=l(y);W=d(w,"TH",{});var zt=l(W);ft=n(zt,"3"),zt.forEach(e),Ct=o(w),Q=d(w,"TD",{});var Mt=l(Q);N=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(w),q=d(w,"TD",{});var bt=l(q);nt=n(bt,"Tax Accountant"),bt.forEach(e),pt=o(w),Z=d(w,"TD",{});var Ot=l(Z);U=n(Ot,"Red"),Ot.forEach(e),w.forEach(e),B.forEach(e),dt.forEach(e),at.forEach(e),this.h()},h(){E($,"class","active"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Dt(F,h,at),t(h,f),t(f,p),t(p,c),t(c,u),t(c,T),t(c,i),t(i,v),t(c,z),t(c,I),t(I,Y),t(c,j),t(c,R),t(R,lt),t(f,_),t(f,m),t(m,D),t(D,V),t(V,rt),t(D,M),t(D,S),t(S,X),t(D,ht),t(D,K),t(K,b),t(D,P),t(D,A),t(A,ot),t(m,st),t(m,$),t($,tt),t(tt,yt),t($,et),t($,O),t(O,gt),t($,ct),t($,J),t(J,wt),t($,it),t($,L),t(L,St),t(m,vt),t(m,y),t(y,W),t(W,ft),t(y,Ct),t(y,Q),t(Q,N),t(y,ut),t(y,q),t(q,nt),t(y,pt),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function rv(H){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$active">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function ov(H){let h,f=`<div className="overflow-x-auto">
  <table className="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr className="$$active">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function sv(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=r(),i=a("th"),v=s("Name"),z=r(),I=a("th"),Y=s("Job"),j=r(),R=a("th"),lt=s("Favorite Color"),_=r(),m=a("tbody"),D=a("tr"),V=a("th"),rt=s("1"),M=r(),S=a("td"),X=s("Cy Ganderton"),ht=r(),K=a("td"),b=s("Quality Control Specialist"),P=r(),A=a("td"),ot=s("Blue"),st=r(),$=a("tr"),tt=a("th"),yt=s("2"),et=r(),O=a("td"),gt=s("Hart Hagerty"),ct=r(),J=a("td"),wt=s("Desktop Support Technician"),it=r(),L=a("td"),St=s("Purple"),vt=r(),y=a("tr"),W=a("th"),ft=s("3"),Ct=r(),Q=a("td"),N=s("Brice Swyre"),ut=r(),q=a("td"),nt=s("Tax Accountant"),pt=r(),Z=a("td"),U=s("Red"),this.h()},l(F){h=d(F,"DIV",{class:!0});var at=l(h);f=d(at,"TABLE",{class:!0});var dt=l(f);p=d(dt,"THEAD",{});var xt=l(p);c=d(xt,"TR",{});var g=l(c);u=d(g,"TH",{}),l(u).forEach(e),T=o(g),i=d(g,"TH",{});var _t=l(i);v=n(_t,"Name"),_t.forEach(e),z=o(g),I=d(g,"TH",{});var mt=l(I);Y=n(mt,"Job"),mt.forEach(e),j=o(g),R=d(g,"TH",{});var Rt=l(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),xt.forEach(e),_=o(dt),m=d(dt,"TBODY",{});var B=l(m);D=d(B,"TR",{});var C=l(D);V=d(C,"TH",{});var Gt=l(V);rt=n(Gt,"1"),Gt.forEach(e),M=o(C),S=d(C,"TD",{});var Ht=l(S);X=n(Ht,"Cy Ganderton"),Ht.forEach(e),ht=o(C),K=d(C,"TD",{});var Tt=l(K);b=n(Tt,"Quality Control Specialist"),Tt.forEach(e),P=o(C),A=d(C,"TD",{});var Vt=l(A);ot=n(Vt,"Blue"),Vt.forEach(e),C.forEach(e),st=o(B),$=d(B,"TR",{class:!0});var k=l($);tt=d(k,"TH",{});var G=l(tt);yt=n(G,"2"),G.forEach(e),et=o(k),O=d(k,"TD",{});var Pt=l(O);gt=n(Pt,"Hart Hagerty"),Pt.forEach(e),ct=o(k),J=d(k,"TD",{});var Ft=l(J);wt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(k),L=d(k,"TD",{});var Et=l(L);St=n(Et,"Purple"),Et.forEach(e),k.forEach(e),vt=o(B),y=d(B,"TR",{});var w=l(y);W=d(w,"TH",{});var zt=l(W);ft=n(zt,"3"),zt.forEach(e),Ct=o(w),Q=d(w,"TD",{});var Mt=l(Q);N=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(w),q=d(w,"TD",{});var bt=l(q);nt=n(bt,"Tax Accountant"),bt.forEach(e),pt=o(w),Z=d(w,"TD",{});var Ot=l(Z);U=n(Ot,"Red"),Ot.forEach(e),w.forEach(e),B.forEach(e),dt.forEach(e),at.forEach(e),this.h()},h(){E($,"class","hover"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Dt(F,h,at),t(h,f),t(f,p),t(p,c),t(c,u),t(c,T),t(c,i),t(i,v),t(c,z),t(c,I),t(I,Y),t(c,j),t(c,R),t(R,lt),t(f,_),t(f,m),t(m,D),t(D,V),t(V,rt),t(D,M),t(D,S),t(S,X),t(D,ht),t(D,K),t(K,b),t(D,P),t(D,A),t(A,ot),t(m,st),t(m,$),t($,tt),t(tt,yt),t($,et),t($,O),t(O,gt),t($,ct),t($,J),t(J,wt),t($,it),t($,L),t(L,St),t(m,vt),t(m,y),t(y,W),t(W,ft),t(y,Ct),t(y,Q),t(Q,N),t(y,ut),t(y,q),t(q,nt),t(y,pt),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function nv(H){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function hv(H){let h,f=`<div className="overflow-x-auto">
  <table className="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr className="$$hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function cv(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=r(),i=a("th"),v=s("Name"),z=r(),I=a("th"),Y=s("Job"),j=r(),R=a("th"),lt=s("Favorite Color"),_=r(),m=a("tbody"),D=a("tr"),V=a("th"),rt=s("1"),M=r(),S=a("td"),X=s("Cy Ganderton"),ht=r(),K=a("td"),b=s("Quality Control Specialist"),P=r(),A=a("td"),ot=s("Blue"),st=r(),$=a("tr"),tt=a("th"),yt=s("2"),et=r(),O=a("td"),gt=s("Hart Hagerty"),ct=r(),J=a("td"),wt=s("Desktop Support Technician"),it=r(),L=a("td"),St=s("Purple"),vt=r(),y=a("tr"),W=a("th"),ft=s("3"),Ct=r(),Q=a("td"),N=s("Brice Swyre"),ut=r(),q=a("td"),nt=s("Tax Accountant"),pt=r(),Z=a("td"),U=s("Red"),this.h()},l(F){h=d(F,"DIV",{class:!0});var at=l(h);f=d(at,"TABLE",{class:!0});var dt=l(f);p=d(dt,"THEAD",{});var xt=l(p);c=d(xt,"TR",{});var g=l(c);u=d(g,"TH",{}),l(u).forEach(e),T=o(g),i=d(g,"TH",{});var _t=l(i);v=n(_t,"Name"),_t.forEach(e),z=o(g),I=d(g,"TH",{});var mt=l(I);Y=n(mt,"Job"),mt.forEach(e),j=o(g),R=d(g,"TH",{});var Rt=l(R);lt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),xt.forEach(e),_=o(dt),m=d(dt,"TBODY",{});var B=l(m);D=d(B,"TR",{});var C=l(D);V=d(C,"TH",{});var Gt=l(V);rt=n(Gt,"1"),Gt.forEach(e),M=o(C),S=d(C,"TD",{});var Ht=l(S);X=n(Ht,"Cy Ganderton"),Ht.forEach(e),ht=o(C),K=d(C,"TD",{});var Tt=l(K);b=n(Tt,"Quality Control Specialist"),Tt.forEach(e),P=o(C),A=d(C,"TD",{});var Vt=l(A);ot=n(Vt,"Blue"),Vt.forEach(e),C.forEach(e),st=o(B),$=d(B,"TR",{});var k=l($);tt=d(k,"TH",{});var G=l(tt);yt=n(G,"2"),G.forEach(e),et=o(k),O=d(k,"TD",{});var Pt=l(O);gt=n(Pt,"Hart Hagerty"),Pt.forEach(e),ct=o(k),J=d(k,"TD",{});var Ft=l(J);wt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(k),L=d(k,"TD",{});var Et=l(L);St=n(Et,"Purple"),Et.forEach(e),k.forEach(e),vt=o(B),y=d(B,"TR",{});var w=l(y);W=d(w,"TH",{});var zt=l(W);ft=n(zt,"3"),zt.forEach(e),Ct=o(w),Q=d(w,"TD",{});var Mt=l(Q);N=n(Mt,"Brice Swyre"),Mt.forEach(e),ut=o(w),q=d(w,"TD",{});var bt=l(q);nt=n(bt,"Tax Accountant"),bt.forEach(e),pt=o(w),Z=d(w,"TD",{});var Ot=l(Z);U=n(Ot,"Red"),Ot.forEach(e),w.forEach(e),B.forEach(e),dt.forEach(e),at.forEach(e),this.h()},h(){E(f,"class","table table-zebra w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Dt(F,h,at),t(h,f),t(f,p),t(p,c),t(c,u),t(c,T),t(c,i),t(i,v),t(c,z),t(c,I),t(I,Y),t(c,j),t(c,R),t(R,lt),t(f,_),t(f,m),t(m,D),t(D,V),t(V,rt),t(D,M),t(D,S),t(S,X),t(D,ht),t(D,K),t(K,b),t(D,P),t(D,A),t(A,ot),t(m,st),t(m,$),t($,tt),t(tt,yt),t($,et),t($,O),t(O,gt),t($,ct),t($,J),t(J,wt),t($,it),t($,L),t(L,St),t(m,vt),t(m,y),t(y,W),t(W,ft),t(y,Ct),t(y,Q),t(Q,N),t(y,ut),t(y,q),t(q,nt),t(y,pt),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function iv(H){let h,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-zebra w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function vv(H){let h,f=`<div className="overflow-x-auto">
  <table className="$$table $$table-zebra w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function fv(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U,F,at,dt,xt,g,_t,mt,Rt,B,C,Gt,Ht,Tt,Vt,k,G,Pt,Ft,Et,w,zt,Mt,bt,Ot,Ed,We,bd,$d,Ke,ta,Dd,pa,Jt,_a,Qe,ma,yd,kt,oe,ea,aa,Be,Wd,gd,Ae,da,wd,Ta,la,Sd,Ea,Ne,Cd,ba,Hd,ra,$a,kd,Da,It,ya,ga,oa,wa,Rd,Wt,qe,Sa,Ca,Ha,ka,Le,Ge,sa,na,Oa,xd,Ue,Ve,Pd,Id,$t,Ra,Ad,Fe,xa,Bd,Nd,ze,Ld,Gd,Ye,Vd,Fd,Ze,ha,zd,Pa,Ia,Kt,ca,Md,Aa,At,Ba,Na,Od,La,Ga,Jd,Va,Ja;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=a("label"),i=a("input"),v=r(),z=a("th"),I=s("Name"),Y=r(),j=a("th"),R=s("Job"),lt=r(),_=a("th"),m=s("Favorite Color"),D=r(),V=a("th"),rt=r(),M=a("tbody"),S=a("tr"),X=a("th"),ht=a("label"),K=a("input"),b=r(),P=a("td"),A=a("div"),ot=a("div"),st=a("div"),$=a("img"),yt=r(),et=a("div"),O=a("div"),gt=s("Hart Hagerty"),ct=r(),J=a("div"),wt=s("United States"),it=r(),L=a("td"),St=s(`Zemlak, Daniel and Leannon
          `),vt=a("br"),y=r(),W=a("span"),ft=s("Desktop Support Technician"),Ct=r(),Q=a("td"),N=s("Purple"),ut=r(),q=a("th"),nt=a("button"),pt=s("details"),Z=r(),U=a("tr"),F=a("th"),at=a("label"),dt=a("input"),xt=r(),g=a("td"),_t=a("div"),mt=a("div"),Rt=a("div"),B=a("img"),Gt=r(),Ht=a("div"),Tt=a("div"),Vt=s("Brice Swyre"),k=r(),G=a("div"),Pt=s("China"),Ft=r(),Et=a("td"),w=s(`Carroll Group
          `),zt=a("br"),Mt=r(),bt=a("span"),Ot=s("Tax Accountant"),Ed=r(),We=a("td"),bd=s("Red"),$d=r(),Ke=a("th"),ta=a("button"),Dd=s("details"),pa=r(),Jt=a("tr"),_a=a("th"),Qe=a("label"),ma=a("input"),yd=r(),kt=a("td"),oe=a("div"),ea=a("div"),aa=a("div"),Be=a("img"),gd=r(),Ae=a("div"),da=a("div"),wd=s("Marjy Ferencz"),Ta=r(),la=a("div"),Sd=s("Russia"),Ea=r(),Ne=a("td"),Cd=s(`Rowe-Schoen
          `),ba=a("br"),Hd=r(),ra=a("span"),$a=s("Office Assistant I"),kd=r(),Da=a("td"),It=s("Crimson"),ya=r(),ga=a("th"),oa=a("button"),wa=s("details"),Rd=r(),Wt=a("tr"),qe=a("th"),Sa=a("label"),Ca=a("input"),Ha=r(),ka=a("td"),Le=a("div"),Ge=a("div"),sa=a("div"),na=a("img"),xd=r(),Ue=a("div"),Ve=a("div"),Pd=s("Yancy Tear"),Id=r(),$t=a("div"),Ra=s("Brazil"),Ad=r(),Fe=a("td"),xa=s(`Wyman-Ledner
          `),Bd=a("br"),Nd=r(),ze=a("span"),Ld=s("Community Outreach Specialist"),Gd=r(),Ye=a("td"),Vd=s("Indigo"),Fd=r(),Ze=a("th"),ha=a("button"),zd=s("details"),Pa=r(),Ia=a("tfoot"),Kt=a("tr"),ca=a("th"),Md=r(),Aa=a("th"),At=s("Name"),Ba=r(),Na=a("th"),Od=s("Job"),La=r(),Ga=a("th"),Jd=s("Favorite Color"),Va=r(),Ja=a("th"),this.h()},l(Fa){h=d(Fa,"DIV",{class:!0});var ia=l(h);f=d(ia,"TABLE",{class:!0});var va=l(f);p=d(va,"THEAD",{});var Kd=l(p);c=d(Kd,"TR",{});var le=l(c);u=d(le,"TH",{});var Qd=l(u);T=d(Qd,"LABEL",{});var qd=l(T);i=d(qd,"INPUT",{type:!0,class:!0}),qd.forEach(e),Qd.forEach(e),v=o(le),z=d(le,"TH",{});var Wa=l(z);I=n(Wa,"Name"),Wa.forEach(e),Y=o(le),j=d(le,"TH",{});var Ud=l(j);R=n(Ud,"Job"),Ud.forEach(e),lt=o(le),_=d(le,"TH",{});var Yd=l(_);m=n(Yd,"Favorite Color"),Yd.forEach(e),D=o(le),V=d(le,"TH",{}),l(V).forEach(e),le.forEach(e),Kd.forEach(e),rt=o(va),M=d(va,"TBODY",{});var se=l(M);S=d(se,"TR",{});var ne=l(S);X=d(ne,"TH",{});var Zd=l(X);ht=d(Zd,"LABEL",{});var Bt=l(ht);K=d(Bt,"INPUT",{type:!0,class:!0}),Bt.forEach(e),Zd.forEach(e),b=o(ne),P=d(ne,"TD",{});var Ka=l(P);A=d(Ka,"DIV",{class:!0});var Qa=l(A);ot=d(Qa,"DIV",{class:!0});var jd=l(ot);st=d(jd,"DIV",{class:!0});var qa=l(st);$=d(qa,"IMG",{src:!0,alt:!0}),qa.forEach(e),jd.forEach(e),yt=o(Qa),et=d(Qa,"DIV",{});var Ua=l(et);O=d(Ua,"DIV",{class:!0});var Xd=l(O);gt=n(Xd,"Hart Hagerty"),Xd.forEach(e),ct=o(Ua),J=d(Ua,"DIV",{class:!0});var Ya=l(J);wt=n(Ya,"United States"),Ya.forEach(e),Ua.forEach(e),Qa.forEach(e),Ka.forEach(e),it=o(ne),L=d(ne,"TD",{});var za=l(L);St=n(za,`Zemlak, Daniel and Leannon
          `),vt=d(za,"BR",{}),y=o(za),W=d(za,"SPAN",{class:!0});var tl=l(W);ft=n(tl,"Desktop Support Technician"),tl.forEach(e),za.forEach(e),Ct=o(ne),Q=d(ne,"TD",{});var Za=l(Q);N=n(Za,"Purple"),Za.forEach(e),ut=o(ne),q=d(ne,"TH",{});var el=l(q);nt=d(el,"BUTTON",{class:!0});var al=l(nt);pt=n(al,"details"),al.forEach(e),el.forEach(e),ne.forEach(e),Z=o(se),U=d(se,"TR",{});var re=l(U);F=d(re,"TH",{});var dl=l(F);at=d(dl,"LABEL",{});var ll=l(at);dt=d(ll,"INPUT",{type:!0,class:!0}),ll.forEach(e),dl.forEach(e),xt=o(re),g=d(re,"TD",{});var ja=l(g);_t=d(ja,"DIV",{class:!0});var Xa=l(_t);mt=d(Xa,"DIV",{class:!0});var rl=l(mt);Rt=d(rl,"DIV",{class:!0});var td=l(Rt);B=d(td,"IMG",{src:!0,alt:!0}),td.forEach(e),rl.forEach(e),Gt=o(Xa),Ht=d(Xa,"DIV",{});var ed=l(Ht);Tt=d(ed,"DIV",{class:!0});var ol=l(Tt);Vt=n(ol,"Brice Swyre"),ol.forEach(e),k=o(ed),G=d(ed,"DIV",{class:!0});var Nt=l(G);Pt=n(Nt,"China"),Nt.forEach(e),ed.forEach(e),Xa.forEach(e),ja.forEach(e),Ft=o(re),Et=d(re,"TD",{});var je=l(Et);w=n(je,`Carroll Group
          `),zt=d(je,"BR",{}),Mt=o(je),bt=d(je,"SPAN",{class:!0});var sl=l(bt);Ot=n(sl,"Tax Accountant"),sl.forEach(e),je.forEach(e),Ed=o(re),We=d(re,"TD",{});var nl=l(We);bd=n(nl,"Red"),nl.forEach(e),$d=o(re),Ke=d(re,"TH",{});var ad=l(Ke);ta=d(ad,"BUTTON",{class:!0});var hl=l(ta);Dd=n(hl,"details"),hl.forEach(e),ad.forEach(e),re.forEach(e),pa=o(se),Jt=d(se,"TR",{});var he=l(Jt);_a=d(he,"TH",{});var dd=l(_a);Qe=d(dd,"LABEL",{});var cl=l(Qe);ma=d(cl,"INPUT",{type:!0,class:!0}),cl.forEach(e),dd.forEach(e),yd=o(he),kt=d(he,"TD",{});var il=l(kt);oe=d(il,"DIV",{class:!0});var fa=l(oe);ea=d(fa,"DIV",{class:!0});var vl=l(ea);aa=d(vl,"DIV",{class:!0});var fl=l(aa);Be=d(fl,"IMG",{src:!0,alt:!0}),fl.forEach(e),vl.forEach(e),gd=o(fa),Ae=d(fa,"DIV",{});var ua=l(Ae);da=d(ua,"DIV",{class:!0});var ul=l(da);wd=n(ul,"Marjy Ferencz"),ul.forEach(e),Ta=o(ua),la=d(ua,"DIV",{class:!0});var pl=l(la);Sd=n(pl,"Russia"),pl.forEach(e),ua.forEach(e),fa.forEach(e),il.forEach(e),Ea=o(he),Ne=d(he,"TD",{});var Xe=l(Ne);Cd=n(Xe,`Rowe-Schoen
          `),ba=d(Xe,"BR",{}),Hd=o(Xe),ra=d(Xe,"SPAN",{class:!0});var _l=l(ra);$a=n(_l,"Office Assistant I"),_l.forEach(e),Xe.forEach(e),kd=o(he),Da=d(he,"TD",{});var ml=l(Da);It=n(ml,"Crimson"),ml.forEach(e),ya=o(he),ga=d(he,"TH",{});var ld=l(ga);oa=d(ld,"BUTTON",{class:!0});var Tl=l(oa);wa=n(Tl,"details"),Tl.forEach(e),ld.forEach(e),he.forEach(e),Rd=o(se),Wt=d(se,"TR",{});var ce=l(Wt);qe=d(ce,"TH",{});var Lt=l(qe);Sa=d(Lt,"LABEL",{});var rd=l(Sa);Ca=d(rd,"INPUT",{type:!0,class:!0}),rd.forEach(e),Lt.forEach(e),Ha=o(ce),ka=d(ce,"TD",{});var El=l(ka);Le=d(El,"DIV",{class:!0});var od=l(Le);Ge=d(od,"DIV",{class:!0});var sd=l(Ge);sa=d(sd,"DIV",{class:!0});var bl=l(sa);na=d(bl,"IMG",{src:!0,alt:!0}),bl.forEach(e),sd.forEach(e),xd=o(od),Ue=d(od,"DIV",{});var nd=l(Ue);Ve=d(nd,"DIV",{class:!0});var hd=l(Ve);Pd=n(hd,"Yancy Tear"),hd.forEach(e),Id=o(nd),$t=d(nd,"DIV",{class:!0});var $l=l($t);Ra=n($l,"Brazil"),$l.forEach(e),nd.forEach(e),od.forEach(e),El.forEach(e),Ad=o(ce),Fe=d(ce,"TD",{});var Ma=l(Fe);xa=n(Ma,`Wyman-Ledner
          `),Bd=d(Ma,"BR",{}),Nd=o(Ma),ze=d(Ma,"SPAN",{class:!0});var cd=l(ze);Ld=n(cd,"Community Outreach Specialist"),cd.forEach(e),Ma.forEach(e),Gd=o(ce),Ye=d(ce,"TD",{});var Dl=l(Ye);Vd=n(Dl,"Indigo"),Dl.forEach(e),Fd=o(ce),Ze=d(ce,"TH",{});var yl=l(Ze);ha=d(yl,"BUTTON",{class:!0});var id=l(ha);zd=n(id,"details"),id.forEach(e),yl.forEach(e),ce.forEach(e),se.forEach(e),Pa=o(va),Ia=d(va,"TFOOT",{});var gl=l(Ia);Kt=d(gl,"TR",{});var ie=l(Kt);ca=d(ie,"TH",{}),l(ca).forEach(e),Md=o(ie),Aa=d(ie,"TH",{});var vd=l(Aa);At=n(vd,"Name"),vd.forEach(e),Ba=o(ie),Na=d(ie,"TH",{});var wl=l(Na);Od=n(wl,"Job"),wl.forEach(e),La=o(ie),Ga=d(ie,"TH",{});var Sl=l(Ga);Jd=n(Sl,"Favorite Color"),Sl.forEach(e),Va=o(ie),Ja=d(ie,"TH",{}),l(Ja).forEach(e),ie.forEach(e),gl.forEach(e),va.forEach(e),ia.forEach(e),this.h()},h(){E(i,"type","checkbox"),E(i,"class","checkbox"),E(K,"type","checkbox"),E(K,"class","checkbox"),ao($.src,tt="/tailwind-css-component-profile-2@56w.png")||E($,"src",tt),E($,"alt","Avatar Tailwind CSS Component"),E(st,"class","w-12 h-12 mask mask-squircle"),E(ot,"class","avatar"),E(O,"class","font-bold"),E(J,"class","text-sm opacity-50"),E(A,"class","flex items-center space-x-3"),E(W,"class","badge badge-ghost badge-sm"),E(nt,"class","btn btn-ghost btn-xs"),E(dt,"type","checkbox"),E(dt,"class","checkbox"),ao(B.src,C="/tailwind-css-component-profile-3@56w.png")||E(B,"src",C),E(B,"alt","Avatar Tailwind CSS Component"),E(Rt,"class","w-12 h-12 mask mask-squircle"),E(mt,"class","avatar"),E(Tt,"class","font-bold"),E(G,"class","text-sm opacity-50"),E(_t,"class","flex items-center space-x-3"),E(bt,"class","badge badge-ghost badge-sm"),E(ta,"class","btn btn-ghost btn-xs"),E(ma,"type","checkbox"),E(ma,"class","checkbox"),ao(Be.src,Wd="/tailwind-css-component-profile-4@56w.png")||E(Be,"src",Wd),E(Be,"alt","Avatar Tailwind CSS Component"),E(aa,"class","w-12 h-12 mask mask-squircle"),E(ea,"class","avatar"),E(da,"class","font-bold"),E(la,"class","text-sm opacity-50"),E(oe,"class","flex items-center space-x-3"),E(ra,"class","badge badge-ghost badge-sm"),E(oa,"class","btn btn-ghost btn-xs"),E(Ca,"type","checkbox"),E(Ca,"class","checkbox"),ao(na.src,Oa="/tailwind-css-component-profile-5@56w.png")||E(na,"src",Oa),E(na,"alt","Avatar Tailwind CSS Component"),E(sa,"class","w-12 h-12 mask mask-squircle"),E(Ge,"class","avatar"),E(Ve,"class","font-bold"),E($t,"class","text-sm opacity-50"),E(Le,"class","flex items-center space-x-3"),E(ze,"class","badge badge-ghost badge-sm"),E(ha,"class","btn btn-ghost btn-xs"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(Fa,ia){Dt(Fa,h,ia),t(h,f),t(f,p),t(p,c),t(c,u),t(u,T),t(T,i),t(c,v),t(c,z),t(z,I),t(c,Y),t(c,j),t(j,R),t(c,lt),t(c,_),t(_,m),t(c,D),t(c,V),t(f,rt),t(f,M),t(M,S),t(S,X),t(X,ht),t(ht,K),t(S,b),t(S,P),t(P,A),t(A,ot),t(ot,st),t(st,$),t(A,yt),t(A,et),t(et,O),t(O,gt),t(et,ct),t(et,J),t(J,wt),t(S,it),t(S,L),t(L,St),t(L,vt),t(L,y),t(L,W),t(W,ft),t(S,Ct),t(S,Q),t(Q,N),t(S,ut),t(S,q),t(q,nt),t(nt,pt),t(M,Z),t(M,U),t(U,F),t(F,at),t(at,dt),t(U,xt),t(U,g),t(g,_t),t(_t,mt),t(mt,Rt),t(Rt,B),t(_t,Gt),t(_t,Ht),t(Ht,Tt),t(Tt,Vt),t(Ht,k),t(Ht,G),t(G,Pt),t(U,Ft),t(U,Et),t(Et,w),t(Et,zt),t(Et,Mt),t(Et,bt),t(bt,Ot),t(U,Ed),t(U,We),t(We,bd),t(U,$d),t(U,Ke),t(Ke,ta),t(ta,Dd),t(M,pa),t(M,Jt),t(Jt,_a),t(_a,Qe),t(Qe,ma),t(Jt,yd),t(Jt,kt),t(kt,oe),t(oe,ea),t(ea,aa),t(aa,Be),t(oe,gd),t(oe,Ae),t(Ae,da),t(da,wd),t(Ae,Ta),t(Ae,la),t(la,Sd),t(Jt,Ea),t(Jt,Ne),t(Ne,Cd),t(Ne,ba),t(Ne,Hd),t(Ne,ra),t(ra,$a),t(Jt,kd),t(Jt,Da),t(Da,It),t(Jt,ya),t(Jt,ga),t(ga,oa),t(oa,wa),t(M,Rd),t(M,Wt),t(Wt,qe),t(qe,Sa),t(Sa,Ca),t(Wt,Ha),t(Wt,ka),t(ka,Le),t(Le,Ge),t(Ge,sa),t(sa,na),t(Le,xd),t(Le,Ue),t(Ue,Ve),t(Ve,Pd),t(Ue,Id),t(Ue,$t),t($t,Ra),t(Wt,Ad),t(Wt,Fe),t(Fe,xa),t(Fe,Bd),t(Fe,Nd),t(Fe,ze),t(ze,Ld),t(Wt,Gd),t(Wt,Ye),t(Ye,Vd),t(Wt,Fd),t(Wt,Ze),t(Ze,ha),t(ha,zd),t(f,Pa),t(f,Ia),t(Ia,Kt),t(Kt,ca),t(Kt,Md),t(Kt,Aa),t(Aa,At),t(Kt,Ba),t(Kt,Na),t(Na,Od),t(Kt,La),t(Kt,Ga),t(Ga,Jd),t(Kt,Va),t(Kt,Ja)},d(Fa){Fa&&e(h)}}}function uv(H){let h,f=`<div class="overflow-x-auto w-full">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Hart Hagerty</div>
              <div class="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Brice Swyre</div>
              <div class="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Marjy Ferencz</div>
              <div class="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Yancy Tear</div>
              <div class="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function pv(H){let h,f=`<div className="overflow-x-auto w-full">
  <table className="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" className="$$checkbox" />
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" className="$$checkbox" />
          </label>
        </th>
        <td>
          <div className="flex items-center space-x-3">
            <div className="$$avatar">
              <div className="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div className="font-bold">Hart Hagerty</div>
              <div className="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br/>
          <span className="$$badge $$badge-ghost $$badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button className="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" className="$$checkbox" />
          </label>
        </th>
        <td>
          <div className="flex items-center space-x-3">
            <div className="$$avatar">
              <div className="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div className="font-bold">Brice Swyre</div>
              <div className="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br/>
          <span className="$$badge $$badge-ghost $$badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button className="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" className="$$checkbox" />
          </label>
        </th>
        <td>
          <div className="flex items-center space-x-3">
            <div className="$$avatar">
              <div className="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div className="font-bold">Marjy Ferencz</div>
              <div className="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br/>
          <span className="$$badge $$badge-ghost $$badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button className="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" className="$$checkbox" />
          </label>
        </th>
        <td>
          <div className="flex items-center space-x-3">
            <div className="$$avatar">
              <div className="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div className="font-bold">Yancy Tear</div>
              <div className="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br/>
          <span className="$$badge $$badge-ghost $$badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button className="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function _v(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt,_,m,D,V,rt,M,S,X,ht,K,b,P,A,ot,st,$,tt,yt,et,O,gt,ct,J,wt,it,L,St,vt,y,W,ft,Ct,Q,N,ut,q,nt,pt,Z,U,F,at,dt,xt,g,_t,mt,Rt,B,C,Gt,Ht,Tt,Vt,k,G,Pt,Ft,Et,w,zt,Mt,bt,Ot,Ed,We,bd,$d,Ke,ta,Dd,pa,Jt,_a,Qe,ma,yd,kt,oe,ea,aa,Be,Wd,gd,Ae,da,wd,Ta,la,Sd,Ea,Ne,Cd,ba,Hd,ra,$a,kd,Da,It,ya,ga,oa,wa,Rd,Wt,qe,Sa,Ca,Ha,ka,Le,Ge,sa,na,Oa,xd,Ue,Ve,Pd,Id,$t,Ra,Ad,Fe,xa,Bd,Nd,ze,Ld,Gd,Ye,Vd,Fd,Ze,ha,zd,Pa,Ia,Kt,ca,Md,Aa,At,Ba,Na,Od,La,Ga,Jd,Va,Ja,Fa,ia,va,Kd,le,Qd,qd,Wa,Ud,Yd,se,ne,Zd,Bt,Ka,Qa,jd,qa,Ua,Xd,Ya,za,tl,Za,el,al,re,dl,ll,ja,Xa,rl,td,ed,ol,Nt,je,sl,nl,ad,hl,he,dd,cl,il,fa,vl,fl,ua,ul,pl,Xe,_l,ml,ld,Tl,ce,Lt,rd,El,od,sd,bl,nd,hd,$l,Ma,cd,Dl,yl,id,gl,ie,vd,wl,Sl,kl,lo,ro,Qt,Rl,oo,so,xl,no,ho,Pl,co,io,Il,vo,fo,Al,uo,po,Bl,_o,mo,Nl,To,Eo,qt,Ll,bo,$o,Gl,Do,yo,Vl,go,wo,Fl,So,Co,zl,Ho,ko,Ml,Ro,xo,Ol,Po,Io,Ut,Jl,Ao,Bo,Wl,No,Lo,Kl,Go,Vo,Ql,Fo,zo,ql,Mo,Oo,Ul,Jo,Wo,Yl,Ko,Qo,Yt,Zl,qo,Uo,jl,Yo,Zo,Xl,jo,Xo,tr,ts,es,er,as,ds,ar,ls,rs,dr,os,ss,Zt,lr,ns,hs,rr,cs,is,or,vs,fs,sr,us,ps,nr,_s,ms,hr,Ts,Es,cr,bs,$s,jt,ir,Ds,ys,vr,gs,ws,fr,Ss,Cs,ur,Hs,ks,pr,Rs,xs,_r,Ps,Is,mr,As,Bs,Xt,Tr,Ns,Ls,Er,Gs,Vs,br,Fs,zs,$r,Ms,Os,Dr,Js,Ws,yr,Ks,Qs,gr,qs,Us,te,wr,Ys,Zs,Sr,js,Xs,Cr,tn,en,Hr,an,dn,kr,ln,rn,Rr,on,sn,xr,nn,hn,ee,Pr,cn,vn,Ir,fn,un,Ar,pn,_n,Br,mn,Tn,Nr,En,bn,Lr,$n,Dn,Gr,yn,gn,ae,Vr,wn,Sn,Fr,Cn,Hn,zr,kn,Rn,Mr,xn,Pn,Or,In,An,Jr,Bn,Nn,Wr,Ln,Gn,Kr,de,to,Vn,Qr,Fn,zn,qr,Mn,On,Ur,Jn,Wn,Yr,Kn,Qn,Zr,qn,Un,jr,Yn;return{c(){h=a("div"),f=a("table"),p=a("thead"),c=a("tr"),u=a("th"),T=r(),i=a("th"),v=s("Name"),z=r(),I=a("th"),Y=s("Job"),j=r(),R=a("th"),lt=s("company"),_=r(),m=a("th"),D=s("location"),V=r(),rt=a("th"),M=s("Last Login"),S=r(),X=a("th"),ht=s("Favorite Color"),K=r(),b=a("tbody"),P=a("tr"),A=a("th"),ot=s("1"),st=r(),$=a("td"),tt=s("Cy Ganderton"),yt=r(),et=a("td"),O=s("Quality Control Specialist"),gt=r(),ct=a("td"),J=s("Littel, Schaden and Vandervort"),wt=r(),it=a("td"),L=s("Canada"),St=r(),vt=a("td"),y=s("12/16/2020"),W=r(),ft=a("td"),Ct=s("Blue"),Q=r(),N=a("tr"),ut=a("th"),q=s("2"),nt=r(),pt=a("td"),Z=s("Hart Hagerty"),U=r(),F=a("td"),at=s("Desktop Support Technician"),dt=r(),xt=a("td"),g=s("Zemlak, Daniel and Leannon"),_t=r(),mt=a("td"),Rt=s("United States"),B=r(),C=a("td"),Gt=s("12/5/2020"),Ht=r(),Tt=a("td"),Vt=s("Purple"),k=r(),G=a("tr"),Pt=a("th"),Ft=s("3"),Et=r(),w=a("td"),zt=s("Brice Swyre"),Mt=r(),bt=a("td"),Ot=s("Tax Accountant"),Ed=r(),We=a("td"),bd=s("Carroll Group"),$d=r(),Ke=a("td"),ta=s("China"),Dd=r(),pa=a("td"),Jt=s("8/15/2020"),_a=r(),Qe=a("td"),ma=s("Red"),yd=r(),kt=a("tr"),oe=a("th"),ea=s("4"),aa=r(),Be=a("td"),Wd=s("Marjy Ferencz"),gd=r(),Ae=a("td"),da=s("Office Assistant I"),wd=r(),Ta=a("td"),la=s("Rowe-Schoen"),Sd=r(),Ea=a("td"),Ne=s("Russia"),Cd=r(),ba=a("td"),Hd=s("3/25/2021"),ra=r(),$a=a("td"),kd=s("Crimson"),Da=r(),It=a("tr"),ya=a("th"),ga=s("5"),oa=r(),wa=a("td"),Rd=s("Yancy Tear"),Wt=r(),qe=a("td"),Sa=s("Community Outreach Specialist"),Ca=r(),Ha=a("td"),ka=s("Wyman-Ledner"),Le=r(),Ge=a("td"),sa=s("Brazil"),na=r(),Oa=a("td"),xd=s("5/22/2020"),Ue=r(),Ve=a("td"),Pd=s("Indigo"),Id=r(),$t=a("tr"),Ra=a("th"),Ad=s("6"),Fe=r(),xa=a("td"),Bd=s("Irma Vasilik"),Nd=r(),ze=a("td"),Ld=s("Editor"),Gd=r(),Ye=a("td"),Vd=s("Wiza, Bins and Emard"),Fd=r(),Ze=a("td"),ha=s("Venezuela"),zd=r(),Pa=a("td"),Ia=s("12/8/2020"),Kt=r(),ca=a("td"),Md=s("Purple"),Aa=r(),At=a("tr"),Ba=a("th"),Na=s("7"),Od=r(),La=a("td"),Ga=s("Meghann Durtnal"),Jd=r(),Va=a("td"),Ja=s("Staff Accountant IV"),Fa=r(),ia=a("td"),va=s("Schuster-Schimmel"),Kd=r(),le=a("td"),Qd=s("Philippines"),qd=r(),Wa=a("td"),Ud=s("2/17/2021"),Yd=r(),se=a("td"),ne=s("Yellow"),Zd=r(),Bt=a("tr"),Ka=a("th"),Qa=s("8"),jd=r(),qa=a("td"),Ua=s("Sammy Seston"),Xd=r(),Ya=a("td"),za=s("Accountant I"),tl=r(),Za=a("td"),el=s("O'Hara, Welch and Keebler"),al=r(),re=a("td"),dl=s("Indonesia"),ll=r(),ja=a("td"),Xa=s("5/23/2020"),rl=r(),td=a("td"),ed=s("Crimson"),ol=r(),Nt=a("tr"),je=a("th"),sl=s("9"),nl=r(),ad=a("td"),hl=s("Lesya Tinham"),he=r(),dd=a("td"),cl=s("Safety Technician IV"),il=r(),fa=a("td"),vl=s("Turner-Kuhlman"),fl=r(),ua=a("td"),ul=s("Philippines"),pl=r(),Xe=a("td"),_l=s("2/21/2021"),ml=r(),ld=a("td"),Tl=s("Maroon"),ce=r(),Lt=a("tr"),rd=a("th"),El=s("10"),od=r(),sd=a("td"),bl=s("Zaneta Tewkesbury"),nd=r(),hd=a("td"),$l=s("VP Marketing"),Ma=r(),cd=a("td"),Dl=s("Sauer LLC"),yl=r(),id=a("td"),gl=s("Chad"),ie=r(),vd=a("td"),wl=s("6/23/2020"),Sl=r(),kl=a("td"),lo=s("Green"),ro=r(),Qt=a("tr"),Rl=a("th"),oo=s("11"),so=r(),xl=a("td"),no=s("Andy Tipple"),ho=r(),Pl=a("td"),co=s("Librarian"),io=r(),Il=a("td"),vo=s("Hilpert Group"),fo=r(),Al=a("td"),uo=s("Poland"),po=r(),Bl=a("td"),_o=s("7/9/2020"),mo=r(),Nl=a("td"),To=s("Indigo"),Eo=r(),qt=a("tr"),Ll=a("th"),bo=s("12"),$o=r(),Gl=a("td"),Do=s("Sophi Biles"),yo=r(),Vl=a("td"),go=s("Recruiting Manager"),wo=r(),Fl=a("td"),So=s("Gutmann Inc"),Co=r(),zl=a("td"),Ho=s("Indonesia"),ko=r(),Ml=a("td"),Ro=s("2/12/2021"),xo=r(),Ol=a("td"),Po=s("Maroon"),Io=r(),Ut=a("tr"),Jl=a("th"),Ao=s("13"),Bo=r(),Wl=a("td"),No=s("Florida Garces"),Lo=r(),Kl=a("td"),Go=s("Web Developer IV"),Vo=r(),Ql=a("td"),Fo=s("Gaylord, Pacocha and Baumbach"),zo=r(),ql=a("td"),Mo=s("Poland"),Oo=r(),Ul=a("td"),Jo=s("5/31/2020"),Wo=r(),Yl=a("td"),Ko=s("Purple"),Qo=r(),Yt=a("tr"),Zl=a("th"),qo=s("14"),Uo=r(),jl=a("td"),Yo=s("Maribeth Popping"),Zo=r(),Xl=a("td"),jo=s("Analyst Programmer"),Xo=r(),tr=a("td"),ts=s("Deckow-Pouros"),es=r(),er=a("td"),as=s("Portugal"),ds=r(),ar=a("td"),ls=s("4/27/2021"),rs=r(),dr=a("td"),os=s("Aquamarine"),ss=r(),Zt=a("tr"),lr=a("th"),ns=s("15"),hs=r(),rr=a("td"),cs=s("Moritz Dryburgh"),is=r(),or=a("td"),vs=s("Dental Hygienist"),fs=r(),sr=a("td"),us=s("Schiller, Cole and Hackett"),ps=r(),nr=a("td"),_s=s("Sri Lanka"),ms=r(),hr=a("td"),Ts=s("8/8/2020"),Es=r(),cr=a("td"),bs=s("Crimson"),$s=r(),jt=a("tr"),ir=a("th"),Ds=s("16"),ys=r(),vr=a("td"),gs=s("Reid Semiras"),ws=r(),fr=a("td"),Ss=s("Teacher"),Cs=r(),ur=a("td"),Hs=s("Sporer, Sipes and Rogahn"),ks=r(),pr=a("td"),Rs=s("Poland"),xs=r(),_r=a("td"),Ps=s("7/30/2020"),Is=r(),mr=a("td"),As=s("Green"),Bs=r(),Xt=a("tr"),Tr=a("th"),Ns=s("17"),Ls=r(),Er=a("td"),Gs=s("Alec Lethby"),Vs=r(),br=a("td"),Fs=s("Teacher"),zs=r(),$r=a("td"),Ms=s("Reichel, Glover and Hamill"),Os=r(),Dr=a("td"),Js=s("China"),Ws=r(),yr=a("td"),Ks=s("2/28/2021"),Qs=r(),gr=a("td"),qs=s("Khaki"),Us=r(),te=a("tr"),wr=a("th"),Ys=s("18"),Zs=r(),Sr=a("td"),js=s("Aland Wilber"),Xs=r(),Cr=a("td"),tn=s("Quality Control Specialist"),en=r(),Hr=a("td"),an=s("Kshlerin, Rogahn and Swaniawski"),dn=r(),kr=a("td"),ln=s("Czech Republic"),rn=r(),Rr=a("td"),on=s("9/29/2020"),sn=r(),xr=a("td"),nn=s("Purple"),hn=r(),ee=a("tr"),Pr=a("th"),cn=s("19"),vn=r(),Ir=a("td"),fn=s("Teddie Duerden"),un=r(),Ar=a("td"),pn=s("Staff Accountant III"),_n=r(),Br=a("td"),mn=s("Pouros, Ullrich and Windler"),Tn=r(),Nr=a("td"),En=s("France"),bn=r(),Lr=a("td"),$n=s("10/27/2020"),Dn=r(),Gr=a("td"),yn=s("Aquamarine"),gn=r(),ae=a("tr"),Vr=a("th"),wn=s("20"),Sn=r(),Fr=a("td"),Cn=s("Lorelei Blackstone"),Hn=r(),zr=a("td"),kn=s("Data Coordinator"),Rn=r(),Mr=a("td"),xn=s("Witting, Kutch and Greenfelder"),Pn=r(),Or=a("td"),In=s("Kazakhstan"),An=r(),Jr=a("td"),Bn=s("6/3/2020"),Nn=r(),Wr=a("td"),Ln=s("Red"),Gn=r(),Kr=a("tfoot"),de=a("tr"),to=a("th"),Vn=r(),Qr=a("th"),Fn=s("Name"),zn=r(),qr=a("th"),Mn=s("Job"),On=r(),Ur=a("th"),Jn=s("company"),Wn=r(),Yr=a("th"),Kn=s("location"),Qn=r(),Zr=a("th"),qn=s("Last Login"),Un=r(),jr=a("th"),Yn=s("Favorite Color"),this.h()},l(Xr){h=d(Xr,"DIV",{class:!0});var eo=l(h);f=d(eo,"TABLE",{class:!0});var Cl=l(f);p=d(Cl,"THEAD",{});var jn=l(p);c=d(jn,"TR",{});var ve=l(c);u=d(ve,"TH",{}),l(u).forEach(e),T=o(ve),i=d(ve,"TH",{});var Xn=l(i);v=n(Xn,"Name"),Xn.forEach(e),z=o(ve),I=d(ve,"TH",{});var th=l(I);Y=n(th,"Job"),th.forEach(e),j=o(ve),R=d(ve,"TH",{});var eh=l(R);lt=n(eh,"company"),eh.forEach(e),_=o(ve),m=d(ve,"TH",{});var ah=l(m);D=n(ah,"location"),ah.forEach(e),V=o(ve),rt=d(ve,"TH",{});var dh=l(rt);M=n(dh,"Last Login"),dh.forEach(e),S=o(ve),X=d(ve,"TH",{});var lh=l(X);ht=n(lh,"Favorite Color"),lh.forEach(e),ve.forEach(e),jn.forEach(e),K=o(Cl),b=d(Cl,"TBODY",{});var x=l(b);P=d(x,"TR",{});var fe=l(P);A=d(fe,"TH",{});var rh=l(A);ot=n(rh,"1"),rh.forEach(e),st=o(fe),$=d(fe,"TD",{});var oh=l($);tt=n(oh,"Cy Ganderton"),oh.forEach(e),yt=o(fe),et=d(fe,"TD",{});var sh=l(et);O=n(sh,"Quality Control Specialist"),sh.forEach(e),gt=o(fe),ct=d(fe,"TD",{});var nh=l(ct);J=n(nh,"Littel, Schaden and Vandervort"),nh.forEach(e),wt=o(fe),it=d(fe,"TD",{});var hh=l(it);L=n(hh,"Canada"),hh.forEach(e),St=o(fe),vt=d(fe,"TD",{});var ch=l(vt);y=n(ch,"12/16/2020"),ch.forEach(e),W=o(fe),ft=d(fe,"TD",{});var ih=l(ft);Ct=n(ih,"Blue"),ih.forEach(e),fe.forEach(e),Q=o(x),N=d(x,"TR",{});var ue=l(N);ut=d(ue,"TH",{});var vh=l(ut);q=n(vh,"2"),vh.forEach(e),nt=o(ue),pt=d(ue,"TD",{});var fh=l(pt);Z=n(fh,"Hart Hagerty"),fh.forEach(e),U=o(ue),F=d(ue,"TD",{});var uh=l(F);at=n(uh,"Desktop Support Technician"),uh.forEach(e),dt=o(ue),xt=d(ue,"TD",{});var ph=l(xt);g=n(ph,"Zemlak, Daniel and Leannon"),ph.forEach(e),_t=o(ue),mt=d(ue,"TD",{});var _h=l(mt);Rt=n(_h,"United States"),_h.forEach(e),B=o(ue),C=d(ue,"TD",{});var mh=l(C);Gt=n(mh,"12/5/2020"),mh.forEach(e),Ht=o(ue),Tt=d(ue,"TD",{});var Th=l(Tt);Vt=n(Th,"Purple"),Th.forEach(e),ue.forEach(e),k=o(x),G=d(x,"TR",{});var pe=l(G);Pt=d(pe,"TH",{});var Eh=l(Pt);Ft=n(Eh,"3"),Eh.forEach(e),Et=o(pe),w=d(pe,"TD",{});var bh=l(w);zt=n(bh,"Brice Swyre"),bh.forEach(e),Mt=o(pe),bt=d(pe,"TD",{});var $h=l(bt);Ot=n($h,"Tax Accountant"),$h.forEach(e),Ed=o(pe),We=d(pe,"TD",{});var Dh=l(We);bd=n(Dh,"Carroll Group"),Dh.forEach(e),$d=o(pe),Ke=d(pe,"TD",{});var yh=l(Ke);ta=n(yh,"China"),yh.forEach(e),Dd=o(pe),pa=d(pe,"TD",{});var gh=l(pa);Jt=n(gh,"8/15/2020"),gh.forEach(e),_a=o(pe),Qe=d(pe,"TD",{});var wh=l(Qe);ma=n(wh,"Red"),wh.forEach(e),pe.forEach(e),yd=o(x),kt=d(x,"TR",{});var _e=l(kt);oe=d(_e,"TH",{});var Sh=l(oe);ea=n(Sh,"4"),Sh.forEach(e),aa=o(_e),Be=d(_e,"TD",{});var Ch=l(Be);Wd=n(Ch,"Marjy Ferencz"),Ch.forEach(e),gd=o(_e),Ae=d(_e,"TD",{});var Hh=l(Ae);da=n(Hh,"Office Assistant I"),Hh.forEach(e),wd=o(_e),Ta=d(_e,"TD",{});var kh=l(Ta);la=n(kh,"Rowe-Schoen"),kh.forEach(e),Sd=o(_e),Ea=d(_e,"TD",{});var Rh=l(Ea);Ne=n(Rh,"Russia"),Rh.forEach(e),Cd=o(_e),ba=d(_e,"TD",{});var xh=l(ba);Hd=n(xh,"3/25/2021"),xh.forEach(e),ra=o(_e),$a=d(_e,"TD",{});var Ph=l($a);kd=n(Ph,"Crimson"),Ph.forEach(e),_e.forEach(e),Da=o(x),It=d(x,"TR",{});var me=l(It);ya=d(me,"TH",{});var Ih=l(ya);ga=n(Ih,"5"),Ih.forEach(e),oa=o(me),wa=d(me,"TD",{});var Ah=l(wa);Rd=n(Ah,"Yancy Tear"),Ah.forEach(e),Wt=o(me),qe=d(me,"TD",{});var Bh=l(qe);Sa=n(Bh,"Community Outreach Specialist"),Bh.forEach(e),Ca=o(me),Ha=d(me,"TD",{});var Nh=l(Ha);ka=n(Nh,"Wyman-Ledner"),Nh.forEach(e),Le=o(me),Ge=d(me,"TD",{});var Lh=l(Ge);sa=n(Lh,"Brazil"),Lh.forEach(e),na=o(me),Oa=d(me,"TD",{});var Gh=l(Oa);xd=n(Gh,"5/22/2020"),Gh.forEach(e),Ue=o(me),Ve=d(me,"TD",{});var Vh=l(Ve);Pd=n(Vh,"Indigo"),Vh.forEach(e),me.forEach(e),Id=o(x),$t=d(x,"TR",{});var Te=l($t);Ra=d(Te,"TH",{});var Fh=l(Ra);Ad=n(Fh,"6"),Fh.forEach(e),Fe=o(Te),xa=d(Te,"TD",{});var zh=l(xa);Bd=n(zh,"Irma Vasilik"),zh.forEach(e),Nd=o(Te),ze=d(Te,"TD",{});var Mh=l(ze);Ld=n(Mh,"Editor"),Mh.forEach(e),Gd=o(Te),Ye=d(Te,"TD",{});var Oh=l(Ye);Vd=n(Oh,"Wiza, Bins and Emard"),Oh.forEach(e),Fd=o(Te),Ze=d(Te,"TD",{});var Jh=l(Ze);ha=n(Jh,"Venezuela"),Jh.forEach(e),zd=o(Te),Pa=d(Te,"TD",{});var Wh=l(Pa);Ia=n(Wh,"12/8/2020"),Wh.forEach(e),Kt=o(Te),ca=d(Te,"TD",{});var Kh=l(ca);Md=n(Kh,"Purple"),Kh.forEach(e),Te.forEach(e),Aa=o(x),At=d(x,"TR",{});var Ee=l(At);Ba=d(Ee,"TH",{});var Qh=l(Ba);Na=n(Qh,"7"),Qh.forEach(e),Od=o(Ee),La=d(Ee,"TD",{});var qh=l(La);Ga=n(qh,"Meghann Durtnal"),qh.forEach(e),Jd=o(Ee),Va=d(Ee,"TD",{});var Uh=l(Va);Ja=n(Uh,"Staff Accountant IV"),Uh.forEach(e),Fa=o(Ee),ia=d(Ee,"TD",{});var Yh=l(ia);va=n(Yh,"Schuster-Schimmel"),Yh.forEach(e),Kd=o(Ee),le=d(Ee,"TD",{});var Zh=l(le);Qd=n(Zh,"Philippines"),Zh.forEach(e),qd=o(Ee),Wa=d(Ee,"TD",{});var jh=l(Wa);Ud=n(jh,"2/17/2021"),jh.forEach(e),Yd=o(Ee),se=d(Ee,"TD",{});var Xh=l(se);ne=n(Xh,"Yellow"),Xh.forEach(e),Ee.forEach(e),Zd=o(x),Bt=d(x,"TR",{});var be=l(Bt);Ka=d(be,"TH",{});var tc=l(Ka);Qa=n(tc,"8"),tc.forEach(e),jd=o(be),qa=d(be,"TD",{});var ec=l(qa);Ua=n(ec,"Sammy Seston"),ec.forEach(e),Xd=o(be),Ya=d(be,"TD",{});var ac=l(Ya);za=n(ac,"Accountant I"),ac.forEach(e),tl=o(be),Za=d(be,"TD",{});var dc=l(Za);el=n(dc,"O'Hara, Welch and Keebler"),dc.forEach(e),al=o(be),re=d(be,"TD",{});var lc=l(re);dl=n(lc,"Indonesia"),lc.forEach(e),ll=o(be),ja=d(be,"TD",{});var rc=l(ja);Xa=n(rc,"5/23/2020"),rc.forEach(e),rl=o(be),td=d(be,"TD",{});var oc=l(td);ed=n(oc,"Crimson"),oc.forEach(e),be.forEach(e),ol=o(x),Nt=d(x,"TR",{});var $e=l(Nt);je=d($e,"TH",{});var sc=l(je);sl=n(sc,"9"),sc.forEach(e),nl=o($e),ad=d($e,"TD",{});var nc=l(ad);hl=n(nc,"Lesya Tinham"),nc.forEach(e),he=o($e),dd=d($e,"TD",{});var hc=l(dd);cl=n(hc,"Safety Technician IV"),hc.forEach(e),il=o($e),fa=d($e,"TD",{});var cc=l(fa);vl=n(cc,"Turner-Kuhlman"),cc.forEach(e),fl=o($e),ua=d($e,"TD",{});var ic=l(ua);ul=n(ic,"Philippines"),ic.forEach(e),pl=o($e),Xe=d($e,"TD",{});var vc=l(Xe);_l=n(vc,"2/21/2021"),vc.forEach(e),ml=o($e),ld=d($e,"TD",{});var fc=l(ld);Tl=n(fc,"Maroon"),fc.forEach(e),$e.forEach(e),ce=o(x),Lt=d(x,"TR",{});var De=l(Lt);rd=d(De,"TH",{});var uc=l(rd);El=n(uc,"10"),uc.forEach(e),od=o(De),sd=d(De,"TD",{});var pc=l(sd);bl=n(pc,"Zaneta Tewkesbury"),pc.forEach(e),nd=o(De),hd=d(De,"TD",{});var _c=l(hd);$l=n(_c,"VP Marketing"),_c.forEach(e),Ma=o(De),cd=d(De,"TD",{});var mc=l(cd);Dl=n(mc,"Sauer LLC"),mc.forEach(e),yl=o(De),id=d(De,"TD",{});var Tc=l(id);gl=n(Tc,"Chad"),Tc.forEach(e),ie=o(De),vd=d(De,"TD",{});var Ec=l(vd);wl=n(Ec,"6/23/2020"),Ec.forEach(e),Sl=o(De),kl=d(De,"TD",{});var bc=l(kl);lo=n(bc,"Green"),bc.forEach(e),De.forEach(e),ro=o(x),Qt=d(x,"TR",{});var ye=l(Qt);Rl=d(ye,"TH",{});var $c=l(Rl);oo=n($c,"11"),$c.forEach(e),so=o(ye),xl=d(ye,"TD",{});var Dc=l(xl);no=n(Dc,"Andy Tipple"),Dc.forEach(e),ho=o(ye),Pl=d(ye,"TD",{});var yc=l(Pl);co=n(yc,"Librarian"),yc.forEach(e),io=o(ye),Il=d(ye,"TD",{});var gc=l(Il);vo=n(gc,"Hilpert Group"),gc.forEach(e),fo=o(ye),Al=d(ye,"TD",{});var wc=l(Al);uo=n(wc,"Poland"),wc.forEach(e),po=o(ye),Bl=d(ye,"TD",{});var Sc=l(Bl);_o=n(Sc,"7/9/2020"),Sc.forEach(e),mo=o(ye),Nl=d(ye,"TD",{});var Cc=l(Nl);To=n(Cc,"Indigo"),Cc.forEach(e),ye.forEach(e),Eo=o(x),qt=d(x,"TR",{});var ge=l(qt);Ll=d(ge,"TH",{});var Hc=l(Ll);bo=n(Hc,"12"),Hc.forEach(e),$o=o(ge),Gl=d(ge,"TD",{});var kc=l(Gl);Do=n(kc,"Sophi Biles"),kc.forEach(e),yo=o(ge),Vl=d(ge,"TD",{});var Rc=l(Vl);go=n(Rc,"Recruiting Manager"),Rc.forEach(e),wo=o(ge),Fl=d(ge,"TD",{});var xc=l(Fl);So=n(xc,"Gutmann Inc"),xc.forEach(e),Co=o(ge),zl=d(ge,"TD",{});var Pc=l(zl);Ho=n(Pc,"Indonesia"),Pc.forEach(e),ko=o(ge),Ml=d(ge,"TD",{});var Ic=l(Ml);Ro=n(Ic,"2/12/2021"),Ic.forEach(e),xo=o(ge),Ol=d(ge,"TD",{});var Ac=l(Ol);Po=n(Ac,"Maroon"),Ac.forEach(e),ge.forEach(e),Io=o(x),Ut=d(x,"TR",{});var we=l(Ut);Jl=d(we,"TH",{});var Bc=l(Jl);Ao=n(Bc,"13"),Bc.forEach(e),Bo=o(we),Wl=d(we,"TD",{});var Nc=l(Wl);No=n(Nc,"Florida Garces"),Nc.forEach(e),Lo=o(we),Kl=d(we,"TD",{});var Lc=l(Kl);Go=n(Lc,"Web Developer IV"),Lc.forEach(e),Vo=o(we),Ql=d(we,"TD",{});var Gc=l(Ql);Fo=n(Gc,"Gaylord, Pacocha and Baumbach"),Gc.forEach(e),zo=o(we),ql=d(we,"TD",{});var Vc=l(ql);Mo=n(Vc,"Poland"),Vc.forEach(e),Oo=o(we),Ul=d(we,"TD",{});var Fc=l(Ul);Jo=n(Fc,"5/31/2020"),Fc.forEach(e),Wo=o(we),Yl=d(we,"TD",{});var zc=l(Yl);Ko=n(zc,"Purple"),zc.forEach(e),we.forEach(e),Qo=o(x),Yt=d(x,"TR",{});var Se=l(Yt);Zl=d(Se,"TH",{});var Mc=l(Zl);qo=n(Mc,"14"),Mc.forEach(e),Uo=o(Se),jl=d(Se,"TD",{});var Oc=l(jl);Yo=n(Oc,"Maribeth Popping"),Oc.forEach(e),Zo=o(Se),Xl=d(Se,"TD",{});var Jc=l(Xl);jo=n(Jc,"Analyst Programmer"),Jc.forEach(e),Xo=o(Se),tr=d(Se,"TD",{});var Wc=l(tr);ts=n(Wc,"Deckow-Pouros"),Wc.forEach(e),es=o(Se),er=d(Se,"TD",{});var Kc=l(er);as=n(Kc,"Portugal"),Kc.forEach(e),ds=o(Se),ar=d(Se,"TD",{});var Qc=l(ar);ls=n(Qc,"4/27/2021"),Qc.forEach(e),rs=o(Se),dr=d(Se,"TD",{});var qc=l(dr);os=n(qc,"Aquamarine"),qc.forEach(e),Se.forEach(e),ss=o(x),Zt=d(x,"TR",{});var Ce=l(Zt);lr=d(Ce,"TH",{});var Uc=l(lr);ns=n(Uc,"15"),Uc.forEach(e),hs=o(Ce),rr=d(Ce,"TD",{});var Yc=l(rr);cs=n(Yc,"Moritz Dryburgh"),Yc.forEach(e),is=o(Ce),or=d(Ce,"TD",{});var Zc=l(or);vs=n(Zc,"Dental Hygienist"),Zc.forEach(e),fs=o(Ce),sr=d(Ce,"TD",{});var jc=l(sr);us=n(jc,"Schiller, Cole and Hackett"),jc.forEach(e),ps=o(Ce),nr=d(Ce,"TD",{});var Xc=l(nr);_s=n(Xc,"Sri Lanka"),Xc.forEach(e),ms=o(Ce),hr=d(Ce,"TD",{});var ti=l(hr);Ts=n(ti,"8/8/2020"),ti.forEach(e),Es=o(Ce),cr=d(Ce,"TD",{});var ei=l(cr);bs=n(ei,"Crimson"),ei.forEach(e),Ce.forEach(e),$s=o(x),jt=d(x,"TR",{});var He=l(jt);ir=d(He,"TH",{});var ai=l(ir);Ds=n(ai,"16"),ai.forEach(e),ys=o(He),vr=d(He,"TD",{});var di=l(vr);gs=n(di,"Reid Semiras"),di.forEach(e),ws=o(He),fr=d(He,"TD",{});var li=l(fr);Ss=n(li,"Teacher"),li.forEach(e),Cs=o(He),ur=d(He,"TD",{});var ri=l(ur);Hs=n(ri,"Sporer, Sipes and Rogahn"),ri.forEach(e),ks=o(He),pr=d(He,"TD",{});var oi=l(pr);Rs=n(oi,"Poland"),oi.forEach(e),xs=o(He),_r=d(He,"TD",{});var si=l(_r);Ps=n(si,"7/30/2020"),si.forEach(e),Is=o(He),mr=d(He,"TD",{});var ni=l(mr);As=n(ni,"Green"),ni.forEach(e),He.forEach(e),Bs=o(x),Xt=d(x,"TR",{});var ke=l(Xt);Tr=d(ke,"TH",{});var hi=l(Tr);Ns=n(hi,"17"),hi.forEach(e),Ls=o(ke),Er=d(ke,"TD",{});var ci=l(Er);Gs=n(ci,"Alec Lethby"),ci.forEach(e),Vs=o(ke),br=d(ke,"TD",{});var ii=l(br);Fs=n(ii,"Teacher"),ii.forEach(e),zs=o(ke),$r=d(ke,"TD",{});var vi=l($r);Ms=n(vi,"Reichel, Glover and Hamill"),vi.forEach(e),Os=o(ke),Dr=d(ke,"TD",{});var fi=l(Dr);Js=n(fi,"China"),fi.forEach(e),Ws=o(ke),yr=d(ke,"TD",{});var ui=l(yr);Ks=n(ui,"2/28/2021"),ui.forEach(e),Qs=o(ke),gr=d(ke,"TD",{});var pi=l(gr);qs=n(pi,"Khaki"),pi.forEach(e),ke.forEach(e),Us=o(x),te=d(x,"TR",{});var Re=l(te);wr=d(Re,"TH",{});var _i=l(wr);Ys=n(_i,"18"),_i.forEach(e),Zs=o(Re),Sr=d(Re,"TD",{});var mi=l(Sr);js=n(mi,"Aland Wilber"),mi.forEach(e),Xs=o(Re),Cr=d(Re,"TD",{});var Ti=l(Cr);tn=n(Ti,"Quality Control Specialist"),Ti.forEach(e),en=o(Re),Hr=d(Re,"TD",{});var Ei=l(Hr);an=n(Ei,"Kshlerin, Rogahn and Swaniawski"),Ei.forEach(e),dn=o(Re),kr=d(Re,"TD",{});var bi=l(kr);ln=n(bi,"Czech Republic"),bi.forEach(e),rn=o(Re),Rr=d(Re,"TD",{});var $i=l(Rr);on=n($i,"9/29/2020"),$i.forEach(e),sn=o(Re),xr=d(Re,"TD",{});var Di=l(xr);nn=n(Di,"Purple"),Di.forEach(e),Re.forEach(e),hn=o(x),ee=d(x,"TR",{});var xe=l(ee);Pr=d(xe,"TH",{});var yi=l(Pr);cn=n(yi,"19"),yi.forEach(e),vn=o(xe),Ir=d(xe,"TD",{});var gi=l(Ir);fn=n(gi,"Teddie Duerden"),gi.forEach(e),un=o(xe),Ar=d(xe,"TD",{});var wi=l(Ar);pn=n(wi,"Staff Accountant III"),wi.forEach(e),_n=o(xe),Br=d(xe,"TD",{});var Si=l(Br);mn=n(Si,"Pouros, Ullrich and Windler"),Si.forEach(e),Tn=o(xe),Nr=d(xe,"TD",{});var Ci=l(Nr);En=n(Ci,"France"),Ci.forEach(e),bn=o(xe),Lr=d(xe,"TD",{});var Hi=l(Lr);$n=n(Hi,"10/27/2020"),Hi.forEach(e),Dn=o(xe),Gr=d(xe,"TD",{});var ki=l(Gr);yn=n(ki,"Aquamarine"),ki.forEach(e),xe.forEach(e),gn=o(x),ae=d(x,"TR",{});var Pe=l(ae);Vr=d(Pe,"TH",{});var Ri=l(Vr);wn=n(Ri,"20"),Ri.forEach(e),Sn=o(Pe),Fr=d(Pe,"TD",{});var xi=l(Fr);Cn=n(xi,"Lorelei Blackstone"),xi.forEach(e),Hn=o(Pe),zr=d(Pe,"TD",{});var Pi=l(zr);kn=n(Pi,"Data Coordinator"),Pi.forEach(e),Rn=o(Pe),Mr=d(Pe,"TD",{});var Ii=l(Mr);xn=n(Ii,"Witting, Kutch and Greenfelder"),Ii.forEach(e),Pn=o(Pe),Or=d(Pe,"TD",{});var Ai=l(Or);In=n(Ai,"Kazakhstan"),Ai.forEach(e),An=o(Pe),Jr=d(Pe,"TD",{});var Bi=l(Jr);Bn=n(Bi,"6/3/2020"),Bi.forEach(e),Nn=o(Pe),Wr=d(Pe,"TD",{});var Ni=l(Wr);Ln=n(Ni,"Red"),Ni.forEach(e),Pe.forEach(e),x.forEach(e),Gn=o(Cl),Kr=d(Cl,"TFOOT",{});var Li=l(Kr);de=d(Li,"TR",{});var Ie=l(de);to=d(Ie,"TH",{}),l(to).forEach(e),Vn=o(Ie),Qr=d(Ie,"TH",{});var Gi=l(Qr);Fn=n(Gi,"Name"),Gi.forEach(e),zn=o(Ie),qr=d(Ie,"TH",{});var Vi=l(qr);Mn=n(Vi,"Job"),Vi.forEach(e),On=o(Ie),Ur=d(Ie,"TH",{});var Fi=l(Ur);Jn=n(Fi,"company"),Fi.forEach(e),Wn=o(Ie),Yr=d(Ie,"TH",{});var zi=l(Yr);Kn=n(zi,"location"),zi.forEach(e),Qn=o(Ie),Zr=d(Ie,"TH",{});var Mi=l(Zr);qn=n(Mi,"Last Login"),Mi.forEach(e),Un=o(Ie),jr=d(Ie,"TH",{});var Oi=l(jr);Yn=n(Oi,"Favorite Color"),Oi.forEach(e),Ie.forEach(e),Li.forEach(e),Cl.forEach(e),eo.forEach(e),this.h()},h(){E(f,"class","table table-compact w-full"),E(h,"class","overflow-x-auto")},m(Xr,eo){Dt(Xr,h,eo),t(h,f),t(f,p),t(p,c),t(c,u),t(c,T),t(c,i),t(i,v),t(c,z),t(c,I),t(I,Y),t(c,j),t(c,R),t(R,lt),t(c,_),t(c,m),t(m,D),t(c,V),t(c,rt),t(rt,M),t(c,S),t(c,X),t(X,ht),t(f,K),t(f,b),t(b,P),t(P,A),t(A,ot),t(P,st),t(P,$),t($,tt),t(P,yt),t(P,et),t(et,O),t(P,gt),t(P,ct),t(ct,J),t(P,wt),t(P,it),t(it,L),t(P,St),t(P,vt),t(vt,y),t(P,W),t(P,ft),t(ft,Ct),t(b,Q),t(b,N),t(N,ut),t(ut,q),t(N,nt),t(N,pt),t(pt,Z),t(N,U),t(N,F),t(F,at),t(N,dt),t(N,xt),t(xt,g),t(N,_t),t(N,mt),t(mt,Rt),t(N,B),t(N,C),t(C,Gt),t(N,Ht),t(N,Tt),t(Tt,Vt),t(b,k),t(b,G),t(G,Pt),t(Pt,Ft),t(G,Et),t(G,w),t(w,zt),t(G,Mt),t(G,bt),t(bt,Ot),t(G,Ed),t(G,We),t(We,bd),t(G,$d),t(G,Ke),t(Ke,ta),t(G,Dd),t(G,pa),t(pa,Jt),t(G,_a),t(G,Qe),t(Qe,ma),t(b,yd),t(b,kt),t(kt,oe),t(oe,ea),t(kt,aa),t(kt,Be),t(Be,Wd),t(kt,gd),t(kt,Ae),t(Ae,da),t(kt,wd),t(kt,Ta),t(Ta,la),t(kt,Sd),t(kt,Ea),t(Ea,Ne),t(kt,Cd),t(kt,ba),t(ba,Hd),t(kt,ra),t(kt,$a),t($a,kd),t(b,Da),t(b,It),t(It,ya),t(ya,ga),t(It,oa),t(It,wa),t(wa,Rd),t(It,Wt),t(It,qe),t(qe,Sa),t(It,Ca),t(It,Ha),t(Ha,ka),t(It,Le),t(It,Ge),t(Ge,sa),t(It,na),t(It,Oa),t(Oa,xd),t(It,Ue),t(It,Ve),t(Ve,Pd),t(b,Id),t(b,$t),t($t,Ra),t(Ra,Ad),t($t,Fe),t($t,xa),t(xa,Bd),t($t,Nd),t($t,ze),t(ze,Ld),t($t,Gd),t($t,Ye),t(Ye,Vd),t($t,Fd),t($t,Ze),t(Ze,ha),t($t,zd),t($t,Pa),t(Pa,Ia),t($t,Kt),t($t,ca),t(ca,Md),t(b,Aa),t(b,At),t(At,Ba),t(Ba,Na),t(At,Od),t(At,La),t(La,Ga),t(At,Jd),t(At,Va),t(Va,Ja),t(At,Fa),t(At,ia),t(ia,va),t(At,Kd),t(At,le),t(le,Qd),t(At,qd),t(At,Wa),t(Wa,Ud),t(At,Yd),t(At,se),t(se,ne),t(b,Zd),t(b,Bt),t(Bt,Ka),t(Ka,Qa),t(Bt,jd),t(Bt,qa),t(qa,Ua),t(Bt,Xd),t(Bt,Ya),t(Ya,za),t(Bt,tl),t(Bt,Za),t(Za,el),t(Bt,al),t(Bt,re),t(re,dl),t(Bt,ll),t(Bt,ja),t(ja,Xa),t(Bt,rl),t(Bt,td),t(td,ed),t(b,ol),t(b,Nt),t(Nt,je),t(je,sl),t(Nt,nl),t(Nt,ad),t(ad,hl),t(Nt,he),t(Nt,dd),t(dd,cl),t(Nt,il),t(Nt,fa),t(fa,vl),t(Nt,fl),t(Nt,ua),t(ua,ul),t(Nt,pl),t(Nt,Xe),t(Xe,_l),t(Nt,ml),t(Nt,ld),t(ld,Tl),t(b,ce),t(b,Lt),t(Lt,rd),t(rd,El),t(Lt,od),t(Lt,sd),t(sd,bl),t(Lt,nd),t(Lt,hd),t(hd,$l),t(Lt,Ma),t(Lt,cd),t(cd,Dl),t(Lt,yl),t(Lt,id),t(id,gl),t(Lt,ie),t(Lt,vd),t(vd,wl),t(Lt,Sl),t(Lt,kl),t(kl,lo),t(b,ro),t(b,Qt),t(Qt,Rl),t(Rl,oo),t(Qt,so),t(Qt,xl),t(xl,no),t(Qt,ho),t(Qt,Pl),t(Pl,co),t(Qt,io),t(Qt,Il),t(Il,vo),t(Qt,fo),t(Qt,Al),t(Al,uo),t(Qt,po),t(Qt,Bl),t(Bl,_o),t(Qt,mo),t(Qt,Nl),t(Nl,To),t(b,Eo),t(b,qt),t(qt,Ll),t(Ll,bo),t(qt,$o),t(qt,Gl),t(Gl,Do),t(qt,yo),t(qt,Vl),t(Vl,go),t(qt,wo),t(qt,Fl),t(Fl,So),t(qt,Co),t(qt,zl),t(zl,Ho),t(qt,ko),t(qt,Ml),t(Ml,Ro),t(qt,xo),t(qt,Ol),t(Ol,Po),t(b,Io),t(b,Ut),t(Ut,Jl),t(Jl,Ao),t(Ut,Bo),t(Ut,Wl),t(Wl,No),t(Ut,Lo),t(Ut,Kl),t(Kl,Go),t(Ut,Vo),t(Ut,Ql),t(Ql,Fo),t(Ut,zo),t(Ut,ql),t(ql,Mo),t(Ut,Oo),t(Ut,Ul),t(Ul,Jo),t(Ut,Wo),t(Ut,Yl),t(Yl,Ko),t(b,Qo),t(b,Yt),t(Yt,Zl),t(Zl,qo),t(Yt,Uo),t(Yt,jl),t(jl,Yo),t(Yt,Zo),t(Yt,Xl),t(Xl,jo),t(Yt,Xo),t(Yt,tr),t(tr,ts),t(Yt,es),t(Yt,er),t(er,as),t(Yt,ds),t(Yt,ar),t(ar,ls),t(Yt,rs),t(Yt,dr),t(dr,os),t(b,ss),t(b,Zt),t(Zt,lr),t(lr,ns),t(Zt,hs),t(Zt,rr),t(rr,cs),t(Zt,is),t(Zt,or),t(or,vs),t(Zt,fs),t(Zt,sr),t(sr,us),t(Zt,ps),t(Zt,nr),t(nr,_s),t(Zt,ms),t(Zt,hr),t(hr,Ts),t(Zt,Es),t(Zt,cr),t(cr,bs),t(b,$s),t(b,jt),t(jt,ir),t(ir,Ds),t(jt,ys),t(jt,vr),t(vr,gs),t(jt,ws),t(jt,fr),t(fr,Ss),t(jt,Cs),t(jt,ur),t(ur,Hs),t(jt,ks),t(jt,pr),t(pr,Rs),t(jt,xs),t(jt,_r),t(_r,Ps),t(jt,Is),t(jt,mr),t(mr,As),t(b,Bs),t(b,Xt),t(Xt,Tr),t(Tr,Ns),t(Xt,Ls),t(Xt,Er),t(Er,Gs),t(Xt,Vs),t(Xt,br),t(br,Fs),t(Xt,zs),t(Xt,$r),t($r,Ms),t(Xt,Os),t(Xt,Dr),t(Dr,Js),t(Xt,Ws),t(Xt,yr),t(yr,Ks),t(Xt,Qs),t(Xt,gr),t(gr,qs),t(b,Us),t(b,te),t(te,wr),t(wr,Ys),t(te,Zs),t(te,Sr),t(Sr,js),t(te,Xs),t(te,Cr),t(Cr,tn),t(te,en),t(te,Hr),t(Hr,an),t(te,dn),t(te,kr),t(kr,ln),t(te,rn),t(te,Rr),t(Rr,on),t(te,sn),t(te,xr),t(xr,nn),t(b,hn),t(b,ee),t(ee,Pr),t(Pr,cn),t(ee,vn),t(ee,Ir),t(Ir,fn),t(ee,un),t(ee,Ar),t(Ar,pn),t(ee,_n),t(ee,Br),t(Br,mn),t(ee,Tn),t(ee,Nr),t(Nr,En),t(ee,bn),t(ee,Lr),t(Lr,$n),t(ee,Dn),t(ee,Gr),t(Gr,yn),t(b,gn),t(b,ae),t(ae,Vr),t(Vr,wn),t(ae,Sn),t(ae,Fr),t(Fr,Cn),t(ae,Hn),t(ae,zr),t(zr,kn),t(ae,Rn),t(ae,Mr),t(Mr,xn),t(ae,Pn),t(ae,Or),t(Or,In),t(ae,An),t(ae,Jr),t(Jr,Bn),t(ae,Nn),t(ae,Wr),t(Wr,Ln),t(f,Gn),t(f,Kr),t(Kr,de),t(de,to),t(de,Vn),t(de,Qr),t(Qr,Fn),t(de,zn),t(de,qr),t(qr,Mn),t(de,On),t(de,Ur),t(Ur,Jn),t(de,Wn),t(de,Yr),t(Yr,Kn),t(de,Qn),t(de,Zr),t(Zr,qn),t(de,Un),t(de,jr),t(jr,Yn)},d(Xr){Xr&&e(h)}}}function mv(H){let h,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-compact w-full">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function Tv(H){let h,f=`<div className="overflow-x-auto">
  <table className="$$table $$table-compact w-full">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,p,c,u,T;return{c(){h=a("pre"),p=s(f),this.h()},l(i){h=d(i,"PRE",{slot:!0});var v=l(h);p=n(v,f),v.forEach(e),this.h()},h(){E(h,"slot","react")},m(i,v){Dt(i,h,v),t(h,p),u||(T=Me(c=Je.call(null,h,{to:H[0]})),u=!0)},p(i,v){c&&Oe(c.update)&&v&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),u=!1,T()}}}function Ev(H){let h,f,p,c,u,T,i,v,z,I,Y,j,R,lt;return h=new tv({props:{data:[{type:"component",class:"table",desc:"For <table> element"},{type:"modifier",class:"table-zebra",desc:"For <table> to zebra stripe rows"},{type:"modifier",class:"active",desc:"For <tr> to highlight current row"},{type:"modifier",class:"hover",desc:"For <tr> to highlight current row on hover"},{type:"responsive",class:"table-normal",desc:"Normal paddings"},{type:"responsive",class:"table-compact",desc:"Compact paddings"}]}}),p=new Hl({props:{title:"Table",$$slots:{react:[dv],html:[av],default:[ev]},$$scope:{ctx:H}}}),u=new Hl({props:{title:"Table with an active row",$$slots:{react:[ov],html:[rv],default:[lv]},$$scope:{ctx:H}}}),i=new Hl({props:{title:"Table with a row that highlights on hover",$$slots:{react:[hv],html:[nv],default:[sv]},$$scope:{ctx:H}}}),z=new Hl({props:{title:"Zebra",$$slots:{react:[vv],html:[iv],default:[cv]},$$scope:{ctx:H}}}),Y=new Hl({props:{title:"Table with visual elements",$$slots:{react:[pv],html:[uv],default:[fv]},$$scope:{ctx:H}}}),R=new Hl({props:{title:"Compact table",$$slots:{react:[Tv],html:[mv],default:[_v]},$$scope:{ctx:H}}}),{c(){fd(h.$$.fragment),f=r(),fd(p.$$.fragment),c=r(),fd(u.$$.fragment),T=r(),fd(i.$$.fragment),v=r(),fd(z.$$.fragment),I=r(),fd(Y.$$.fragment),j=r(),fd(R.$$.fragment)},l(_){ud(h.$$.fragment,_),f=o(_),ud(p.$$.fragment,_),c=o(_),ud(u.$$.fragment,_),T=o(_),ud(i.$$.fragment,_),v=o(_),ud(z.$$.fragment,_),I=o(_),ud(Y.$$.fragment,_),j=o(_),ud(R.$$.fragment,_)},m(_,m){pd(h,_,m),Dt(_,f,m),pd(p,_,m),Dt(_,c,m),pd(u,_,m),Dt(_,T,m),pd(i,_,m),Dt(_,v,m),pd(z,_,m),Dt(_,I,m),pd(Y,_,m),Dt(_,j,m),pd(R,_,m),lt=!0},p(_,m){const D={};m&5&&(D.$$scope={dirty:m,ctx:_}),p.$set(D);const V={};m&5&&(V.$$scope={dirty:m,ctx:_}),u.$set(V);const rt={};m&5&&(rt.$$scope={dirty:m,ctx:_}),i.$set(rt);const M={};m&5&&(M.$$scope={dirty:m,ctx:_}),z.$set(M);const S={};m&5&&(S.$$scope={dirty:m,ctx:_}),Y.$set(S);const X={};m&5&&(X.$$scope={dirty:m,ctx:_}),R.$set(X)},i(_){lt||(_d(h.$$.fragment,_),_d(p.$$.fragment,_),_d(u.$$.fragment,_),_d(i.$$.fragment,_),_d(z.$$.fragment,_),_d(Y.$$.fragment,_),_d(R.$$.fragment,_),lt=!0)},o(_){md(h.$$.fragment,_),md(p.$$.fragment,_),md(u.$$.fragment,_),md(i.$$.fragment,_),md(z.$$.fragment,_),md(Y.$$.fragment,_),md(R.$$.fragment,_),lt=!1},d(_){Td(h,_),_&&e(f),Td(p,_),_&&e(c),Td(u,_),_&&e(T),Td(i,_),_&&e(v),Td(z,_),_&&e(I),Td(Y,_),_&&e(j),Td(R,_)}}}function bv(H){let h,f;const p=[H[1],Ki];let c={$$slots:{default:[Ev]},$$scope:{ctx:H}};for(let u=0;u<p.length;u+=1)c=Zn(c,p[u]);return h=new ji({props:c}),{c(){fd(h.$$.fragment)},l(u){ud(h.$$.fragment,u)},m(u,T){pd(h,u,T),f=!0},p(u,[T]){const i=T&2?Yi(p,[T&2&&Ji(u[1]),T&0&&Ji(Ki)]):{};T&5&&(i.$$scope={dirty:T,ctx:u}),h.$set(i)},i(u){f||(_d(h.$$.fragment,u),f=!0)},o(u){md(h.$$.fragment,u),f=!1},d(u){Td(h,u)}}}const Ki={title:"Table",desc:"Table can be used to show a list of data in a table format.",published:!0};function $v(H,h,f){let p;return Zi(H,Xi,c=>f(0,p=c)),H.$$set=c=>{f(1,h=Zn(Zn({},h),Wi(c)))},h=Wi(h),[p,h]}class xv extends Qi{constructor(h){super();qi(this,h,$v,bv,Ui,{})}}export{xv as default,Ki as metadata};
