import{S as Ae,i as Ve,s as Te,C as me,w as K,x as Q,y as W,z as je,A as Ne,q as G,o as X,B as Z,K as Be,ag as Se,k as E,e as d,t as I,m as x,c,a as u,h as k,d as l,b as i,g as V,F as a,a9 as q,Q as H,H as Le,I as De}from"../../chunks/vendor-3400f70d.js";import{M as Me}from"../../chunks/_markdown-c6e5d82d.js";import{p as Oe,C as Ce,a as ie,r as J}from"../../chunks/actions-25d1509e.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-2fc8a938.js";import"../../chunks/index-6d18b392.js";import"../../chunks/SEO-4d6e6aa8.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-00fadf31.js";function Fe(w){let e,m,p,o,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),o=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var v=u(e);m=c(v,"INPUT",{id:!0,type:!0,class:!0}),p=x(v),o=c(v,"DIV",{class:!0});var M=u(o);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(v),t=c(v,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var n=u(L);D=k(n,"Sidebar Item 1"),n.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var b=u(N);y=c(b,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),b.forEach(l),g.forEach(l),T.forEach(l),v.forEach(l),this.h()},h(){i(m,"id","my-drawer"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer"),i(s,"class","btn btn-primary drawer-button"),i(o,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer h-56 rounded")},m(S,v){V(S,e,v),a(e,m),a(e,p),a(e,o),a(o,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function Re(w){let e,m=`<div class="$$drawer">
  <input id="my-drawer" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content">
    <!-- Page content here -->
    <label for="my-drawer" class="$$btn $$btn-primary $$drawer-button">Open drawer</label>
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer" class="$$drawer-overlay"></label>
    <ul class="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function ze(w){let e,m=`<div className="$$drawer">
  <input id="my-drawer" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content">
    <!-- Page content here -->
    <label htmlFor="my-drawer" className="$$btn $$btn-primary $$drawer-button">Open drawer</label>
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer" className="$$drawer-overlay"></label>
    <ul className="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ue(w){let e,m,p,o,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),o=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var v=u(e);m=c(v,"INPUT",{id:!0,type:!0,class:!0}),p=x(v),o=c(v,"DIV",{class:!0});var M=u(o);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(v),t=c(v,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var n=u(L);D=k(n,"Sidebar Item 1"),n.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var b=u(N);y=c(b,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),b.forEach(l),g.forEach(l),T.forEach(l),v.forEach(l),this.h()},h(){i(m,"id","my-drawer-2"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer-2"),i(s,"class","btn btn-primary drawer-button lg:hidden"),i(o,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer-2"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer drawer-mobile h-56 rounded")},m(S,v){V(S,e,v),a(e,m),a(e,p),a(e,o),a(o,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function qe(w){let e,m=`<div class="$$drawer $$drawer-mobile">
  <input id="my-drawer-2" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content flex flex-col items-center justify-center">
    <!-- Page content here -->
    <label for="my-drawer-2" class="$$btn $$btn-primary $$drawer-button lg:hidden">Open drawer</label>
  
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-2" class="$$drawer-overlay"></label> 
    <ul class="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function He(w){let e,m=`<div className="$$drawer $$drawer-mobile">
  <input id="my-drawer-2" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content flex flex-col items-center justify-center">
    <!-- Page content here -->
    <label htmlFor="my-drawer-2" className="$$btn $$btn-primary $$drawer-button lg:hidden">Open drawer</label>
  
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-2" className="$$drawer-overlay"></label> 
    <ul className="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Je(w){let e,m,p,o,s,f,r,t,$,O,h,_,L,D,P,N,y,A,S,v,M,j,T,g,C,n,b,B,z,F,R,ee,de,ce,ae,te,ue;return{c(){e=d("div"),m=d("input"),p=E(),o=d("div"),s=d("div"),f=d("div"),r=d("label"),t=Le("svg"),$=Le("path"),O=E(),h=d("div"),_=I("Navbar Title"),L=E(),D=d("div"),P=d("ul"),N=d("li"),y=d("a"),A=I("Navbar Item 1"),S=E(),v=d("li"),M=d("a"),j=I("Navbar Item 2"),T=E(),g=d("div"),C=I("Content"),n=E(),b=d("div"),B=d("label"),z=E(),F=d("ul"),R=d("li"),ee=d("a"),de=I("Sidebar Item 1"),ce=E(),ae=d("li"),te=d("a"),ue=I("Sidebar Item 2"),this.h()},l(re){e=c(re,"DIV",{class:!0});var U=u(e);m=c(U,"INPUT",{id:!0,type:!0,class:!0}),p=x(U),o=c(U,"DIV",{class:!0});var le=u(o);s=c(le,"DIV",{class:!0});var Y=u(s);f=c(Y,"DIV",{class:!0});var pe=u(f);r=c(pe,"LABEL",{for:!0,class:!0});var fe=u(r);t=De(fe,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var be=u(t);$=De(be,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u($).forEach(l),be.forEach(l),fe.forEach(l),pe.forEach(l),O=x(Y),h=c(Y,"DIV",{class:!0});var ve=u(h);_=k(ve,"Navbar Title"),ve.forEach(l),L=x(Y),D=c(Y,"DIV",{class:!0});var he=u(D);P=c(he,"UL",{class:!0});var se=u(P);N=c(se,"LI",{});var $e=u(N);y=c($e,"A",{});var we=u(y);A=k(we,"Navbar Item 1"),we.forEach(l),$e.forEach(l),S=x(se),v=c(se,"LI",{});var _e=u(v);M=c(_e,"A",{});var ge=u(M);j=k(ge,"Navbar Item 2"),ge.forEach(l),_e.forEach(l),se.forEach(l),he.forEach(l),Y.forEach(l),T=x(le),g=c(le,"DIV",{class:!0});var ye=u(g);C=k(ye,"Content"),ye.forEach(l),le.forEach(l),n=x(U),b=c(U,"DIV",{class:!0});var ne=u(b);B=c(ne,"LABEL",{for:!0,class:!0}),u(B).forEach(l),z=x(ne),F=c(ne,"UL",{class:!0});var oe=u(F);R=c(oe,"LI",{});var Ee=u(R);ee=c(Ee,"A",{});var xe=u(ee);de=k(xe,"Sidebar Item 1"),xe.forEach(l),Ee.forEach(l),ce=x(oe),ae=c(oe,"LI",{});var Ie=u(ae);te=c(Ie,"A",{});var ke=u(te);ue=k(ke,"Sidebar Item 2"),ke.forEach(l),Ie.forEach(l),oe.forEach(l),ne.forEach(l),U.forEach(l),this.h()},h(){i(m,"id","my-drawer-3"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i($,"stroke-linecap","round"),i($,"stroke-linejoin","round"),i($,"stroke-width","2"),i($,"d","M4 6h16M4 12h16M4 18h16"),i(t,"xmlns","http://www.w3.org/2000/svg"),i(t,"fill","none"),i(t,"viewBox","0 0 24 24"),i(t,"class","inline-block w-6 h-6 stroke-current"),i(r,"for","my-drawer-3"),i(r,"class","btn btn-square btn-ghost"),i(f,"class","flex-none lg:hidden"),i(h,"class","flex-1 px-2 mx-2"),i(P,"class","menu menu-horizontal"),i(D,"class","flex-none hidden lg:block"),i(s,"class","w-full navbar bg-base-300"),i(g,"class","flex justify-center items-center flex-grow"),i(o,"class","flex flex-col drawer-content"),i(B,"for","my-drawer-3"),i(B,"class","drawer-overlay"),i(F,"class","p-4 menu w-60 md:w-80 bg-base-100"),i(b,"class","drawer-side"),i(e,"class","drawer h-56 rounded")},m(re,U){V(re,e,U),a(e,m),a(e,p),a(e,o),a(o,s),a(s,f),a(f,r),a(r,t),a(t,$),a(s,O),a(s,h),a(h,_),a(s,L),a(s,D),a(D,P),a(P,N),a(N,y),a(y,A),a(P,S),a(P,v),a(v,M),a(M,j),a(o,T),a(o,g),a(g,C),a(e,n),a(e,b),a(b,B),a(b,z),a(b,F),a(F,R),a(R,ee),a(ee,de),a(F,ce),a(F,ae),a(ae,te),a(te,ue)},d(re){re&&l(e)}}}function Ye(w){let e,m=`<div class="$$drawer">
  <input id="my-drawer-3" type="checkbox" class="$$drawer-toggle" /> 
  <div class="$$drawer-content flex flex-col">
    <!-- Navbar -->
    <div class="w-full $$navbar bg-base-300">
      <div class="flex-none lg:hidden">
        <label for="my-drawer-3" class="$$btn $$btn-square $$btn-ghost">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-6 h-6 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
        </label>
      </div> 
      <div class="flex-1 px-2 mx-2">Navbar Title</div>
      <div class="flex-none hidden lg:block">
        <ul class="$$menu $$menu-horizontal">
          <!-- Navbar menu content here -->
          <li><a>Navbar Item 1</a></li>
          <li><a>Navbar Item 2</a></li>
        </ul>
      </div>
    </div>
    <!-- Page content here -->
    Content
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-3" class="$$drawer-overlay"></label> 
    <ul class="$$menu p-4 w-80 bg-base-100">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
    
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ke(w){let e,m=`<div className="$$drawer">
  <input id="my-drawer-3" type="checkbox" className="$$drawer-toggle" /> 
  <div className="$$drawer-content flex flex-col">
    <!-- Navbar -->
    <div className="w-full $$navbar bg-base-300">
      <div className="flex-none lg:hidden">
        <label htmlFor="my-drawer-3" className="$$btn $$btn-square $$btn-ghost">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-6 h-6 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
        </label>
      </div> 
      <div className="flex-1 px-2 mx-2">Navbar Title</div>
      <div className="flex-none hidden lg:block">
        <ul className="$$menu $$menu-horizontal">
          <!-- Navbar menu content here -->
          <li><a>Navbar Item 1</a></li>
          <li><a>Navbar Item 2</a></li>
        </ul>
      </div>
    </div>
    <!-- Page content here -->
    Content
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-3" className="$$drawer-overlay"></label> 
    <ul className="$$menu p-4 w-80 bg-base-100">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
    
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Qe(w){let e,m,p,o,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),o=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var v=u(e);m=c(v,"INPUT",{id:!0,type:!0,class:!0}),p=x(v),o=c(v,"DIV",{class:!0});var M=u(o);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(v),t=c(v,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var n=u(L);D=k(n,"Sidebar Item 1"),n.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var b=u(N);y=c(b,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),b.forEach(l),g.forEach(l),T.forEach(l),v.forEach(l),this.h()},h(){i(m,"id","my-drawer-4"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer-4"),i(s,"class","btn btn-primary drawer-button"),i(o,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer-4"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer drawer-end h-56 rounded")},m(S,v){V(S,e,v),a(e,m),a(e,p),a(e,o),a(o,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function We(w){let e,m=`<div class="$$drawer $$drawer-end">
  <input id="my-drawer-4" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content">
    <!-- Page content here -->
    <label for="my-drawer-4" class="$$drawer-button $$btn $$btn-primary">Open drawer</label>
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-4" class="$$drawer-overlay"></label>
    <ul class="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ge(w){let e,m=`<div className="$$drawer $$drawer-end">
  <input id="my-drawer-4" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content">
    <!-- Page content here -->
    <label htmlFor="my-drawer-4" className="$$drawer-button $$btn $$btn-primary">Open drawer</label>
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-4" className="$$drawer-overlay"></label>
    <ul className="$$menu p-4 w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  </div>
</div>`,p,o,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(o=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){o&&H(o.update)&&t&1&&o.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Xe(w){let e,m,p,o,s,f,r,t,$,O=`<code class="language-js"><span class="token punctuation">.</span>drawer <span class="token comment">// The root container</span>
  \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>toggle <span class="token comment">// A hidden checkbox to toggle the visibility of the sidebar</span>
  \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>content <span class="token comment">// All your page content goes here</span>
  \u2502    \u251C\u2500\u2500 <span class="token comment">// navbar</span>
  \u2502    \u251C\u2500\u2500 <span class="token comment">// content</span>
  \u2502    \u2514\u2500\u2500 <span class="token comment">// footer</span>
  \u2514\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>side <span class="token comment">// Sidebar wrapper</span>
       \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>overlay <span class="token comment">// A dark overlay that covers the whole page when the drawer is open</span>
       \u2514\u2500\u2500 <span class="token comment">// Sidebar content (menu or anything)</span></code>`,h,_,L,D,P,N,y,A,S,v,M,j,T,g,C;return e=new Ce({props:{data:[{type:"component",class:"drawer",desc:"Container element"},{type:"component",class:"drawer-toggle",desc:"For checkbox element that controls the drawer"},{type:"component",class:"drawer-content",desc:"The content container"},{type:"component",class:"drawer-side",desc:"The sidebar container"},{type:"component",class:"drawer-overlay",desc:"The label covers the content when drawer is open"},{type:"modifier",class:"drawer-mobile",desc:"Makes drawer to open/close on mobile but will be always visible on desktop"},{type:"modifier",class:"drawer-end",desc:"puts drawer to the right"}]}}),A=new ie({props:{title:"Drawer",$$slots:{react:[ze],html:[Re],default:[Fe]},$$scope:{ctx:w}}}),v=new ie({props:{title:"Drawer for mobile + fixed sidebar for desktop",desc:"Drawer is always open on desktop size. Drawer can be toggled on mobile size. Resize the browser to see toggle button on mobile size",$$slots:{react:[He],html:[qe],default:[Ue]},$$scope:{ctx:w}}}),j=new ie({props:{title:"Navbar menu for desktop + sidebar drawer for mobile",desc:"Change screen size to show/hide menu",$$slots:{react:[Ke],html:[Ye],default:[Je]},$$scope:{ctx:w}}}),g=new ie({props:{title:"Drawer that opens from right side of page",$$slots:{react:[Ge],html:[We],default:[Qe]},$$scope:{ctx:w}}}),{c(){K(e.$$.fragment),m=E(),p=d("p"),o=I("Drawer sidebar can be visible by default on large screens or it can be toggleable on both large and small screens."),s=E(),f=d("p"),r=I("Drawer tags structure:"),t=E(),$=d("pre"),h=E(),_=d("p"),L=I("You can check/uncheck the checkbox using JavaScript or using "),D=d("code"),P=I("<label>"),N=I(" tag."),y=E(),K(A.$$.fragment),S=E(),K(v.$$.fragment),M=E(),K(j.$$.fragment),T=E(),K(g.$$.fragment),this.h()},l(n){Q(e.$$.fragment,n),m=x(n),p=c(n,"P",{});var b=u(p);o=k(b,"Drawer sidebar can be visible by default on large screens or it can be toggleable on both large and small screens."),b.forEach(l),s=x(n),f=c(n,"P",{});var B=u(f);r=k(B,"Drawer tags structure:"),B.forEach(l),t=x(n),$=c(n,"PRE",{class:!0});var z=u($);z.forEach(l),h=x(n),_=c(n,"P",{});var F=u(_);L=k(F,"You can check/uncheck the checkbox using JavaScript or using "),D=c(F,"CODE",{});var R=u(D);P=k(R,"<label>"),R.forEach(l),N=k(F," tag."),F.forEach(l),y=x(n),Q(A.$$.fragment,n),S=x(n),Q(v.$$.fragment,n),M=x(n),Q(j.$$.fragment,n),T=x(n),Q(g.$$.fragment,n),this.h()},h(){i($,"class","language-js")},m(n,b){W(e,n,b),V(n,m,b),V(n,p,b),a(p,o),V(n,s,b),V(n,f,b),a(f,r),V(n,t,b),V(n,$,b),$.innerHTML=O,V(n,h,b),V(n,_,b),a(_,L),a(_,D),a(D,P),a(_,N),V(n,y,b),W(A,n,b),V(n,S,b),W(v,n,b),V(n,M,b),W(j,n,b),V(n,T,b),W(g,n,b),C=!0},p(n,b){const B={};b&5&&(B.$$scope={dirty:b,ctx:n}),A.$set(B);const z={};b&5&&(z.$$scope={dirty:b,ctx:n}),v.$set(z);const F={};b&5&&(F.$$scope={dirty:b,ctx:n}),j.$set(F);const R={};b&5&&(R.$$scope={dirty:b,ctx:n}),g.$set(R)},i(n){C||(G(e.$$.fragment,n),G(A.$$.fragment,n),G(v.$$.fragment,n),G(j.$$.fragment,n),G(g.$$.fragment,n),C=!0)},o(n){X(e.$$.fragment,n),X(A.$$.fragment,n),X(v.$$.fragment,n),X(j.$$.fragment,n),X(g.$$.fragment,n),C=!1},d(n){Z(e,n),n&&l(m),n&&l(p),n&&l(s),n&&l(f),n&&l(t),n&&l($),n&&l(h),n&&l(_),n&&l(y),Z(A,n),n&&l(S),Z(v,n),n&&l(M),Z(j,n),n&&l(T),Z(g,n)}}}function Ze(w){let e,m;const p=[w[1],Pe];let o={$$slots:{default:[Xe]},$$scope:{ctx:w}};for(let s=0;s<p.length;s+=1)o=me(o,p[s]);return e=new Me({props:o}),{c(){K(e.$$.fragment)},l(s){Q(e.$$.fragment,s)},m(s,f){W(e,s,f),m=!0},p(s,[f]){const r=f&2?je(p,[f&2&&Ne(s[1]),f&0&&Ne(Pe)]):{};f&5&&(r.$$scope={dirty:f,ctx:s}),e.$set(r)},i(s){m||(G(e.$$.fragment,s),m=!0)},o(s){X(e.$$.fragment,s),m=!1},d(s){Z(e,s)}}}const Pe={title:"Drawer",desc:"Drawer is a grid layout that can show/hide a sidebar on the left or right side of the page.",published:!0};function ea(w,e,m){let p;return Be(w,Oe,o=>m(0,p=o)),w.$$set=o=>{m(1,e=me(me({},e),Se(o)))},e=Se(e),[p,e]}class ca extends Ae{constructor(e){super();Ve(this,e,ea,Ze,Te,{})}}export{ca as default,Pe as metadata};
