import{S as le,i as oe,s as pe,C as ee,w as Q,x as F,y as G,z as ce,A as se,q as U,o as W,B as X,K as ue,v as re,ag as ae,e as f,t as _,k as R,c as i,a as v,h as w,d as p,m as k,g,H as u,f as S,b as x,a9 as J,j as Y,Q as z}from"../../chunks/vendor-40028f80.js";import{M as de}from"../../chunks/_markdown-93641f90.js";import{p as fe,C as ie,a as Z,r as B}from"../../chunks/actions-3317a27b.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-1e274391.js";import"../../chunks/index-6f188c90.js";import"../../chunks/SEO-b37e315e.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-8494eb6e.js";function ve(d){let e,a;return{c(){e=f("span"),a=f("span"),this.h()},l(n){e=i(n,"SPAN",{class:!0});var l=v(e);a=i(l,"SPAN",{style:!0}),v(a).forEach(p),l.forEach(p),this.h()},h(){S(a,"--value",d[0]),x(e,"class","countdown")},m(n,l){g(n,e,l),u(e,a)},p(n,l){l&1&&S(a,"--value",n[0])},d(n){n&&p(e)}}}function me(d){let e,a=`<span class="$$countdown">
  <span style="--value:${d[0]};"></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span class="$$countdown">
  <span style="--value:${t[0]};"></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function $e(d){let e,a=`<span className="$$countdown">
  <span style={{"--value":${d[0]}}}></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span className="$$countdown">
  <span style={{"--value":${t[0]}}}></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function xe(d){let e,a;return{c(){e=f("span"),a=f("span"),this.h()},l(n){e=i(n,"SPAN",{class:!0});var l=v(e);a=i(l,"SPAN",{style:!0}),v(a).forEach(p),l.forEach(p),this.h()},h(){S(a,"--value",d[0]),x(e,"class","countdown font-mono text-6xl")},m(n,l){g(n,e,l),u(e,a)},p(n,l){l&1&&S(a,"--value",n[0])},d(n){n&&p(e)}}}function he(d){let e,a=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${d[0]};"></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${t[0]};"></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function _e(d){let e,a=`<span className="$$countdown font-mono text-6xl">
  <span style={{"--value":${d[0]}}}></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span className="$$countdown font-mono text-6xl">
  <span style={{"--value":${t[0]}}}></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function we(d){let e,a,n,l,o,r,t;return{c(){e=f("span"),a=f("span"),n=_(`h
  `),l=f("span"),o=_(`m
  `),r=f("span"),t=_("s"),this.h()},l(s){e=i(s,"SPAN",{class:!0});var h=v(e);a=i(h,"SPAN",{style:!0}),v(a).forEach(p),n=w(h,`h
  `),l=i(h,"SPAN",{style:!0}),v(l).forEach(p),o=w(h,`m
  `),r=i(h,"SPAN",{style:!0}),v(r).forEach(p),t=w(h,"s"),h.forEach(p),this.h()},h(){S(a,"--value","10"),S(l,"--value","24"),S(r,"--value",d[0]),x(e,"class","font-mono text-2xl countdown")},m(s,h){g(s,e,h),u(e,a),u(e,n),u(e,l),u(e,o),u(e,r),u(e,t)},p(s,h){h&1&&S(r,"--value",s[0])},d(s){s&&p(e)}}}function ye(d){let e,a=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${d[0]};"></span>s
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${t[0]};"></span>s
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Ne(d){let e,a=`<span className="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>h
  <span style={{"--value":24}}></span>m
  <span style={{"--value":${d[0]}}}></span>s
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span className="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>h
  <span style={{"--value":24}}></span>m
  <span style={{"--value":${t[0]}}}></span>s
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function ge(d){let e,a,n,l,o,r;return{c(){e=f("span"),a=f("span"),n=_(`:
  `),l=f("span"),o=_(`:
  `),r=f("span"),this.h()},l(t){e=i(t,"SPAN",{class:!0});var s=v(e);a=i(s,"SPAN",{style:!0}),v(a).forEach(p),n=w(s,`:
  `),l=i(s,"SPAN",{style:!0}),v(l).forEach(p),o=w(s,`:
  `),r=i(s,"SPAN",{style:!0}),v(r).forEach(p),s.forEach(p),this.h()},h(){S(a,"--value","10"),S(l,"--value","24"),S(r,"--value",d[0]),x(e,"class","font-mono text-2xl countdown")},m(t,s){g(t,e,s),u(e,a),u(e,n),u(e,l),u(e,o),u(e,r)},p(t,s){s&1&&S(r,"--value",t[0])},d(t){t&&p(e)}}}function Ee(d){let e,a=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${d[0]};"></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${t[0]};"></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function be(d){let e,a=`<span className="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>:
  <span style={{"--value":24}}></span>:
  <span style={{"--value":${d[0]}}}></span>
</span>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<span className="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>:
  <span style={{"--value":24}}></span>:
  <span style={{"--value":${t[0]}}}></span>
</span>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Pe(d){let e,a,n,l,o,r,t,s,h,L,D,P,E,V,I,M,N,A,b,T;return{c(){e=f("div"),a=f("div"),n=f("span"),l=f("span"),o=_(`
    days`),r=R(),t=f("div"),s=f("span"),h=f("span"),L=_(`
    hours`),D=R(),P=f("div"),E=f("span"),V=f("span"),I=_(`
    minutes`),M=R(),N=f("div"),A=f("span"),b=f("span"),T=_(`
    sec`),this.h()},l(y){e=i(y,"DIV",{class:!0});var $=v(e);a=i($,"DIV",{});var c=v(a);n=i(c,"SPAN",{class:!0});var m=v(n);l=i(m,"SPAN",{style:!0}),v(l).forEach(p),m.forEach(p),o=w(c,`
    days`),c.forEach(p),r=k($),t=i($,"DIV",{});var C=v(t);s=i(C,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),L=w(C,`
    hours`),C.forEach(p),D=k($),P=i($,"DIV",{});var j=v(P);E=i(j,"SPAN",{class:!0});var K=v(E);V=i(K,"SPAN",{style:!0}),v(V).forEach(p),K.forEach(p),I=w(j,`
    minutes`),j.forEach(p),M=k($),N=i($,"DIV",{});var q=v(N);A=i(q,"SPAN",{class:!0});var O=v(A);b=i(O,"SPAN",{style:!0}),v(b).forEach(p),O.forEach(p),T=w(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){S(l,"--value","15"),x(n,"class","font-mono text-4xl countdown"),S(h,"--value","10"),x(s,"class","font-mono text-4xl countdown"),S(V,"--value","24"),x(E,"class","font-mono text-4xl countdown"),S(b,"--value",d[0]),x(A,"class","font-mono text-4xl countdown"),x(e,"class","flex gap-5")},m(y,$){g(y,e,$),u(e,a),u(a,n),u(n,l),u(a,o),u(e,r),u(e,t),u(t,s),u(s,h),u(t,L),u(e,D),u(e,P),u(P,E),u(E,V),u(P,I),u(e,M),u(e,N),u(N,A),u(A,b),u(N,T)},p(y,$){$&1&&S(b,"--value",y[0])},d(y){y&&p(e)}}}function Se(d){let e,a=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${t[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Ae(d){let e,a=`<div className="flex gap-5">
  <div>
    <span className="$$countdown font-mono text-4xl">
        <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
        <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div className="flex gap-5">
  <div>
    <span className="$$countdown font-mono text-4xl">
        <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
        <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div>
    <span className="$$countdown font-mono text-4xl">
      <span style={{"--value":${t[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Ve(d){let e,a,n,l,o,r,t,s,h,L,D,P,E,V,I,M,N,A,b,T;return{c(){e=f("div"),a=f("div"),n=f("span"),l=f("span"),o=_(`
    days`),r=R(),t=f("div"),s=f("span"),h=f("span"),L=_(`
    hours`),D=R(),P=f("div"),E=f("span"),V=f("span"),I=_(`
    min`),M=R(),N=f("div"),A=f("span"),b=f("span"),T=_(`
    sec`),this.h()},l(y){e=i(y,"DIV",{class:!0});var $=v(e);a=i($,"DIV",{class:!0});var c=v(a);n=i(c,"SPAN",{class:!0});var m=v(n);l=i(m,"SPAN",{style:!0}),v(l).forEach(p),m.forEach(p),o=w(c,`
    days`),c.forEach(p),r=k($),t=i($,"DIV",{class:!0});var C=v(t);s=i(C,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),L=w(C,`
    hours`),C.forEach(p),D=k($),P=i($,"DIV",{class:!0});var j=v(P);E=i(j,"SPAN",{class:!0});var K=v(E);V=i(K,"SPAN",{style:!0}),v(V).forEach(p),K.forEach(p),I=w(j,`
    min`),j.forEach(p),M=k($),N=i($,"DIV",{class:!0});var q=v(N);A=i(q,"SPAN",{class:!0});var O=v(A);b=i(O,"SPAN",{style:!0}),v(b).forEach(p),O.forEach(p),T=w(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){S(l,"--value","15"),x(n,"class","font-mono text-5xl countdown"),x(a,"class","flex flex-col"),S(h,"--value","10"),x(s,"class","font-mono text-5xl countdown"),x(t,"class","flex flex-col"),S(V,"--value","24"),x(E,"class","font-mono text-5xl countdown"),x(P,"class","flex flex-col"),S(b,"--value",d[0]),x(A,"class","font-mono text-5xl countdown"),x(N,"class","flex flex-col"),x(e,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(y,$){g(y,e,$),u(e,a),u(a,n),u(n,l),u(a,o),u(e,r),u(e,t),u(t,s),u(s,h),u(t,L),u(e,D),u(e,P),u(P,E),u(E,V),u(P,I),u(e,M),u(e,N),u(N,A),u(A,b),u(N,T)},p(y,$){$&1&&S(b,"--value",y[0])},d(y){y&&p(e)}}}function De(d){let e,a=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${t[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Ie(d){let e,a=`<div className="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div className="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div className="flex flex-col">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":${t[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Ce(d){let e,a,n,l,o,r,t,s,h,L,D,P,E,V,I,M,N,A,b,T;return{c(){e=f("div"),a=f("div"),n=f("span"),l=f("span"),o=_(`
    days`),r=R(),t=f("div"),s=f("span"),h=f("span"),L=_(`
    hours`),D=R(),P=f("div"),E=f("span"),V=f("span"),I=_(`
    min`),M=R(),N=f("div"),A=f("span"),b=f("span"),T=_(`
    sec`),this.h()},l(y){e=i(y,"DIV",{class:!0});var $=v(e);a=i($,"DIV",{class:!0});var c=v(a);n=i(c,"SPAN",{class:!0});var m=v(n);l=i(m,"SPAN",{style:!0}),v(l).forEach(p),m.forEach(p),o=w(c,`
    days`),c.forEach(p),r=k($),t=i($,"DIV",{class:!0});var C=v(t);s=i(C,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),L=w(C,`
    hours`),C.forEach(p),D=k($),P=i($,"DIV",{class:!0});var j=v(P);E=i(j,"SPAN",{class:!0});var K=v(E);V=i(K,"SPAN",{style:!0}),v(V).forEach(p),K.forEach(p),I=w(j,`
    min`),j.forEach(p),M=k($),N=i($,"DIV",{class:!0});var q=v(N);A=i(q,"SPAN",{class:!0});var O=v(A);b=i(O,"SPAN",{style:!0}),v(b).forEach(p),O.forEach(p),T=w(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){S(l,"--value","15"),x(n,"class","font-mono text-5xl countdown"),x(a,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),S(h,"--value","10"),x(s,"class","font-mono text-5xl countdown"),x(t,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),S(V,"--value","24"),x(E,"class","font-mono text-5xl countdown"),x(P,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),S(b,"--value",d[0]),x(A,"class","font-mono text-5xl countdown"),x(N,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),x(e,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(y,$){g(y,e,$),u(e,a),u(a,n),u(n,l),u(a,o),u(e,r),u(e,t),u(t,s),u(s,h),u(t,L),u(e,D),u(e,P),u(P,E),u(E,V),u(P,I),u(e,M),u(e,N),u(N,A),u(A,b),u(N,T)},p(y,$){$&1&&S(b,"--value",y[0])},d(y){y&&p(e)}}}function Re(d){let e,a=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","html")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${t[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function ke(d){let e,a=`<div className="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,n,l,o,r;return{c(){e=f("pre"),n=_(a),this.h()},l(t){e=i(t,"PRE",{slot:!0});var s=v(e);n=w(s,a),s.forEach(p),this.h()},h(){x(e,"slot","react")},m(t,s){g(t,e,s),u(e,n),o||(r=J(l=B.call(null,e,{to:d[1]})),o=!0)},p(t,s){s&1&&a!==(a=`<div className="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div className="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span className="$$countdown font-mono text-5xl">
      <span style={{"--value":${t[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&Y(n,a),l&&z(l.update)&&s&2&&l.update.call(null,{to:t[1]})},d(t){t&&p(e),o=!1,r()}}}function Le(d){let e,a,n,l,o,r,t,s,h,L,D,P,E,V,I,M,N,A,b,T,y,$;return t=new ie({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),h=new Z({props:{title:"Countdown",$$slots:{react:[$e],html:[me],default:[ve]},$$scope:{ctx:d}}}),D=new Z({props:{title:"Large text",$$slots:{react:[_e],html:[he],default:[xe]},$$scope:{ctx:d}}}),E=new Z({props:{title:"Clock countdown",$$slots:{react:[Ne],html:[ye],default:[we]},$$scope:{ctx:d}}}),I=new Z({props:{title:"Clock countdown with colons",$$slots:{react:[be],html:[Ee],default:[ge]},$$scope:{ctx:d}}}),N=new Z({props:{title:"Large text with labels",$$slots:{react:[Ae],html:[Se],default:[Pe]},$$scope:{ctx:d}}}),b=new Z({props:{title:"Large text with labels under",$$slots:{react:[Ie],html:[De],default:[Ve]},$$scope:{ctx:d}}}),y=new Z({props:{title:"In boxes",$$slots:{react:[ke],html:[Re],default:[Ce]},$$scope:{ctx:d}}}),{c(){e=f("p"),a=_("You need to change to "),n=f("code"),l=_("--value"),o=_(" CSS variable using JS. Value must be a number between 0 and 99."),r=R(),Q(t.$$.fragment),s=R(),Q(h.$$.fragment),L=R(),Q(D.$$.fragment),P=R(),Q(E.$$.fragment),V=R(),Q(I.$$.fragment),M=R(),Q(N.$$.fragment),A=R(),Q(b.$$.fragment),T=R(),Q(y.$$.fragment)},l(c){e=i(c,"P",{});var m=v(e);a=w(m,"You need to change to "),n=i(m,"CODE",{});var C=v(n);l=w(C,"--value"),C.forEach(p),o=w(m," CSS variable using JS. Value must be a number between 0 and 99."),m.forEach(p),r=k(c),F(t.$$.fragment,c),s=k(c),F(h.$$.fragment,c),L=k(c),F(D.$$.fragment,c),P=k(c),F(E.$$.fragment,c),V=k(c),F(I.$$.fragment,c),M=k(c),F(N.$$.fragment,c),A=k(c),F(b.$$.fragment,c),T=k(c),F(y.$$.fragment,c)},m(c,m){g(c,e,m),u(e,a),u(e,n),u(n,l),u(e,o),g(c,r,m),G(t,c,m),g(c,s,m),G(h,c,m),g(c,L,m),G(D,c,m),g(c,P,m),G(E,c,m),g(c,V,m),G(I,c,m),g(c,M,m),G(N,c,m),g(c,A,m),G(b,c,m),g(c,T,m),G(y,c,m),$=!0},p(c,m){const C={};m&19&&(C.$$scope={dirty:m,ctx:c}),h.$set(C);const H={};m&19&&(H.$$scope={dirty:m,ctx:c}),D.$set(H);const j={};m&19&&(j.$$scope={dirty:m,ctx:c}),E.$set(j);const K={};m&19&&(K.$$scope={dirty:m,ctx:c}),I.$set(K);const q={};m&19&&(q.$$scope={dirty:m,ctx:c}),N.$set(q);const O={};m&19&&(O.$$scope={dirty:m,ctx:c}),b.$set(O);const te={};m&19&&(te.$$scope={dirty:m,ctx:c}),y.$set(te)},i(c){$||(U(t.$$.fragment,c),U(h.$$.fragment,c),U(D.$$.fragment,c),U(E.$$.fragment,c),U(I.$$.fragment,c),U(N.$$.fragment,c),U(b.$$.fragment,c),U(y.$$.fragment,c),$=!0)},o(c){W(t.$$.fragment,c),W(h.$$.fragment,c),W(D.$$.fragment,c),W(E.$$.fragment,c),W(I.$$.fragment,c),W(N.$$.fragment,c),W(b.$$.fragment,c),W(y.$$.fragment,c),$=!1},d(c){c&&p(e),c&&p(r),X(t,c),c&&p(s),X(h,c),c&&p(L),X(D,c),c&&p(P),X(E,c),c&&p(V),X(I,c),c&&p(M),X(N,c),c&&p(A),X(b,c),c&&p(T),X(y,c)}}}function Me(d){let e,a;const n=[d[2],ne];let l={$$slots:{default:[Le]},$$scope:{ctx:d}};for(let o=0;o<n.length;o+=1)l=ee(l,n[o]);return e=new de({props:l}),{c(){Q(e.$$.fragment)},l(o){F(e.$$.fragment,o)},m(o,r){G(e,o,r),a=!0},p(o,[r]){const t=r&4?ce(n,[r&4&&se(o[2]),r&0&&se(ne)]):{};r&19&&(t.$$scope={dirty:r,ctx:o}),e.$set(t)},i(o){a||(U(e.$$.fragment,o),a=!0)},o(o){W(e.$$.fragment,o),a=!1},d(o){X(e,o)}}}const ne={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers.",published:!0};function Te(d,e,a){let n;ue(d,fe,r=>a(1,n=r));let l=59;function o(){l>0?(a(0,l--,l),setTimeout(o,1e3)):(a(0,l=59),setTimeout(o,1e3))}return re(()=>{o()}),d.$$set=r=>{a(2,e=ee(ee({},e),ae(r)))},e=ae(e),[l,n,e]}class Qe extends le{constructor(e){super();oe(this,e,Te,Me,pe,{})}}export{Qe as default,ne as metadata};
