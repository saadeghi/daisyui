import{S as Pe,i as Re,s as Ve,C as xe,w as z,x as q,y as O,z as Ue,A as Ae,q as S,o as W,B as Y,K as ye,ag as De,k as B,e as $,H as ue,t as w,m as P,c as m,a as u,I as pe,d as r,h as x,b as p,g as N,F as s,a9 as V,W as U}from"../../chunks/vendor-c5cb7521.js";import{M as je}from"../../chunks/_markdown-0fe8ecfa.js";import{p as He,C as Me,a as J,r as y}from"../../chunks/actions-d7957719.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-bda0821c.js";import"../../chunks/index-166248de.js";import"../../chunks/SEO-0749408c.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-9d18ab54.js";function ze(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown mb-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function qe(h){let e,n=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Oe(h){let e,n=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Se(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-end mb-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function We(h){let e,n=`<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ye(h){let e,n=`<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Fe(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-top mt-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function Ke(h){let e,n=`<div class="$$dropdown $$dropdown-top">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Te(h){let e,n=`<div className="$$dropdown $$dropdown-top">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ge(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-top dropdown-end mt-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function Je(h){let e,n=`<div class="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Qe(h){let e,n=`<div className="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Xe(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-left mb-16")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function Ze(h){let e,n=`<div class="$$dropdown $$dropdown-left">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function et(h){let e,n=`<div className="$$dropdown $$dropdown-left">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function tt(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-left dropdown-end mt-16")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function lt(h){let e,n=`<div class="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function at(h){let e,n=`<div className="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ot(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-right mb-16")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function st(h){let e,n=`<div class="$$dropdown $$dropdown-right">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function nt(h){let e,n=`<div className="$$dropdown $$dropdown-right">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function rt(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Click"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-right dropdown-end mt-16")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function dt(h){let e,n=`<div class="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function it(h){let e,n=`<div className="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ct(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Hover"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Hover"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-hover mb-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function ut(h){let e,n=`<div class="$$dropdown $$dropdown-hover">
  <label tabindex="0" class="$$btn m-1">Hover</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function pt(h){let e,n=`<div className="$$dropdown $$dropdown-hover">
  <label tabIndex={0} className="$$btn m-1">Hover</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function $t(h){let e,n,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),n=$("label"),i=w("Button"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);n=m(f,"LABEL",{tabindex:!0,class:!0});var L=u(n);i=x(L,"Button"),L.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var C=u(d);t=m(C,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),C.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-open mb-32")},m(b,f){N(b,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,_),s(_,v),s(v,I)},d(b){b&&r(e)}}}function mt(h){let e,n=`<div class="$$dropdown $$dropdown-open">
  <label tabindex="0" class="$$btn m-1">Button</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ft(h){let e,n=`<div className="$$dropdown $$dropdown-open">
  <label tabIndex={0} className="$$btn m-1">Button</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ht(h){let e,n,i,o,l,d,t,a,k,_,v;return{c(){e=$("div"),n=$("label"),i=w("Click"),o=B(),l=$("div"),d=$("div"),t=$("h3"),a=w("Card title!"),k=B(),_=$("p"),v=w("you can use any element as a dropdown."),this.h()},l(I){e=m(I,"DIV",{class:!0});var b=u(e);n=m(b,"LABEL",{tabindex:!0,class:!0});var f=u(n);i=x(f,"Click"),f.forEach(r),o=P(b),l=m(b,"DIV",{tabindex:!0,class:!0});var L=u(l);d=m(L,"DIV",{class:!0});var E=u(d);t=m(E,"H3",{class:!0});var C=u(t);a=x(C,"Card title!"),C.forEach(r),k=P(E),_=m(E,"P",{});var A=u(_);v=x(A,"you can use any element as a dropdown."),A.forEach(r),E.forEach(r),L.forEach(r),b.forEach(r),this.h()},h(){p(n,"tabindex","0"),p(n,"class","m-1 btn"),p(t,"class","card-title"),p(d,"class","card-body"),p(l,"tabindex","0"),p(l,"class","w-64 p-2 shadow card card-compact dropdown-content bg-primary text-primary-content"),p(e,"class","dropdown mb-32")},m(I,b){N(I,e,b),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(d,k),s(d,_),s(_,v)},d(I){I&&r(e)}}}function bt(h){let e,n=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <div tabindex="0" class="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div class="$$card-body">
      <h3 class="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function vt(h){let e,n=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <div tabIndex={0} className="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div className="$$card-body">
      <h3 className="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function _t(h){let e,n,i,o,l,d,t,a,k,_,v,I,b,f,L,E,C,A,R,D,j,H;return{c(){e=$("div"),n=$("div"),i=$("a"),o=w("daisyUI"),l=B(),d=$("div"),t=$("div"),a=$("a"),k=w("Button"),_=B(),v=$("div"),I=$("label"),b=w("Dropdown"),f=B(),L=$("ul"),E=$("li"),C=$("a"),A=w("Item 1"),R=B(),D=$("li"),j=$("a"),H=w("Item 2"),this.h()},l(F){e=m(F,"DIV",{class:!0});var M=u(e);n=m(M,"DIV",{class:!0});var oe=u(n);i=m(oe,"A",{class:!0});var Q=u(i);o=x(Q,"daisyUI"),Q.forEach(r),oe.forEach(r),l=P(M),d=m(M,"DIV",{class:!0});var se=u(d);t=m(se,"DIV",{class:!0});var K=u(t);a=m(K,"A",{class:!0});var ne=u(a);k=x(ne,"Button"),ne.forEach(r),_=P(K),v=m(K,"DIV",{class:!0});var T=u(v);I=m(T,"LABEL",{tabindex:!0,class:!0});var re=u(I);b=x(re,"Dropdown"),re.forEach(r),f=P(T),L=m(T,"UL",{tabindex:!0,class:!0});var G=u(L);E=m(G,"LI",{});var de=u(E);C=m(de,"A",{});var X=u(C);A=x(X,"Item 1"),X.forEach(r),de.forEach(r),R=P(G),D=m(G,"LI",{});var ie=u(D);j=m(ie,"A",{});var Z=u(j);H=x(Z,"Item 2"),Z.forEach(r),ie.forEach(r),G.forEach(r),T.forEach(r),K.forEach(r),se.forEach(r),M.forEach(r),this.h()},h(){p(i,"class","text-lg font-bold"),p(n,"class","flex-1 px-2 lg:flex-none"),p(a,"class","btn btn-ghost rounded-btn"),p(I,"tabindex","0"),p(I,"class","btn btn-ghost rounded-btn"),p(L,"tabindex","0"),p(L,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52 mt-4"),p(v,"class","dropdown dropdown-end"),p(t,"class","flex items-stretch"),p(d,"class","flex justify-end flex-1 px-2"),p(e,"class","navbar mb-40 bg-base-300 rounded-box w-full")},m(F,M){N(F,e,M),s(e,n),s(n,i),s(i,o),s(e,l),s(e,d),s(d,t),s(t,a),s(a,k),s(t,_),s(t,v),s(v,I),s(I,b),s(v,f),s(v,L),s(L,E),s(E,C),s(C,A),s(L,R),s(L,D),s(D,j),s(j,H)},d(F){F&&r(e)}}}function wt(h){let e,n=`<div class="$$navbar bg-base-300 rounded-box">
  <div class="flex-1 px-2 lg:flex-none">
    <a class="text-lg font-bold">daisyUI</a>
  </div> 
  <div class="flex justify-end flex-1 px-2">
    <div class="flex items-stretch">
      <a class="$$btn $$btn-ghost rounded-btn">Button</a>
      <div class="$$dropdown $$dropdown-end">
        <label tabindex="0" class="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabindex="0" class="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function xt(h){let e,n=`<div className="$$navbar bg-base-300 rounded-box">
  <div className="flex-1 px-2 lg:flex-none">
    <a className="text-lg font-bold">daisyUI</a>
  </div> 
  <div className="flex justify-end flex-1 px-2">
    <div className="flex items-stretch">
      <a className="$$btn $$btn-ghost rounded-btn">Button</a>
      <div className="$$dropdown $$dropdown-end">
        <label tabIndex={0} className="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabIndex={0} className="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Et(h){let e,n,i,o,l,d,t,a,k,_,v,I,b,f;return{c(){e=$("div"),n=w(`A normal text and a helper dropdown
  `),i=$("div"),o=$("label"),l=ue("svg"),d=ue("path"),t=B(),a=$("div"),k=$("div"),_=$("h2"),v=w("You needed more info?"),I=B(),b=$("p"),f=w("Here is a description!"),this.h()},l(L){e=m(L,"DIV",{class:!0});var E=u(e);n=x(E,`A normal text and a helper dropdown
  `),i=m(E,"DIV",{class:!0});var C=u(i);o=m(C,"LABEL",{tabindex:!0,class:!0});var A=u(o);l=pe(A,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var R=u(l);d=pe(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),R.forEach(r),A.forEach(r),t=P(C),a=m(C,"DIV",{tabindex:!0,class:!0});var D=u(a);k=m(D,"DIV",{class:!0});var j=u(k);_=m(j,"H2",{class:!0});var H=u(_);v=x(H,"You needed more info?"),H.forEach(r),I=P(j),b=m(j,"P",{});var F=u(b);f=x(F,"Here is a description!"),F.forEach(r),j.forEach(r),D.forEach(r),C.forEach(r),E.forEach(r),this.h()},h(){p(d,"stroke-linecap","round"),p(d,"stroke-linejoin","round"),p(d,"stroke-width","2"),p(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(l,"xmlns","http://www.w3.org/2000/svg"),p(l,"fill","none"),p(l,"viewBox","0 0 24 24"),p(l,"class","w-4 h-4 stroke-current"),p(o,"tabindex","0"),p(o,"class","btn btn-circle btn-ghost btn-xs text-info"),p(_,"class","card-title"),p(k,"class","card-body"),p(a,"tabindex","0"),p(a,"class","shadow card compact dropdown-content bg-base-100 rounded-box w-64"),p(i,"class","dropdown dropdown-end"),p(e,"class","mb-28 mt-6 flex gap-1 items-center")},m(L,E){N(L,e,E),s(e,n),s(e,i),s(i,o),s(o,l),s(l,d),s(i,t),s(i,a),s(a,k),s(k,_),s(_,v),s(k,I),s(k,b),s(b,f)},d(L){L&&r(e)}}}function It(h){let e,n=`A normal text and a helper dropdown
<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabindex="0" class="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div class="$$card-body">
      <h2 class="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function gt(h){let e,n=`A normal text and a helper dropdown
<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabIndex={0} className="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div className="$$card-body">
      <h2 className="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,n),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){N(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function kt(h){let e,n,i,o,l,d,t,a,k,_,v,I,b,f,L,E,C,A,R,D,j,H,F,M,oe,Q,se,K,ne,T,re,G,de,X,ie,Z,be,ee,ve,te,_e,le,we;return e=new Me({props:{data:[{type:"component",class:"dropdown",desc:"Container element"},{type:"component",class:"dropdown-content",desc:"Container for content"},{type:"modifier",class:"dropdown-end",desc:"Aligns to end"},{type:"modifier",class:"dropdown-top",desc:"Open from top"},{type:"modifier",class:"dropdown-left",desc:"Open from left"},{type:"modifier",class:"dropdown-right",desc:"Open from right"},{type:"modifier",class:"dropdown-hover",desc:"Opens on hover too"},{type:"modifier",class:"dropdown-open",desc:"Force open"}]}}),A=new J({props:{title:"Dropdown menu",$$slots:{react:[Oe],html:[qe],default:[ze]},$$scope:{ctx:h}}}),D=new J({props:{title:"Dropdown / aligns to end",$$slots:{react:[Ye],html:[We],default:[Se]},$$scope:{ctx:h}}}),H=new J({props:{title:"Dropdown top",$$slots:{react:[Te],html:[Ke],default:[Fe]},$$scope:{ctx:h}}}),M=new J({props:{title:"Dropdown top / aligns to end",$$slots:{react:[Qe],html:[Je],default:[Ge]},$$scope:{ctx:h}}}),Q=new J({props:{title:"Dropdown left",$$slots:{react:[et],html:[Ze],default:[Xe]},$$scope:{ctx:h}}}),K=new J({props:{title:"Dropdown left / aligns to end",$$slots:{react:[at],html:[lt],default:[tt]},$$scope:{ctx:h}}}),T=new J({props:{title:"Dropdown right",$$slots:{react:[nt],html:[st],default:[ot]},$$scope:{ctx:h}}}),G=new J({props:{title:"Dropdown right / aligns to end",$$slots:{react:[it],html:[dt],default:[rt]},$$scope:{ctx:h}}}),X=new J({props:{title:"Dropdown on hover",$$slots:{react:[pt],html:[ut],default:[ct]},$$scope:{ctx:h}}}),Z=new J({props:{title:"Force open",$$slots:{react:[ft],html:[mt],default:[$t]},$$scope:{ctx:h}}}),ee=new J({props:{title:"Card as dropdown",$$slots:{react:[vt],html:[bt],default:[ht]},$$scope:{ctx:h}}}),te=new J({props:{title:"Dropdown in navbar",$$slots:{react:[xt],html:[wt],default:[_t]},$$scope:{ctx:h}}}),le=new J({props:{title:"Helper dropdown",$$slots:{react:[gt],html:[It],default:[Et]},$$scope:{ctx:h}}}),{c(){z(e.$$.fragment),n=B(),i=$("div"),o=$("div"),l=ue("svg"),d=ue("path"),t=w(`
    We use a <label tabindex="0"> instead of a <button> because Safari has `),a=$("a"),k=w("a bug"),_=w(" that prevents the button from being focused."),v=B(),I=$("div"),b=$("div"),f=ue("svg"),L=ue("path"),E=w(`
    Using tabindex="0" is required so the dropdown can be focused.`),C=B(),z(A.$$.fragment),R=B(),z(D.$$.fragment),j=B(),z(H.$$.fragment),F=B(),z(M.$$.fragment),oe=B(),z(Q.$$.fragment),se=B(),z(K.$$.fragment),ne=B(),z(T.$$.fragment),re=B(),z(G.$$.fragment),de=B(),z(X.$$.fragment),ie=B(),z(Z.$$.fragment),be=B(),z(ee.$$.fragment),ve=B(),z(te.$$.fragment),_e=B(),z(le.$$.fragment),this.h()},l(c){q(e.$$.fragment,c),n=P(c),i=m(c,"DIV",{class:!0});var g=u(i);o=m(g,"DIV",{});var ae=u(o);l=pe(ae,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var $e=u(l);d=pe($e,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),$e.forEach(r),t=x(ae,`
    We use a <label tabindex="0"> instead of a <button> because Safari has `),a=m(ae,"A",{rel:!0,target:!0,href:!0});var me=u(a);k=x(me,"a bug"),me.forEach(r),_=x(ae," that prevents the button from being focused."),ae.forEach(r),g.forEach(r),v=P(c),I=m(c,"DIV",{class:!0});var fe=u(I);b=m(fe,"DIV",{});var ce=u(b);f=pe(ce,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var he=u(f);L=pe(he,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(L).forEach(r),he.forEach(r),E=x(ce,`
    Using tabindex="0" is required so the dropdown can be focused.`),ce.forEach(r),fe.forEach(r),C=P(c),q(A.$$.fragment,c),R=P(c),q(D.$$.fragment,c),j=P(c),q(H.$$.fragment,c),F=P(c),q(M.$$.fragment,c),oe=P(c),q(Q.$$.fragment,c),se=P(c),q(K.$$.fragment,c),ne=P(c),q(T.$$.fragment,c),re=P(c),q(G.$$.fragment,c),de=P(c),q(X.$$.fragment,c),ie=P(c),q(Z.$$.fragment,c),be=P(c),q(ee.$$.fragment,c),ve=P(c),q(te.$$.fragment,c),_e=P(c),q(le.$$.fragment,c),this.h()},h(){p(d,"stroke-linecap","round"),p(d,"stroke-linejoin","round"),p(d,"stroke-width","2"),p(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(l,"xmlns","http://www.w3.org/2000/svg"),p(l,"fill","none"),p(l,"viewBox","0 0 24 24"),p(l,"class","stroke-info-content flex-shrink-0 w-6 h-6"),p(a,"rel","noopener noreferrer"),p(a,"target","_blank"),p(a,"href","https://bugs.webkit.org/show_bug.cgi?id=22261"),p(i,"class","alert alert-info text-sm mb-2"),p(L,"stroke-linecap","round"),p(L,"stroke-linejoin","round"),p(L,"stroke-width","2"),p(L,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(f,"xmlns","http://www.w3.org/2000/svg"),p(f,"fill","none"),p(f,"viewBox","0 0 24 24"),p(f,"class","stroke-info-content flex-shrink-0 w-6 h-6"),p(I,"class","alert alert-info text-sm")},m(c,g){O(e,c,g),N(c,n,g),N(c,i,g),s(i,o),s(o,l),s(l,d),s(o,t),s(o,a),s(a,k),s(o,_),N(c,v,g),N(c,I,g),s(I,b),s(b,f),s(f,L),s(b,E),N(c,C,g),O(A,c,g),N(c,R,g),O(D,c,g),N(c,j,g),O(H,c,g),N(c,F,g),O(M,c,g),N(c,oe,g),O(Q,c,g),N(c,se,g),O(K,c,g),N(c,ne,g),O(T,c,g),N(c,re,g),O(G,c,g),N(c,de,g),O(X,c,g),N(c,ie,g),O(Z,c,g),N(c,be,g),O(ee,c,g),N(c,ve,g),O(te,c,g),N(c,_e,g),O(le,c,g),we=!0},p(c,g){const ae={};g&5&&(ae.$$scope={dirty:g,ctx:c}),A.$set(ae);const $e={};g&5&&($e.$$scope={dirty:g,ctx:c}),D.$set($e);const me={};g&5&&(me.$$scope={dirty:g,ctx:c}),H.$set(me);const fe={};g&5&&(fe.$$scope={dirty:g,ctx:c}),M.$set(fe);const ce={};g&5&&(ce.$$scope={dirty:g,ctx:c}),Q.$set(ce);const he={};g&5&&(he.$$scope={dirty:g,ctx:c}),K.$set(he);const Ee={};g&5&&(Ee.$$scope={dirty:g,ctx:c}),T.$set(Ee);const Ie={};g&5&&(Ie.$$scope={dirty:g,ctx:c}),G.$set(Ie);const ge={};g&5&&(ge.$$scope={dirty:g,ctx:c}),X.$set(ge);const ke={};g&5&&(ke.$$scope={dirty:g,ctx:c}),Z.$set(ke);const Le={};g&5&&(Le.$$scope={dirty:g,ctx:c}),ee.$set(Le);const Ne={};g&5&&(Ne.$$scope={dirty:g,ctx:c}),te.$set(Ne);const Ce={};g&5&&(Ce.$$scope={dirty:g,ctx:c}),le.$set(Ce)},i(c){we||(S(e.$$.fragment,c),S(A.$$.fragment,c),S(D.$$.fragment,c),S(H.$$.fragment,c),S(M.$$.fragment,c),S(Q.$$.fragment,c),S(K.$$.fragment,c),S(T.$$.fragment,c),S(G.$$.fragment,c),S(X.$$.fragment,c),S(Z.$$.fragment,c),S(ee.$$.fragment,c),S(te.$$.fragment,c),S(le.$$.fragment,c),we=!0)},o(c){W(e.$$.fragment,c),W(A.$$.fragment,c),W(D.$$.fragment,c),W(H.$$.fragment,c),W(M.$$.fragment,c),W(Q.$$.fragment,c),W(K.$$.fragment,c),W(T.$$.fragment,c),W(G.$$.fragment,c),W(X.$$.fragment,c),W(Z.$$.fragment,c),W(ee.$$.fragment,c),W(te.$$.fragment,c),W(le.$$.fragment,c),we=!1},d(c){Y(e,c),c&&r(n),c&&r(i),c&&r(v),c&&r(I),c&&r(C),Y(A,c),c&&r(R),Y(D,c),c&&r(j),Y(H,c),c&&r(F),Y(M,c),c&&r(oe),Y(Q,c),c&&r(se),Y(K,c),c&&r(ne),Y(T,c),c&&r(re),Y(G,c),c&&r(de),Y(X,c),c&&r(ie),Y(Z,c),c&&r(be),Y(ee,c),c&&r(ve),Y(te,c),c&&r(_e),Y(le,c)}}}function Lt(h){let e,n;const i=[h[1],Be];let o={$$slots:{default:[kt]},$$scope:{ctx:h}};for(let l=0;l<i.length;l+=1)o=xe(o,i[l]);return e=new je({props:o}),{c(){z(e.$$.fragment)},l(l){q(e.$$.fragment,l)},m(l,d){O(e,l,d),n=!0},p(l,[d]){const t=d&2?Ue(i,[d&2&&Ae(l[1]),d&0&&Ae(Be)]):{};d&5&&(t.$$scope={dirty:d,ctx:l}),e.$set(t)},i(l){n||(S(e.$$.fragment,l),n=!0)},o(l){W(e.$$.fragment,l),n=!1},d(l){Y(e,l)}}}const Be={title:"Dropdown",desc:"Dropdown can open a menu or any other element when the button is clicked.",published:!0};function Nt(h,e,n){let i;return ye(h,He,o=>n(0,i=o)),h.$$set=o=>{n(1,e=xe(xe({},e),De(o)))},e=De(e),[i,e]}class jt extends Pe{constructor(e){super();Re(this,e,Nt,Lt,Ve,{})}}export{jt as default,Be as metadata};
