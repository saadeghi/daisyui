import{S as Mi,i as zi,s as Oi,w as Ll,k as d,x as Vl,m as o,y as Gl,g as Ot,q as Fl,o as Nl,B as Ml,d as e,e as a,t as s,c as l,a as r,h as n,b as u,H as t,M as wr,N as to}from"../../chunks/vendor-1f04da3c.js";import{C as Ji,a as Hr}from"../../chunks/ClassTable-d5f58326.js";import"../../chunks/preload-helper-ec9aa979.js";function Wi(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=d(),g=a("th"),at=s("Name"),G=d(),k=a("th"),Q=s("Job"),Y=d(),C=a("th"),lt=s("Favorite Color"),i=d(),f=a("tbody"),m=a("tr"),L=a("th"),rt=s("1"),F=d(),S=a("td"),Z=s("Cy Ganderton"),nt=d(),O=a("td"),E=s("Quality Control Specialist"),$=d(),x=a("td"),dt=s("Blue"),ot=d(),p=a("tr"),j=a("th"),Dt=s("2"),X=d(),N=a("td"),yt=s("Hart Hagerty"),ht=d(),M=a("td"),gt=s("Desktop Support Technician"),ct=d(),P=a("td"),St=s("Purple"),it=d(),b=a("tr"),z=a("th"),vt=s("3"),Ht=d(),J=a("td"),A=s("Brice Swyre"),ft=d(),W=a("td"),st=s("Tax Accountant"),_t=d(),U=a("td"),K=s("Red"),this.h()},l(V){c=l(V,"DIV",{class:!0});var tt=r(c);v=l(tt,"TABLE",{class:!0});var et=r(v);T=l(et,"THEAD",{});var $t=r(T);h=l($t,"TR",{});var D=r(h);_=l(D,"TH",{}),r(_).forEach(e),q=o(D),g=l(D,"TH",{});var Tt=r(g);at=n(Tt,"Name"),Tt.forEach(e),G=o(D),k=l(D,"TH",{});var ut=r(k);Q=n(ut,"Job"),ut.forEach(e),Y=o(D),C=l(D,"TH",{});var Rt=r(C);lt=n(Rt,"Favorite Color"),Rt.forEach(e),D.forEach(e),$t.forEach(e),i=o(et),f=l(et,"TBODY",{});var I=r(f);m=l(I,"TR",{});var H=r(m);L=l(H,"TH",{});var Vt=r(L);rt=n(Vt,"1"),Vt.forEach(e),F=o(H),S=l(H,"TD",{});var wt=r(S);Z=n(wt,"Cy Ganderton"),wt.forEach(e),nt=o(H),O=l(H,"TD",{});var Et=r(O);E=n(Et,"Quality Control Specialist"),Et.forEach(e),$=o(H),x=l(H,"TD",{});var Gt=r(x);dt=n(Gt,"Blue"),Gt.forEach(e),H.forEach(e),ot=o(I),p=l(I,"TR",{});var w=r(p);j=l(w,"TH",{});var B=r(j);Dt=n(B,"2"),B.forEach(e),X=o(w),N=l(w,"TD",{});var kt=r(N);yt=n(kt,"Hart Hagerty"),kt.forEach(e),ht=o(w),M=l(w,"TD",{});var Ft=r(M);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),ct=o(w),P=l(w,"TD",{});var pt=r(P);St=n(pt,"Purple"),pt.forEach(e),w.forEach(e),it=o(I),b=l(I,"TR",{});var y=r(b);z=l(y,"TH",{});var Nt=r(z);vt=n(Nt,"3"),Nt.forEach(e),Ht=o(y),J=l(y,"TD",{});var Mt=r(J);A=n(Mt,"Brice Swyre"),Mt.forEach(e),ft=o(y),W=l(y,"TD",{});var mt=r(W);st=n(mt,"Tax Accountant"),mt.forEach(e),_t=o(y),U=l(y,"TD",{});var zt=r(U);K=n(zt,"Red"),zt.forEach(e),y.forEach(e),I.forEach(e),et.forEach(e),tt.forEach(e),this.h()},h(){u(v,"class","table w-full"),u(c,"class","overflow-x-auto w-full")},m(V,tt){Ot(V,c,tt),t(c,v),t(v,T),t(T,h),t(h,_),t(h,q),t(h,g),t(g,at),t(h,G),t(h,k),t(k,Q),t(h,Y),t(h,C),t(C,lt),t(v,i),t(v,f),t(f,m),t(m,L),t(L,rt),t(m,F),t(m,S),t(S,Z),t(m,nt),t(m,O),t(O,E),t(m,$),t(m,x),t(x,dt),t(f,ot),t(f,p),t(p,j),t(j,Dt),t(p,X),t(p,N),t(N,yt),t(p,ht),t(p,M),t(M,gt),t(p,ct),t(p,P),t(P,St),t(f,it),t(f,b),t(b,z),t(z,vt),t(b,Ht),t(b,J),t(J,A),t(b,ft),t(b,W),t(W,st),t(b,_t),t(b,U),t(U,K)},d(V){V&&e(c)}}}function Ki(Lt){let c,v=`<div class="overflow-x-auto">
  <table class="table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function Qi(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=d(),g=a("th"),at=s("Name"),G=d(),k=a("th"),Q=s("Job"),Y=d(),C=a("th"),lt=s("Favorite Color"),i=d(),f=a("tbody"),m=a("tr"),L=a("th"),rt=s("1"),F=d(),S=a("td"),Z=s("Cy Ganderton"),nt=d(),O=a("td"),E=s("Quality Control Specialist"),$=d(),x=a("td"),dt=s("Blue"),ot=d(),p=a("tr"),j=a("th"),Dt=s("2"),X=d(),N=a("td"),yt=s("Hart Hagerty"),ht=d(),M=a("td"),gt=s("Desktop Support Technician"),ct=d(),P=a("td"),St=s("Purple"),it=d(),b=a("tr"),z=a("th"),vt=s("3"),Ht=d(),J=a("td"),A=s("Brice Swyre"),ft=d(),W=a("td"),st=s("Tax Accountant"),_t=d(),U=a("td"),K=s("Red"),this.h()},l(V){c=l(V,"DIV",{class:!0});var tt=r(c);v=l(tt,"TABLE",{class:!0});var et=r(v);T=l(et,"THEAD",{});var $t=r(T);h=l($t,"TR",{});var D=r(h);_=l(D,"TH",{}),r(_).forEach(e),q=o(D),g=l(D,"TH",{});var Tt=r(g);at=n(Tt,"Name"),Tt.forEach(e),G=o(D),k=l(D,"TH",{});var ut=r(k);Q=n(ut,"Job"),ut.forEach(e),Y=o(D),C=l(D,"TH",{});var Rt=r(C);lt=n(Rt,"Favorite Color"),Rt.forEach(e),D.forEach(e),$t.forEach(e),i=o(et),f=l(et,"TBODY",{});var I=r(f);m=l(I,"TR",{});var H=r(m);L=l(H,"TH",{});var Vt=r(L);rt=n(Vt,"1"),Vt.forEach(e),F=o(H),S=l(H,"TD",{});var wt=r(S);Z=n(wt,"Cy Ganderton"),wt.forEach(e),nt=o(H),O=l(H,"TD",{});var Et=r(O);E=n(Et,"Quality Control Specialist"),Et.forEach(e),$=o(H),x=l(H,"TD",{});var Gt=r(x);dt=n(Gt,"Blue"),Gt.forEach(e),H.forEach(e),ot=o(I),p=l(I,"TR",{class:!0});var w=r(p);j=l(w,"TH",{});var B=r(j);Dt=n(B,"2"),B.forEach(e),X=o(w),N=l(w,"TD",{});var kt=r(N);yt=n(kt,"Hart Hagerty"),kt.forEach(e),ht=o(w),M=l(w,"TD",{});var Ft=r(M);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),ct=o(w),P=l(w,"TD",{});var pt=r(P);St=n(pt,"Purple"),pt.forEach(e),w.forEach(e),it=o(I),b=l(I,"TR",{});var y=r(b);z=l(y,"TH",{});var Nt=r(z);vt=n(Nt,"3"),Nt.forEach(e),Ht=o(y),J=l(y,"TD",{});var Mt=r(J);A=n(Mt,"Brice Swyre"),Mt.forEach(e),ft=o(y),W=l(y,"TD",{});var mt=r(W);st=n(mt,"Tax Accountant"),mt.forEach(e),_t=o(y),U=l(y,"TD",{});var zt=r(U);K=n(zt,"Red"),zt.forEach(e),y.forEach(e),I.forEach(e),et.forEach(e),tt.forEach(e),this.h()},h(){u(p,"class","active"),u(v,"class","table w-full"),u(c,"class","overflow-x-auto w-full")},m(V,tt){Ot(V,c,tt),t(c,v),t(v,T),t(T,h),t(h,_),t(h,q),t(h,g),t(g,at),t(h,G),t(h,k),t(k,Q),t(h,Y),t(h,C),t(C,lt),t(v,i),t(v,f),t(f,m),t(m,L),t(L,rt),t(m,F),t(m,S),t(S,Z),t(m,nt),t(m,O),t(O,E),t(m,$),t(m,x),t(x,dt),t(f,ot),t(f,p),t(p,j),t(j,Dt),t(p,X),t(p,N),t(N,yt),t(p,ht),t(p,M),t(M,gt),t(p,ct),t(p,P),t(P,St),t(f,it),t(f,b),t(b,z),t(z,vt),t(b,Ht),t(b,J),t(J,A),t(b,ft),t(b,W),t(W,st),t(b,_t),t(b,U),t(U,K)},d(V){V&&e(c)}}}function Ui(Lt){let c,v=`<div class="overflow-x-auto">
  <table class="table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="active">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function qi(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=d(),g=a("th"),at=s("Name"),G=d(),k=a("th"),Q=s("Job"),Y=d(),C=a("th"),lt=s("Favorite Color"),i=d(),f=a("tbody"),m=a("tr"),L=a("th"),rt=s("1"),F=d(),S=a("td"),Z=s("Cy Ganderton"),nt=d(),O=a("td"),E=s("Quality Control Specialist"),$=d(),x=a("td"),dt=s("Blue"),ot=d(),p=a("tr"),j=a("th"),Dt=s("2"),X=d(),N=a("td"),yt=s("Hart Hagerty"),ht=d(),M=a("td"),gt=s("Desktop Support Technician"),ct=d(),P=a("td"),St=s("Purple"),it=d(),b=a("tr"),z=a("th"),vt=s("3"),Ht=d(),J=a("td"),A=s("Brice Swyre"),ft=d(),W=a("td"),st=s("Tax Accountant"),_t=d(),U=a("td"),K=s("Red"),this.h()},l(V){c=l(V,"DIV",{class:!0});var tt=r(c);v=l(tt,"TABLE",{class:!0});var et=r(v);T=l(et,"THEAD",{});var $t=r(T);h=l($t,"TR",{});var D=r(h);_=l(D,"TH",{}),r(_).forEach(e),q=o(D),g=l(D,"TH",{});var Tt=r(g);at=n(Tt,"Name"),Tt.forEach(e),G=o(D),k=l(D,"TH",{});var ut=r(k);Q=n(ut,"Job"),ut.forEach(e),Y=o(D),C=l(D,"TH",{});var Rt=r(C);lt=n(Rt,"Favorite Color"),Rt.forEach(e),D.forEach(e),$t.forEach(e),i=o(et),f=l(et,"TBODY",{});var I=r(f);m=l(I,"TR",{});var H=r(m);L=l(H,"TH",{});var Vt=r(L);rt=n(Vt,"1"),Vt.forEach(e),F=o(H),S=l(H,"TD",{});var wt=r(S);Z=n(wt,"Cy Ganderton"),wt.forEach(e),nt=o(H),O=l(H,"TD",{});var Et=r(O);E=n(Et,"Quality Control Specialist"),Et.forEach(e),$=o(H),x=l(H,"TD",{});var Gt=r(x);dt=n(Gt,"Blue"),Gt.forEach(e),H.forEach(e),ot=o(I),p=l(I,"TR",{class:!0});var w=r(p);j=l(w,"TH",{});var B=r(j);Dt=n(B,"2"),B.forEach(e),X=o(w),N=l(w,"TD",{});var kt=r(N);yt=n(kt,"Hart Hagerty"),kt.forEach(e),ht=o(w),M=l(w,"TD",{});var Ft=r(M);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),ct=o(w),P=l(w,"TD",{});var pt=r(P);St=n(pt,"Purple"),pt.forEach(e),w.forEach(e),it=o(I),b=l(I,"TR",{});var y=r(b);z=l(y,"TH",{});var Nt=r(z);vt=n(Nt,"3"),Nt.forEach(e),Ht=o(y),J=l(y,"TD",{});var Mt=r(J);A=n(Mt,"Brice Swyre"),Mt.forEach(e),ft=o(y),W=l(y,"TD",{});var mt=r(W);st=n(mt,"Tax Accountant"),mt.forEach(e),_t=o(y),U=l(y,"TD",{});var zt=r(U);K=n(zt,"Red"),zt.forEach(e),y.forEach(e),I.forEach(e),et.forEach(e),tt.forEach(e),this.h()},h(){u(p,"class","hover"),u(v,"class","table w-full"),u(c,"class","overflow-x-auto w-full")},m(V,tt){Ot(V,c,tt),t(c,v),t(v,T),t(T,h),t(h,_),t(h,q),t(h,g),t(g,at),t(h,G),t(h,k),t(k,Q),t(h,Y),t(h,C),t(C,lt),t(v,i),t(v,f),t(f,m),t(m,L),t(L,rt),t(m,F),t(m,S),t(S,Z),t(m,nt),t(m,O),t(O,E),t(m,$),t(m,x),t(x,dt),t(f,ot),t(f,p),t(p,j),t(j,Dt),t(p,X),t(p,N),t(N,yt),t(p,ht),t(p,M),t(M,gt),t(p,ct),t(p,P),t(P,St),t(f,it),t(f,b),t(b,z),t(z,vt),t(b,Ht),t(b,J),t(J,A),t(b,ft),t(b,W),t(W,st),t(b,_t),t(b,U),t(U,K)},d(V){V&&e(c)}}}function Yi(Lt){let c,v=`<div class="overflow-x-auto">
  <table class="table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function Zi(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=d(),g=a("th"),at=s("Name"),G=d(),k=a("th"),Q=s("Job"),Y=d(),C=a("th"),lt=s("Favorite Color"),i=d(),f=a("tbody"),m=a("tr"),L=a("th"),rt=s("1"),F=d(),S=a("td"),Z=s("Cy Ganderton"),nt=d(),O=a("td"),E=s("Quality Control Specialist"),$=d(),x=a("td"),dt=s("Blue"),ot=d(),p=a("tr"),j=a("th"),Dt=s("2"),X=d(),N=a("td"),yt=s("Hart Hagerty"),ht=d(),M=a("td"),gt=s("Desktop Support Technician"),ct=d(),P=a("td"),St=s("Purple"),it=d(),b=a("tr"),z=a("th"),vt=s("3"),Ht=d(),J=a("td"),A=s("Brice Swyre"),ft=d(),W=a("td"),st=s("Tax Accountant"),_t=d(),U=a("td"),K=s("Red"),this.h()},l(V){c=l(V,"DIV",{class:!0});var tt=r(c);v=l(tt,"TABLE",{class:!0});var et=r(v);T=l(et,"THEAD",{});var $t=r(T);h=l($t,"TR",{});var D=r(h);_=l(D,"TH",{}),r(_).forEach(e),q=o(D),g=l(D,"TH",{});var Tt=r(g);at=n(Tt,"Name"),Tt.forEach(e),G=o(D),k=l(D,"TH",{});var ut=r(k);Q=n(ut,"Job"),ut.forEach(e),Y=o(D),C=l(D,"TH",{});var Rt=r(C);lt=n(Rt,"Favorite Color"),Rt.forEach(e),D.forEach(e),$t.forEach(e),i=o(et),f=l(et,"TBODY",{});var I=r(f);m=l(I,"TR",{});var H=r(m);L=l(H,"TH",{});var Vt=r(L);rt=n(Vt,"1"),Vt.forEach(e),F=o(H),S=l(H,"TD",{});var wt=r(S);Z=n(wt,"Cy Ganderton"),wt.forEach(e),nt=o(H),O=l(H,"TD",{});var Et=r(O);E=n(Et,"Quality Control Specialist"),Et.forEach(e),$=o(H),x=l(H,"TD",{});var Gt=r(x);dt=n(Gt,"Blue"),Gt.forEach(e),H.forEach(e),ot=o(I),p=l(I,"TR",{});var w=r(p);j=l(w,"TH",{});var B=r(j);Dt=n(B,"2"),B.forEach(e),X=o(w),N=l(w,"TD",{});var kt=r(N);yt=n(kt,"Hart Hagerty"),kt.forEach(e),ht=o(w),M=l(w,"TD",{});var Ft=r(M);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),ct=o(w),P=l(w,"TD",{});var pt=r(P);St=n(pt,"Purple"),pt.forEach(e),w.forEach(e),it=o(I),b=l(I,"TR",{});var y=r(b);z=l(y,"TH",{});var Nt=r(z);vt=n(Nt,"3"),Nt.forEach(e),Ht=o(y),J=l(y,"TD",{});var Mt=r(J);A=n(Mt,"Brice Swyre"),Mt.forEach(e),ft=o(y),W=l(y,"TD",{});var mt=r(W);st=n(mt,"Tax Accountant"),mt.forEach(e),_t=o(y),U=l(y,"TD",{});var zt=r(U);K=n(zt,"Red"),zt.forEach(e),y.forEach(e),I.forEach(e),et.forEach(e),tt.forEach(e),this.h()},h(){u(v,"class","table table-zebra w-full"),u(c,"class","overflow-x-auto w-full")},m(V,tt){Ot(V,c,tt),t(c,v),t(v,T),t(T,h),t(h,_),t(h,q),t(h,g),t(g,at),t(h,G),t(h,k),t(k,Q),t(h,Y),t(h,C),t(C,lt),t(v,i),t(v,f),t(f,m),t(m,L),t(L,rt),t(m,F),t(m,S),t(S,Z),t(m,nt),t(m,O),t(O,E),t(m,$),t(m,x),t(x,dt),t(f,ot),t(f,p),t(p,j),t(j,Dt),t(p,X),t(p,N),t(N,yt),t(p,ht),t(p,M),t(M,gt),t(p,ct),t(p,P),t(P,St),t(f,it),t(f,b),t(b,z),t(z,vt),t(b,Ht),t(b,J),t(J,A),t(b,ft),t(b,W),t(W,st),t(b,_t),t(b,U),t(U,K)},d(V){V&&e(c)}}}function ji(Lt){let c,v=`<div class="overflow-x-auto">
  <table class="table table-zebra w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function Xi(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K,V,tt,et,$t,D,Tt,ut,Rt,I,H,Vt,wt,Et,Gt,w,B,kt,Ft,pt,y,Nt,Mt,mt,zt,cl,ze,il,vl,Oe,Ze,fl,va,Jt,fa,Je,_a,_l,Ct,oe,je,Xe,Be,zl,Tl,Pe,ta,ul,Ta,ea,El,ua,Le,pl,Ea,ml,aa,pa,bl,ma,xt,ba,Da,la,ya,Dl,Wt,We,ga,Sa,Ha,wa,Ve,Ge,ra,da,Na,yl,Ke,Fe,gl,Sl,bt,Ca,Hl,Ne,Ra,wl,Cl,Me,Rl,$l,Qe,kl,xl,Ue,oa,Il,$a,ka,Kt,sa,Al,xa,It,Ia,Aa,Pl,Pa,Ba,Bl,La,Ma;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=a("label"),g=a("input"),at=d(),G=a("th"),k=s("Name"),Q=d(),Y=a("th"),C=s("Job"),lt=d(),i=a("th"),f=s("Favorite Color"),m=d(),L=a("th"),rt=d(),F=a("tbody"),S=a("tr"),Z=a("th"),nt=a("label"),O=a("input"),E=d(),$=a("td"),x=a("div"),dt=a("div"),ot=a("div"),p=a("img"),Dt=d(),X=a("div"),N=a("div"),yt=s("Hart Hagerty"),ht=d(),M=a("div"),gt=s("United States"),ct=d(),P=a("td"),St=s(`Zemlak, Daniel and Leannon
          `),it=a("br"),b=d(),z=a("span"),vt=s("Desktop Support Technician"),Ht=d(),J=a("td"),A=s("Purple"),ft=d(),W=a("th"),st=a("button"),_t=s("details"),U=d(),K=a("tr"),V=a("th"),tt=a("label"),et=a("input"),$t=d(),D=a("td"),Tt=a("div"),ut=a("div"),Rt=a("div"),I=a("img"),Vt=d(),wt=a("div"),Et=a("div"),Gt=s("Brice Swyre"),w=d(),B=a("div"),kt=s("China"),Ft=d(),pt=a("td"),y=s(`Carroll Group
          `),Nt=a("br"),Mt=d(),mt=a("span"),zt=s("Tax Accountant"),cl=d(),ze=a("td"),il=s("Red"),vl=d(),Oe=a("th"),Ze=a("button"),fl=s("details"),va=d(),Jt=a("tr"),fa=a("th"),Je=a("label"),_a=a("input"),_l=d(),Ct=a("td"),oe=a("div"),je=a("div"),Xe=a("div"),Be=a("img"),Tl=d(),Pe=a("div"),ta=a("div"),ul=s("Marjy Ferencz"),Ta=d(),ea=a("div"),El=s("Russia"),ua=d(),Le=a("td"),pl=s(`Rowe-Schoen
          `),Ea=a("br"),ml=d(),aa=a("span"),pa=s("Office Assistant I"),bl=d(),ma=a("td"),xt=s("Crimson"),ba=d(),Da=a("th"),la=a("button"),ya=s("details"),Dl=d(),Wt=a("tr"),We=a("th"),ga=a("label"),Sa=a("input"),Ha=d(),wa=a("td"),Ve=a("div"),Ge=a("div"),ra=a("div"),da=a("img"),yl=d(),Ke=a("div"),Fe=a("div"),gl=s("Yancy Tear"),Sl=d(),bt=a("div"),Ca=s("Brazil"),Hl=d(),Ne=a("td"),Ra=s(`Wyman-Ledner
          `),wl=a("br"),Cl=d(),Me=a("span"),Rl=s("Community Outreach Specialist"),$l=d(),Qe=a("td"),kl=s("Indigo"),xl=d(),Ue=a("th"),oa=a("button"),Il=s("details"),$a=d(),ka=a("tfoot"),Kt=a("tr"),sa=a("th"),Al=d(),xa=a("th"),It=s("Name"),Ia=d(),Aa=a("th"),Pl=s("Job"),Pa=d(),Ba=a("th"),Bl=s("Favorite Color"),La=d(),Ma=a("th"),this.h()},l(Va){c=l(Va,"DIV",{class:!0});var na=r(c);v=l(na,"TABLE",{class:!0});var ha=r(v);T=l(ha,"THEAD",{});var Ol=r(T);h=l(Ol,"TR",{});var re=r(h);_=l(re,"TH",{});var Jl=r(_);q=l(Jl,"LABEL",{});var Wl=r(q);g=l(Wl,"INPUT",{type:!0,class:!0}),Wl.forEach(e),Jl.forEach(e),at=o(re),G=l(re,"TH",{});var za=r(G);k=n(za,"Name"),za.forEach(e),Q=o(re),Y=l(re,"TH",{});var Kl=r(Y);C=n(Kl,"Job"),Kl.forEach(e),lt=o(re),i=l(re,"TH",{});var Ql=r(i);f=n(Ql,"Favorite Color"),Ql.forEach(e),m=o(re),L=l(re,"TH",{}),r(L).forEach(e),re.forEach(e),Ol.forEach(e),rt=o(ha),F=l(ha,"TBODY",{});var se=r(F);S=l(se,"TR",{});var ne=r(S);Z=l(ne,"TH",{});var Ul=r(Z);nt=l(Ul,"LABEL",{});var At=r(nt);O=l(At,"INPUT",{type:!0,class:!0}),At.forEach(e),Ul.forEach(e),E=o(ne),$=l(ne,"TD",{});var Oa=r($);x=l(Oa,"DIV",{class:!0});var Ja=r(x);dt=l(Ja,"DIV",{class:!0});var ql=r(dt);ot=l(ql,"DIV",{class:!0});var Wa=r(ot);p=l(Wa,"IMG",{src:!0,alt:!0}),Wa.forEach(e),ql.forEach(e),Dt=o(Ja),X=l(Ja,"DIV",{});var Ka=r(X);N=l(Ka,"DIV",{class:!0});var Yl=r(N);yt=n(Yl,"Hart Hagerty"),Yl.forEach(e),ht=o(Ka),M=l(Ka,"DIV",{class:!0});var Qa=r(M);gt=n(Qa,"United States"),Qa.forEach(e),Ka.forEach(e),Ja.forEach(e),Oa.forEach(e),ct=o(ne),P=l(ne,"TD",{});var Ga=r(P);St=n(Ga,`Zemlak, Daniel and Leannon
          `),it=l(Ga,"BR",{}),b=o(Ga),z=l(Ga,"SPAN",{class:!0});var Zl=r(z);vt=n(Zl,"Desktop Support Technician"),Zl.forEach(e),Ga.forEach(e),Ht=o(ne),J=l(ne,"TD",{});var Ua=r(J);A=n(Ua,"Purple"),Ua.forEach(e),ft=o(ne),W=l(ne,"TH",{});var jl=r(W);st=l(jl,"BUTTON",{class:!0});var Xl=r(st);_t=n(Xl,"details"),Xl.forEach(e),jl.forEach(e),ne.forEach(e),U=o(se),K=l(se,"TR",{});var de=r(K);V=l(de,"TH",{});var tr=r(V);tt=l(tr,"LABEL",{});var er=r(tt);et=l(er,"INPUT",{type:!0,class:!0}),er.forEach(e),tr.forEach(e),$t=o(de),D=l(de,"TD",{});var qa=r(D);Tt=l(qa,"DIV",{class:!0});var Ya=r(Tt);ut=l(Ya,"DIV",{class:!0});var ar=r(ut);Rt=l(ar,"DIV",{class:!0});var Za=r(Rt);I=l(Za,"IMG",{src:!0,alt:!0}),Za.forEach(e),ar.forEach(e),Vt=o(Ya),wt=l(Ya,"DIV",{});var ja=r(wt);Et=l(ja,"DIV",{class:!0});var lr=r(Et);Gt=n(lr,"Brice Swyre"),lr.forEach(e),w=o(ja),B=l(ja,"DIV",{class:!0});var Pt=r(B);kt=n(Pt,"China"),Pt.forEach(e),ja.forEach(e),Ya.forEach(e),qa.forEach(e),Ft=o(de),pt=l(de,"TD",{});var qe=r(pt);y=n(qe,`Carroll Group
          `),Nt=l(qe,"BR",{}),Mt=o(qe),mt=l(qe,"SPAN",{class:!0});var rr=r(mt);zt=n(rr,"Tax Accountant"),rr.forEach(e),qe.forEach(e),cl=o(de),ze=l(de,"TD",{});var dr=r(ze);il=n(dr,"Red"),dr.forEach(e),vl=o(de),Oe=l(de,"TH",{});var Xa=r(Oe);Ze=l(Xa,"BUTTON",{class:!0});var or=r(Ze);fl=n(or,"details"),or.forEach(e),Xa.forEach(e),de.forEach(e),va=o(se),Jt=l(se,"TR",{});var he=r(Jt);fa=l(he,"TH",{});var tl=r(fa);Je=l(tl,"LABEL",{});var sr=r(Je);_a=l(sr,"INPUT",{type:!0,class:!0}),sr.forEach(e),tl.forEach(e),_l=o(he),Ct=l(he,"TD",{});var nr=r(Ct);oe=l(nr,"DIV",{class:!0});var ca=r(oe);je=l(ca,"DIV",{class:!0});var hr=r(je);Xe=l(hr,"DIV",{class:!0});var cr=r(Xe);Be=l(cr,"IMG",{src:!0,alt:!0}),cr.forEach(e),hr.forEach(e),Tl=o(ca),Pe=l(ca,"DIV",{});var ia=r(Pe);ta=l(ia,"DIV",{class:!0});var ir=r(ta);ul=n(ir,"Marjy Ferencz"),ir.forEach(e),Ta=o(ia),ea=l(ia,"DIV",{class:!0});var vr=r(ea);El=n(vr,"Russia"),vr.forEach(e),ia.forEach(e),ca.forEach(e),nr.forEach(e),ua=o(he),Le=l(he,"TD",{});var Ye=r(Le);pl=n(Ye,`Rowe-Schoen
          `),Ea=l(Ye,"BR",{}),ml=o(Ye),aa=l(Ye,"SPAN",{class:!0});var fr=r(aa);pa=n(fr,"Office Assistant I"),fr.forEach(e),Ye.forEach(e),bl=o(he),ma=l(he,"TD",{});var _r=r(ma);xt=n(_r,"Crimson"),_r.forEach(e),ba=o(he),Da=l(he,"TH",{});var el=r(Da);la=l(el,"BUTTON",{class:!0});var Tr=r(la);ya=n(Tr,"details"),Tr.forEach(e),el.forEach(e),he.forEach(e),Dl=o(se),Wt=l(se,"TR",{});var ce=r(Wt);We=l(ce,"TH",{});var Bt=r(We);ga=l(Bt,"LABEL",{});var al=r(ga);Sa=l(al,"INPUT",{type:!0,class:!0}),al.forEach(e),Bt.forEach(e),Ha=o(ce),wa=l(ce,"TD",{});var ur=r(wa);Ve=l(ur,"DIV",{class:!0});var ll=r(Ve);Ge=l(ll,"DIV",{class:!0});var rl=r(Ge);ra=l(rl,"DIV",{class:!0});var Er=r(ra);da=l(Er,"IMG",{src:!0,alt:!0}),Er.forEach(e),rl.forEach(e),yl=o(ll),Ke=l(ll,"DIV",{});var dl=r(Ke);Fe=l(dl,"DIV",{class:!0});var ol=r(Fe);gl=n(ol,"Yancy Tear"),ol.forEach(e),Sl=o(dl),bt=l(dl,"DIV",{class:!0});var pr=r(bt);Ca=n(pr,"Brazil"),pr.forEach(e),dl.forEach(e),ll.forEach(e),ur.forEach(e),Hl=o(ce),Ne=l(ce,"TD",{});var Fa=r(Ne);Ra=n(Fa,`Wyman-Ledner
          `),wl=l(Fa,"BR",{}),Cl=o(Fa),Me=l(Fa,"SPAN",{class:!0});var sl=r(Me);Rl=n(sl,"Community Outreach Specialist"),sl.forEach(e),Fa.forEach(e),$l=o(ce),Qe=l(ce,"TD",{});var mr=r(Qe);kl=n(mr,"Indigo"),mr.forEach(e),xl=o(ce),Ue=l(ce,"TH",{});var br=r(Ue);oa=l(br,"BUTTON",{class:!0});var nl=r(oa);Il=n(nl,"details"),nl.forEach(e),br.forEach(e),ce.forEach(e),se.forEach(e),$a=o(ha),ka=l(ha,"TFOOT",{});var Dr=r(ka);Kt=l(Dr,"TR",{});var ie=r(Kt);sa=l(ie,"TH",{}),r(sa).forEach(e),Al=o(ie),xa=l(ie,"TH",{});var hl=r(xa);It=n(hl,"Name"),hl.forEach(e),Ia=o(ie),Aa=l(ie,"TH",{});var yr=r(Aa);Pl=n(yr,"Job"),yr.forEach(e),Pa=o(ie),Ba=l(ie,"TH",{});var gr=r(Ba);Bl=n(gr,"Favorite Color"),gr.forEach(e),La=o(ie),Ma=l(ie,"TH",{}),r(Ma).forEach(e),ie.forEach(e),Dr.forEach(e),ha.forEach(e),na.forEach(e),this.h()},h(){u(g,"type","checkbox"),u(g,"class","checkbox"),u(O,"type","checkbox"),u(O,"class","checkbox"),to(p.src,j="/tailwind-css-component-profile-2@56w.png")||u(p,"src",j),u(p,"alt","Avatar Tailwind CSS Component"),u(ot,"class","w-12 h-12 mask mask-squircle"),u(dt,"class","avatar"),u(N,"class","font-bold"),u(M,"class","text-sm opacity-50"),u(x,"class","flex items-center space-x-3"),u(z,"class","badge badge-ghost badge-sm"),u(st,"class","btn btn-ghost btn-xs"),u(et,"type","checkbox"),u(et,"class","checkbox"),to(I.src,H="/tailwind-css-component-profile-3@56w.png")||u(I,"src",H),u(I,"alt","Avatar Tailwind CSS Component"),u(Rt,"class","w-12 h-12 mask mask-squircle"),u(ut,"class","avatar"),u(Et,"class","font-bold"),u(B,"class","text-sm opacity-50"),u(Tt,"class","flex items-center space-x-3"),u(mt,"class","badge badge-ghost badge-sm"),u(Ze,"class","btn btn-ghost btn-xs"),u(_a,"type","checkbox"),u(_a,"class","checkbox"),to(Be.src,zl="/tailwind-css-component-profile-4@56w.png")||u(Be,"src",zl),u(Be,"alt","Avatar Tailwind CSS Component"),u(Xe,"class","w-12 h-12 mask mask-squircle"),u(je,"class","avatar"),u(ta,"class","font-bold"),u(ea,"class","text-sm opacity-50"),u(oe,"class","flex items-center space-x-3"),u(aa,"class","badge badge-ghost badge-sm"),u(la,"class","btn btn-ghost btn-xs"),u(Sa,"type","checkbox"),u(Sa,"class","checkbox"),to(da.src,Na="/tailwind-css-component-profile-5@56w.png")||u(da,"src",Na),u(da,"alt","Avatar Tailwind CSS Component"),u(ra,"class","w-12 h-12 mask mask-squircle"),u(Ge,"class","avatar"),u(Fe,"class","font-bold"),u(bt,"class","text-sm opacity-50"),u(Ve,"class","flex items-center space-x-3"),u(Me,"class","badge badge-ghost badge-sm"),u(oa,"class","btn btn-ghost btn-xs"),u(v,"class","table w-full"),u(c,"class","overflow-x-auto w-full")},m(Va,na){Ot(Va,c,na),t(c,v),t(v,T),t(T,h),t(h,_),t(_,q),t(q,g),t(h,at),t(h,G),t(G,k),t(h,Q),t(h,Y),t(Y,C),t(h,lt),t(h,i),t(i,f),t(h,m),t(h,L),t(v,rt),t(v,F),t(F,S),t(S,Z),t(Z,nt),t(nt,O),t(S,E),t(S,$),t($,x),t(x,dt),t(dt,ot),t(ot,p),t(x,Dt),t(x,X),t(X,N),t(N,yt),t(X,ht),t(X,M),t(M,gt),t(S,ct),t(S,P),t(P,St),t(P,it),t(P,b),t(P,z),t(z,vt),t(S,Ht),t(S,J),t(J,A),t(S,ft),t(S,W),t(W,st),t(st,_t),t(F,U),t(F,K),t(K,V),t(V,tt),t(tt,et),t(K,$t),t(K,D),t(D,Tt),t(Tt,ut),t(ut,Rt),t(Rt,I),t(Tt,Vt),t(Tt,wt),t(wt,Et),t(Et,Gt),t(wt,w),t(wt,B),t(B,kt),t(K,Ft),t(K,pt),t(pt,y),t(pt,Nt),t(pt,Mt),t(pt,mt),t(mt,zt),t(K,cl),t(K,ze),t(ze,il),t(K,vl),t(K,Oe),t(Oe,Ze),t(Ze,fl),t(F,va),t(F,Jt),t(Jt,fa),t(fa,Je),t(Je,_a),t(Jt,_l),t(Jt,Ct),t(Ct,oe),t(oe,je),t(je,Xe),t(Xe,Be),t(oe,Tl),t(oe,Pe),t(Pe,ta),t(ta,ul),t(Pe,Ta),t(Pe,ea),t(ea,El),t(Jt,ua),t(Jt,Le),t(Le,pl),t(Le,Ea),t(Le,ml),t(Le,aa),t(aa,pa),t(Jt,bl),t(Jt,ma),t(ma,xt),t(Jt,ba),t(Jt,Da),t(Da,la),t(la,ya),t(F,Dl),t(F,Wt),t(Wt,We),t(We,ga),t(ga,Sa),t(Wt,Ha),t(Wt,wa),t(wa,Ve),t(Ve,Ge),t(Ge,ra),t(ra,da),t(Ve,yl),t(Ve,Ke),t(Ke,Fe),t(Fe,gl),t(Ke,Sl),t(Ke,bt),t(bt,Ca),t(Wt,Hl),t(Wt,Ne),t(Ne,Ra),t(Ne,wl),t(Ne,Cl),t(Ne,Me),t(Me,Rl),t(Wt,$l),t(Wt,Qe),t(Qe,kl),t(Wt,xl),t(Wt,Ue),t(Ue,oa),t(oa,Il),t(v,$a),t(v,ka),t(ka,Kt),t(Kt,sa),t(Kt,Al),t(Kt,xa),t(xa,It),t(Kt,Ia),t(Kt,Aa),t(Aa,Pl),t(Kt,Pa),t(Kt,Ba),t(Ba,Bl),t(Kt,La),t(Kt,Ma)},d(Va){Va&&e(c)}}}function t1(Lt){let c,v=`<div class="overflow-x-auto w-full">
  <table class="table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" class="checkbox">
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="avatar">
              <div class="w-12 h-12 mask mask-squircle">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Hart Hagerty</div>
              <div class="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br>
          <span class="badge badge-ghost badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button class="btn btn-ghost btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="avatar">
              <div class="w-12 h-12 mask mask-squircle">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Brice Swyre</div>
              <div class="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br>
          <span class="badge badge-ghost badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button class="btn btn-ghost btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="avatar">
              <div class="w-12 h-12 mask mask-squircle">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Marjy Ferencz</div>
              <div class="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br>
          <span class="badge badge-ghost badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button class="btn btn-ghost btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="checkbox">
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="avatar">
              <div class="w-12 h-12 mask mask-squircle">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component">
              </div>
            </div>
            <div>
              <div class="font-bold">Yancy Tear</div>
              <div class="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br>
          <span class="badge badge-ghost badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button class="btn btn-ghost btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function e1(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt,i,f,m,L,rt,F,S,Z,nt,O,E,$,x,dt,ot,p,j,Dt,X,N,yt,ht,M,gt,ct,P,St,it,b,z,vt,Ht,J,A,ft,W,st,_t,U,K,V,tt,et,$t,D,Tt,ut,Rt,I,H,Vt,wt,Et,Gt,w,B,kt,Ft,pt,y,Nt,Mt,mt,zt,cl,ze,il,vl,Oe,Ze,fl,va,Jt,fa,Je,_a,_l,Ct,oe,je,Xe,Be,zl,Tl,Pe,ta,ul,Ta,ea,El,ua,Le,pl,Ea,ml,aa,pa,bl,ma,xt,ba,Da,la,ya,Dl,Wt,We,ga,Sa,Ha,wa,Ve,Ge,ra,da,Na,yl,Ke,Fe,gl,Sl,bt,Ca,Hl,Ne,Ra,wl,Cl,Me,Rl,$l,Qe,kl,xl,Ue,oa,Il,$a,ka,Kt,sa,Al,xa,It,Ia,Aa,Pl,Pa,Ba,Bl,La,Ma,Va,na,ha,Ol,re,Jl,Wl,za,Kl,Ql,se,ne,Ul,At,Oa,Ja,ql,Wa,Ka,Yl,Qa,Ga,Zl,Ua,jl,Xl,de,tr,er,qa,Ya,ar,Za,ja,lr,Pt,qe,rr,dr,Xa,or,he,tl,sr,nr,ca,hr,cr,ia,ir,vr,Ye,fr,_r,el,Tr,ce,Bt,al,ur,ll,rl,Er,dl,ol,pr,Fa,sl,mr,br,nl,Dr,ie,hl,yr,gr,Cr,eo,ao,Qt,Rr,lo,ro,$r,oo,so,kr,no,ho,xr,co,io,Ir,vo,fo,Ar,_o,To,Pr,uo,Eo,Ut,Br,po,mo,Lr,bo,Do,Vr,yo,go,Gr,So,Ho,Fr,wo,Co,Nr,Ro,$o,Mr,ko,xo,qt,zr,Io,Ao,Or,Po,Bo,Jr,Lo,Vo,Wr,Go,Fo,Kr,No,Mo,Qr,zo,Oo,Ur,Jo,Wo,Yt,qr,Ko,Qo,Yr,Uo,qo,Zr,Yo,Zo,jr,jo,Xo,Xr,ts,es,td,as,ls,ed,rs,ds,Zt,ad,os,ss,ld,ns,hs,rd,cs,is,dd,vs,fs,od,_s,Ts,sd,us,Es,nd,ps,ms,jt,hd,bs,Ds,cd,ys,gs,id,Ss,Hs,vd,ws,Cs,fd,Rs,$s,_d,ks,xs,Td,Is,As,Xt,ud,Ps,Bs,Ed,Ls,Vs,pd,Gs,Fs,md,Ns,Ms,bd,zs,Os,Dd,Js,Ws,yd,Ks,Qs,te,gd,Us,qs,Sd,Ys,Zs,Hd,js,Xs,wd,tn,en,Cd,an,ln,Rd,rn,dn,$d,on,sn,ee,kd,nn,hn,xd,cn,vn,Id,fn,_n,Ad,Tn,un,Pd,En,pn,Bd,mn,bn,Ld,Dn,yn,ae,Vd,gn,Sn,Gd,Hn,wn,Fd,Cn,Rn,Nd,$n,kn,Md,xn,In,zd,An,Pn,Od,Bn,Ln,Jd,le,jd,Vn,Wd,Gn,Fn,Kd,Nn,Mn,Qd,zn,On,Ud,Jn,Wn,qd,Kn,Qn,Yd,Un;return{c(){c=a("div"),v=a("table"),T=a("thead"),h=a("tr"),_=a("th"),q=d(),g=a("th"),at=s("Name"),G=d(),k=a("th"),Q=s("Job"),Y=d(),C=a("th"),lt=s("company"),i=d(),f=a("th"),m=s("location"),L=d(),rt=a("th"),F=s("Last Login"),S=d(),Z=a("th"),nt=s("Favorite Color"),O=d(),E=a("tbody"),$=a("tr"),x=a("th"),dt=s("1"),ot=d(),p=a("td"),j=s("Cy Ganderton"),Dt=d(),X=a("td"),N=s("Quality Control Specialist"),yt=d(),ht=a("td"),M=s("Littel, Schaden and Vandervort"),gt=d(),ct=a("td"),P=s("Canada"),St=d(),it=a("td"),b=s("12/16/2020"),z=d(),vt=a("td"),Ht=s("Blue"),J=d(),A=a("tr"),ft=a("th"),W=s("2"),st=d(),_t=a("td"),U=s("Hart Hagerty"),K=d(),V=a("td"),tt=s("Desktop Support Technician"),et=d(),$t=a("td"),D=s("Zemlak, Daniel and Leannon"),Tt=d(),ut=a("td"),Rt=s("United States"),I=d(),H=a("td"),Vt=s("12/5/2020"),wt=d(),Et=a("td"),Gt=s("Purple"),w=d(),B=a("tr"),kt=a("th"),Ft=s("3"),pt=d(),y=a("td"),Nt=s("Brice Swyre"),Mt=d(),mt=a("td"),zt=s("Tax Accountant"),cl=d(),ze=a("td"),il=s("Carroll Group"),vl=d(),Oe=a("td"),Ze=s("China"),fl=d(),va=a("td"),Jt=s("8/15/2020"),fa=d(),Je=a("td"),_a=s("Red"),_l=d(),Ct=a("tr"),oe=a("th"),je=s("4"),Xe=d(),Be=a("td"),zl=s("Marjy Ferencz"),Tl=d(),Pe=a("td"),ta=s("Office Assistant I"),ul=d(),Ta=a("td"),ea=s("Rowe-Schoen"),El=d(),ua=a("td"),Le=s("Russia"),pl=d(),Ea=a("td"),ml=s("3/25/2021"),aa=d(),pa=a("td"),bl=s("Crimson"),ma=d(),xt=a("tr"),ba=a("th"),Da=s("5"),la=d(),ya=a("td"),Dl=s("Yancy Tear"),Wt=d(),We=a("td"),ga=s("Community Outreach Specialist"),Sa=d(),Ha=a("td"),wa=s("Wyman-Ledner"),Ve=d(),Ge=a("td"),ra=s("Brazil"),da=d(),Na=a("td"),yl=s("5/22/2020"),Ke=d(),Fe=a("td"),gl=s("Indigo"),Sl=d(),bt=a("tr"),Ca=a("th"),Hl=s("6"),Ne=d(),Ra=a("td"),wl=s("Irma Vasilik"),Cl=d(),Me=a("td"),Rl=s("Editor"),$l=d(),Qe=a("td"),kl=s("Wiza, Bins and Emard"),xl=d(),Ue=a("td"),oa=s("Venezuela"),Il=d(),$a=a("td"),ka=s("12/8/2020"),Kt=d(),sa=a("td"),Al=s("Purple"),xa=d(),It=a("tr"),Ia=a("th"),Aa=s("7"),Pl=d(),Pa=a("td"),Ba=s("Meghann Durtnal"),Bl=d(),La=a("td"),Ma=s("Staff Accountant IV"),Va=d(),na=a("td"),ha=s("Schuster-Schimmel"),Ol=d(),re=a("td"),Jl=s("Philippines"),Wl=d(),za=a("td"),Kl=s("2/17/2021"),Ql=d(),se=a("td"),ne=s("Yellow"),Ul=d(),At=a("tr"),Oa=a("th"),Ja=s("8"),ql=d(),Wa=a("td"),Ka=s("Sammy Seston"),Yl=d(),Qa=a("td"),Ga=s("Accountant I"),Zl=d(),Ua=a("td"),jl=s("O'Hara, Welch and Keebler"),Xl=d(),de=a("td"),tr=s("Indonesia"),er=d(),qa=a("td"),Ya=s("5/23/2020"),ar=d(),Za=a("td"),ja=s("Crimson"),lr=d(),Pt=a("tr"),qe=a("th"),rr=s("9"),dr=d(),Xa=a("td"),or=s("Lesya Tinham"),he=d(),tl=a("td"),sr=s("Safety Technician IV"),nr=d(),ca=a("td"),hr=s("Turner-Kuhlman"),cr=d(),ia=a("td"),ir=s("Philippines"),vr=d(),Ye=a("td"),fr=s("2/21/2021"),_r=d(),el=a("td"),Tr=s("Maroon"),ce=d(),Bt=a("tr"),al=a("th"),ur=s("10"),ll=d(),rl=a("td"),Er=s("Zaneta Tewkesbury"),dl=d(),ol=a("td"),pr=s("VP Marketing"),Fa=d(),sl=a("td"),mr=s("Sauer LLC"),br=d(),nl=a("td"),Dr=s("Chad"),ie=d(),hl=a("td"),yr=s("6/23/2020"),gr=d(),Cr=a("td"),eo=s("Green"),ao=d(),Qt=a("tr"),Rr=a("th"),lo=s("11"),ro=d(),$r=a("td"),oo=s("Andy Tipple"),so=d(),kr=a("td"),no=s("Librarian"),ho=d(),xr=a("td"),co=s("Hilpert Group"),io=d(),Ir=a("td"),vo=s("Poland"),fo=d(),Ar=a("td"),_o=s("7/9/2020"),To=d(),Pr=a("td"),uo=s("Indigo"),Eo=d(),Ut=a("tr"),Br=a("th"),po=s("12"),mo=d(),Lr=a("td"),bo=s("Sophi Biles"),Do=d(),Vr=a("td"),yo=s("Recruiting Manager"),go=d(),Gr=a("td"),So=s("Gutmann Inc"),Ho=d(),Fr=a("td"),wo=s("Indonesia"),Co=d(),Nr=a("td"),Ro=s("2/12/2021"),$o=d(),Mr=a("td"),ko=s("Maroon"),xo=d(),qt=a("tr"),zr=a("th"),Io=s("13"),Ao=d(),Or=a("td"),Po=s("Florida Garces"),Bo=d(),Jr=a("td"),Lo=s("Web Developer IV"),Vo=d(),Wr=a("td"),Go=s("Gaylord, Pacocha and Baumbach"),Fo=d(),Kr=a("td"),No=s("Poland"),Mo=d(),Qr=a("td"),zo=s("5/31/2020"),Oo=d(),Ur=a("td"),Jo=s("Purple"),Wo=d(),Yt=a("tr"),qr=a("th"),Ko=s("14"),Qo=d(),Yr=a("td"),Uo=s("Maribeth Popping"),qo=d(),Zr=a("td"),Yo=s("Analyst Programmer"),Zo=d(),jr=a("td"),jo=s("Deckow-Pouros"),Xo=d(),Xr=a("td"),ts=s("Portugal"),es=d(),td=a("td"),as=s("4/27/2021"),ls=d(),ed=a("td"),rs=s("Aquamarine"),ds=d(),Zt=a("tr"),ad=a("th"),os=s("15"),ss=d(),ld=a("td"),ns=s("Moritz Dryburgh"),hs=d(),rd=a("td"),cs=s("Dental Hygienist"),is=d(),dd=a("td"),vs=s("Schiller, Cole and Hackett"),fs=d(),od=a("td"),_s=s("Sri Lanka"),Ts=d(),sd=a("td"),us=s("8/8/2020"),Es=d(),nd=a("td"),ps=s("Crimson"),ms=d(),jt=a("tr"),hd=a("th"),bs=s("16"),Ds=d(),cd=a("td"),ys=s("Reid Semiras"),gs=d(),id=a("td"),Ss=s("Teacher"),Hs=d(),vd=a("td"),ws=s("Sporer, Sipes and Rogahn"),Cs=d(),fd=a("td"),Rs=s("Poland"),$s=d(),_d=a("td"),ks=s("7/30/2020"),xs=d(),Td=a("td"),Is=s("Green"),As=d(),Xt=a("tr"),ud=a("th"),Ps=s("17"),Bs=d(),Ed=a("td"),Ls=s("Alec Lethby"),Vs=d(),pd=a("td"),Gs=s("Teacher"),Fs=d(),md=a("td"),Ns=s("Reichel, Glover and Hamill"),Ms=d(),bd=a("td"),zs=s("China"),Os=d(),Dd=a("td"),Js=s("2/28/2021"),Ws=d(),yd=a("td"),Ks=s("Khaki"),Qs=d(),te=a("tr"),gd=a("th"),Us=s("18"),qs=d(),Sd=a("td"),Ys=s("Aland Wilber"),Zs=d(),Hd=a("td"),js=s("Quality Control Specialist"),Xs=d(),wd=a("td"),tn=s("Kshlerin, Rogahn and Swaniawski"),en=d(),Cd=a("td"),an=s("Czech Republic"),ln=d(),Rd=a("td"),rn=s("9/29/2020"),dn=d(),$d=a("td"),on=s("Purple"),sn=d(),ee=a("tr"),kd=a("th"),nn=s("19"),hn=d(),xd=a("td"),cn=s("Teddie Duerden"),vn=d(),Id=a("td"),fn=s("Staff Accountant III"),_n=d(),Ad=a("td"),Tn=s("Pouros, Ullrich and Windler"),un=d(),Pd=a("td"),En=s("France"),pn=d(),Bd=a("td"),mn=s("10/27/2020"),bn=d(),Ld=a("td"),Dn=s("Aquamarine"),yn=d(),ae=a("tr"),Vd=a("th"),gn=s("20"),Sn=d(),Gd=a("td"),Hn=s("Lorelei Blackstone"),wn=d(),Fd=a("td"),Cn=s("Data Coordinator"),Rn=d(),Nd=a("td"),$n=s("Witting, Kutch and Greenfelder"),kn=d(),Md=a("td"),xn=s("Kazakhstan"),In=d(),zd=a("td"),An=s("6/3/2020"),Pn=d(),Od=a("td"),Bn=s("Red"),Ln=d(),Jd=a("tfoot"),le=a("tr"),jd=a("th"),Vn=d(),Wd=a("th"),Gn=s("Name"),Fn=d(),Kd=a("th"),Nn=s("Job"),Mn=d(),Qd=a("th"),zn=s("company"),On=d(),Ud=a("th"),Jn=s("location"),Wn=d(),qd=a("th"),Kn=s("Last Login"),Qn=d(),Yd=a("th"),Un=s("Favorite Color"),this.h()},l(Zd){c=l(Zd,"DIV",{class:!0});var Xd=r(c);v=l(Xd,"TABLE",{class:!0});var Sr=r(v);T=l(Sr,"THEAD",{});var qn=r(T);h=l(qn,"TR",{});var ve=r(h);_=l(ve,"TH",{}),r(_).forEach(e),q=o(ve),g=l(ve,"TH",{});var Yn=r(g);at=n(Yn,"Name"),Yn.forEach(e),G=o(ve),k=l(ve,"TH",{});var Zn=r(k);Q=n(Zn,"Job"),Zn.forEach(e),Y=o(ve),C=l(ve,"TH",{});var jn=r(C);lt=n(jn,"company"),jn.forEach(e),i=o(ve),f=l(ve,"TH",{});var Xn=r(f);m=n(Xn,"location"),Xn.forEach(e),L=o(ve),rt=l(ve,"TH",{});var th=r(rt);F=n(th,"Last Login"),th.forEach(e),S=o(ve),Z=l(ve,"TH",{});var eh=r(Z);nt=n(eh,"Favorite Color"),eh.forEach(e),ve.forEach(e),qn.forEach(e),O=o(Sr),E=l(Sr,"TBODY",{});var R=r(E);$=l(R,"TR",{});var fe=r($);x=l(fe,"TH",{});var ah=r(x);dt=n(ah,"1"),ah.forEach(e),ot=o(fe),p=l(fe,"TD",{});var lh=r(p);j=n(lh,"Cy Ganderton"),lh.forEach(e),Dt=o(fe),X=l(fe,"TD",{});var rh=r(X);N=n(rh,"Quality Control Specialist"),rh.forEach(e),yt=o(fe),ht=l(fe,"TD",{});var dh=r(ht);M=n(dh,"Littel, Schaden and Vandervort"),dh.forEach(e),gt=o(fe),ct=l(fe,"TD",{});var oh=r(ct);P=n(oh,"Canada"),oh.forEach(e),St=o(fe),it=l(fe,"TD",{});var sh=r(it);b=n(sh,"12/16/2020"),sh.forEach(e),z=o(fe),vt=l(fe,"TD",{});var nh=r(vt);Ht=n(nh,"Blue"),nh.forEach(e),fe.forEach(e),J=o(R),A=l(R,"TR",{});var _e=r(A);ft=l(_e,"TH",{});var hh=r(ft);W=n(hh,"2"),hh.forEach(e),st=o(_e),_t=l(_e,"TD",{});var ch=r(_t);U=n(ch,"Hart Hagerty"),ch.forEach(e),K=o(_e),V=l(_e,"TD",{});var ih=r(V);tt=n(ih,"Desktop Support Technician"),ih.forEach(e),et=o(_e),$t=l(_e,"TD",{});var vh=r($t);D=n(vh,"Zemlak, Daniel and Leannon"),vh.forEach(e),Tt=o(_e),ut=l(_e,"TD",{});var fh=r(ut);Rt=n(fh,"United States"),fh.forEach(e),I=o(_e),H=l(_e,"TD",{});var _h=r(H);Vt=n(_h,"12/5/2020"),_h.forEach(e),wt=o(_e),Et=l(_e,"TD",{});var Th=r(Et);Gt=n(Th,"Purple"),Th.forEach(e),_e.forEach(e),w=o(R),B=l(R,"TR",{});var Te=r(B);kt=l(Te,"TH",{});var uh=r(kt);Ft=n(uh,"3"),uh.forEach(e),pt=o(Te),y=l(Te,"TD",{});var Eh=r(y);Nt=n(Eh,"Brice Swyre"),Eh.forEach(e),Mt=o(Te),mt=l(Te,"TD",{});var ph=r(mt);zt=n(ph,"Tax Accountant"),ph.forEach(e),cl=o(Te),ze=l(Te,"TD",{});var mh=r(ze);il=n(mh,"Carroll Group"),mh.forEach(e),vl=o(Te),Oe=l(Te,"TD",{});var bh=r(Oe);Ze=n(bh,"China"),bh.forEach(e),fl=o(Te),va=l(Te,"TD",{});var Dh=r(va);Jt=n(Dh,"8/15/2020"),Dh.forEach(e),fa=o(Te),Je=l(Te,"TD",{});var yh=r(Je);_a=n(yh,"Red"),yh.forEach(e),Te.forEach(e),_l=o(R),Ct=l(R,"TR",{});var ue=r(Ct);oe=l(ue,"TH",{});var gh=r(oe);je=n(gh,"4"),gh.forEach(e),Xe=o(ue),Be=l(ue,"TD",{});var Sh=r(Be);zl=n(Sh,"Marjy Ferencz"),Sh.forEach(e),Tl=o(ue),Pe=l(ue,"TD",{});var Hh=r(Pe);ta=n(Hh,"Office Assistant I"),Hh.forEach(e),ul=o(ue),Ta=l(ue,"TD",{});var wh=r(Ta);ea=n(wh,"Rowe-Schoen"),wh.forEach(e),El=o(ue),ua=l(ue,"TD",{});var Ch=r(ua);Le=n(Ch,"Russia"),Ch.forEach(e),pl=o(ue),Ea=l(ue,"TD",{});var Rh=r(Ea);ml=n(Rh,"3/25/2021"),Rh.forEach(e),aa=o(ue),pa=l(ue,"TD",{});var $h=r(pa);bl=n($h,"Crimson"),$h.forEach(e),ue.forEach(e),ma=o(R),xt=l(R,"TR",{});var Ee=r(xt);ba=l(Ee,"TH",{});var kh=r(ba);Da=n(kh,"5"),kh.forEach(e),la=o(Ee),ya=l(Ee,"TD",{});var xh=r(ya);Dl=n(xh,"Yancy Tear"),xh.forEach(e),Wt=o(Ee),We=l(Ee,"TD",{});var Ih=r(We);ga=n(Ih,"Community Outreach Specialist"),Ih.forEach(e),Sa=o(Ee),Ha=l(Ee,"TD",{});var Ah=r(Ha);wa=n(Ah,"Wyman-Ledner"),Ah.forEach(e),Ve=o(Ee),Ge=l(Ee,"TD",{});var Ph=r(Ge);ra=n(Ph,"Brazil"),Ph.forEach(e),da=o(Ee),Na=l(Ee,"TD",{});var Bh=r(Na);yl=n(Bh,"5/22/2020"),Bh.forEach(e),Ke=o(Ee),Fe=l(Ee,"TD",{});var Lh=r(Fe);gl=n(Lh,"Indigo"),Lh.forEach(e),Ee.forEach(e),Sl=o(R),bt=l(R,"TR",{});var pe=r(bt);Ca=l(pe,"TH",{});var Vh=r(Ca);Hl=n(Vh,"6"),Vh.forEach(e),Ne=o(pe),Ra=l(pe,"TD",{});var Gh=r(Ra);wl=n(Gh,"Irma Vasilik"),Gh.forEach(e),Cl=o(pe),Me=l(pe,"TD",{});var Fh=r(Me);Rl=n(Fh,"Editor"),Fh.forEach(e),$l=o(pe),Qe=l(pe,"TD",{});var Nh=r(Qe);kl=n(Nh,"Wiza, Bins and Emard"),Nh.forEach(e),xl=o(pe),Ue=l(pe,"TD",{});var Mh=r(Ue);oa=n(Mh,"Venezuela"),Mh.forEach(e),Il=o(pe),$a=l(pe,"TD",{});var zh=r($a);ka=n(zh,"12/8/2020"),zh.forEach(e),Kt=o(pe),sa=l(pe,"TD",{});var Oh=r(sa);Al=n(Oh,"Purple"),Oh.forEach(e),pe.forEach(e),xa=o(R),It=l(R,"TR",{});var me=r(It);Ia=l(me,"TH",{});var Jh=r(Ia);Aa=n(Jh,"7"),Jh.forEach(e),Pl=o(me),Pa=l(me,"TD",{});var Wh=r(Pa);Ba=n(Wh,"Meghann Durtnal"),Wh.forEach(e),Bl=o(me),La=l(me,"TD",{});var Kh=r(La);Ma=n(Kh,"Staff Accountant IV"),Kh.forEach(e),Va=o(me),na=l(me,"TD",{});var Qh=r(na);ha=n(Qh,"Schuster-Schimmel"),Qh.forEach(e),Ol=o(me),re=l(me,"TD",{});var Uh=r(re);Jl=n(Uh,"Philippines"),Uh.forEach(e),Wl=o(me),za=l(me,"TD",{});var qh=r(za);Kl=n(qh,"2/17/2021"),qh.forEach(e),Ql=o(me),se=l(me,"TD",{});var Yh=r(se);ne=n(Yh,"Yellow"),Yh.forEach(e),me.forEach(e),Ul=o(R),At=l(R,"TR",{});var be=r(At);Oa=l(be,"TH",{});var Zh=r(Oa);Ja=n(Zh,"8"),Zh.forEach(e),ql=o(be),Wa=l(be,"TD",{});var jh=r(Wa);Ka=n(jh,"Sammy Seston"),jh.forEach(e),Yl=o(be),Qa=l(be,"TD",{});var Xh=r(Qa);Ga=n(Xh,"Accountant I"),Xh.forEach(e),Zl=o(be),Ua=l(be,"TD",{});var tc=r(Ua);jl=n(tc,"O'Hara, Welch and Keebler"),tc.forEach(e),Xl=o(be),de=l(be,"TD",{});var ec=r(de);tr=n(ec,"Indonesia"),ec.forEach(e),er=o(be),qa=l(be,"TD",{});var ac=r(qa);Ya=n(ac,"5/23/2020"),ac.forEach(e),ar=o(be),Za=l(be,"TD",{});var lc=r(Za);ja=n(lc,"Crimson"),lc.forEach(e),be.forEach(e),lr=o(R),Pt=l(R,"TR",{});var De=r(Pt);qe=l(De,"TH",{});var rc=r(qe);rr=n(rc,"9"),rc.forEach(e),dr=o(De),Xa=l(De,"TD",{});var dc=r(Xa);or=n(dc,"Lesya Tinham"),dc.forEach(e),he=o(De),tl=l(De,"TD",{});var oc=r(tl);sr=n(oc,"Safety Technician IV"),oc.forEach(e),nr=o(De),ca=l(De,"TD",{});var sc=r(ca);hr=n(sc,"Turner-Kuhlman"),sc.forEach(e),cr=o(De),ia=l(De,"TD",{});var nc=r(ia);ir=n(nc,"Philippines"),nc.forEach(e),vr=o(De),Ye=l(De,"TD",{});var hc=r(Ye);fr=n(hc,"2/21/2021"),hc.forEach(e),_r=o(De),el=l(De,"TD",{});var cc=r(el);Tr=n(cc,"Maroon"),cc.forEach(e),De.forEach(e),ce=o(R),Bt=l(R,"TR",{});var ye=r(Bt);al=l(ye,"TH",{});var ic=r(al);ur=n(ic,"10"),ic.forEach(e),ll=o(ye),rl=l(ye,"TD",{});var vc=r(rl);Er=n(vc,"Zaneta Tewkesbury"),vc.forEach(e),dl=o(ye),ol=l(ye,"TD",{});var fc=r(ol);pr=n(fc,"VP Marketing"),fc.forEach(e),Fa=o(ye),sl=l(ye,"TD",{});var _c=r(sl);mr=n(_c,"Sauer LLC"),_c.forEach(e),br=o(ye),nl=l(ye,"TD",{});var Tc=r(nl);Dr=n(Tc,"Chad"),Tc.forEach(e),ie=o(ye),hl=l(ye,"TD",{});var uc=r(hl);yr=n(uc,"6/23/2020"),uc.forEach(e),gr=o(ye),Cr=l(ye,"TD",{});var Ec=r(Cr);eo=n(Ec,"Green"),Ec.forEach(e),ye.forEach(e),ao=o(R),Qt=l(R,"TR",{});var ge=r(Qt);Rr=l(ge,"TH",{});var pc=r(Rr);lo=n(pc,"11"),pc.forEach(e),ro=o(ge),$r=l(ge,"TD",{});var mc=r($r);oo=n(mc,"Andy Tipple"),mc.forEach(e),so=o(ge),kr=l(ge,"TD",{});var bc=r(kr);no=n(bc,"Librarian"),bc.forEach(e),ho=o(ge),xr=l(ge,"TD",{});var Dc=r(xr);co=n(Dc,"Hilpert Group"),Dc.forEach(e),io=o(ge),Ir=l(ge,"TD",{});var yc=r(Ir);vo=n(yc,"Poland"),yc.forEach(e),fo=o(ge),Ar=l(ge,"TD",{});var gc=r(Ar);_o=n(gc,"7/9/2020"),gc.forEach(e),To=o(ge),Pr=l(ge,"TD",{});var Sc=r(Pr);uo=n(Sc,"Indigo"),Sc.forEach(e),ge.forEach(e),Eo=o(R),Ut=l(R,"TR",{});var Se=r(Ut);Br=l(Se,"TH",{});var Hc=r(Br);po=n(Hc,"12"),Hc.forEach(e),mo=o(Se),Lr=l(Se,"TD",{});var wc=r(Lr);bo=n(wc,"Sophi Biles"),wc.forEach(e),Do=o(Se),Vr=l(Se,"TD",{});var Cc=r(Vr);yo=n(Cc,"Recruiting Manager"),Cc.forEach(e),go=o(Se),Gr=l(Se,"TD",{});var Rc=r(Gr);So=n(Rc,"Gutmann Inc"),Rc.forEach(e),Ho=o(Se),Fr=l(Se,"TD",{});var $c=r(Fr);wo=n($c,"Indonesia"),$c.forEach(e),Co=o(Se),Nr=l(Se,"TD",{});var kc=r(Nr);Ro=n(kc,"2/12/2021"),kc.forEach(e),$o=o(Se),Mr=l(Se,"TD",{});var xc=r(Mr);ko=n(xc,"Maroon"),xc.forEach(e),Se.forEach(e),xo=o(R),qt=l(R,"TR",{});var He=r(qt);zr=l(He,"TH",{});var Ic=r(zr);Io=n(Ic,"13"),Ic.forEach(e),Ao=o(He),Or=l(He,"TD",{});var Ac=r(Or);Po=n(Ac,"Florida Garces"),Ac.forEach(e),Bo=o(He),Jr=l(He,"TD",{});var Pc=r(Jr);Lo=n(Pc,"Web Developer IV"),Pc.forEach(e),Vo=o(He),Wr=l(He,"TD",{});var Bc=r(Wr);Go=n(Bc,"Gaylord, Pacocha and Baumbach"),Bc.forEach(e),Fo=o(He),Kr=l(He,"TD",{});var Lc=r(Kr);No=n(Lc,"Poland"),Lc.forEach(e),Mo=o(He),Qr=l(He,"TD",{});var Vc=r(Qr);zo=n(Vc,"5/31/2020"),Vc.forEach(e),Oo=o(He),Ur=l(He,"TD",{});var Gc=r(Ur);Jo=n(Gc,"Purple"),Gc.forEach(e),He.forEach(e),Wo=o(R),Yt=l(R,"TR",{});var we=r(Yt);qr=l(we,"TH",{});var Fc=r(qr);Ko=n(Fc,"14"),Fc.forEach(e),Qo=o(we),Yr=l(we,"TD",{});var Nc=r(Yr);Uo=n(Nc,"Maribeth Popping"),Nc.forEach(e),qo=o(we),Zr=l(we,"TD",{});var Mc=r(Zr);Yo=n(Mc,"Analyst Programmer"),Mc.forEach(e),Zo=o(we),jr=l(we,"TD",{});var zc=r(jr);jo=n(zc,"Deckow-Pouros"),zc.forEach(e),Xo=o(we),Xr=l(we,"TD",{});var Oc=r(Xr);ts=n(Oc,"Portugal"),Oc.forEach(e),es=o(we),td=l(we,"TD",{});var Jc=r(td);as=n(Jc,"4/27/2021"),Jc.forEach(e),ls=o(we),ed=l(we,"TD",{});var Wc=r(ed);rs=n(Wc,"Aquamarine"),Wc.forEach(e),we.forEach(e),ds=o(R),Zt=l(R,"TR",{});var Ce=r(Zt);ad=l(Ce,"TH",{});var Kc=r(ad);os=n(Kc,"15"),Kc.forEach(e),ss=o(Ce),ld=l(Ce,"TD",{});var Qc=r(ld);ns=n(Qc,"Moritz Dryburgh"),Qc.forEach(e),hs=o(Ce),rd=l(Ce,"TD",{});var Uc=r(rd);cs=n(Uc,"Dental Hygienist"),Uc.forEach(e),is=o(Ce),dd=l(Ce,"TD",{});var qc=r(dd);vs=n(qc,"Schiller, Cole and Hackett"),qc.forEach(e),fs=o(Ce),od=l(Ce,"TD",{});var Yc=r(od);_s=n(Yc,"Sri Lanka"),Yc.forEach(e),Ts=o(Ce),sd=l(Ce,"TD",{});var Zc=r(sd);us=n(Zc,"8/8/2020"),Zc.forEach(e),Es=o(Ce),nd=l(Ce,"TD",{});var jc=r(nd);ps=n(jc,"Crimson"),jc.forEach(e),Ce.forEach(e),ms=o(R),jt=l(R,"TR",{});var Re=r(jt);hd=l(Re,"TH",{});var Xc=r(hd);bs=n(Xc,"16"),Xc.forEach(e),Ds=o(Re),cd=l(Re,"TD",{});var ti=r(cd);ys=n(ti,"Reid Semiras"),ti.forEach(e),gs=o(Re),id=l(Re,"TD",{});var ei=r(id);Ss=n(ei,"Teacher"),ei.forEach(e),Hs=o(Re),vd=l(Re,"TD",{});var ai=r(vd);ws=n(ai,"Sporer, Sipes and Rogahn"),ai.forEach(e),Cs=o(Re),fd=l(Re,"TD",{});var li=r(fd);Rs=n(li,"Poland"),li.forEach(e),$s=o(Re),_d=l(Re,"TD",{});var ri=r(_d);ks=n(ri,"7/30/2020"),ri.forEach(e),xs=o(Re),Td=l(Re,"TD",{});var di=r(Td);Is=n(di,"Green"),di.forEach(e),Re.forEach(e),As=o(R),Xt=l(R,"TR",{});var $e=r(Xt);ud=l($e,"TH",{});var oi=r(ud);Ps=n(oi,"17"),oi.forEach(e),Bs=o($e),Ed=l($e,"TD",{});var si=r(Ed);Ls=n(si,"Alec Lethby"),si.forEach(e),Vs=o($e),pd=l($e,"TD",{});var ni=r(pd);Gs=n(ni,"Teacher"),ni.forEach(e),Fs=o($e),md=l($e,"TD",{});var hi=r(md);Ns=n(hi,"Reichel, Glover and Hamill"),hi.forEach(e),Ms=o($e),bd=l($e,"TD",{});var ci=r(bd);zs=n(ci,"China"),ci.forEach(e),Os=o($e),Dd=l($e,"TD",{});var ii=r(Dd);Js=n(ii,"2/28/2021"),ii.forEach(e),Ws=o($e),yd=l($e,"TD",{});var vi=r(yd);Ks=n(vi,"Khaki"),vi.forEach(e),$e.forEach(e),Qs=o(R),te=l(R,"TR",{});var ke=r(te);gd=l(ke,"TH",{});var fi=r(gd);Us=n(fi,"18"),fi.forEach(e),qs=o(ke),Sd=l(ke,"TD",{});var _i=r(Sd);Ys=n(_i,"Aland Wilber"),_i.forEach(e),Zs=o(ke),Hd=l(ke,"TD",{});var Ti=r(Hd);js=n(Ti,"Quality Control Specialist"),Ti.forEach(e),Xs=o(ke),wd=l(ke,"TD",{});var ui=r(wd);tn=n(ui,"Kshlerin, Rogahn and Swaniawski"),ui.forEach(e),en=o(ke),Cd=l(ke,"TD",{});var Ei=r(Cd);an=n(Ei,"Czech Republic"),Ei.forEach(e),ln=o(ke),Rd=l(ke,"TD",{});var pi=r(Rd);rn=n(pi,"9/29/2020"),pi.forEach(e),dn=o(ke),$d=l(ke,"TD",{});var mi=r($d);on=n(mi,"Purple"),mi.forEach(e),ke.forEach(e),sn=o(R),ee=l(R,"TR",{});var xe=r(ee);kd=l(xe,"TH",{});var bi=r(kd);nn=n(bi,"19"),bi.forEach(e),hn=o(xe),xd=l(xe,"TD",{});var Di=r(xd);cn=n(Di,"Teddie Duerden"),Di.forEach(e),vn=o(xe),Id=l(xe,"TD",{});var yi=r(Id);fn=n(yi,"Staff Accountant III"),yi.forEach(e),_n=o(xe),Ad=l(xe,"TD",{});var gi=r(Ad);Tn=n(gi,"Pouros, Ullrich and Windler"),gi.forEach(e),un=o(xe),Pd=l(xe,"TD",{});var Si=r(Pd);En=n(Si,"France"),Si.forEach(e),pn=o(xe),Bd=l(xe,"TD",{});var Hi=r(Bd);mn=n(Hi,"10/27/2020"),Hi.forEach(e),bn=o(xe),Ld=l(xe,"TD",{});var wi=r(Ld);Dn=n(wi,"Aquamarine"),wi.forEach(e),xe.forEach(e),yn=o(R),ae=l(R,"TR",{});var Ie=r(ae);Vd=l(Ie,"TH",{});var Ci=r(Vd);gn=n(Ci,"20"),Ci.forEach(e),Sn=o(Ie),Gd=l(Ie,"TD",{});var Ri=r(Gd);Hn=n(Ri,"Lorelei Blackstone"),Ri.forEach(e),wn=o(Ie),Fd=l(Ie,"TD",{});var $i=r(Fd);Cn=n($i,"Data Coordinator"),$i.forEach(e),Rn=o(Ie),Nd=l(Ie,"TD",{});var ki=r(Nd);$n=n(ki,"Witting, Kutch and Greenfelder"),ki.forEach(e),kn=o(Ie),Md=l(Ie,"TD",{});var xi=r(Md);xn=n(xi,"Kazakhstan"),xi.forEach(e),In=o(Ie),zd=l(Ie,"TD",{});var Ii=r(zd);An=n(Ii,"6/3/2020"),Ii.forEach(e),Pn=o(Ie),Od=l(Ie,"TD",{});var Ai=r(Od);Bn=n(Ai,"Red"),Ai.forEach(e),Ie.forEach(e),R.forEach(e),Ln=o(Sr),Jd=l(Sr,"TFOOT",{});var Pi=r(Jd);le=l(Pi,"TR",{});var Ae=r(le);jd=l(Ae,"TH",{}),r(jd).forEach(e),Vn=o(Ae),Wd=l(Ae,"TH",{});var Bi=r(Wd);Gn=n(Bi,"Name"),Bi.forEach(e),Fn=o(Ae),Kd=l(Ae,"TH",{});var Li=r(Kd);Nn=n(Li,"Job"),Li.forEach(e),Mn=o(Ae),Qd=l(Ae,"TH",{});var Vi=r(Qd);zn=n(Vi,"company"),Vi.forEach(e),On=o(Ae),Ud=l(Ae,"TH",{});var Gi=r(Ud);Jn=n(Gi,"location"),Gi.forEach(e),Wn=o(Ae),qd=l(Ae,"TH",{});var Fi=r(qd);Kn=n(Fi,"Last Login"),Fi.forEach(e),Qn=o(Ae),Yd=l(Ae,"TH",{});var Ni=r(Yd);Un=n(Ni,"Favorite Color"),Ni.forEach(e),Ae.forEach(e),Pi.forEach(e),Sr.forEach(e),Xd.forEach(e),this.h()},h(){u(v,"class","table table-compact w-full"),u(c,"class","overflow-x-auto")},m(Zd,Xd){Ot(Zd,c,Xd),t(c,v),t(v,T),t(T,h),t(h,_),t(h,q),t(h,g),t(g,at),t(h,G),t(h,k),t(k,Q),t(h,Y),t(h,C),t(C,lt),t(h,i),t(h,f),t(f,m),t(h,L),t(h,rt),t(rt,F),t(h,S),t(h,Z),t(Z,nt),t(v,O),t(v,E),t(E,$),t($,x),t(x,dt),t($,ot),t($,p),t(p,j),t($,Dt),t($,X),t(X,N),t($,yt),t($,ht),t(ht,M),t($,gt),t($,ct),t(ct,P),t($,St),t($,it),t(it,b),t($,z),t($,vt),t(vt,Ht),t(E,J),t(E,A),t(A,ft),t(ft,W),t(A,st),t(A,_t),t(_t,U),t(A,K),t(A,V),t(V,tt),t(A,et),t(A,$t),t($t,D),t(A,Tt),t(A,ut),t(ut,Rt),t(A,I),t(A,H),t(H,Vt),t(A,wt),t(A,Et),t(Et,Gt),t(E,w),t(E,B),t(B,kt),t(kt,Ft),t(B,pt),t(B,y),t(y,Nt),t(B,Mt),t(B,mt),t(mt,zt),t(B,cl),t(B,ze),t(ze,il),t(B,vl),t(B,Oe),t(Oe,Ze),t(B,fl),t(B,va),t(va,Jt),t(B,fa),t(B,Je),t(Je,_a),t(E,_l),t(E,Ct),t(Ct,oe),t(oe,je),t(Ct,Xe),t(Ct,Be),t(Be,zl),t(Ct,Tl),t(Ct,Pe),t(Pe,ta),t(Ct,ul),t(Ct,Ta),t(Ta,ea),t(Ct,El),t(Ct,ua),t(ua,Le),t(Ct,pl),t(Ct,Ea),t(Ea,ml),t(Ct,aa),t(Ct,pa),t(pa,bl),t(E,ma),t(E,xt),t(xt,ba),t(ba,Da),t(xt,la),t(xt,ya),t(ya,Dl),t(xt,Wt),t(xt,We),t(We,ga),t(xt,Sa),t(xt,Ha),t(Ha,wa),t(xt,Ve),t(xt,Ge),t(Ge,ra),t(xt,da),t(xt,Na),t(Na,yl),t(xt,Ke),t(xt,Fe),t(Fe,gl),t(E,Sl),t(E,bt),t(bt,Ca),t(Ca,Hl),t(bt,Ne),t(bt,Ra),t(Ra,wl),t(bt,Cl),t(bt,Me),t(Me,Rl),t(bt,$l),t(bt,Qe),t(Qe,kl),t(bt,xl),t(bt,Ue),t(Ue,oa),t(bt,Il),t(bt,$a),t($a,ka),t(bt,Kt),t(bt,sa),t(sa,Al),t(E,xa),t(E,It),t(It,Ia),t(Ia,Aa),t(It,Pl),t(It,Pa),t(Pa,Ba),t(It,Bl),t(It,La),t(La,Ma),t(It,Va),t(It,na),t(na,ha),t(It,Ol),t(It,re),t(re,Jl),t(It,Wl),t(It,za),t(za,Kl),t(It,Ql),t(It,se),t(se,ne),t(E,Ul),t(E,At),t(At,Oa),t(Oa,Ja),t(At,ql),t(At,Wa),t(Wa,Ka),t(At,Yl),t(At,Qa),t(Qa,Ga),t(At,Zl),t(At,Ua),t(Ua,jl),t(At,Xl),t(At,de),t(de,tr),t(At,er),t(At,qa),t(qa,Ya),t(At,ar),t(At,Za),t(Za,ja),t(E,lr),t(E,Pt),t(Pt,qe),t(qe,rr),t(Pt,dr),t(Pt,Xa),t(Xa,or),t(Pt,he),t(Pt,tl),t(tl,sr),t(Pt,nr),t(Pt,ca),t(ca,hr),t(Pt,cr),t(Pt,ia),t(ia,ir),t(Pt,vr),t(Pt,Ye),t(Ye,fr),t(Pt,_r),t(Pt,el),t(el,Tr),t(E,ce),t(E,Bt),t(Bt,al),t(al,ur),t(Bt,ll),t(Bt,rl),t(rl,Er),t(Bt,dl),t(Bt,ol),t(ol,pr),t(Bt,Fa),t(Bt,sl),t(sl,mr),t(Bt,br),t(Bt,nl),t(nl,Dr),t(Bt,ie),t(Bt,hl),t(hl,yr),t(Bt,gr),t(Bt,Cr),t(Cr,eo),t(E,ao),t(E,Qt),t(Qt,Rr),t(Rr,lo),t(Qt,ro),t(Qt,$r),t($r,oo),t(Qt,so),t(Qt,kr),t(kr,no),t(Qt,ho),t(Qt,xr),t(xr,co),t(Qt,io),t(Qt,Ir),t(Ir,vo),t(Qt,fo),t(Qt,Ar),t(Ar,_o),t(Qt,To),t(Qt,Pr),t(Pr,uo),t(E,Eo),t(E,Ut),t(Ut,Br),t(Br,po),t(Ut,mo),t(Ut,Lr),t(Lr,bo),t(Ut,Do),t(Ut,Vr),t(Vr,yo),t(Ut,go),t(Ut,Gr),t(Gr,So),t(Ut,Ho),t(Ut,Fr),t(Fr,wo),t(Ut,Co),t(Ut,Nr),t(Nr,Ro),t(Ut,$o),t(Ut,Mr),t(Mr,ko),t(E,xo),t(E,qt),t(qt,zr),t(zr,Io),t(qt,Ao),t(qt,Or),t(Or,Po),t(qt,Bo),t(qt,Jr),t(Jr,Lo),t(qt,Vo),t(qt,Wr),t(Wr,Go),t(qt,Fo),t(qt,Kr),t(Kr,No),t(qt,Mo),t(qt,Qr),t(Qr,zo),t(qt,Oo),t(qt,Ur),t(Ur,Jo),t(E,Wo),t(E,Yt),t(Yt,qr),t(qr,Ko),t(Yt,Qo),t(Yt,Yr),t(Yr,Uo),t(Yt,qo),t(Yt,Zr),t(Zr,Yo),t(Yt,Zo),t(Yt,jr),t(jr,jo),t(Yt,Xo),t(Yt,Xr),t(Xr,ts),t(Yt,es),t(Yt,td),t(td,as),t(Yt,ls),t(Yt,ed),t(ed,rs),t(E,ds),t(E,Zt),t(Zt,ad),t(ad,os),t(Zt,ss),t(Zt,ld),t(ld,ns),t(Zt,hs),t(Zt,rd),t(rd,cs),t(Zt,is),t(Zt,dd),t(dd,vs),t(Zt,fs),t(Zt,od),t(od,_s),t(Zt,Ts),t(Zt,sd),t(sd,us),t(Zt,Es),t(Zt,nd),t(nd,ps),t(E,ms),t(E,jt),t(jt,hd),t(hd,bs),t(jt,Ds),t(jt,cd),t(cd,ys),t(jt,gs),t(jt,id),t(id,Ss),t(jt,Hs),t(jt,vd),t(vd,ws),t(jt,Cs),t(jt,fd),t(fd,Rs),t(jt,$s),t(jt,_d),t(_d,ks),t(jt,xs),t(jt,Td),t(Td,Is),t(E,As),t(E,Xt),t(Xt,ud),t(ud,Ps),t(Xt,Bs),t(Xt,Ed),t(Ed,Ls),t(Xt,Vs),t(Xt,pd),t(pd,Gs),t(Xt,Fs),t(Xt,md),t(md,Ns),t(Xt,Ms),t(Xt,bd),t(bd,zs),t(Xt,Os),t(Xt,Dd),t(Dd,Js),t(Xt,Ws),t(Xt,yd),t(yd,Ks),t(E,Qs),t(E,te),t(te,gd),t(gd,Us),t(te,qs),t(te,Sd),t(Sd,Ys),t(te,Zs),t(te,Hd),t(Hd,js),t(te,Xs),t(te,wd),t(wd,tn),t(te,en),t(te,Cd),t(Cd,an),t(te,ln),t(te,Rd),t(Rd,rn),t(te,dn),t(te,$d),t($d,on),t(E,sn),t(E,ee),t(ee,kd),t(kd,nn),t(ee,hn),t(ee,xd),t(xd,cn),t(ee,vn),t(ee,Id),t(Id,fn),t(ee,_n),t(ee,Ad),t(Ad,Tn),t(ee,un),t(ee,Pd),t(Pd,En),t(ee,pn),t(ee,Bd),t(Bd,mn),t(ee,bn),t(ee,Ld),t(Ld,Dn),t(E,yn),t(E,ae),t(ae,Vd),t(Vd,gn),t(ae,Sn),t(ae,Gd),t(Gd,Hn),t(ae,wn),t(ae,Fd),t(Fd,Cn),t(ae,Rn),t(ae,Nd),t(Nd,$n),t(ae,kn),t(ae,Md),t(Md,xn),t(ae,In),t(ae,zd),t(zd,An),t(ae,Pn),t(ae,Od),t(Od,Bn),t(v,Ln),t(v,Jd),t(Jd,le),t(le,jd),t(le,Vn),t(le,Wd),t(Wd,Gn),t(le,Fn),t(le,Kd),t(Kd,Nn),t(le,Mn),t(le,Qd),t(Qd,zn),t(le,On),t(le,Ud),t(Ud,Jn),t(le,Wn),t(le,qd),t(qd,Kn),t(le,Qn),t(le,Yd),t(Yd,Un)},d(Zd){Zd&&e(c)}}}function a1(Lt){let c,v=`<div class="overflow-x-auto">
  <table class="table table-compact w-full">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,T;return{c(){c=a("pre"),T=s(v),this.h()},l(h){c=l(h,"PRE",{slot:!0});var _=r(c);T=n(_,v),_.forEach(e),this.h()},h(){u(c,"slot","html")},m(h,_){Ot(h,c,_),t(c,T)},p:wr,d(h){h&&e(c)}}}function l1(Lt){let c,v,T,h,_,q,g,at,G,k,Q,Y,C,lt;return c=new Ji({props:{data:[{type:"component",class:"table",desc:"For <table> element"},{type:"modifier",class:"table-zebra",desc:"For the active tab"},{type:"modifier",class:"active",desc:"For <tr> to highlight current row"},{type:"modifier",class:"hover",desc:"For <tr> to highlight current row on hover"},{type:"responsive",class:"table-normal",desc:"Normal paddings"},{type:"responsive",class:"table-compact",desc:"Compact paddings"}]}}),T=new Hr({props:{title:"Table",$$slots:{html:[Ki],default:[Wi]},$$scope:{ctx:Lt}}}),_=new Hr({props:{title:"Table with an active row",$$slots:{html:[Ui],default:[Qi]},$$scope:{ctx:Lt}}}),g=new Hr({props:{title:"Table with a row that highlights on hover",$$slots:{html:[Yi],default:[qi]},$$scope:{ctx:Lt}}}),G=new Hr({props:{title:"Zebra",$$slots:{html:[ji],default:[Zi]},$$scope:{ctx:Lt}}}),Q=new Hr({props:{title:"Table with visual elements",$$slots:{html:[t1],default:[Xi]},$$scope:{ctx:Lt}}}),C=new Hr({props:{title:"Compact table",$$slots:{html:[a1],default:[e1]},$$scope:{ctx:Lt}}}),{c(){Ll(c.$$.fragment),v=d(),Ll(T.$$.fragment),h=d(),Ll(_.$$.fragment),q=d(),Ll(g.$$.fragment),at=d(),Ll(G.$$.fragment),k=d(),Ll(Q.$$.fragment),Y=d(),Ll(C.$$.fragment)},l(i){Vl(c.$$.fragment,i),v=o(i),Vl(T.$$.fragment,i),h=o(i),Vl(_.$$.fragment,i),q=o(i),Vl(g.$$.fragment,i),at=o(i),Vl(G.$$.fragment,i),k=o(i),Vl(Q.$$.fragment,i),Y=o(i),Vl(C.$$.fragment,i)},m(i,f){Gl(c,i,f),Ot(i,v,f),Gl(T,i,f),Ot(i,h,f),Gl(_,i,f),Ot(i,q,f),Gl(g,i,f),Ot(i,at,f),Gl(G,i,f),Ot(i,k,f),Gl(Q,i,f),Ot(i,Y,f),Gl(C,i,f),lt=!0},p(i,[f]){const m={};f&1&&(m.$$scope={dirty:f,ctx:i}),T.$set(m);const L={};f&1&&(L.$$scope={dirty:f,ctx:i}),_.$set(L);const rt={};f&1&&(rt.$$scope={dirty:f,ctx:i}),g.$set(rt);const F={};f&1&&(F.$$scope={dirty:f,ctx:i}),G.$set(F);const S={};f&1&&(S.$$scope={dirty:f,ctx:i}),Q.$set(S);const Z={};f&1&&(Z.$$scope={dirty:f,ctx:i}),C.$set(Z)},i(i){lt||(Fl(c.$$.fragment,i),Fl(T.$$.fragment,i),Fl(_.$$.fragment,i),Fl(g.$$.fragment,i),Fl(G.$$.fragment,i),Fl(Q.$$.fragment,i),Fl(C.$$.fragment,i),lt=!0)},o(i){Nl(c.$$.fragment,i),Nl(T.$$.fragment,i),Nl(_.$$.fragment,i),Nl(g.$$.fragment,i),Nl(G.$$.fragment,i),Nl(Q.$$.fragment,i),Nl(C.$$.fragment,i),lt=!1},d(i){Ml(c,i),i&&e(v),Ml(T,i),i&&e(h),Ml(_,i),i&&e(q),Ml(g,i),i&&e(at),Ml(G,i),i&&e(k),Ml(Q,i),i&&e(Y),Ml(C,i)}}}const s1={title:"Table",desc:"Table can be used to show a list of data in a table format.",published:!0};class n1 extends Mi{constructor(c){super();zi(this,c,null,l1,Oi,{})}}export{n1 as default,s1 as metadata};
