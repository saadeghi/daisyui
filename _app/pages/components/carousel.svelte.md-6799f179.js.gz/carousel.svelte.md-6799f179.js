import{S as ke,i as Fe,s as Pe,C as Ie,w as X,x as Y,y as Z,z as ye,A as Ge,q as ee,o as se,B as ae,K as je,af as xe,k as I,m as b,g as U,d as m,e as l,c as r,a as v,O as V,b as s,F as a,t as N,h as Q,a7 as ie,U as ce}from"../../chunks/vendor-858a832d.js";import{M as Re}from"../../chunks/_markdown-dde168bf.js";import{p as qe,C as Ke,a as re,r as me}from"../../chunks/actions-2c560130.js";import"../../chunks/stores-a44b3550.js";import"../../chunks/Ads-0ebb372f.js";import"../../chunks/index-1a9baffb.js";import"../../chunks/SEO-efc0516a.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-1c86c3c5.js";function Oe(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Burger"),s(o,"class","carousel-item"),V(t.src,n="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB")||s(t,"src",n),s(t,"alt","Burger"),s(h,"class","carousel-item"),V(_.src,q="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6")||s(_,"src",q),s(_,"alt","Burger"),s(D,"class","carousel-item"),V(w.src,K="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693")||s(w,"src",K),s(w,"alt","Burger"),s(E,"class","carousel-item"),V($.src,j="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7")||s($,"src",j),s($,"alt","Burger"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Burger"),s(d,"class","carousel-item"),V(B.src,k="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A")||s(B,"src",k),s(B,"alt","Burger"),s(S,"class","carousel-item"),s(e,"class","carousel rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Ue(T){let e,o=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A" alt="Burger" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function He(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Pizza"),s(o,"class","carousel-item"),V(t.src,n="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB")||s(t,"src",n),s(t,"alt","Pizza"),s(h,"class","carousel-item"),V(_.src,q="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6")||s(_,"src",q),s(_,"alt","Pizza"),s(D,"class","carousel-item"),V(w.src,K="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693")||s(w,"src",K),s(w,"alt","Pizza"),s(E,"class","carousel-item"),V($.src,j="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7")||s($,"src",j),s($,"alt","Pizza"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Pizza"),s(d,"class","carousel-item"),V(B.src,k="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A")||s(B,"src",k),s(B,"alt","Pizza"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-center rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Je(T){let e,o=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A" alt="Pizza" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function Le(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Drink"),s(o,"class","carousel-item"),V(t.src,n="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB")||s(t,"src",n),s(t,"alt","Drink"),s(h,"class","carousel-item"),V(_.src,q="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6")||s(_,"src",q),s(_,"alt","Drink"),s(D,"class","carousel-item"),V(w.src,K="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693")||s(w,"src",K),s(w,"alt","Drink"),s(E,"class","carousel-item"),V($.src,j="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7")||s($,"src",j),s($,"alt","Drink"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094")||s(C,"src",P),s(C,"alt","Drink"),s(d,"class","carousel-item"),V(B.src,k="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A")||s(B,"src",k),s(B,"alt","Drink"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-end rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Ne(T){let e,o=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A" alt="Drink" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function Qe(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS carousel component"),s(o,"class","w-full carousel-item"),V(t.src,n="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(t,"src",n),s(t,"class","w-full"),s(t,"alt","Tailwind CSS carousel component"),s(h,"class","w-full carousel-item"),V(_.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s(_,"src",q),s(_,"class","w-full"),s(_,"alt","Tailwind CSS carousel component"),s(D,"class","w-full carousel-item"),V(w.src,K="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",K),s(w,"class","w-full"),s(w,"alt","Tailwind CSS carousel component"),s(E,"class","w-full carousel-item"),V($.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s($,"src",j),s($,"class","w-full"),s($,"alt","Tailwind CSS carousel component"),s(g,"class","w-full carousel-item"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"class","w-full"),s(C,"alt","Tailwind CSS carousel component"),s(d,"class","w-full carousel-item"),V(B.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",k),s(B,"class","w-full"),s(B,"alt","Tailwind CSS carousel component"),s(S,"class","w-full carousel-item"),s(e,"class","w-64 carousel rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function We(T){let e,o=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function Xe(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"alt","Tailwind Image slider"),s(o,"class","carousel-item h-full"),V(t.src,n="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(t,"src",n),s(t,"alt","Tailwind Image slider"),s(h,"class","carousel-item h-full"),V(_.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s(_,"src",q),s(_,"alt","Tailwind Image slider"),s(D,"class","carousel-item h-full"),V(w.src,K="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",K),s(w,"alt","Tailwind Image slider"),s(E,"class","carousel-item h-full"),V($.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s($,"src",j),s($,"alt","Tailwind Image slider"),s(g,"class","carousel-item h-full"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"alt","Tailwind Image slider"),s(d,"class","carousel-item h-full"),V(B.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",k),s(B,"alt","Tailwind Image slider"),s(S,"class","carousel-item h-full"),s(e,"class","h-96 carousel carousel-vertical rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function Ye(T){let e,o=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function Ze(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS Image slider"),s(o,"class","w-1/2 carousel-item"),V(t.src,n="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||s(t,"src",n),s(t,"class","w-full"),s(t,"alt","Tailwind CSS Image slider"),s(h,"class","w-1/2 carousel-item"),V(_.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||s(_,"src",q),s(_,"class","w-full"),s(_,"alt","Tailwind CSS Image slider"),s(D,"class","w-1/2 carousel-item"),V(w.src,K="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||s(w,"src",K),s(w,"class","w-full"),s(w,"alt","Tailwind CSS Image slider"),s(E,"class","w-1/2 carousel-item"),V($.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||s($,"src",j),s($,"class","w-full"),s($,"alt","Tailwind CSS Image slider"),s(g,"class","w-1/2 carousel-item"),V(C.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||s(C,"src",P),s(C,"class","w-full"),s(C,"alt","Tailwind CSS Image slider"),s(d,"class","w-1/2 carousel-item"),V(B.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||s(B,"src",k),s(B,"class","w-full"),s(B,"alt","Tailwind CSS Image slider"),s(S,"class","w-1/2 carousel-item"),s(e,"class","w-96 carousel rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function es(T){let e,o=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function ss(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("img"),c=I(),d=l("div"),C=l("img"),G=I(),S=l("div"),B=l("img"),this.h()},l(A){e=r(A,"DIV",{class:!0});var i=v(e);o=r(i,"DIV",{class:!0});var F=v(o);u=r(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(m),p=b(i),h=r(i,"DIV",{class:!0});var O=v(h);t=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),x=b(i),D=r(i,"DIV",{class:!0});var H=v(D);_=r(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),M=b(i),E=r(i,"DIV",{class:!0});var J=v(E);w=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var R=v(g);$=r(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),c=b(i),d=r(i,"DIV",{class:!0});var y=v(d);C=r(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(m),G=b(i),S=r(i,"DIV",{class:!0});var L=v(S);B=r(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(m),i.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","rounded-box"),s(u,"alt","Tailwind CSS component"),s(o,"class","carousel-item"),V(t.src,n="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB")||s(t,"src",n),s(t,"class","rounded-box"),s(t,"alt","Tailwind CSS component"),s(h,"class","carousel-item"),V(_.src,q="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6")||s(_,"src",q),s(_,"class","rounded-box"),s(_,"alt","Tailwind CSS component"),s(D,"class","carousel-item"),V(w.src,K="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693")||s(w,"src",K),s(w,"class","rounded-box"),s(w,"alt","Tailwind CSS component"),s(E,"class","carousel-item"),V($.src,j="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7")||s($,"src",j),s($,"class","rounded-box"),s($,"alt","Tailwind CSS component"),s(g,"class","carousel-item"),V(C.src,P="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094")||s(C,"src",P),s(C,"class","rounded-box"),s(C,"alt","Tailwind CSS component"),s(d,"class","carousel-item"),V(B.src,k="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A")||s(B,"src",k),s(B,"class","rounded-box"),s(B,"alt","Tailwind CSS component"),s(S,"class","carousel-item"),s(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(A,i){U(A,e,i),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),a(e,z),a(e,g),a(g,$),a(e,c),a(e,d),a(d,C),a(e,G),a(e,S),a(S,B)},d(A){A&&m(e)}}}function as(T){let e,o=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A" class="rounded-box" />
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function ts(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k,A;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("img"),x=I(),D=l("div"),_=l("img"),M=I(),E=l("div"),w=l("img"),z=I(),g=l("div"),$=l("a"),j=N("1"),c=I(),d=l("a"),C=N("2"),P=I(),G=l("a"),S=N("3"),B=I(),k=l("a"),A=N("4"),this.h()},l(i){e=r(i,"DIV",{class:!0});var F=v(e);o=r(F,"DIV",{id:!0,class:!0});var O=v(o);u=r(O,"IMG",{src:!0,class:!0,alt:!0}),O.forEach(m),p=b(F),h=r(F,"DIV",{id:!0,class:!0});var H=v(h);t=r(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(m),x=b(F),D=r(F,"DIV",{id:!0,class:!0});var J=v(D);_=r(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(m),M=b(F),E=r(F,"DIV",{id:!0,class:!0});var R=v(E);w=r(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(m),F.forEach(m),z=b(i),g=r(i,"DIV",{class:!0});var y=v(g);$=r(y,"A",{href:!0,class:!0});var L=v($);j=Q(L,"1"),L.forEach(m),c=b(y),d=r(y,"A",{href:!0,class:!0});var oe=v(d);C=Q(oe,"2"),oe.forEach(m),P=b(y),G=r(y,"A",{href:!0,class:!0});var W=v(G);S=Q(W,"3"),W.forEach(m),B=b(y),k=r(y,"A",{href:!0,class:!0});var te=v(k);A=Q(te,"4"),te.forEach(m),y.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image gallery"),s(o,"id","item1"),s(o,"class","w-full carousel-item"),V(t.src,n="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||s(t,"src",n),s(t,"class","w-full"),s(t,"alt","Tailwind CSS image gallery"),s(h,"id","item2"),s(h,"class","w-full carousel-item"),V(_.src,q="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||s(_,"src",q),s(_,"class","w-full"),s(_,"alt","Tailwind CSS image gallery"),s(D,"id","item3"),s(D,"class","w-full carousel-item"),V(w.src,K="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||s(w,"src",K),s(w,"class","w-full"),s(w,"alt","Tailwind CSS image gallery"),s(E,"id","item4"),s(E,"class","w-full carousel-item"),s(e,"class","w-full carousel"),s($,"href","#item1"),s($,"class","btn btn-xs"),s(d,"href","#item2"),s(d,"class","btn btn-xs"),s(G,"href","#item3"),s(G,"class","btn btn-xs"),s(k,"href","#item4"),s(k,"class","btn btn-xs"),s(g,"class","flex justify-center w-full py-2 gap-2")},m(i,F){U(i,e,F),a(e,o),a(o,u),a(e,p),a(e,h),a(h,t),a(e,x),a(e,D),a(D,_),a(e,M),a(e,E),a(E,w),U(i,z,F),U(i,g,F),a(g,$),a($,j),a(g,c),a(g,d),a(d,C),a(g,P),a(g,G),a(G,S),a(g,B),a(g,k),a(k,A)},d(i){i&&m(e),i&&m(z),i&&m(g)}}}function ls(T){let e,o=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function rs(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j,c,d,C,P,G,S,B,k,A,i,F,O,H,J,R,y,L,oe,W,te,we,De,ue,Ee;return{c(){e=l("div"),o=l("div"),u=l("img"),p=I(),h=l("div"),t=l("a"),n=N("\u276E"),x=I(),D=l("a"),_=N("\u276F"),q=I(),M=l("div"),E=l("img"),K=I(),z=l("div"),g=l("a"),$=N("\u276E"),j=I(),c=l("a"),d=N("\u276F"),C=I(),P=l("div"),G=l("img"),B=I(),k=l("div"),A=l("a"),i=N("\u276E"),F=I(),O=l("a"),H=N("\u276F"),J=I(),R=l("div"),y=l("img"),oe=I(),W=l("div"),te=l("a"),we=N("\u276E"),De=I(),ue=l("a"),Ee=N("\u276F"),this.h()},l(he){e=r(he,"DIV",{class:!0});var le=v(e);o=r(le,"DIV",{id:!0,class:!0});var de=v(o);u=r(de,"IMG",{src:!0,class:!0,alt:!0}),p=b(de),h=r(de,"DIV",{class:!0});var pe=v(h);t=r(pe,"A",{href:!0,class:!0});var be=v(t);n=Q(be,"\u276E"),be.forEach(m),x=b(pe),D=r(pe,"A",{href:!0,class:!0});var Ce=v(D);_=Q(Ce,"\u276F"),Ce.forEach(m),pe.forEach(m),de.forEach(m),q=b(le),M=r(le,"DIV",{id:!0,class:!0});var ne=v(M);E=r(ne,"IMG",{src:!0,class:!0,alt:!0}),K=b(ne),z=r(ne,"DIV",{class:!0});var ve=v(z);g=r(ve,"A",{href:!0,class:!0});var Be=v(g);$=Q(Be,"\u276E"),Be.forEach(m),j=b(ve),c=r(ve,"A",{href:!0,class:!0});var Se=v(c);d=Q(Se,"\u276F"),Se.forEach(m),ve.forEach(m),ne.forEach(m),C=b(le),P=r(le,"DIV",{id:!0,class:!0});var fe=v(P);G=r(fe,"IMG",{src:!0,class:!0,alt:!0}),B=b(fe),k=r(fe,"DIV",{class:!0});var ge=v(k);A=r(ge,"A",{href:!0,class:!0});var Ve=v(A);i=Q(Ve,"\u276E"),Ve.forEach(m),F=b(ge),O=r(ge,"A",{href:!0,class:!0});var Ae=v(O);H=Q(Ae,"\u276F"),Ae.forEach(m),ge.forEach(m),fe.forEach(m),J=b(le),R=r(le,"DIV",{id:!0,class:!0});var _e=v(R);y=r(_e,"IMG",{src:!0,class:!0,alt:!0}),oe=b(_e),W=r(_e,"DIV",{class:!0});var $e=v(W);te=r($e,"A",{href:!0,class:!0});var Me=v(te);we=Q(Me,"\u276E"),Me.forEach(m),De=b($e),ue=r($e,"A",{href:!0,class:!0});var ze=v(ue);Ee=Q(ze,"\u276F"),ze.forEach(m),$e.forEach(m),_e.forEach(m),le.forEach(m),this.h()},h(){V(u.src,f="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||s(u,"src",f),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image slide"),s(t,"href","#slide4"),s(t,"class","btn btn-circle"),s(D,"href","#slide2"),s(D,"class","btn btn-circle"),s(h,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(o,"id","slide1"),s(o,"class","relative w-full carousel-item"),V(E.src,w="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||s(E,"src",w),s(E,"class","w-full"),s(E,"alt","Tailwind CSS image slide"),s(g,"href","#slide1"),s(g,"class","btn btn-circle"),s(c,"href","#slide3"),s(c,"class","btn btn-circle"),s(z,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(M,"id","slide2"),s(M,"class","relative w-full carousel-item"),V(G.src,S="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||s(G,"src",S),s(G,"class","w-full"),s(G,"alt","Tailwind CSS image slide"),s(A,"href","#slide2"),s(A,"class","btn btn-circle"),s(O,"href","#slide4"),s(O,"class","btn btn-circle"),s(k,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(P,"id","slide3"),s(P,"class","relative w-full carousel-item"),V(y.src,L="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||s(y,"src",L),s(y,"class","w-full"),s(y,"alt","Tailwind CSS image slide"),s(te,"href","#slide3"),s(te,"class","btn btn-circle"),s(ue,"href","#slide1"),s(ue,"class","btn btn-circle"),s(W,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(R,"id","slide4"),s(R,"class","relative w-full carousel-item"),s(e,"class","w-full carousel")},m(he,le){U(he,e,le),a(e,o),a(o,u),a(o,p),a(o,h),a(h,t),a(t,n),a(h,x),a(h,D),a(D,_),a(e,q),a(e,M),a(M,E),a(M,K),a(M,z),a(z,g),a(g,$),a(z,j),a(z,c),a(c,d),a(e,C),a(e,P),a(P,G),a(P,B),a(P,k),a(k,A),a(A,i),a(k,F),a(k,O),a(O,H),a(e,J),a(e,R),a(R,y),a(R,oe),a(R,W),a(W,te),a(te,we),a(W,De),a(W,ue),a(ue,Ee)},d(he){he&&m(e)}}}function is(T){let e,o=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full"> / 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full"> / 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full"> / 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full"> / 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,u,f,p,h;return{c(){e=l("pre"),u=N(o),this.h()},l(t){e=r(t,"PRE",{slot:!0});var n=v(e);u=Q(n,o),n.forEach(m),this.h()},h(){s(e,"slot","html")},m(t,n){U(t,e,n),a(e,u),p||(h=ie(f=me.call(null,e,{to:T[0]})),p=!0)},p(t,n){f&&ce(f.update)&&n&1&&f.update.call(null,{to:t[0]})},d(t){t&&m(e),p=!1,h()}}}function cs(T){let e,o,u,f,p,h,t,n,x,D,_,q,M,E,w,K,z,g,$,j;return e=new Ke({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),u=new re({props:{title:"Snap to start (default)",$$slots:{html:[Ue],default:[Oe]},$$scope:{ctx:T}}}),p=new re({props:{title:"Snap to center",$$slots:{html:[Je],default:[He]},$$scope:{ctx:T}}}),t=new re({props:{title:"Snap to end",$$slots:{html:[Ne],default:[Le]},$$scope:{ctx:T}}}),x=new re({props:{title:"Carousel with full width items",$$slots:{html:[We],default:[Qe]},$$scope:{ctx:T}}}),_=new re({props:{title:"Vertical carousel",$$slots:{html:[Ye],default:[Xe]},$$scope:{ctx:T}}}),M=new re({props:{title:"Carousel with half width items",$$slots:{html:[es],default:[Ze]},$$scope:{ctx:T}}}),w=new re({props:{title:"Full-bleed carousel",$$slots:{html:[as],default:[ss]},$$scope:{ctx:T}}}),z=new re({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[ls],default:[ts]},$$scope:{ctx:T}}}),$=new re({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[is],default:[rs]},$$scope:{ctx:T}}}),{c(){X(e.$$.fragment),o=I(),X(u.$$.fragment),f=I(),X(p.$$.fragment),h=I(),X(t.$$.fragment),n=I(),X(x.$$.fragment),D=I(),X(_.$$.fragment),q=I(),X(M.$$.fragment),E=I(),X(w.$$.fragment),K=I(),X(z.$$.fragment),g=I(),X($.$$.fragment)},l(c){Y(e.$$.fragment,c),o=b(c),Y(u.$$.fragment,c),f=b(c),Y(p.$$.fragment,c),h=b(c),Y(t.$$.fragment,c),n=b(c),Y(x.$$.fragment,c),D=b(c),Y(_.$$.fragment,c),q=b(c),Y(M.$$.fragment,c),E=b(c),Y(w.$$.fragment,c),K=b(c),Y(z.$$.fragment,c),g=b(c),Y($.$$.fragment,c)},m(c,d){Z(e,c,d),U(c,o,d),Z(u,c,d),U(c,f,d),Z(p,c,d),U(c,h,d),Z(t,c,d),U(c,n,d),Z(x,c,d),U(c,D,d),Z(_,c,d),U(c,q,d),Z(M,c,d),U(c,E,d),Z(w,c,d),U(c,K,d),Z(z,c,d),U(c,g,d),Z($,c,d),j=!0},p(c,d){const C={};d&5&&(C.$$scope={dirty:d,ctx:c}),u.$set(C);const P={};d&5&&(P.$$scope={dirty:d,ctx:c}),p.$set(P);const G={};d&5&&(G.$$scope={dirty:d,ctx:c}),t.$set(G);const S={};d&5&&(S.$$scope={dirty:d,ctx:c}),x.$set(S);const B={};d&5&&(B.$$scope={dirty:d,ctx:c}),_.$set(B);const k={};d&5&&(k.$$scope={dirty:d,ctx:c}),M.$set(k);const A={};d&5&&(A.$$scope={dirty:d,ctx:c}),w.$set(A);const i={};d&5&&(i.$$scope={dirty:d,ctx:c}),z.$set(i);const F={};d&5&&(F.$$scope={dirty:d,ctx:c}),$.$set(F)},i(c){j||(ee(e.$$.fragment,c),ee(u.$$.fragment,c),ee(p.$$.fragment,c),ee(t.$$.fragment,c),ee(x.$$.fragment,c),ee(_.$$.fragment,c),ee(M.$$.fragment,c),ee(w.$$.fragment,c),ee(z.$$.fragment,c),ee($.$$.fragment,c),j=!0)},o(c){se(e.$$.fragment,c),se(u.$$.fragment,c),se(p.$$.fragment,c),se(t.$$.fragment,c),se(x.$$.fragment,c),se(_.$$.fragment,c),se(M.$$.fragment,c),se(w.$$.fragment,c),se(z.$$.fragment,c),se($.$$.fragment,c),j=!1},d(c){ae(e,c),c&&m(o),ae(u,c),c&&m(f),ae(p,c),c&&m(h),ae(t,c),c&&m(n),ae(x,c),c&&m(D),ae(_,c),c&&m(q),ae(M,c),c&&m(E),ae(w,c),c&&m(K),ae(z,c),c&&m(g),ae($,c)}}}function ms(T){let e,o;const u=[T[1],Te];let f={$$slots:{default:[cs]},$$scope:{ctx:T}};for(let p=0;p<u.length;p+=1)f=Ie(f,u[p]);return e=new Re({props:f}),{c(){X(e.$$.fragment)},l(p){Y(e.$$.fragment,p)},m(p,h){Z(e,p,h),o=!0},p(p,[h]){const t=h&2?ye(u,[h&2&&Ge(p[1]),h&0&&Ge(Te)]):{};h&5&&(t.$$scope={dirty:h,ctx:p}),e.$set(t)},i(p){o||(ee(e.$$.fragment,p),o=!0)},o(p){se(e.$$.fragment,p),o=!1},d(p){ae(e,p)}}}const Te={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function us(T,e,o){let u;return je(T,qe,f=>o(0,u=f)),T.$$set=f=>{o(1,e=Ie(Ie({},e),xe(f)))},e=xe(e),[u,e]}class $s extends ke{constructor(e){super();Fe(this,e,us,ms,Pe,{})}}export{$s as default,Te as metadata};
