import{S as et,i as st,s as nt,e as u,t as S,k as R,w as M,c as r,a as f,h as b,d as p,m as k,x as O,g as N,H as c,y as z,q as F,o as G,B as K,J as lt,v as at,f as P,b as h,a1 as U,j as W,P as X}from"../../chunks/vendor-1fc5b034.js";import{C as ot,a as Q,r as Z,p as pt}from"../../chunks/actions-a46bfef7.js";import"../../chunks/preload-helper-ec9aa979.js";function ct($){let t,n;return{c(){t=u("span"),n=u("span"),this.h()},l(a){t=r(a,"SPAN",{class:!0});var o=f(t);n=r(o,"SPAN",{style:!0}),f(n).forEach(p),o.forEach(p),this.h()},h(){P(n,"--value",$[0]),h(t,"class","countdown")},m(a,o){N(a,t,o),c(t,n)},p(a,o){o&1&&P(n,"--value",a[0])},d(a){a&&p(t)}}}function ut($){let t,n=`<span class="$$countdown">
  <span style="--value:${$[0]};"></span>
</span>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown">
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function rt($){let t,n;return{c(){t=u("span"),n=u("span"),this.h()},l(a){t=r(a,"SPAN",{class:!0});var o=f(t);n=r(o,"SPAN",{style:!0}),f(n).forEach(p),o.forEach(p),this.h()},h(){P(n,"--value",$[0]),h(t,"class","countdown font-mono text-6xl")},m(a,o){N(a,t,o),c(t,n)},p(a,o){o&1&&P(n,"--value",a[0])},d(a){a&&p(t)}}}function ft($){let t,n=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${$[0]};"></span>
</span>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function dt($){let t,n,a,o,d,i,e;return{c(){t=u("span"),n=u("span"),a=S(`h
  `),o=u("span"),d=S(`m
  `),i=u("span"),e=S("s"),this.h()},l(s){t=r(s,"SPAN",{class:!0});var x=f(t);n=r(x,"SPAN",{style:!0}),f(n).forEach(p),a=b(x,`h
  `),o=r(x,"SPAN",{style:!0}),f(o).forEach(p),d=b(x,`m
  `),i=r(x,"SPAN",{style:!0}),f(i).forEach(p),e=b(x,"s"),x.forEach(p),this.h()},h(){P(n,"--value","10"),P(o,"--value","24"),P(i,"--value",$[0]),h(t,"class","font-mono text-2xl countdown")},m(s,x){N(s,t,x),c(t,n),c(t,a),c(t,o),c(t,d),c(t,i),c(t,e)},p(s,x){x&1&&P(i,"--value",s[0])},d(s){s&&p(t)}}}function it($){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${$[0]};"></span>s
</span>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${e[0]};"></span>s
</span>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function vt($){let t,n,a,o,d,i;return{c(){t=u("span"),n=u("span"),a=S(`:
  `),o=u("span"),d=S(`:
  `),i=u("span"),this.h()},l(e){t=r(e,"SPAN",{class:!0});var s=f(t);n=r(s,"SPAN",{style:!0}),f(n).forEach(p),a=b(s,`:
  `),o=r(s,"SPAN",{style:!0}),f(o).forEach(p),d=b(s,`:
  `),i=r(s,"SPAN",{style:!0}),f(i).forEach(p),s.forEach(p),this.h()},h(){P(n,"--value","10"),P(o,"--value","24"),P(i,"--value",$[0]),h(t,"class","font-mono text-2xl countdown")},m(e,s){N(e,t,s),c(t,n),c(t,a),c(t,o),c(t,d),c(t,i)},p(e,s){s&1&&P(i,"--value",e[0])},d(e){e&&p(t)}}}function $t($){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${$[0]};"></span>
</span>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function mt($){let t,n,a,o,d,i,e,s,x,J,D,g,E,V,I,L,w,A,y,T;return{c(){t=u("div"),n=u("div"),a=u("span"),o=u("span"),d=S(`
    days`),i=R(),e=u("div"),s=u("span"),x=u("span"),J=S(`
    hours`),D=R(),g=u("div"),E=u("span"),V=u("span"),I=S(`
    minutes`),L=R(),w=u("div"),A=u("span"),y=u("span"),T=S(`
    sec`),this.h()},l(_){t=r(_,"DIV",{class:!0});var m=f(t);n=r(m,"DIV",{});var l=f(n);a=r(l,"SPAN",{class:!0});var v=f(a);o=r(v,"SPAN",{style:!0}),f(o).forEach(p),v.forEach(p),d=b(l,`
    days`),l.forEach(p),i=k(m),e=r(m,"DIV",{});var C=f(e);s=r(C,"SPAN",{class:!0});var j=f(s);x=r(j,"SPAN",{style:!0}),f(x).forEach(p),j.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k(m),g=r(m,"DIV",{});var q=f(g);E=r(q,"SPAN",{class:!0});var B=f(E);V=r(B,"SPAN",{style:!0}),f(V).forEach(p),B.forEach(p),I=b(q,`
    minutes`),q.forEach(p),L=k(m),w=r(m,"DIV",{});var Y=f(w);A=r(Y,"SPAN",{class:!0});var H=f(A);y=r(H,"SPAN",{style:!0}),f(y).forEach(p),H.forEach(p),T=b(Y,`
    sec`),Y.forEach(p),m.forEach(p),this.h()},h(){P(o,"--value","15"),h(a,"class","font-mono text-4xl countdown"),P(x,"--value","10"),h(s,"class","font-mono text-4xl countdown"),P(V,"--value","24"),h(E,"class","font-mono text-4xl countdown"),P(y,"--value",$[0]),h(A,"class","font-mono text-4xl countdown"),h(t,"class","flex gap-5")},m(_,m){N(_,t,m),c(t,n),c(n,a),c(a,o),c(n,d),c(t,i),c(t,e),c(e,s),c(s,x),c(e,J),c(t,D),c(t,g),c(g,E),c(E,V),c(g,I),c(t,L),c(t,w),c(w,A),c(A,y),c(w,T)},p(_,m){m&1&&P(y,"--value",_[0])},d(_){_&&p(t)}}}function xt($){let t,n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${$[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function ht($){let t,n,a,o,d,i,e,s,x,J,D,g,E,V,I,L,w,A,y,T;return{c(){t=u("div"),n=u("div"),a=u("span"),o=u("span"),d=S(`
    days`),i=R(),e=u("div"),s=u("span"),x=u("span"),J=S(`
    hours`),D=R(),g=u("div"),E=u("span"),V=u("span"),I=S(`
    min`),L=R(),w=u("div"),A=u("span"),y=u("span"),T=S(`
    sec`),this.h()},l(_){t=r(_,"DIV",{class:!0});var m=f(t);n=r(m,"DIV",{class:!0});var l=f(n);a=r(l,"SPAN",{class:!0});var v=f(a);o=r(v,"SPAN",{style:!0}),f(o).forEach(p),v.forEach(p),d=b(l,`
    days`),l.forEach(p),i=k(m),e=r(m,"DIV",{class:!0});var C=f(e);s=r(C,"SPAN",{class:!0});var j=f(s);x=r(j,"SPAN",{style:!0}),f(x).forEach(p),j.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k(m),g=r(m,"DIV",{class:!0});var q=f(g);E=r(q,"SPAN",{class:!0});var B=f(E);V=r(B,"SPAN",{style:!0}),f(V).forEach(p),B.forEach(p),I=b(q,`
    min`),q.forEach(p),L=k(m),w=r(m,"DIV",{class:!0});var Y=f(w);A=r(Y,"SPAN",{class:!0});var H=f(A);y=r(H,"SPAN",{style:!0}),f(y).forEach(p),H.forEach(p),T=b(Y,`
    sec`),Y.forEach(p),m.forEach(p),this.h()},h(){P(o,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(n,"class","flex flex-col"),P(x,"--value","10"),h(s,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(g,"class","flex flex-col"),P(y,"--value",$[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,m){N(_,t,m),c(t,n),c(n,a),c(a,o),c(n,d),c(t,i),c(t,e),c(e,s),c(s,x),c(e,J),c(t,D),c(t,g),c(g,E),c(E,V),c(g,I),c(t,L),c(t,w),c(w,A),c(A,y),c(w,T)},p(_,m){m&1&&P(y,"--value",_[0])},d(_){_&&p(t)}}}function _t($){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${$[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function wt($){let t,n,a,o,d,i,e,s,x,J,D,g,E,V,I,L,w,A,y,T;return{c(){t=u("div"),n=u("div"),a=u("span"),o=u("span"),d=S(`
    days`),i=R(),e=u("div"),s=u("span"),x=u("span"),J=S(`
    hours`),D=R(),g=u("div"),E=u("span"),V=u("span"),I=S(`
    min`),L=R(),w=u("div"),A=u("span"),y=u("span"),T=S(`
    sec`),this.h()},l(_){t=r(_,"DIV",{class:!0});var m=f(t);n=r(m,"DIV",{class:!0});var l=f(n);a=r(l,"SPAN",{class:!0});var v=f(a);o=r(v,"SPAN",{style:!0}),f(o).forEach(p),v.forEach(p),d=b(l,`
    days`),l.forEach(p),i=k(m),e=r(m,"DIV",{class:!0});var C=f(e);s=r(C,"SPAN",{class:!0});var j=f(s);x=r(j,"SPAN",{style:!0}),f(x).forEach(p),j.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k(m),g=r(m,"DIV",{class:!0});var q=f(g);E=r(q,"SPAN",{class:!0});var B=f(E);V=r(B,"SPAN",{style:!0}),f(V).forEach(p),B.forEach(p),I=b(q,`
    min`),q.forEach(p),L=k(m),w=r(m,"DIV",{class:!0});var Y=f(w);A=r(Y,"SPAN",{class:!0});var H=f(A);y=r(H,"SPAN",{style:!0}),f(y).forEach(p),H.forEach(p),T=b(Y,`
    sec`),Y.forEach(p),m.forEach(p),this.h()},h(){P(o,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(n,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(x,"--value","10"),h(s,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(g,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(y,"--value",$[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,m){N(_,t,m),c(t,n),c(n,a),c(a,o),c(n,d),c(t,i),c(t,e),c(e,s),c(s,x),c(e,J),c(t,D),c(t,g),c(g,E),c(E,V),c(g,I),c(t,L),c(t,w),c(w,A),c(A,y),c(w,T)},p(_,m){m&1&&P(y,"--value",_[0])},d(_){_&&p(t)}}}function Et($){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${$[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,o,d,i;return{c(){t=u("pre"),a=S(n),this.h()},l(e){t=r(e,"PRE",{slot:!0});var s=f(t);a=b(s,n),s.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,s){N(e,t,s),c(t,a),d||(i=U(o=Z.call(null,t,{to:$[1]})),d=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,n),o&&X(o.update)&&s&2&&o.update.call(null,{to:e[1]})},d(e){e&&p(t),d=!1,i()}}}function yt($){let t,n,a,o,d,i,e,s,x,J,D,g,E,V,I,L,w,A,y,T,_,m;return e=new ot({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),x=new Q({props:{title:"Countdown",$$slots:{html:[ut],default:[ct]},$$scope:{ctx:$}}}),D=new Q({props:{title:"Large text",$$slots:{html:[ft],default:[rt]},$$scope:{ctx:$}}}),E=new Q({props:{title:"Clock countdown",$$slots:{html:[it],default:[dt]},$$scope:{ctx:$}}}),I=new Q({props:{title:"Clock countdown with colons",$$slots:{html:[$t],default:[vt]},$$scope:{ctx:$}}}),w=new Q({props:{title:"Large text with labels",$$slots:{html:[xt],default:[mt]},$$scope:{ctx:$}}}),y=new Q({props:{title:"Large text with labels under",$$slots:{html:[_t],default:[ht]},$$scope:{ctx:$}}}),_=new Q({props:{title:"In boxes",$$slots:{html:[Et],default:[wt]},$$scope:{ctx:$}}}),{c(){t=u("p"),n=S("You need to change to "),a=u("code"),o=S("--value"),d=S(" CSS variable using JS. Value must be a number between 0 and 99"),i=R(),M(e.$$.fragment),s=R(),M(x.$$.fragment),J=R(),M(D.$$.fragment),g=R(),M(E.$$.fragment),V=R(),M(I.$$.fragment),L=R(),M(w.$$.fragment),A=R(),M(y.$$.fragment),T=R(),M(_.$$.fragment)},l(l){t=r(l,"P",{});var v=f(t);n=b(v,"You need to change to "),a=r(v,"CODE",{});var C=f(a);o=b(C,"--value"),C.forEach(p),d=b(v," CSS variable using JS. Value must be a number between 0 and 99"),v.forEach(p),i=k(l),O(e.$$.fragment,l),s=k(l),O(x.$$.fragment,l),J=k(l),O(D.$$.fragment,l),g=k(l),O(E.$$.fragment,l),V=k(l),O(I.$$.fragment,l),L=k(l),O(w.$$.fragment,l),A=k(l),O(y.$$.fragment,l),T=k(l),O(_.$$.fragment,l)},m(l,v){N(l,t,v),c(t,n),c(t,a),c(a,o),c(t,d),N(l,i,v),z(e,l,v),N(l,s,v),z(x,l,v),N(l,J,v),z(D,l,v),N(l,g,v),z(E,l,v),N(l,V,v),z(I,l,v),N(l,L,v),z(w,l,v),N(l,A,v),z(y,l,v),N(l,T,v),z(_,l,v),m=!0},p(l,[v]){const C={};v&11&&(C.$$scope={dirty:v,ctx:l}),x.$set(C);const j={};v&11&&(j.$$scope={dirty:v,ctx:l}),D.$set(j);const q={};v&11&&(q.$$scope={dirty:v,ctx:l}),E.$set(q);const B={};v&11&&(B.$$scope={dirty:v,ctx:l}),I.$set(B);const Y={};v&11&&(Y.$$scope={dirty:v,ctx:l}),w.$set(Y);const H={};v&11&&(H.$$scope={dirty:v,ctx:l}),y.$set(H);const tt={};v&11&&(tt.$$scope={dirty:v,ctx:l}),_.$set(tt)},i(l){m||(F(e.$$.fragment,l),F(x.$$.fragment,l),F(D.$$.fragment,l),F(E.$$.fragment,l),F(I.$$.fragment,l),F(w.$$.fragment,l),F(y.$$.fragment,l),F(_.$$.fragment,l),m=!0)},o(l){G(e.$$.fragment,l),G(x.$$.fragment,l),G(D.$$.fragment,l),G(E.$$.fragment,l),G(I.$$.fragment,l),G(w.$$.fragment,l),G(y.$$.fragment,l),G(_.$$.fragment,l),m=!1},d(l){l&&p(t),l&&p(i),K(e,l),l&&p(s),K(x,l),l&&p(J),K(D,l),l&&p(g),K(E,l),l&&p(V),K(I,l),l&&p(L),K(w,l),l&&p(A),K(y,l),l&&p(T),K(_,l)}}}const At={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers",published:!0};function gt($,t,n){let a;lt($,pt,i=>n(1,a=i));let o=59;function d(){o>0?(n(0,o--,o),setTimeout(d,1e3)):(n(0,o=59),setTimeout(d,1e3))}return at(()=>{d()}),[o,a]}class Nt extends et{constructor(t){super();st(this,t,gt,yt,nt,{})}}export{Nt as default,At as metadata};
