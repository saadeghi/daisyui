import{S as Ee,i as Ne,s as ye,C as ne,w as O,x as T,y as L,z as Ie,A as _e,q as C,o as R,B as A,K as qe,ag as xe,k as I,m as q,g as D,d,e as p,t as E,c as m,a as h,h as N,b as u,F as i,a9 as H,Q as G,O as we,f as Pe}from"../../chunks/vendor-3400f70d.js";import{M as Se}from"../../chunks/_markdown-0009eda1.js";import{p as De,C as Qe,a as W,r as B}from"../../chunks/actions-921298e2.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-b30c3da6.js";import"../../chunks/index-13ae800f.js";import"../../chunks/SEO-224f676c.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-f74a1e78.js";function Ve(v){let e,o,a,r,s,c,t,l,g,$,b;return{c(){e=p("div"),o=p("div"),a=p("div"),r=p("h3"),s=E("Hello there"),c=I(),t=p("p"),l=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),g=I(),$=p("button"),b=E("Get Started"),this.h()},l(_){e=m(_,"DIV",{class:!0});var n=h(e);o=m(n,"DIV",{class:!0});var f=h(o);a=m(f,"DIV",{class:!0});var x=h(a);r=m(x,"H3",{class:!0});var P=h(r);s=N(P,"Hello there"),P.forEach(d),c=q(x),t=m(x,"P",{class:!0});var w=h(t);l=N(w,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),w.forEach(d),g=q(x),$=m(x,"BUTTON",{class:!0});var y=h($);b=N(y,"Get Started"),y.forEach(d),x.forEach(d),f.forEach(d),n.forEach(d),this.h()},h(){u(r,"class","text-5xl font-bold"),u(t,"class","py-6"),u($,"class","btn btn-primary"),u(a,"class","max-w-md"),u(o,"class","text-center hero-content"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(_,n){D(_,e,n),i(e,o),i(o,a),i(a,r),i(r,s),i(a,c),i(a,t),i(t,l),i(a,g),i(a,$),i($,b)},d(_){_&&d(e)}}}function He(v){let e,o=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold">Hello there</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ge(v){let e,o=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content text-center">
    <div className="max-w-md">
      <h1 className="text-5xl font-bold">Hello there</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Be(v){let e,o,a,r,s,c,t,l,g,$,b,_,n,f;return{c(){e=p("div"),o=p("div"),a=p("img"),s=I(),c=p("div"),t=p("h3"),l=E("Box Office News!"),g=I(),$=p("p"),b=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),_=I(),n=p("button"),f=E("Get Started"),this.h()},l(x){e=m(x,"DIV",{class:!0});var P=h(e);o=m(P,"DIV",{class:!0});var w=h(o);a=m(w,"IMG",{src:!0,class:!0,alt:!0}),s=q(w),c=m(w,"DIV",{});var y=h(c);t=m(y,"H3",{class:!0});var S=h(t);l=N(S,"Box Office News!"),S.forEach(d),g=q(y),$=m(y,"P",{class:!0});var Q=h($);b=N(Q,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),Q.forEach(d),_=q(y),n=m(y,"BUTTON",{class:!0});var V=h(n);f=N(V,"Get Started"),V.forEach(d),y.forEach(d),w.forEach(d),P.forEach(d),this.h()},h(){we(a.src,r="https://placeimg.com/260/400/arch")||u(a,"src",r),u(a,"class","max-w-sm rounded-lg shadow-2xl"),u(a,"alt","Tailwind CSS hero component"),u(t,"class","text-5xl font-bold"),u($,"class","py-6"),u(n,"class","btn btn-primary"),u(o,"class","flex-col hero-content lg:flex-row"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(x,P){D(x,e,P),i(e,o),i(o,a),i(o,s),i(o,c),i(c,t),i(t,l),i(c,g),i(c,$),i($,b),i(c,_),i(c,n),i(n,f)},d(x){x&&d(e)}}}function ke(v){let e,o=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row">
    <img src="https://placeimg.com/260/400/arch" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Oe(v){let e,o=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row">
    <img src="https://placeimg.com/260/400/arch" className="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 className="text-5xl font-bold">Box Office News!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Te(v){let e,o,a,r,s,c,t,l,g,$,b,_,n,f;return{c(){e=p("div"),o=p("div"),a=p("img"),s=I(),c=p("div"),t=p("h3"),l=E("Box Office News!"),g=I(),$=p("p"),b=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),_=I(),n=p("button"),f=E("Get Started"),this.h()},l(x){e=m(x,"DIV",{class:!0});var P=h(e);o=m(P,"DIV",{class:!0});var w=h(o);a=m(w,"IMG",{src:!0,class:!0,alt:!0}),s=q(w),c=m(w,"DIV",{});var y=h(c);t=m(y,"H3",{class:!0});var S=h(t);l=N(S,"Box Office News!"),S.forEach(d),g=q(y),$=m(y,"P",{class:!0});var Q=h($);b=N(Q,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),Q.forEach(d),_=q(y),n=m(y,"BUTTON",{class:!0});var V=h(n);f=N(V,"Get Started"),V.forEach(d),y.forEach(d),w.forEach(d),P.forEach(d),this.h()},h(){we(a.src,r="https://placeimg.com/260/400/arch")||u(a,"src",r),u(a,"class","max-w-sm rounded-lg shadow-2xl"),u(a,"alt","Tailwind CSS hero component"),u(t,"class","text-5xl font-bold"),u($,"class","py-6"),u(n,"class","btn btn-primary"),u(o,"class","flex-col hero-content lg:flex-row-reverse"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(x,P){D(x,e,P),i(e,o),i(o,a),i(o,s),i(o,c),i(c,t),i(t,l),i(c,g),i(c,$),i($,b),i(c,_),i(c,n),i(n,f)},d(x){x&&d(e)}}}function Le(v){let e,o=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <img src="https://placeimg.com/260/400/arch" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ce(v){let e,o=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row-reverse">
    <img src="https://placeimg.com/260/400/arch" className="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 className="text-5xl font-bold">Box Office News!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Re(v){let e,o,a,r,s,c,t,l,g,$,b,_,n,f,x,P,w,y,S,Q,V,te,ae,U,le,F,k,se,re,M,j,ie;return{c(){e=p("div"),o=p("div"),a=p("div"),r=p("h3"),s=E("Login now!"),c=I(),t=p("p"),l=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),g=I(),$=p("div"),b=p("div"),_=p("div"),n=p("label"),f=p("span"),x=E("Email"),P=I(),w=p("input"),y=I(),S=p("div"),Q=p("label"),V=p("span"),te=E("Password"),ae=I(),U=p("input"),le=I(),F=p("label"),k=p("a"),se=E("Forgot password?"),re=I(),M=p("div"),j=p("button"),ie=E("Login"),this.h()},l(J){e=m(J,"DIV",{class:!0});var X=h(e);o=m(X,"DIV",{class:!0});var Y=h(o);a=m(Y,"DIV",{class:!0});var Z=h(a);r=m(Z,"H3",{class:!0});var oe=h(r);s=N(oe,"Login now!"),oe.forEach(d),c=q(Z),t=m(Z,"P",{class:!0});var ce=h(t);l=N(ce,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),ce.forEach(d),Z.forEach(d),g=q(Y),$=m(Y,"DIV",{class:!0});var de=h($);b=m(de,"DIV",{class:!0});var z=h(b);_=m(z,"DIV",{class:!0});var ee=h(_);n=m(ee,"LABEL",{class:!0});var ue=h(n);f=m(ue,"SPAN",{class:!0});var pe=h(f);x=N(pe,"Email"),pe.forEach(d),ue.forEach(d),P=q(ee),w=m(ee,"INPUT",{type:!0,placeholder:!0,class:!0}),ee.forEach(d),y=q(z),S=m(z,"DIV",{class:!0});var K=h(S);Q=m(K,"LABEL",{class:!0});var me=h(Q);V=m(me,"SPAN",{class:!0});var he=h(V);te=N(he,"Password"),he.forEach(d),me.forEach(d),ae=q(K),U=m(K,"INPUT",{type:!0,placeholder:!0,class:!0}),le=q(K),F=m(K,"LABEL",{class:!0});var fe=h(F);k=m(fe,"A",{href:!0,class:!0});var ve=h(k);se=N(ve,"Forgot password?"),ve.forEach(d),fe.forEach(d),K.forEach(d),re=q(z),M=m(z,"DIV",{class:!0});var $e=h(M);j=m($e,"BUTTON",{class:!0});var be=h(j);ie=N(be,"Login"),be.forEach(d),$e.forEach(d),z.forEach(d),de.forEach(d),Y.forEach(d),X.forEach(d),this.h()},h(){u(r,"class","text-5xl font-bold"),u(t,"class","py-6"),u(a,"class","text-center lg:text-left"),u(f,"class","label-text"),u(n,"class","label"),u(w,"type","text"),u(w,"placeholder","email"),u(w,"class","input input-bordered"),u(_,"class","form-control"),u(V,"class","label-text"),u(Q,"class","label"),u(U,"type","text"),u(U,"placeholder","password"),u(U,"class","input input-bordered"),u(k,"href","#"),u(k,"class","label-text-alt link link-hover"),u(F,"class","label"),u(S,"class","form-control"),u(j,"class","btn btn-primary"),u(M,"class","form-control mt-6"),u(b,"class","card-body"),u($,"class","card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100"),u(o,"class","flex-col hero-content lg:flex-row-reverse"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(J,X){D(J,e,X),i(e,o),i(o,a),i(a,r),i(r,s),i(a,c),i(a,t),i(t,l),i(o,g),i(o,$),i($,b),i(b,_),i(_,n),i(n,f),i(f,x),i(_,P),i(_,w),i(b,y),i(b,S),i(S,Q),i(Q,V),i(V,te),i(S,ae),i(S,U),i(S,le),i(S,F),i(F,k),i(k,se),i(b,re),i(b,M),i(M,j),i(j,ie)},d(J){J&&d(e)}}}function Ae(v){let e,o=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <div class="text-center lg:text-left">
      <h1 class="text-5xl font-bold">Login now!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
    </div>
    <div class="$$card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
      <div class="$$card-body">
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Email</span>
          </label>
          <input type="text" placeholder="email" class="$$input $$input-bordered" />
        </div>
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Password</span>
          </label>
          <input type="text" placeholder="password" class="$$input $$input-bordered" />
          <label class="$$label">
            <a href="#" class="$$label-text-alt $$link $$link-hover">Forgot password?</a>
          </label>
        </div>
        <div class="$$form-control mt-6">
          <button class="$$btn $$btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ue(v){let e,o=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row-reverse">
    <div className="text-center lg:text-left">
      <h1 className="text-5xl font-bold">Login now!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
    </div>
    <div className="$$card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
      <div className="$$card-body">
        <div className="$$form-control">
          <label className="$$label">
            <span className="$$label-text">Email</span>
          </label>
          <input type="text" placeholder="email" className="$$input $$input-bordered" />
        </div>
        <div className="$$form-control">
          <label className="$$label">
            <span className="$$label-text">Password</span>
          </label>
          <input type="text" placeholder="password" className="$$input $$input-bordered" />
          <label className="$$label">
            <a href="#" className="$$label-text-alt $$link $$link-hover">Forgot password?</a>
          </label>
        </div>
        <div className="$$form-control mt-6">
          <button className="$$btn $$btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Fe(v){let e,o,a,r,s,c,t,l,g,$,b,_,n;return{c(){e=p("div"),o=p("div"),a=I(),r=p("div"),s=p("div"),c=p("h1"),t=E("Hello there"),l=I(),g=p("p"),$=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),b=I(),_=p("button"),n=E("Get Started"),this.h()},l(f){e=m(f,"DIV",{class:!0,style:!0});var x=h(e);o=m(x,"DIV",{class:!0}),h(o).forEach(d),a=q(x),r=m(x,"DIV",{class:!0});var P=h(r);s=m(P,"DIV",{class:!0});var w=h(s);c=m(w,"H1",{class:!0});var y=h(c);t=N(y,"Hello there"),y.forEach(d),l=q(w),g=m(w,"P",{class:!0});var S=h(g);$=N(S,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),S.forEach(d),b=q(w),_=m(w,"BUTTON",{class:!0});var Q=h(_);n=N(Q,"Get Started"),Q.forEach(d),w.forEach(d),P.forEach(d),x.forEach(d),this.h()},h(){u(o,"class","hero-overlay rounded bg-opacity-60"),u(c,"class","mb-5 text-5xl font-bold"),u(g,"class","mb-5"),u(_,"class","btn btn-primary"),u(s,"class","max-w-md"),u(r,"class","text-center hero-content text-neutral-content"),u(e,"class","hero min-h-[30rem] rounded"),Pe(e,"background-image","url(https://placeimg.com/1000/800/arch)")},m(f,x){D(f,e,x),i(e,o),i(e,a),i(e,r),i(r,s),i(s,c),i(c,t),i(s,l),i(s,g),i(g,$),i(s,b),i(s,_),i(_,n)},d(f){f&&d(e)}}}function Me(v){let e,o=`<div class="$$hero min-h-screen" style="background-image: url(https://placeimg.com/1000/800/arch);">
  <div class="$$hero-overlay bg-opacity-60"></div>
  <div class="$$hero-content text-center text-neutral-content">
    <div class="max-w-md">
      <h1 class="mb-5 text-5xl font-bold">Hello there</h1>
      <p class="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function je(v){let e,o=`<div className="$$hero min-h-screen" style={{ backgroundImage: \`url("https://placeimg.com/1000/800/arch")\` }}>
  <div className="$$hero-overlay bg-opacity-60"></div>
  <div className="$$hero-content text-center text-neutral-content">
    <div className="max-w-md">
      <h1 className="mb-5 text-5xl font-bold">Hello there</h1>
      <p className="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,r,s,c;return{c(){e=p("pre"),a=E(o),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=h(e);a=N(l,o),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){D(t,e,l),i(e,a),s||(c=H(r=B.call(null,e,{to:v[0]})),s=!0)},p(t,l){r&&G(r.update)&&l&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function ze(v){let e,o,a,r,s,c,t,l,g,$,b,_;return e=new Qe({props:{data:[{type:"component",class:"hero",desc:"Container element"},{type:"component",class:"hero-content",desc:"Container for content"},{type:"component",class:"hero-overlay",desc:"Overlay that covers the background image"}]}}),a=new W({props:{title:"Centered hero",$$slots:{react:[Ge],html:[He],default:[Ve]},$$scope:{ctx:v}}}),s=new W({props:{title:"Hero with figure",$$slots:{react:[Oe],html:[ke],default:[Be]},$$scope:{ctx:v}}}),t=new W({props:{title:"Hero with figure but reverse order",$$slots:{react:[Ce],html:[Le],default:[Te]},$$scope:{ctx:v}}}),g=new W({props:{title:"Hero with form",$$slots:{react:[Ue],html:[Ae],default:[Re]},$$scope:{ctx:v}}}),b=new W({props:{title:"Hero with overlay image",$$slots:{react:[je],html:[Me],default:[Fe]},$$scope:{ctx:v}}}),{c(){O(e.$$.fragment),o=I(),O(a.$$.fragment),r=I(),O(s.$$.fragment),c=I(),O(t.$$.fragment),l=I(),O(g.$$.fragment),$=I(),O(b.$$.fragment)},l(n){T(e.$$.fragment,n),o=q(n),T(a.$$.fragment,n),r=q(n),T(s.$$.fragment,n),c=q(n),T(t.$$.fragment,n),l=q(n),T(g.$$.fragment,n),$=q(n),T(b.$$.fragment,n)},m(n,f){L(e,n,f),D(n,o,f),L(a,n,f),D(n,r,f),L(s,n,f),D(n,c,f),L(t,n,f),D(n,l,f),L(g,n,f),D(n,$,f),L(b,n,f),_=!0},p(n,f){const x={};f&5&&(x.$$scope={dirty:f,ctx:n}),a.$set(x);const P={};f&5&&(P.$$scope={dirty:f,ctx:n}),s.$set(P);const w={};f&5&&(w.$$scope={dirty:f,ctx:n}),t.$set(w);const y={};f&5&&(y.$$scope={dirty:f,ctx:n}),g.$set(y);const S={};f&5&&(S.$$scope={dirty:f,ctx:n}),b.$set(S)},i(n){_||(C(e.$$.fragment,n),C(a.$$.fragment,n),C(s.$$.fragment,n),C(t.$$.fragment,n),C(g.$$.fragment,n),C(b.$$.fragment,n),_=!0)},o(n){R(e.$$.fragment,n),R(a.$$.fragment,n),R(s.$$.fragment,n),R(t.$$.fragment,n),R(g.$$.fragment,n),R(b.$$.fragment,n),_=!1},d(n){A(e,n),n&&d(o),A(a,n),n&&d(r),A(s,n),n&&d(c),A(t,n),n&&d(l),A(g,n),n&&d($),A(b,n)}}}function Ke(v){let e,o;const a=[v[1],ge];let r={$$slots:{default:[ze]},$$scope:{ctx:v}};for(let s=0;s<a.length;s+=1)r=ne(r,a[s]);return e=new Se({props:r}),{c(){O(e.$$.fragment)},l(s){T(e.$$.fragment,s)},m(s,c){L(e,s,c),o=!0},p(s,[c]){const t=c&2?Ie(a,[c&2&&_e(s[1]),c&0&&_e(ge)]):{};c&5&&(t.$$scope={dirty:c,ctx:s}),e.$set(t)},i(s){o||(C(e.$$.fragment,s),o=!0)},o(s){R(e.$$.fragment,s),o=!1},d(s){A(e,s)}}}const ge={title:"Hero",desc:"Hero is a component for displaying a large box or image with a title and description.",published:!0};function Je(v,e,o){let a;return qe(v,De,r=>o(0,a=r)),v.$$set=r=>{o(1,e=ne(ne({},e),xe(r)))},e=xe(e),[a,e]}class rt extends Ee{constructor(e){super();Ne(this,e,Je,Ke,ye,{})}}export{rt as default,ge as metadata};
