import{S as O,i as Q,s as U,C as q,w as k,x as w,y as E,z as V,A as G,q as M,o as C,B as P,K as X,ag as H,k as A,m as L,g as u,d,e as f,t as $,c as h,a as b,h as _,b as p,F as g,a9 as I,W as T}from"../../chunks/vendor-c5cb7521.js";import{M as Z}from"../../chunks/_markdown-cb8219e9.js";import{p as ee,C as te,a as Y,r as W}from"../../chunks/actions-23e43a16.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-01eee55c.js";import"../../chunks/index-93366905.js";import"../../chunks/SEO-b90857e2.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-fcdb19d7.js";function oe(m){let e,s;return{c(){e=f("label"),s=$("open modal"),this.h()},l(t){e=h(t,"LABEL",{for:!0,class:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"for","my-modal"),p(e,"class","btn modal-button")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function le(m){let e,s=`<!-- The button to open modal -->
<label for="my-modal" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function ae(m){let e,s;return{c(){e=f("a"),s=$("open modal"),this.h()},l(t){e=h(t,"A",{href:!0,class:!0,rel:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"href","#my-modal-2"),p(e,"class","btn"),p(e,"rel","external")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function se(m){let e,s=`<!-- The button to open modal -->
<a href="#my-modal-2" class="$$btn">open modal</a>
<!-- Put this part before </body> tag -->
<div class="$$modal" id="my-modal-2">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
     <a href="#" class="$$btn">Yay!</a>
    </div>
  </div>
</div>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function ne(m){let e,s;return{c(){e=f("label"),s=$("open modal"),this.h()},l(t){e=h(t,"LABEL",{for:!0,class:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"for","my-modal-3"),p(e,"class","btn modal-button")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function re(m){let e,s=`<!-- The button to open modal -->
<label for="my-modal-3" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-3" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box relative">
    <label for="my-modal-3" class="$$btn $$btn-sm $$btn-circle absolute right-2 top-2">\u2715</label>
    <h3 class="text-lg font-bold">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </div>
</div>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function me(m){let e,s;return{c(){e=f("label"),s=$("open modal"),this.h()},l(t){e=h(t,"LABEL",{for:!0,class:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"for","my-modal-4"),p(e,"class","btn modal-button")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function ce(m){let e,s=`<!-- The button to open modal -->
<label for="my-modal-4" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-4" class="$$modal-toggle" />
<label for="my-modal-4" class="$$modal cursor-pointer">
  <label class="$$modal-box relative" for="">
    <h3 class="text-lg font-bold">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </label>
</label>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function de(m){let e,s;return{c(){e=f("label"),s=$("open modal"),this.h()},l(t){e=h(t,"LABEL",{for:!0,class:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"for","my-modal-5"),p(e,"class","btn modal-button")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function ie(m){let e,s=`<!-- The button to open modal -->
<label for="my-modal-5" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-5" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box w-11/12 max-w-5xl">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal-5" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function pe(m){let e,s;return{c(){e=f("label"),s=$("open modal"),this.h()},l(t){e=h(t,"LABEL",{for:!0,class:!0});var o=b(e);s=_(o,"open modal"),o.forEach(d),this.h()},h(){p(e,"for","my-modal-6"),p(e,"class","btn modal-button")},m(t,o){u(t,e,o),g(e,s)},d(t){t&&d(e)}}}function ue(m){let e,s=`<!-- The button to open modal -->
<label for="my-modal-6" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-6" class="$$modal-toggle" />
<div class="$$modal $$modal-bottom sm:$$modal-middle">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal-6" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,t,o,n,c;return{c(){e=f("pre"),t=$(s),this.h()},l(a){e=h(a,"PRE",{slot:!0});var r=b(e);t=_(r,s),r.forEach(d),this.h()},h(){p(e,"slot","html")},m(a,r){u(a,e,r),g(e,t),n||(c=I(o=W.call(null,e,{to:m[0]})),n=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),n=!1,c()}}}function fe(m){let e,s,t,o,n,c,a,r,v,R,y,B,x,S;return e=new te({props:{data:[{type:"component",class:"modal",desc:"Container element"},{type:"component",class:"modal-box",desc:"The content of modal"},{type:"component",class:"modal-action",desc:"Container for modal buttons"},{type:"component",class:"modal-toggle",desc:"For checkbox that controls modal"},{type:"component",class:"modal-button",desc:"For <label> that checks the checkbox to opens/closes modal"},{type:"modifier",class:"modal-open",desc:"Add/remove this class to open/close the modal using JS"},{type:"responsive",class:"modal-bottom",desc:"Moves the modal to bottom"},{type:"responsive",class:"modal-middle",desc:"Moves the modal to middle (default)"}]}}),t=new Y({props:{title:"Modal using label + hidden checkbox",desc:'Make sure each modal you use, has a unique ID. In this example, ID is "my-modal".',$$slots:{html:[le],default:[oe]},$$scope:{ctx:m}}}),n=new Y({props:{title:"Modal using anchor link",desc:"Anchor links might not work well on some SPA frameworks so if there are problems, use the first example",$$slots:{html:[se],default:[ae]},$$scope:{ctx:m}}}),a=new Y({props:{title:"Modal using with a close button at corner",$$slots:{html:[re],default:[ne]},$$scope:{ctx:m}}}),v=new Y({props:{title:"Modal that closes when clicked outside",desc:"Modal works with a hidden checkbox and labels can toggle the checkbox so we can use a label tag for the whole modal and use another label for modal-box to prevent closing when modal-box is clicked",$$slots:{html:[ce],default:[me]},$$scope:{ctx:m}}}),y=new Y({props:{title:"Modal with custom width",desc:"We remove max-width so we can use a custom size",$$slots:{html:[ie],default:[de]},$$scope:{ctx:m}}}),x=new Y({props:{title:"Responsive: Modal goes bottom on mobile screen and goes middle on desktop",$$slots:{html:[ue],default:[pe]},$$scope:{ctx:m}}}),{c(){k(e.$$.fragment),s=A(),k(t.$$.fragment),o=A(),k(n.$$.fragment),c=A(),k(a.$$.fragment),r=A(),k(v.$$.fragment),R=A(),k(y.$$.fragment),B=A(),k(x.$$.fragment)},l(l){w(e.$$.fragment,l),s=L(l),w(t.$$.fragment,l),o=L(l),w(n.$$.fragment,l),c=L(l),w(a.$$.fragment,l),r=L(l),w(v.$$.fragment,l),R=L(l),w(y.$$.fragment,l),B=L(l),w(x.$$.fragment,l)},m(l,i){E(e,l,i),u(l,s,i),E(t,l,i),u(l,o,i),E(n,l,i),u(l,c,i),E(a,l,i),u(l,r,i),E(v,l,i),u(l,R,i),E(y,l,i),u(l,B,i),E(x,l,i),S=!0},p(l,i){const F={};i&5&&(F.$$scope={dirty:i,ctx:l}),t.$set(F);const z={};i&5&&(z.$$scope={dirty:i,ctx:l}),n.$set(z);const D={};i&5&&(D.$$scope={dirty:i,ctx:l}),a.$set(D);const j={};i&5&&(j.$$scope={dirty:i,ctx:l}),v.$set(j);const J={};i&5&&(J.$$scope={dirty:i,ctx:l}),y.$set(J);const K={};i&5&&(K.$$scope={dirty:i,ctx:l}),x.$set(K)},i(l){S||(M(e.$$.fragment,l),M(t.$$.fragment,l),M(n.$$.fragment,l),M(a.$$.fragment,l),M(v.$$.fragment,l),M(y.$$.fragment,l),M(x.$$.fragment,l),S=!0)},o(l){C(e.$$.fragment,l),C(t.$$.fragment,l),C(n.$$.fragment,l),C(a.$$.fragment,l),C(v.$$.fragment,l),C(y.$$.fragment,l),C(x.$$.fragment,l),S=!1},d(l){P(e,l),l&&d(s),P(t,l),l&&d(o),P(n,l),l&&d(c),P(a,l),l&&d(r),P(v,l),l&&d(R),P(y,l),l&&d(B),P(x,l)}}}function $e(m){let e,s;const t=[m[1],N];let o={$$slots:{default:[fe]},$$scope:{ctx:m}};for(let n=0;n<t.length;n+=1)o=q(o,t[n]);return e=new Z({props:o}),{c(){k(e.$$.fragment)},l(n){w(e.$$.fragment,n)},m(n,c){E(e,n,c),s=!0},p(n,[c]){const a=c&2?V(t,[c&2&&G(n[1]),c&0&&G(N)]):{};c&5&&(a.$$scope={dirty:c,ctx:n}),e.$set(a)},i(n){s||(M(e.$$.fragment,n),s=!0)},o(n){C(e.$$.fragment,n),s=!1},d(n){P(e,n)}}}const N={title:"Modal",desc:"Modal is used to show a dialog or a box when you click a button.",published:!0};function he(m,e,s){let t;return X(m,ee,o=>s(0,t=o)),m.$$set=o=>{s(1,e=q(q({},e),H(o)))},e=H(e),[t,e]}class Me extends O{constructor(e){super();Q(this,e,he,$e,U,{})}}export{Me as default,N as metadata};
