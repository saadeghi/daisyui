import{S as Wt,i as Ht,s as Jt,C as Ut,w as F,x as G,y as K,z as Lt,A as Gt,q as Q,o as W,B as H,K as Xt,ag as Kt,k as N,m as T,g as x,d as c,e as $,t as m,c as i,a as d,h as _,b as f,F as s,a9 as C,Q as q}from"../../chunks/vendor-3400f70d.js";import{M as Yt}from"../../chunks/_markdown-9f09a4b6.js";import{p as Zt,C as yt,a as at,r as S}from"../../chunks/actions-e99283e9.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-f7bbbf56.js";import"../../chunks/index-c84d4ef2.js";import"../../chunks/SEO-63184e7b.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-bef29b39.js";function te(v){let t,o,u,a,l,r,e,n,g,E,h,B;return{c(){t=$("div"),o=$("button"),u=m("1"),a=N(),l=$("button"),r=m("2"),e=N(),n=$("button"),g=m("3"),E=N(),h=$("button"),B=m("4"),this.h()},l(b){t=i(b,"DIV",{class:!0});var p=d(t);o=i(p,"BUTTON",{class:!0});var O=d(o);u=_(O,"1"),O.forEach(c),a=T(p),l=i(p,"BUTTON",{class:!0});var P=d(l);r=_(P,"2"),P.forEach(c),e=T(p),n=i(p,"BUTTON",{class:!0});var U=d(n);g=_(U,"3"),U.forEach(c),E=T(p),h=i(p,"BUTTON",{class:!0});var w=d(h);B=_(w,"4"),w.forEach(c),p.forEach(c),this.h()},h(){f(o,"class","btn"),f(l,"class","btn btn-active"),f(n,"class","btn"),f(h,"class","btn"),f(t,"class","btn-group")},m(b,p){x(b,t,p),s(t,o),s(o,u),s(t,a),s(t,l),s(l,r),s(t,e),s(t,n),s(n,g),s(t,E),s(t,h),s(h,B)},d(b){b&&c(t)}}}function ee(v){let t,o=`<div class="$$btn-group">
  <button class="$$btn">1</button>
  <button class="$$btn $$btn-active">2</button>
  <button class="$$btn">3</button>
  <button class="$$btn">4</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","html")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function ne(v){let t,o=`<div className="$$btn-group">
  <button className="$$btn">1</button>
  <button className="$$btn $$btn-active">2</button>
  <button className="$$btn">3</button>
  <button className="$$btn">4</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","react")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function se(v){let t,o,u,a,l,r,e,n,g,E,h,B,b,p,O,P,U,w,R,J,L,k,ut,bt,X,ct,rt,D,Y,$t,it,Z,dt,ft,y,pt,mt,tt,_t,vt,I,et,ht,gt,nt,Nt,Tt,st,Et,Bt,lt,Ot;return{c(){t=$("div"),o=$("div"),u=$("button"),a=m("1"),l=N(),r=$("button"),e=m("2"),n=N(),g=$("button"),E=m("3"),h=N(),B=$("button"),b=m("4"),p=N(),O=$("div"),P=$("button"),U=m("1"),w=N(),R=$("button"),J=m("2"),L=N(),k=$("button"),ut=m("3"),bt=N(),X=$("button"),ct=m("4"),rt=N(),D=$("div"),Y=$("button"),$t=m("1"),it=N(),Z=$("button"),dt=m("2"),ft=N(),y=$("button"),pt=m("3"),mt=N(),tt=$("button"),_t=m("4"),vt=N(),I=$("div"),et=$("button"),ht=m("1"),gt=N(),nt=$("button"),Nt=m("2"),Tt=N(),st=$("button"),Et=m("3"),Bt=N(),lt=$("button"),Ot=m("4"),this.h()},l(ot){t=i(ot,"DIV",{class:!0});var V=d(t);o=i(V,"DIV",{class:!0});var z=d(o);u=i(z,"BUTTON",{class:!0});var xt=d(u);a=_(xt,"1"),xt.forEach(c),l=T(z),r=i(z,"BUTTON",{class:!0});var Pt=d(r);e=_(Pt,"2"),Pt.forEach(c),n=T(z),g=i(z,"BUTTON",{class:!0});var wt=d(g);E=_(wt,"3"),wt.forEach(c),h=T(z),B=i(z,"BUTTON",{class:!0});var Rt=d(B);b=_(Rt,"4"),Rt.forEach(c),z.forEach(c),p=T(V),O=i(V,"DIV",{class:!0});var M=d(O);P=i(M,"BUTTON",{class:!0});var Dt=d(P);U=_(Dt,"1"),Dt.forEach(c),w=T(M),R=i(M,"BUTTON",{class:!0});var It=d(R);J=_(It,"2"),It.forEach(c),L=T(M),k=i(M,"BUTTON",{class:!0});var Vt=d(k);ut=_(Vt,"3"),Vt.forEach(c),bt=T(M),X=i(M,"BUTTON",{class:!0});var Ct=d(X);ct=_(Ct,"4"),Ct.forEach(c),M.forEach(c),rt=T(V),D=i(V,"DIV",{class:!0});var j=d(D);Y=i(j,"BUTTON",{class:!0});var qt=d(Y);$t=_(qt,"1"),qt.forEach(c),it=T(j),Z=i(j,"BUTTON",{class:!0});var St=d(Z);dt=_(St,"2"),St.forEach(c),ft=T(j),y=i(j,"BUTTON",{class:!0});var kt=d(y);pt=_(kt,"3"),kt.forEach(c),mt=T(j),tt=i(j,"BUTTON",{class:!0});var zt=d(tt);_t=_(zt,"4"),zt.forEach(c),j.forEach(c),vt=T(V),I=i(V,"DIV",{class:!0});var A=d(I);et=i(A,"BUTTON",{class:!0});var Mt=d(et);ht=_(Mt,"1"),Mt.forEach(c),gt=T(A),nt=i(A,"BUTTON",{class:!0});var jt=d(nt);Nt=_(jt,"2"),jt.forEach(c),Tt=T(A),st=i(A,"BUTTON",{class:!0});var At=d(st);Et=_(At,"3"),At.forEach(c),Bt=T(A),lt=i(A,"BUTTON",{class:!0});var Ft=d(lt);Ot=_(Ft,"4"),Ft.forEach(c),A.forEach(c),V.forEach(c),this.h()},h(){f(u,"class","btn btn-xs"),f(r,"class","btn btn-xs btn-active"),f(g,"class","btn btn-xs"),f(B,"class","btn btn-xs"),f(o,"class","btn-group"),f(P,"class","btn btn-sm"),f(R,"class","btn btn-sm btn-active"),f(k,"class","btn btn-sm"),f(X,"class","btn btn-sm"),f(O,"class","btn-group"),f(Y,"class","btn btn-md"),f(Z,"class","btn btn-md btn-active"),f(y,"class","btn btn-md"),f(tt,"class","btn btn-md"),f(D,"class","btn-group"),f(et,"class","btn btn-lg"),f(nt,"class","btn btn-lg btn-active"),f(st,"class","btn btn-lg"),f(lt,"class","btn btn-lg"),f(I,"class","btn-group"),f(t,"class","flex flex-col gap-2 items-center")},m(ot,V){x(ot,t,V),s(t,o),s(o,u),s(u,a),s(o,l),s(o,r),s(r,e),s(o,n),s(o,g),s(g,E),s(o,h),s(o,B),s(B,b),s(t,p),s(t,O),s(O,P),s(P,U),s(O,w),s(O,R),s(R,J),s(O,L),s(O,k),s(k,ut),s(O,bt),s(O,X),s(X,ct),s(t,rt),s(t,D),s(D,Y),s(Y,$t),s(D,it),s(D,Z),s(Z,dt),s(D,ft),s(D,y),s(y,pt),s(D,mt),s(D,tt),s(tt,_t),s(t,vt),s(t,I),s(I,et),s(et,ht),s(I,gt),s(I,nt),s(nt,Nt),s(I,Tt),s(I,st),s(st,Et),s(I,Bt),s(I,lt),s(lt,Ot)},d(ot){ot&&c(t)}}}function le(v){let t,o=`<div class="$$btn-group">
  <button class="$$btn $$btn-xs">1</button>
  <button class="$$btn $$btn-xs $$btn-active">2</button>
  <button class="$$btn $$btn-xs">3</button>
  <button class="$$btn $$btn-xs">4</button>
</div>
<div class="$$btn-group">
  <button class="$$btn $$btn-sm">1</button>
  <button class="$$btn $$btn-sm $$btn-active">2</button>
  <button class="$$btn $$btn-sm">3</button>
  <button class="$$btn $$btn-sm">4</button>
</div>
<div class="$$btn-group">
  <button class="$$btn $$btn-md">1</button>
  <button class="$$btn $$btn-md $$btn-active">2</button>
  <button class="$$btn $$btn-md">3</button>
  <button class="$$btn $$btn-md">4</button>
</div>
<div class="$$btn-group">
  <button class="$$btn $$btn-lg">1</button>
  <button class="$$btn $$btn-lg $$btn-active">2</button>
  <button class="$$btn $$btn-lg">3</button>
  <button class="$$btn $$btn-lg">4</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","html")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function oe(v){let t,o=`<div className="$$btn-group">
  <button className="$$btn $$btn-xs">1</button>
  <button className="$$btn $$btn-xs $$btn-active">2</button>
  <button className="$$btn $$btn-xs">3</button>
  <button className="$$btn $$btn-xs">4</button>
</div>
<div className="$$btn-group">
  <button className="$$btn $$btn-sm">1</button>
  <button className="$$btn $$btn-sm $$btn-active">2</button>
  <button className="$$btn $$btn-sm">3</button>
  <button className="$$btn $$btn-sm">4</button>
</div>
<div className="$$btn-group">
  <button className="$$btn $$btn-md">1</button>
  <button className="$$btn $$btn-md $$btn-active">2</button>
  <button className="$$btn $$btn-md">3</button>
  <button className="$$btn $$btn-md">4</button>
</div>
<div className="$$btn-group">
  <button className="$$btn $$btn-lg">1</button>
  <button className="$$btn $$btn-lg $$btn-active">2</button>
  <button className="$$btn $$btn-lg">3</button>
  <button className="$$btn $$btn-lg">4</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","react")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function ae(v){let t,o,u,a,l,r,e,n,g,E,h,B,b,p,O;return{c(){t=$("div"),o=$("button"),u=m("1"),a=N(),l=$("button"),r=m("2"),e=N(),n=$("button"),g=m("..."),E=N(),h=$("button"),B=m("99"),b=N(),p=$("button"),O=m("100"),this.h()},l(P){t=i(P,"DIV",{class:!0});var U=d(t);o=i(U,"BUTTON",{class:!0});var w=d(o);u=_(w,"1"),w.forEach(c),a=T(U),l=i(U,"BUTTON",{class:!0});var R=d(l);r=_(R,"2"),R.forEach(c),e=T(U),n=i(U,"BUTTON",{class:!0});var J=d(n);g=_(J,"..."),J.forEach(c),E=T(U),h=i(U,"BUTTON",{class:!0});var L=d(h);B=_(L,"99"),L.forEach(c),b=T(U),p=i(U,"BUTTON",{class:!0});var k=d(p);O=_(k,"100"),k.forEach(c),U.forEach(c),this.h()},h(){f(o,"class","btn"),f(l,"class","btn"),f(n,"class","btn btn-disabled"),f(h,"class","btn"),f(p,"class","btn"),f(t,"class","btn-group")},m(P,U){x(P,t,U),s(t,o),s(o,u),s(t,a),s(t,l),s(l,r),s(t,e),s(t,n),s(n,g),s(t,E),s(t,h),s(h,B),s(t,b),s(t,p),s(p,O)},d(P){P&&c(t)}}}function ue(v){let t,o=`<div class="$$btn-group">
  <button class="$$btn">1</button>
  <button class="$$btn">2</button>
  <button class="$$btn $$btn-disabled">...</button>
  <button class="$$btn">99</button>
  <button class="$$btn">100</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","html")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function be(v){let t,o=`<div className="$$btn-group">
  <button className="$$btn">1</button>
  <button className="$$btn">2</button>
  <button className="$$btn $$btn-disabled">...</button>
  <button className="$$btn">99</button>
  <button className="$$btn">100</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","react")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function ce(v){let t,o,u,a,l,r,e,n,g;return{c(){t=$("div"),o=$("button"),u=m("\xAB"),a=N(),l=$("button"),r=m("Page 22"),e=N(),n=$("button"),g=m("\xBB"),this.h()},l(E){t=i(E,"DIV",{class:!0});var h=d(t);o=i(h,"BUTTON",{class:!0});var B=d(o);u=_(B,"\xAB"),B.forEach(c),a=T(h),l=i(h,"BUTTON",{class:!0});var b=d(l);r=_(b,"Page 22"),b.forEach(c),e=T(h),n=i(h,"BUTTON",{class:!0});var p=d(n);g=_(p,"\xBB"),p.forEach(c),h.forEach(c),this.h()},h(){f(o,"class","btn"),f(l,"class","btn"),f(n,"class","btn"),f(t,"class","btn-group")},m(E,h){x(E,t,h),s(t,o),s(o,u),s(t,a),s(t,l),s(l,r),s(t,e),s(t,n),s(n,g)},d(E){E&&c(t)}}}function re(v){let t,o=`<div class="$$btn-group">
  <button class="$$btn">\xAB</button>
  <button class="$$btn">Page 22</button>
  <button class="$$btn">\xBB</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","html")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function $e(v){let t,o=`<div className="$$btn-group">
  <button className="$$btn">\xAB</button>
  <button className="$$btn">Page 22</button>
  <button className="$$btn">\xBB</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","react")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function ie(v){let t,o,u,a,l,r;return{c(){t=$("div"),o=$("button"),u=m("Previous page"),a=N(),l=$("button"),r=m("Next"),this.h()},l(e){t=i(e,"DIV",{class:!0});var n=d(t);o=i(n,"BUTTON",{class:!0});var g=d(o);u=_(g,"Previous page"),g.forEach(c),a=T(n),l=i(n,"BUTTON",{class:!0});var E=d(l);r=_(E,"Next"),E.forEach(c),n.forEach(c),this.h()},h(){f(o,"class","btn btn-outline"),f(l,"class","btn btn-outline"),f(t,"class","btn-group grid grid-cols-2")},m(e,n){x(e,t,n),s(t,o),s(o,u),s(t,a),s(t,l),s(l,r)},d(e){e&&c(t)}}}function de(v){let t,o=`<div class="$$btn-group grid grid-cols-2">
  <button class="$$btn $$btn-outline">Previous page</button>
  <button class="$$btn $$btn-outline">Next</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","html")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function fe(v){let t,o=`<div className="$$btn-group grid grid-cols-2">
  <button className="$$btn $$btn-outline">Previous page</button>
  <button className="$$btn $$btn-outline">Next</button>
</div>`,u,a,l,r;return{c(){t=$("pre"),u=m(o),this.h()},l(e){t=i(e,"PRE",{slot:!0});var n=d(t);u=_(n,o),n.forEach(c),this.h()},h(){f(t,"slot","react")},m(e,n){x(e,t,n),s(t,u),l||(r=C(a=S.call(null,t,{to:v[0]})),l=!0)},p(e,n){a&&q(a.update)&&n&1&&a.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,r()}}}function pe(v){let t,o,u,a,l,r,e,n,g,E,h,B;return t=new yt({props:{data:[{type:"component",class:"btn-group",desc:"Groups buttons together"}]}}),u=new at({props:{title:"Pagination with an active button",$$slots:{react:[ne],html:[ee],default:[te]},$$scope:{ctx:v}}}),l=new at({props:{title:"Sizes",$$slots:{react:[oe],html:[le],default:[se]},$$scope:{ctx:v}}}),e=new at({props:{title:"With a disabled button",$$slots:{react:[be],html:[ue],default:[ae]},$$scope:{ctx:v}}}),g=new at({props:{title:"Extra small buttons",$$slots:{react:[$e],html:[re],default:[ce]},$$scope:{ctx:v}}}),h=new at({props:{title:"Nex/Prev outline buttons with equal width",$$slots:{react:[fe],html:[de],default:[ie]},$$scope:{ctx:v}}}),{c(){F(t.$$.fragment),o=N(),F(u.$$.fragment),a=N(),F(l.$$.fragment),r=N(),F(e.$$.fragment),n=N(),F(g.$$.fragment),E=N(),F(h.$$.fragment)},l(b){G(t.$$.fragment,b),o=T(b),G(u.$$.fragment,b),a=T(b),G(l.$$.fragment,b),r=T(b),G(e.$$.fragment,b),n=T(b),G(g.$$.fragment,b),E=T(b),G(h.$$.fragment,b)},m(b,p){K(t,b,p),x(b,o,p),K(u,b,p),x(b,a,p),K(l,b,p),x(b,r,p),K(e,b,p),x(b,n,p),K(g,b,p),x(b,E,p),K(h,b,p),B=!0},p(b,p){const O={};p&5&&(O.$$scope={dirty:p,ctx:b}),u.$set(O);const P={};p&5&&(P.$$scope={dirty:p,ctx:b}),l.$set(P);const U={};p&5&&(U.$$scope={dirty:p,ctx:b}),e.$set(U);const w={};p&5&&(w.$$scope={dirty:p,ctx:b}),g.$set(w);const R={};p&5&&(R.$$scope={dirty:p,ctx:b}),h.$set(R)},i(b){B||(Q(t.$$.fragment,b),Q(u.$$.fragment,b),Q(l.$$.fragment,b),Q(e.$$.fragment,b),Q(g.$$.fragment,b),Q(h.$$.fragment,b),B=!0)},o(b){W(t.$$.fragment,b),W(u.$$.fragment,b),W(l.$$.fragment,b),W(e.$$.fragment,b),W(g.$$.fragment,b),W(h.$$.fragment,b),B=!1},d(b){H(t,b),b&&c(o),H(u,b),b&&c(a),H(l,b),b&&c(r),H(e,b),b&&c(n),H(g,b),b&&c(E),H(h,b)}}}function me(v){let t,o;const u=[v[1],Qt];let a={$$slots:{default:[pe]},$$scope:{ctx:v}};for(let l=0;l<u.length;l+=1)a=Ut(a,u[l]);return t=new Yt({props:a}),{c(){F(t.$$.fragment)},l(l){G(t.$$.fragment,l)},m(l,r){K(t,l,r),o=!0},p(l,[r]){const e=r&2?Lt(u,[r&2&&Gt(l[1]),r&0&&Gt(Qt)]):{};r&5&&(e.$$scope={dirty:r,ctx:l}),t.$set(e)},i(l){o||(Q(t.$$.fragment,l),o=!0)},o(l){W(t.$$.fragment,l),o=!1},d(l){H(t,l)}}}const Qt={title:"Pagination",desc:"Pagination is a group of buttons that allow the user to navigate between a set of related content.",published:!0};function _e(v,t,o){let u;return Xt(v,Zt,a=>o(0,u=a)),v.$$set=a=>{o(1,t=Ut(Ut({},t),Kt(a)))},t=Kt(t),[u,t]}class xe extends Wt{constructor(t){super();Ht(this,t,_e,me,Jt,{})}}export{xe as default,Qt as metadata};
