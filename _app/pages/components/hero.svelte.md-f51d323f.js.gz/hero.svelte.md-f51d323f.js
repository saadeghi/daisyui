import{S as Ee,i as Ne,s as ye,C as oe,w as O,x as T,y as L,z as Ie,A as _e,q as j,o as C,B as R,K as qe,ag as xe,k as I,m as q,g as S,d,e as p,t as E,c as m,a as f,h as N,b as u,H as r,a9 as Q,Q as V,O as we,f as Pe}from"../../chunks/vendor-40028f80.js";import{M as ke}from"../../chunks/_markdown-cebd451d.js";import{p as Se,C as De,a as W,r as G}from"../../chunks/actions-fd4934ca.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-109a4022.js";import"../../chunks/index-6a9c0989.js";import"../../chunks/SEO-1e1c3caf.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-589377c3.js";function He(v){let e,n,a,i,s,c,t,l,g,$,b;return{c(){e=p("div"),n=p("div"),a=p("div"),i=p("h3"),s=E("Hello there"),c=I(),t=p("p"),l=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),g=I(),$=p("button"),b=E("Get Started"),this.h()},l(_){e=m(_,"DIV",{class:!0});var o=f(e);n=m(o,"DIV",{class:!0});var h=f(n);a=m(h,"DIV",{class:!0});var x=f(a);i=m(x,"H3",{class:!0});var P=f(i);s=N(P,"Hello there"),P.forEach(d),c=q(x),t=m(x,"P",{class:!0});var w=f(t);l=N(w,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),w.forEach(d),g=q(x),$=m(x,"BUTTON",{class:!0});var y=f($);b=N(y,"Get Started"),y.forEach(d),x.forEach(d),h.forEach(d),o.forEach(d),this.h()},h(){u(i,"class","text-5xl font-bold"),u(t,"class","py-6"),u($,"class","btn btn-primary"),u(a,"class","max-w-md"),u(n,"class","text-center hero-content"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(_,o){S(_,e,o),r(e,n),r(n,a),r(a,i),r(i,s),r(a,c),r(a,t),r(t,l),r(a,g),r(a,$),r($,b)},d(_){_&&d(e)}}}function Qe(v){let e,n=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold">Hello there</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ve(v){let e,n=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content text-center">
    <div className="max-w-md">
      <h1 className="text-5xl font-bold">Hello there</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ge(v){let e,n,a,i,s,c,t,l,g,$,b,_,o,h;return{c(){e=p("div"),n=p("div"),a=p("img"),s=I(),c=p("div"),t=p("h3"),l=E("Box Office News!"),g=I(),$=p("p"),b=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),_=I(),o=p("button"),h=E("Get Started"),this.h()},l(x){e=m(x,"DIV",{class:!0});var P=f(e);n=m(P,"DIV",{class:!0});var w=f(n);a=m(w,"IMG",{src:!0,class:!0,alt:!0}),s=q(w),c=m(w,"DIV",{});var y=f(c);t=m(y,"H3",{class:!0});var k=f(t);l=N(k,"Box Office News!"),k.forEach(d),g=q(y),$=m(y,"P",{class:!0});var D=f($);b=N(D,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),D.forEach(d),_=q(y),o=m(y,"BUTTON",{class:!0});var H=f(o);h=N(H,"Get Started"),H.forEach(d),y.forEach(d),w.forEach(d),P.forEach(d),this.h()},h(){we(a.src,i="/images/stock/photo-1635805737707-575885ab0820.jpg")||u(a,"src",i),u(a,"class","max-w-sm rounded-lg shadow-2xl"),u(a,"alt","Tailwind CSS hero component"),u(t,"class","text-5xl font-bold"),u($,"class","py-6"),u(o,"class","btn btn-primary"),u(n,"class","flex-col hero-content lg:flex-row"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(x,P){S(x,e,P),r(e,n),r(n,a),r(n,s),r(n,c),r(c,t),r(t,l),r(c,g),r(c,$),r($,b),r(c,_),r(c,o),r(o,h)},d(x){x&&d(e)}}}function Be(v){let e,n=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Oe(v){let e,n=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" className="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 className="text-5xl font-bold">Box Office News!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Te(v){let e,n,a,i,s,c,t,l,g,$,b,_,o,h;return{c(){e=p("div"),n=p("div"),a=p("img"),s=I(),c=p("div"),t=p("h3"),l=E("Box Office News!"),g=I(),$=p("p"),b=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),_=I(),o=p("button"),h=E("Get Started"),this.h()},l(x){e=m(x,"DIV",{class:!0});var P=f(e);n=m(P,"DIV",{class:!0});var w=f(n);a=m(w,"IMG",{src:!0,class:!0,alt:!0}),s=q(w),c=m(w,"DIV",{});var y=f(c);t=m(y,"H3",{class:!0});var k=f(t);l=N(k,"Box Office News!"),k.forEach(d),g=q(y),$=m(y,"P",{class:!0});var D=f($);b=N(D,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),D.forEach(d),_=q(y),o=m(y,"BUTTON",{class:!0});var H=f(o);h=N(H,"Get Started"),H.forEach(d),y.forEach(d),w.forEach(d),P.forEach(d),this.h()},h(){we(a.src,i="/images/stock/photo-1635805737707-575885ab0820.jpg")||u(a,"src",i),u(a,"class","max-w-sm rounded-lg shadow-2xl"),u(a,"alt","Tailwind CSS hero component"),u(t,"class","text-5xl font-bold"),u($,"class","py-6"),u(o,"class","btn btn-primary"),u(n,"class","flex-col hero-content lg:flex-row-reverse"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(x,P){S(x,e,P),r(e,n),r(n,a),r(n,s),r(n,c),r(c,t),r(t,l),r(c,g),r(c,$),r($,b),r(c,_),r(c,o),r(o,h)},d(x){x&&d(e)}}}function Le(v){let e,n=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function je(v){let e,n=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row-reverse">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" className="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 className="text-5xl font-bold">Box Office News!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ce(v){let e,n,a,i,s,c,t,l,g,$,b,_,o,h,x,P,w,y,k,D,H,te,ae,A,le,U,B,se,ie,F,M,re;return{c(){e=p("div"),n=p("div"),a=p("div"),i=p("h3"),s=E("Login now!"),c=I(),t=p("p"),l=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),g=I(),$=p("div"),b=p("div"),_=p("div"),o=p("label"),h=p("span"),x=E("Email"),P=I(),w=p("input"),y=I(),k=p("div"),D=p("label"),H=p("span"),te=E("Password"),ae=I(),A=p("input"),le=I(),U=p("label"),B=p("a"),se=E("Forgot password?"),ie=I(),F=p("div"),M=p("button"),re=E("Login"),this.h()},l(J){e=m(J,"DIV",{class:!0});var X=f(e);n=m(X,"DIV",{class:!0});var Y=f(n);a=m(Y,"DIV",{class:!0});var Z=f(a);i=m(Z,"H3",{class:!0});var ne=f(i);s=N(ne,"Login now!"),ne.forEach(d),c=q(Z),t=m(Z,"P",{class:!0});var ce=f(t);l=N(ce,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),ce.forEach(d),Z.forEach(d),g=q(Y),$=m(Y,"DIV",{class:!0});var de=f($);b=m(de,"DIV",{class:!0});var z=f(b);_=m(z,"DIV",{class:!0});var ee=f(_);o=m(ee,"LABEL",{class:!0});var ue=f(o);h=m(ue,"SPAN",{class:!0});var pe=f(h);x=N(pe,"Email"),pe.forEach(d),ue.forEach(d),P=q(ee),w=m(ee,"INPUT",{type:!0,placeholder:!0,class:!0}),ee.forEach(d),y=q(z),k=m(z,"DIV",{class:!0});var K=f(k);D=m(K,"LABEL",{class:!0});var me=f(D);H=m(me,"SPAN",{class:!0});var fe=f(H);te=N(fe,"Password"),fe.forEach(d),me.forEach(d),ae=q(K),A=m(K,"INPUT",{type:!0,placeholder:!0,class:!0}),le=q(K),U=m(K,"LABEL",{class:!0});var he=f(U);B=m(he,"A",{href:!0,class:!0});var ve=f(B);se=N(ve,"Forgot password?"),ve.forEach(d),he.forEach(d),K.forEach(d),ie=q(z),F=m(z,"DIV",{class:!0});var $e=f(F);M=m($e,"BUTTON",{class:!0});var be=f(M);re=N(be,"Login"),be.forEach(d),$e.forEach(d),z.forEach(d),de.forEach(d),Y.forEach(d),X.forEach(d),this.h()},h(){u(i,"class","text-5xl font-bold"),u(t,"class","py-6"),u(a,"class","text-center lg:text-left"),u(h,"class","label-text"),u(o,"class","label"),u(w,"type","text"),u(w,"placeholder","email"),u(w,"class","input input-bordered"),u(_,"class","form-control"),u(H,"class","label-text"),u(D,"class","label"),u(A,"type","text"),u(A,"placeholder","password"),u(A,"class","input input-bordered"),u(B,"href","#"),u(B,"class","label-text-alt link link-hover"),u(U,"class","label"),u(k,"class","form-control"),u(M,"class","btn btn-primary"),u(F,"class","form-control mt-6"),u(b,"class","card-body"),u($,"class","card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100"),u(n,"class","flex-col hero-content lg:flex-row-reverse"),u(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(J,X){S(J,e,X),r(e,n),r(n,a),r(a,i),r(i,s),r(a,c),r(a,t),r(t,l),r(n,g),r(n,$),r($,b),r(b,_),r(_,o),r(o,h),r(h,x),r(_,P),r(_,w),r(b,y),r(b,k),r(k,D),r(D,H),r(H,te),r(k,ae),r(k,A),r(k,le),r(k,U),r(U,B),r(B,se),r(b,ie),r(b,F),r(F,M),r(M,re)},d(J){J&&d(e)}}}function Re(v){let e,n=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <div class="text-center lg:text-left">
      <h1 class="text-5xl font-bold">Login now!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
    </div>
    <div class="$$card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
      <div class="$$card-body">
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Email</span>
          </label>
          <input type="text" placeholder="email" class="$$input $$input-bordered" />
        </div>
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Password</span>
          </label>
          <input type="text" placeholder="password" class="$$input $$input-bordered" />
          <label class="$$label">
            <a href="#" class="$$label-text-alt $$link $$link-hover">Forgot password?</a>
          </label>
        </div>
        <div class="$$form-control mt-6">
          <button class="$$btn $$btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ae(v){let e,n=`<div className="$$hero min-h-screen bg-base-200">
  <div className="$$hero-content flex-col lg:flex-row-reverse">
    <div className="text-center lg:text-left">
      <h1 className="text-5xl font-bold">Login now!</h1>
      <p className="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
    </div>
    <div className="$$card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
      <div className="$$card-body">
        <div className="$$form-control">
          <label className="$$label">
            <span className="$$label-text">Email</span>
          </label>
          <input type="text" placeholder="email" className="$$input $$input-bordered" />
        </div>
        <div className="$$form-control">
          <label className="$$label">
            <span className="$$label-text">Password</span>
          </label>
          <input type="text" placeholder="password" className="$$input $$input-bordered" />
          <label className="$$label">
            <a href="#" className="$$label-text-alt $$link $$link-hover">Forgot password?</a>
          </label>
        </div>
        <div className="$$form-control mt-6">
          <button className="$$btn $$btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Ue(v){let e,n,a,i,s,c,t,l,g,$,b,_,o;return{c(){e=p("div"),n=p("div"),a=I(),i=p("div"),s=p("div"),c=p("h1"),t=E("Hello there"),l=I(),g=p("p"),$=E("Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),b=I(),_=p("button"),o=E("Get Started"),this.h()},l(h){e=m(h,"DIV",{class:!0,style:!0});var x=f(e);n=m(x,"DIV",{class:!0}),f(n).forEach(d),a=q(x),i=m(x,"DIV",{class:!0});var P=f(i);s=m(P,"DIV",{class:!0});var w=f(s);c=m(w,"H1",{class:!0});var y=f(c);t=N(y,"Hello there"),y.forEach(d),l=q(w),g=m(w,"P",{class:!0});var k=f(g);$=N(k,"Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi."),k.forEach(d),b=q(w),_=m(w,"BUTTON",{class:!0});var D=f(_);o=N(D,"Get Started"),D.forEach(d),w.forEach(d),P.forEach(d),x.forEach(d),this.h()},h(){u(n,"class","hero-overlay rounded bg-opacity-60"),u(c,"class","mb-5 text-5xl font-bold"),u(g,"class","mb-5"),u(_,"class","btn btn-primary"),u(s,"class","max-w-md"),u(i,"class","text-center hero-content text-neutral-content"),u(e,"class","hero min-h-[30rem] rounded"),Pe(e,"background-image","url(/images/stock/photo-1507358522600-9f71e620c44e.jpg)")},m(h,x){S(h,e,x),r(e,n),r(e,a),r(e,i),r(i,s),r(s,c),r(c,t),r(s,l),r(s,g),r(g,$),r(s,b),r(s,_),r(_,o)},d(h){h&&d(e)}}}function Fe(v){let e,n=`<div class="$$hero min-h-screen" style="background-image: url(/images/stock/photo-1507358522600-9f71e620c44e.jpg);">
  <div class="$$hero-overlay bg-opacity-60"></div>
  <div class="$$hero-content text-center text-neutral-content">
    <div class="max-w-md">
      <h1 class="mb-5 text-5xl font-bold">Hello there</h1>
      <p class="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","html")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function Me(v){let e,n=`<div className="$$hero min-h-screen" style={{ backgroundImage: \`url("/images/stock/photo-1507358522600-9f71e620c44e.jpg")\` }}>
  <div className="$$hero-overlay bg-opacity-60"></div>
  <div className="$$hero-content text-center text-neutral-content">
    <div className="max-w-md">
      <h1 className="mb-5 text-5xl font-bold">Hello there</h1>
      <p className="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button className="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,a,i,s,c;return{c(){e=p("pre"),a=E(n),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=f(e);a=N(l,n),l.forEach(d),this.h()},h(){u(e,"slot","react")},m(t,l){S(t,e,l),r(e,a),s||(c=Q(i=G.call(null,e,{to:v[0]})),s=!0)},p(t,l){i&&V(i.update)&&l&1&&i.update.call(null,{to:t[0]})},d(t){t&&d(e),s=!1,c()}}}function ze(v){let e,n,a,i,s,c,t,l,g,$,b,_;return e=new De({props:{data:[{type:"component",class:"hero",desc:"Container element"},{type:"component",class:"hero-content",desc:"Container for content"},{type:"component",class:"hero-overlay",desc:"Overlay that covers the background image"}]}}),a=new W({props:{title:"Centered hero",$$slots:{react:[Ve],html:[Qe],default:[He]},$$scope:{ctx:v}}}),s=new W({props:{title:"Hero with figure",$$slots:{react:[Oe],html:[Be],default:[Ge]},$$scope:{ctx:v}}}),t=new W({props:{title:"Hero with figure but reverse order",$$slots:{react:[je],html:[Le],default:[Te]},$$scope:{ctx:v}}}),g=new W({props:{title:"Hero with form",$$slots:{react:[Ae],html:[Re],default:[Ce]},$$scope:{ctx:v}}}),b=new W({props:{title:"Hero with overlay image",$$slots:{react:[Me],html:[Fe],default:[Ue]},$$scope:{ctx:v}}}),{c(){O(e.$$.fragment),n=I(),O(a.$$.fragment),i=I(),O(s.$$.fragment),c=I(),O(t.$$.fragment),l=I(),O(g.$$.fragment),$=I(),O(b.$$.fragment)},l(o){T(e.$$.fragment,o),n=q(o),T(a.$$.fragment,o),i=q(o),T(s.$$.fragment,o),c=q(o),T(t.$$.fragment,o),l=q(o),T(g.$$.fragment,o),$=q(o),T(b.$$.fragment,o)},m(o,h){L(e,o,h),S(o,n,h),L(a,o,h),S(o,i,h),L(s,o,h),S(o,c,h),L(t,o,h),S(o,l,h),L(g,o,h),S(o,$,h),L(b,o,h),_=!0},p(o,h){const x={};h&5&&(x.$$scope={dirty:h,ctx:o}),a.$set(x);const P={};h&5&&(P.$$scope={dirty:h,ctx:o}),s.$set(P);const w={};h&5&&(w.$$scope={dirty:h,ctx:o}),t.$set(w);const y={};h&5&&(y.$$scope={dirty:h,ctx:o}),g.$set(y);const k={};h&5&&(k.$$scope={dirty:h,ctx:o}),b.$set(k)},i(o){_||(j(e.$$.fragment,o),j(a.$$.fragment,o),j(s.$$.fragment,o),j(t.$$.fragment,o),j(g.$$.fragment,o),j(b.$$.fragment,o),_=!0)},o(o){C(e.$$.fragment,o),C(a.$$.fragment,o),C(s.$$.fragment,o),C(t.$$.fragment,o),C(g.$$.fragment,o),C(b.$$.fragment,o),_=!1},d(o){R(e,o),o&&d(n),R(a,o),o&&d(i),R(s,o),o&&d(c),R(t,o),o&&d(l),R(g,o),o&&d($),R(b,o)}}}function Ke(v){let e,n;const a=[v[1],ge];let i={$$slots:{default:[ze]},$$scope:{ctx:v}};for(let s=0;s<a.length;s+=1)i=oe(i,a[s]);return e=new ke({props:i}),{c(){O(e.$$.fragment)},l(s){T(e.$$.fragment,s)},m(s,c){L(e,s,c),n=!0},p(s,[c]){const t=c&2?Ie(a,[c&2&&_e(s[1]),c&0&&_e(ge)]):{};c&5&&(t.$$scope={dirty:c,ctx:s}),e.$set(t)},i(s){n||(j(e.$$.fragment,s),n=!0)},o(s){C(e.$$.fragment,s),n=!1},d(s){R(e,s)}}}const ge={title:"Hero",desc:"Hero is a component for displaying a large box or image with a title and description.",published:!0};function Je(v,e,n){let a;return qe(v,Se,i=>n(0,a=i)),v.$$set=i=>{n(1,e=oe(oe({},e),xe(i)))},e=xe(e),[a,e]}class it extends Ee{constructor(e){super();Ne(this,e,Je,Ke,ye,{})}}export{it as default,ge as metadata};
