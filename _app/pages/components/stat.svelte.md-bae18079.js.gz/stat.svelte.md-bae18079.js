import{S as zt,i as Jt,s as Ct,C as Bt,w as nt,x as ut,y as $t,z as St,A as Kt,q as ht,o as ft,B as mt,K as Lt,ag as Ut,k as w,m as g,g as Y,d as a,e as v,t as m,c as o,a as i,h as p,b as e,F as t,a9 as _t,W as wt,H as ot,I as ct,O as At}from"../../chunks/vendor-c5cb7521.js";import{M as Ot}from"../../chunks/_markdown-a0b8e7c6.js";import{p as Wt,C as qt,a as pt,r as gt}from"../../chunks/actions-28c29da8.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-0b87cd30.js";import"../../chunks/index-ec4de4fd.js";import"../../chunks/SEO-092d7cd6.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-7e406ec1.js";function Gt(R){let s,l,c,u,n,h,r,$,D,y;return{c(){s=v("div"),l=v("div"),c=v("div"),u=m("Total Page Views"),n=w(),h=v("div"),r=m("89,400"),$=w(),D=v("div"),y=m("21% more than last month"),this.h()},l(M){s=o(M,"DIV",{class:!0});var V=i(s);l=o(V,"DIV",{class:!0});var _=i(l);c=o(_,"DIV",{class:!0});var K=i(c);u=p(K,"Total Page Views"),K.forEach(a),n=g(_),h=o(_,"DIV",{class:!0});var B=i(h);r=p(B,"89,400"),B.forEach(a),$=g(_),D=o(_,"DIV",{class:!0});var E=i(D);y=p(E,"21% more than last month"),E.forEach(a),_.forEach(a),V.forEach(a),this.h()},h(){e(c,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(s,"class","shadow stats")},m(M,V){Y(M,s,V),t(s,l),t(l,c),t(c,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y)},d(M){M&&a(s)}}}function Ht(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Total Page Views</div>
    <div class="$$stat-value">89,400</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function Qt(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A,U,J,O,S,N,P,k,x,q,G,H,z,W,tt,Z,L,st,Q,X;return{c(){s=v("div"),l=v("div"),c=v("div"),u=ot("svg"),n=ot("path"),h=w(),r=v("div"),$=m("Total Likes"),D=w(),y=v("div"),M=m("25.6K"),V=w(),_=v("div"),K=m("21% more than last month"),B=w(),E=v("div"),d=v("div"),f=ot("svg"),b=ot("path"),C=w(),F=v("div"),I=m("Page Views"),T=w(),j=v("div"),A=m("2.6M"),U=w(),J=v("div"),O=m("21% more than last month"),S=w(),N=v("div"),P=v("div"),k=v("div"),x=v("div"),q=v("img"),H=w(),z=v("div"),W=m("86%"),tt=w(),Z=v("div"),L=m("Tasks done"),st=w(),Q=v("div"),X=m("31 tasks remaining"),this.h()},l(et){s=o(et,"DIV",{class:!0});var at=i(s);l=o(at,"DIV",{class:!0});var lt=i(l);c=o(lt,"DIV",{class:!0});var Et=i(c);u=ct(Et,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Vt=i(u);n=ct(Vt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(n).forEach(a),Vt.forEach(a),Et.forEach(a),h=g(lt),r=o(lt,"DIV",{class:!0});var Dt=i(r);$=p(Dt,"Total Likes"),Dt.forEach(a),D=g(lt),y=o(lt,"DIV",{class:!0});var it=i(y);M=p(it,"25.6K"),it.forEach(a),V=g(lt),_=o(lt,"DIV",{class:!0});var It=i(_);K=p(It,"21% more than last month"),It.forEach(a),lt.forEach(a),B=g(at),E=o(at,"DIV",{class:!0});var dt=i(E);d=o(dt,"DIV",{class:!0});var kt=i(d);f=ct(kt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var bt=i(f);b=ct(bt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),bt.forEach(a),kt.forEach(a),C=g(dt),F=o(dt,"DIV",{class:!0});var xt=i(F);I=p(xt,"Page Views"),xt.forEach(a),T=g(dt),j=o(dt,"DIV",{class:!0});var rt=i(j);A=p(rt,"2.6M"),rt.forEach(a),U=g(dt),J=o(dt,"DIV",{class:!0});var yt=i(J);O=p(yt,"21% more than last month"),yt.forEach(a),dt.forEach(a),S=g(at),N=o(at,"DIV",{class:!0});var vt=i(N);P=o(vt,"DIV",{class:!0});var Nt=i(P);k=o(Nt,"DIV",{class:!0});var Mt=i(k);x=o(Mt,"DIV",{class:!0});var Rt=i(x);q=o(Rt,"IMG",{src:!0}),Rt.forEach(a),Mt.forEach(a),Nt.forEach(a),H=g(vt),z=o(vt,"DIV",{class:!0});var Ft=i(z);W=p(Ft,"86%"),Ft.forEach(a),tt=g(vt),Z=o(vt,"DIV",{class:!0});var Tt=i(Z);L=p(Tt,"Tasks done"),Tt.forEach(a),st=g(vt),Q=o(vt,"DIV",{class:!0});var jt=i(Q);X=p(jt,"31 tasks remaining"),jt.forEach(a),vt.forEach(a),at.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(c,"class","stat-figure text-primary"),e(r,"class","stat-title"),e(y,"class","stat-value text-primary"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M13 10V3L4 14h7v7l9-11h-7z"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(F,"class","stat-title"),e(j,"class","stat-value text-secondary"),e(J,"class","stat-desc"),e(E,"class","stat"),At(q.src,G="https://placeimg.com/128/128/people")||e(q,"src",G),e(x,"class","w-16 rounded-full"),e(k,"class","avatar online"),e(P,"class","stat-figure text-secondary"),e(z,"class","stat-value"),e(Z,"class","stat-title"),e(Q,"class","stat-desc text-secondary"),e(N,"class","stat"),e(s,"class","shadow stats")},m(et,at){Y(et,s,at),t(s,l),t(l,c),t(c,u),t(u,n),t(l,h),t(l,r),t(r,$),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,K),t(s,B),t(s,E),t(E,d),t(d,f),t(f,b),t(E,C),t(E,F),t(F,I),t(E,T),t(E,j),t(j,A),t(E,U),t(E,J),t(J,O),t(s,S),t(s,N),t(N,P),t(P,k),t(k,x),t(x,q),t(N,H),t(N,z),t(z,W),t(N,tt),t(N,Z),t(Z,L),t(N,st),t(N,Q),t(Q,X)},d(et){et&&a(s)}}}function Xt(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="$$stat-title">Total Likes</div>
    <div class="$$stat-value text-primary">25.6K</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="$$stat-title">Page Views</div>
    <div class="$$stat-value text-secondary">2.6M</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <div class="$$avatar $$online">
        <div class="w-16 rounded-full">
          <img src="https://placeimg.com/128/128/people" />
        </div>
      </div>
    </div>
    <div class="$$stat-value">86%</div>
    <div class="$$stat-title">Tasks done</div>
    <div class="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function Yt(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A,U,J,O,S,N,P,k,x,q,G,H,z,W,tt,Z,L,st;return{c(){s=v("div"),l=v("div"),c=v("div"),u=ot("svg"),n=ot("path"),h=w(),r=v("div"),$=m("Downloads"),D=w(),y=v("div"),M=m("31K"),V=w(),_=v("div"),K=m("Jan 1st - Feb 1st"),B=w(),E=v("div"),d=v("div"),f=ot("svg"),b=ot("path"),C=w(),F=v("div"),I=m("New Users"),T=w(),j=v("div"),A=m("4,200"),U=w(),J=v("div"),O=m("\u2197\uFE0E 400 (22%)"),S=w(),N=v("div"),P=v("div"),k=ot("svg"),x=ot("path"),q=w(),G=v("div"),H=m("New Registers"),z=w(),W=v("div"),tt=m("1,200"),Z=w(),L=v("div"),st=m("\u2198\uFE0E 90 (14%)"),this.h()},l(Q){s=o(Q,"DIV",{class:!0});var X=i(s);l=o(X,"DIV",{class:!0});var et=i(l);c=o(et,"DIV",{class:!0});var at=i(c);u=ct(at,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var lt=i(u);n=ct(lt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(n).forEach(a),lt.forEach(a),at.forEach(a),h=g(et),r=o(et,"DIV",{class:!0});var Et=i(r);$=p(Et,"Downloads"),Et.forEach(a),D=g(et),y=o(et,"DIV",{class:!0});var Vt=i(y);M=p(Vt,"31K"),Vt.forEach(a),V=g(et),_=o(et,"DIV",{class:!0});var Dt=i(_);K=p(Dt,"Jan 1st - Feb 1st"),Dt.forEach(a),et.forEach(a),B=g(X),E=o(X,"DIV",{class:!0});var it=i(E);d=o(it,"DIV",{class:!0});var It=i(d);f=ct(It,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var dt=i(f);b=ct(dt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),dt.forEach(a),It.forEach(a),C=g(it),F=o(it,"DIV",{class:!0});var kt=i(F);I=p(kt,"New Users"),kt.forEach(a),T=g(it),j=o(it,"DIV",{class:!0});var bt=i(j);A=p(bt,"4,200"),bt.forEach(a),U=g(it),J=o(it,"DIV",{class:!0});var xt=i(J);O=p(xt,"\u2197\uFE0E 400 (22%)"),xt.forEach(a),it.forEach(a),S=g(X),N=o(X,"DIV",{class:!0});var rt=i(N);P=o(rt,"DIV",{class:!0});var yt=i(P);k=ct(yt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var vt=i(k);x=ct(vt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(x).forEach(a),vt.forEach(a),yt.forEach(a),q=g(rt),G=o(rt,"DIV",{class:!0});var Nt=i(G);H=p(Nt,"New Registers"),Nt.forEach(a),z=g(rt),W=o(rt,"DIV",{class:!0});var Mt=i(W);tt=p(Mt,"1,200"),Mt.forEach(a),Z=g(rt),L=o(rt,"DIV",{class:!0});var Rt=i(L);st=p(Rt,"\u2198\uFE0E 90 (14%)"),Rt.forEach(a),rt.forEach(a),X.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(c,"class","stat-figure text-secondary"),e(r,"class","stat-title"),e(y,"class","stat-value"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(F,"class","stat-title"),e(j,"class","stat-value"),e(J,"class","stat-desc"),e(E,"class","stat"),e(x,"stroke-linecap","round"),e(x,"stroke-linejoin","round"),e(x,"stroke-width","2"),e(x,"d","M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"),e(k,"xmlns","http://www.w3.org/2000/svg"),e(k,"fill","none"),e(k,"viewBox","0 0 24 24"),e(k,"class","inline-block w-8 h-8 stroke-current"),e(P,"class","stat-figure text-secondary"),e(G,"class","stat-title"),e(W,"class","stat-value"),e(L,"class","stat-desc"),e(N,"class","stat"),e(s,"class","shadow stats")},m(Q,X){Y(Q,s,X),t(s,l),t(l,c),t(c,u),t(u,n),t(l,h),t(l,r),t(r,$),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,K),t(s,B),t(s,E),t(E,d),t(d,f),t(f,b),t(E,C),t(E,F),t(F,I),t(E,T),t(E,j),t(j,A),t(E,U),t(E,J),t(J,O),t(s,S),t(s,N),t(N,P),t(P,k),t(k,x),t(N,q),t(N,G),t(G,H),t(N,z),t(N,W),t(W,tt),t(N,Z),t(N,L),t(L,st)},d(Q){Q&&a(s)}}}function Zt(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function ts(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A,U,J,O,S,N;return{c(){s=v("div"),l=v("div"),c=v("div"),u=m("Downloads"),n=w(),h=v("div"),r=m("31K"),$=w(),D=v("div"),y=m("From January 1st to February 1st"),M=w(),V=v("div"),_=v("div"),K=m("Users"),B=w(),E=v("div"),d=m("4,200"),f=w(),b=v("div"),C=m("\u2197\uFE0E 40 (2%)"),F=w(),I=v("div"),T=v("div"),j=m("New Registers"),A=w(),U=v("div"),J=m("1,200"),O=w(),S=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);c=o(x,"DIV",{class:!0});var q=i(c);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"From January 1st to February 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"\u2197\uFE0E 40 (2%)"),Z.forEach(a),z.forEach(a),F=g(k),I=o(k,"DIV",{class:!0});var L=i(I);T=o(L,"DIV",{class:!0});var st=i(T);j=p(st,"New Registers"),st.forEach(a),A=g(L),U=o(L,"DIV",{class:!0});var Q=i(U);J=p(Q,"1,200"),Q.forEach(a),O=g(L),S=o(L,"DIV",{class:!0});var X=i(S);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(c,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat place-items-center"),e(_,"class","stat-title"),e(E,"class","stat-value text-secondary"),e(b,"class","stat-desc text-secondary"),e(V,"class","stat place-items-center"),e(T,"class","stat-title"),e(U,"class","stat-value"),e(S,"class","stat-desc"),e(I,"class","stat place-items-center"),e(s,"class","shadow stats")},m(P,k){Y(P,s,k),t(s,l),t(l,c),t(c,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,F),t(s,I),t(I,T),t(T,j),t(I,A),t(I,U),t(U,J),t(I,O),t(I,S),t(S,N)},d(P){P&&a(s)}}}function ss(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Users</div>
    <div class="$$stat-value text-secondary">4,200</div>
    <div class="$$stat-desc text-secondary">\u2197\uFE0E 40 (2%)</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function es(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A,U,J,O,S,N;return{c(){s=v("div"),l=v("div"),c=v("div"),u=m("Downloads"),n=w(),h=v("div"),r=m("31K"),$=w(),D=v("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=v("div"),_=v("div"),K=m("New Users"),B=w(),E=v("div"),d=m("4,200"),f=w(),b=v("div"),C=m("\u2197\uFE0E 400 (22%)"),F=w(),I=v("div"),T=v("div"),j=m("New Registers"),A=w(),U=v("div"),J=m("1,200"),O=w(),S=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);c=o(x,"DIV",{class:!0});var q=i(c);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"New Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),z.forEach(a),F=g(k),I=o(k,"DIV",{class:!0});var L=i(I);T=o(L,"DIV",{class:!0});var st=i(T);j=p(st,"New Registers"),st.forEach(a),A=g(L),U=o(L,"DIV",{class:!0});var Q=i(U);J=p(Q,"1,200"),Q.forEach(a),O=g(L),S=o(L,"DIV",{class:!0});var X=i(S);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(c,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(E,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(T,"class","stat-title"),e(U,"class","stat-value"),e(S,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical")},m(P,k){Y(P,s,k),t(s,l),t(l,c),t(c,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,F),t(s,I),t(I,T),t(T,j),t(I,A),t(I,U),t(U,J),t(I,O),t(I,S),t(S,N)},d(P){P&&a(s)}}}function as(R){let s,l=`<div class="$$stats $$stats-vertical shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function ls(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A,U,J,O,S,N;return{c(){s=v("div"),l=v("div"),c=v("div"),u=m("Downloads"),n=w(),h=v("div"),r=m("31K"),$=w(),D=v("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=v("div"),_=v("div"),K=m("New Users"),B=w(),E=v("div"),d=m("4,200"),f=w(),b=v("div"),C=m("\u2197\uFE0E 400 (22%)"),F=w(),I=v("div"),T=v("div"),j=m("New Registers"),A=w(),U=v("div"),J=m("1,200"),O=w(),S=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);c=o(x,"DIV",{class:!0});var q=i(c);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"New Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),z.forEach(a),F=g(k),I=o(k,"DIV",{class:!0});var L=i(I);T=o(L,"DIV",{class:!0});var st=i(T);j=p(st,"New Registers"),st.forEach(a),A=g(L),U=o(L,"DIV",{class:!0});var Q=i(U);J=p(Q,"1,200"),Q.forEach(a),O=g(L),S=o(L,"DIV",{class:!0});var X=i(S);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(c,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(E,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(T,"class","stat-title"),e(U,"class","stat-value"),e(S,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical lg:stats-horizontal")},m(P,k){Y(P,s,k),t(s,l),t(l,c),t(c,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,F),t(s,I),t(I,T),t(T,j),t(I,A),t(I,U),t(U,J),t(I,O),t(I,S),t(S,N)},d(P){P&&a(s)}}}function is(R){let s,l=`<div class="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function ds(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,F,I,T,j,A;return{c(){s=v("div"),l=v("div"),c=v("div"),u=m("Account balance"),n=w(),h=v("div"),r=m("$89,400"),$=w(),D=v("div"),y=v("button"),M=m("Add funds"),V=w(),_=v("div"),K=v("div"),B=m("Current balance"),E=w(),d=v("div"),f=m("$89,400"),b=w(),C=v("div"),F=v("button"),I=m("Withdrawal"),T=w(),j=v("button"),A=m("deposit"),this.h()},l(U){s=o(U,"DIV",{class:!0});var J=i(s);l=o(J,"DIV",{class:!0});var O=i(l);c=o(O,"DIV",{class:!0});var S=i(c);u=p(S,"Account balance"),S.forEach(a),n=g(O),h=o(O,"DIV",{class:!0});var N=i(h);r=p(N,"$89,400"),N.forEach(a),$=g(O),D=o(O,"DIV",{class:!0});var P=i(D);y=o(P,"BUTTON",{class:!0});var k=i(y);M=p(k,"Add funds"),k.forEach(a),P.forEach(a),O.forEach(a),V=g(J),_=o(J,"DIV",{class:!0});var x=i(_);K=o(x,"DIV",{class:!0});var q=i(K);B=p(q,"Current balance"),q.forEach(a),E=g(x),d=o(x,"DIV",{class:!0});var G=i(d);f=p(G,"$89,400"),G.forEach(a),b=g(x),C=o(x,"DIV",{class:!0});var H=i(C);F=o(H,"BUTTON",{class:!0});var z=i(F);I=p(z,"Withdrawal"),z.forEach(a),T=g(H),j=o(H,"BUTTON",{class:!0});var W=i(j);A=p(W,"deposit"),W.forEach(a),H.forEach(a),x.forEach(a),J.forEach(a),this.h()},h(){e(c,"class","stat-title"),e(h,"class","stat-value"),e(y,"class","btn btn-sm btn-success"),e(D,"class","stat-actions"),e(l,"class","stat"),e(K,"class","stat-title"),e(d,"class","stat-value"),e(F,"class","btn btn-sm"),e(j,"class","btn btn-sm"),e(C,"class","stat-actions"),e(_,"class","stat"),e(s,"class","stats bg-primary text-primary-content")},m(U,J){Y(U,s,J),t(s,l),t(l,c),t(c,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(y,M),t(s,V),t(s,_),t(_,K),t(K,B),t(_,E),t(_,d),t(d,f),t(_,b),t(_,C),t(C,F),t(F,I),t(C,T),t(C,j),t(j,A)},d(U){U&&a(s)}}}function rs(R){let s,l=`<div class="$$stats bg-primary text-primary-content">
  
  <div class="$$stat">
    <div class="$$stat-title">Account balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">Current balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm">Withdrawal</button> 
      <button class="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,c,u,n,h;return{c(){s=v("pre"),c=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);c=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){Y(r,s,$),t(s,c),n||(h=_t(u=gt.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&wt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function vs(R){let s,l,c,u,n,h,r,$,D,y,M,V,_,K,B,E;return s=new qt({props:{data:[{type:"component",class:"stats",desc:"Container of multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),c=new pt({props:{title:"Stat",$$slots:{html:[Ht],default:[Gt]},$$scope:{ctx:R}}}),n=new pt({props:{title:"Stat with icons or image",$$slots:{html:[Xt],default:[Qt]},$$scope:{ctx:R}}}),r=new pt({props:{title:"Stat",$$slots:{html:[Zt],default:[Yt]},$$scope:{ctx:R}}}),D=new pt({props:{title:"Centered items",$$slots:{html:[ss],default:[ts]},$$scope:{ctx:R}}}),M=new pt({props:{title:"Vertical",$$slots:{html:[as],default:[es]},$$scope:{ctx:R}}}),_=new pt({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{html:[is],default:[ls]},$$scope:{ctx:R}}}),B=new pt({props:{title:"With custom colors and button",$$slots:{html:[rs],default:[ds]},$$scope:{ctx:R}}}),{c(){nt(s.$$.fragment),l=w(),nt(c.$$.fragment),u=w(),nt(n.$$.fragment),h=w(),nt(r.$$.fragment),$=w(),nt(D.$$.fragment),y=w(),nt(M.$$.fragment),V=w(),nt(_.$$.fragment),K=w(),nt(B.$$.fragment)},l(d){ut(s.$$.fragment,d),l=g(d),ut(c.$$.fragment,d),u=g(d),ut(n.$$.fragment,d),h=g(d),ut(r.$$.fragment,d),$=g(d),ut(D.$$.fragment,d),y=g(d),ut(M.$$.fragment,d),V=g(d),ut(_.$$.fragment,d),K=g(d),ut(B.$$.fragment,d)},m(d,f){$t(s,d,f),Y(d,l,f),$t(c,d,f),Y(d,u,f),$t(n,d,f),Y(d,h,f),$t(r,d,f),Y(d,$,f),$t(D,d,f),Y(d,y,f),$t(M,d,f),Y(d,V,f),$t(_,d,f),Y(d,K,f),$t(B,d,f),E=!0},p(d,f){const b={};f&5&&(b.$$scope={dirty:f,ctx:d}),c.$set(b);const C={};f&5&&(C.$$scope={dirty:f,ctx:d}),n.$set(C);const F={};f&5&&(F.$$scope={dirty:f,ctx:d}),r.$set(F);const I={};f&5&&(I.$$scope={dirty:f,ctx:d}),D.$set(I);const T={};f&5&&(T.$$scope={dirty:f,ctx:d}),M.$set(T);const j={};f&5&&(j.$$scope={dirty:f,ctx:d}),_.$set(j);const A={};f&5&&(A.$$scope={dirty:f,ctx:d}),B.$set(A)},i(d){E||(ht(s.$$.fragment,d),ht(c.$$.fragment,d),ht(n.$$.fragment,d),ht(r.$$.fragment,d),ht(D.$$.fragment,d),ht(M.$$.fragment,d),ht(_.$$.fragment,d),ht(B.$$.fragment,d),E=!0)},o(d){ft(s.$$.fragment,d),ft(c.$$.fragment,d),ft(n.$$.fragment,d),ft(r.$$.fragment,d),ft(D.$$.fragment,d),ft(M.$$.fragment,d),ft(_.$$.fragment,d),ft(B.$$.fragment,d),E=!1},d(d){mt(s,d),d&&a(l),mt(c,d),d&&a(u),mt(n,d),d&&a(h),mt(r,d),d&&a($),mt(D,d),d&&a(y),mt(M,d),d&&a(V),mt(_,d),d&&a(K),mt(B,d)}}}function os(R){let s,l;const c=[R[1],Pt];let u={$$slots:{default:[vs]},$$scope:{ctx:R}};for(let n=0;n<c.length;n+=1)u=Bt(u,c[n]);return s=new Ot({props:u}),{c(){nt(s.$$.fragment)},l(n){ut(s.$$.fragment,n)},m(n,h){$t(s,n,h),l=!0},p(n,[h]){const r=h&2?St(c,[h&2&&Kt(n[1]),h&0&&Kt(Pt)]):{};h&5&&(r.$$scope={dirty:h,ctx:n}),s.$set(r)},i(n){l||(ht(s.$$.fragment,n),l=!0)},o(n){ft(s.$$.fragment,n),l=!1},d(n){mt(s,n)}}}const Pt={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0};function cs(R,s,l){let c;return Lt(R,Wt,u=>l(0,c=u)),R.$$set=u=>{l(1,s=Bt(Bt({},s),Ut(u)))},s=Ut(s),[c,s]}class gs extends zt{constructor(s){super();Jt(this,s,cs,os,Ct,{})}}export{gs as default,Pt as metadata};
