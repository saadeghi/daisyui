import{S as at,i as st,s as rt,C as Q,w as q,x as y,y as S,z as ot,A as tt,q as F,o as K,B as T,K as nt,ag as et,k as I,m as V,g as D,d as c,e as p,t as k,c as f,a as m,h as L,b as d,F as u,a9 as N,W as P,H as z,I as C}from"../../chunks/vendor-c5cb7521.js";import{M as it}from"../../chunks/_markdown-16b10cd9.js";import{p as ut,C as ct,a as O,r as R}from"../../chunks/actions-1a136406.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-d1f04178.js";import"../../chunks/index-573e9b6d.js";import"../../chunks/SEO-bc78b2ea.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-9e732a78.js";function dt(v){let t,a,o,r,l,i,e,s,n,h,_,g;return{c(){t=p("div"),a=p("ul"),o=p("li"),r=p("a"),l=k("Home"),i=I(),e=p("li"),s=p("a"),n=k("Documents"),h=I(),_=p("li"),g=k("Add Document"),this.h()},l(E){t=f(E,"DIV",{class:!0});var B=m(t);a=f(B,"UL",{});var w=m(a);o=f(w,"LI",{});var b=m(o);r=f(b,"A",{});var x=m(r);l=L(x,"Home"),x.forEach(c),b.forEach(c),i=V(w),e=f(w,"LI",{});var H=m(e);s=f(H,"A",{});var $=m(s);n=L($,"Documents"),$.forEach(c),H.forEach(c),h=V(w),_=f(w,"LI",{});var j=m(_);g=L(j,"Add Document"),j.forEach(c),w.forEach(c),B.forEach(c),this.h()},h(){d(t,"class","text-sm breadcrumbs")},m(E,B){D(E,t,B),u(t,a),u(a,o),u(o,r),u(r,l),u(a,i),u(a,e),u(e,s),u(s,n),u(a,h),u(a,_),u(_,g)},d(E){E&&c(t)}}}function mt(v){let t,a=`<div class="text-sm $$breadcrumbs">
  <ul>
    <li><a>Home</a></li> 
    <li><a>Documents</a></li> 
    <li>Add Document</li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","html")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function ht(v){let t,a=`<div className="text-sm $$breadcrumbs">
  <ul>
    <li><a>Home</a></li> 
    <li><a>Documents</a></li> 
    <li>Add Document</li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","react")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function pt(v){let t,a,o,r,l,i,e,s,n,h,_,g,E,B,w,b,x,H;return{c(){t=p("div"),a=p("ul"),o=p("li"),r=p("a"),l=z("svg"),i=z("path"),e=k(`
        Home`),s=I(),n=p("li"),h=p("a"),_=z("svg"),g=z("path"),E=k(`
        Documents`),B=I(),w=p("li"),b=z("svg"),x=z("path"),H=k(`
      Add Document`),this.h()},l($){t=f($,"DIV",{class:!0});var j=m(t);a=f(j,"UL",{});var A=m(a);o=f(A,"LI",{});var W=m(o);r=f(W,"A",{});var M=m(r);l=C(M,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var U=m(l);i=C(U,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),m(i).forEach(c),U.forEach(c),e=L(M,`
        Home`),M.forEach(c),W.forEach(c),s=V(A),n=f(A,"LI",{});var X=m(n);h=f(X,"A",{});var G=m(h);_=C(G,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Y=m(_);g=C(Y,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),m(g).forEach(c),Y.forEach(c),E=L(G,`
        Documents`),G.forEach(c),X.forEach(c),B=V(A),w=f(A,"LI",{});var J=m(w);b=C(J,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Z=m(b);x=C(Z,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),m(x).forEach(c),Z.forEach(c),H=L(J,`
      Add Document`),J.forEach(c),A.forEach(c),j.forEach(c),this.h()},h(){d(i,"stroke-linecap","round"),d(i,"stroke-linejoin","round"),d(i,"stroke-width","2"),d(i,"d","M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"),d(l,"xmlns","http://www.w3.org/2000/svg"),d(l,"fill","none"),d(l,"viewBox","0 0 24 24"),d(l,"class","w-4 h-4 mr-2 stroke-current"),d(g,"stroke-linecap","round"),d(g,"stroke-linejoin","round"),d(g,"stroke-width","2"),d(g,"d","M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"),d(_,"xmlns","http://www.w3.org/2000/svg"),d(_,"fill","none"),d(_,"viewBox","0 0 24 24"),d(_,"class","w-4 h-4 mr-2 stroke-current"),d(x,"stroke-linecap","round"),d(x,"stroke-linejoin","round"),d(x,"stroke-width","2"),d(x,"d","M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"),d(b,"xmlns","http://www.w3.org/2000/svg"),d(b,"fill","none"),d(b,"viewBox","0 0 24 24"),d(b,"class","w-4 h-4 mr-2 stroke-current"),d(t,"class","text-sm breadcrumbs")},m($,j){D($,t,j),u(t,a),u(a,o),u(o,r),u(r,l),u(l,i),u(r,e),u(a,s),u(a,n),u(n,h),u(h,_),u(_,g),u(h,E),u(a,B),u(a,w),u(w,b),u(b,x),u(w,H)},d($){$&&c(t)}}}function ft(v){let t,a=`<div class="text-sm $$breadcrumbs">
  <ul>
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 mr-2 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Home
      </a>
    </li> 
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 mr-2 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Documents
      </a>
    </li> 
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 mr-2 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
      Add Document
    </li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","html")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function vt(v){let t,a=`<div className="text-sm $$breadcrumbs">
  <ul>
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 mr-2 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Home
      </a>
    </li> 
    <li>
      <a>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 mr-2 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
        Documents
      </a>
    </li> 
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 mr-2 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
      Add Document
    </li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","react")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function _t(v){let t,a,o,r,l,i,e,s,n,h,_,g,E,B,w,b;return{c(){t=p("div"),a=p("ul"),o=p("li"),r=k("Long text 1"),l=I(),i=p("li"),e=k("Long text 2"),s=I(),n=p("li"),h=k("Long text 3"),_=I(),g=p("li"),E=k("Long text 4"),B=I(),w=p("li"),b=k("Long text 5"),this.h()},l(x){t=f(x,"DIV",{class:!0});var H=m(t);a=f(H,"UL",{});var $=m(a);o=f($,"LI",{});var j=m(o);r=L(j,"Long text 1"),j.forEach(c),l=V($),i=f($,"LI",{});var A=m(i);e=L(A,"Long text 2"),A.forEach(c),s=V($),n=f($,"LI",{});var W=m(n);h=L(W,"Long text 3"),W.forEach(c),_=V($),g=f($,"LI",{});var M=m(g);E=L(M,"Long text 4"),M.forEach(c),B=V($),w=f($,"LI",{});var U=m(w);b=L(U,"Long text 5"),U.forEach(c),$.forEach(c),H.forEach(c),this.h()},h(){d(t,"class","max-w-xs text-sm breadcrumbs")},m(x,H){D(x,t,H),u(t,a),u(a,o),u(o,r),u(a,l),u(a,i),u(i,e),u(a,s),u(a,n),u(n,h),u(a,_),u(a,g),u(g,E),u(a,B),u(a,w),u(w,b)},d(x){x&&c(t)}}}function gt(v){let t,a=`<div class="max-w-xs text-sm $$breadcrumbs">
  <ul>
    <li>Long text 1</li>
    <li>Long text 2</li>
    <li>Long text 3</li>
    <li>Long text 4</li>
    <li>Long text 5</li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","html")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function wt(v){let t,a=`<div className="max-w-xs text-sm $$breadcrumbs">
  <ul>
    <li>Long text 1</li>
    <li>Long text 2</li>
    <li>Long text 3</li>
    <li>Long text 4</li>
    <li>Long text 5</li>
  </ul>
</div>`,o,r,l,i;return{c(){t=p("pre"),o=k(a),this.h()},l(e){t=f(e,"PRE",{slot:!0});var s=m(t);o=L(s,a),s.forEach(c),this.h()},h(){d(t,"slot","react")},m(e,s){D(e,t,s),u(t,o),l||(i=N(r=R.call(null,t,{to:v[0]})),l=!0)},p(e,s){r&&P(r.update)&&s&1&&r.update.call(null,{to:e[0]})},d(e){e&&c(t),l=!1,i()}}}function $t(v){let t,a,o,r,l,i,e,s;return t=new ct({props:{data:[{type:"component",class:"breadcrumbs",desc:"Container element"}]}}),o=new O({props:{title:"Breadcrumbs",$$slots:{react:[ht],html:[mt],default:[dt]},$$scope:{ctx:v}}}),l=new O({props:{title:"Breadcrumbs with icons",$$slots:{react:[vt],html:[ft],default:[pt]},$$scope:{ctx:v}}}),e=new O({props:{title:"Breadcrumbs with max-width",desc:"If you set max-width or the list gets larger than the container it will scroll",$$slots:{react:[wt],html:[gt],default:[_t]},$$scope:{ctx:v}}}),{c(){q(t.$$.fragment),a=I(),q(o.$$.fragment),r=I(),q(l.$$.fragment),i=I(),q(e.$$.fragment)},l(n){y(t.$$.fragment,n),a=V(n),y(o.$$.fragment,n),r=V(n),y(l.$$.fragment,n),i=V(n),y(e.$$.fragment,n)},m(n,h){S(t,n,h),D(n,a,h),S(o,n,h),D(n,r,h),S(l,n,h),D(n,i,h),S(e,n,h),s=!0},p(n,h){const _={};h&5&&(_.$$scope={dirty:h,ctx:n}),o.$set(_);const g={};h&5&&(g.$$scope={dirty:h,ctx:n}),l.$set(g);const E={};h&5&&(E.$$scope={dirty:h,ctx:n}),e.$set(E)},i(n){s||(F(t.$$.fragment,n),F(o.$$.fragment,n),F(l.$$.fragment,n),F(e.$$.fragment,n),s=!0)},o(n){K(t.$$.fragment,n),K(o.$$.fragment,n),K(l.$$.fragment,n),K(e.$$.fragment,n),s=!1},d(n){T(t,n),n&&c(a),T(o,n),n&&c(r),T(l,n),n&&c(i),T(e,n)}}}function xt(v){let t,a;const o=[v[1],lt];let r={$$slots:{default:[$t]},$$scope:{ctx:v}};for(let l=0;l<o.length;l+=1)r=Q(r,o[l]);return t=new it({props:r}),{c(){q(t.$$.fragment)},l(l){y(t.$$.fragment,l)},m(l,i){S(t,l,i),a=!0},p(l,[i]){const e=i&2?ot(o,[i&2&&tt(l[1]),i&0&&tt(lt)]):{};i&5&&(e.$$scope={dirty:i,ctx:l}),t.$set(e)},i(l){a||(F(t.$$.fragment,l),a=!0)},o(l){K(t.$$.fragment,l),a=!1},d(l){T(t,l)}}}const lt={title:"Breadcrumbs",desc:"Breadcrumbs helps users to navigate through the website.",published:!0};function kt(v,t,a){let o;return nt(v,ut,r=>a(0,o=r)),v.$$set=r=>{a(1,t=Q(Q({},t),et(r)))},t=et(t),[o,t]}class At extends at{constructor(t){super();st(this,t,kt,xt,rt,{})}}export{At as default,lt as metadata};
