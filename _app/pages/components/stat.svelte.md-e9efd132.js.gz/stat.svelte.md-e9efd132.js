import{S as Ut,i as zt,s as Jt,C as Bt,w as ht,x as mt,y as ft,z as Ct,A as jt,q as pt,o as _t,B as wt,K as St,ag as Kt,k as w,m as g,g as W,d as l,e as u,t as m,c as $,a as o,h as f,b as a,F as s,a9 as at,Q as lt,H as ut,I as $t,O as Wt}from"../../chunks/vendor-3400f70d.js";import{M as At}from"../../chunks/_markdown-0aba8325.js";import{p as Ot,C as qt,a as gt,r as it}from"../../chunks/actions-bb6d9301.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-1a8b7daa.js";import"../../chunks/index-2aac554d.js";import"../../chunks/SEO-dc8deace.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-11002da1.js";function Gt(k){let t,i,v,r,c,h,e,d,V,y;return{c(){t=u("div"),i=u("div"),v=u("div"),r=m("Total Page Views"),c=w(),h=u("div"),e=m("89,400"),d=w(),V=u("div"),y=m("21% more than last month"),this.h()},l(R){t=$(R,"DIV",{class:!0});var N=o(t);i=$(N,"DIV",{class:!0});var _=o(i);v=$(_,"DIV",{class:!0});var j=o(v);r=f(j,"Total Page Views"),j.forEach(l),c=g(_),h=$(_,"DIV",{class:!0});var B=o(h);e=f(B,"89,400"),B.forEach(l),d=g(_),V=$(_,"DIV",{class:!0});var E=o(V);y=f(E,"21% more than last month"),E.forEach(l),_.forEach(l),N.forEach(l),this.h()},h(){a(v,"class","stat-title"),a(h,"class","stat-value"),a(V,"class","stat-desc"),a(i,"class","stat"),a(t,"class","shadow stats")},m(R,N){W(R,t,N),s(t,i),s(i,v),s(v,r),s(i,c),s(i,h),s(h,e),s(i,d),s(i,V),s(V,y)},d(R){R&&l(t)}}}function Ht(k){let t,i=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Total Page Views</div>
    <div class="$$stat-value">89,400</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function Qt(k){let t,i=`<div className="$$stats shadow">
  
  <div className="$$stat">
    <div className="$$stat-title">Total Page Views</div>
    <div className="$$stat-value">89,400</div>
    <div className="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function Xt(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A,K,z,O,C,M,T,b,x,G,H,Q,U,q,tt,Z,S,st,X,Y;return{c(){t=u("div"),i=u("div"),v=u("div"),r=ut("svg"),c=ut("path"),h=w(),e=u("div"),d=m("Total Likes"),V=w(),y=u("div"),R=m("25.6K"),N=w(),_=u("div"),j=m("21% more than last month"),B=w(),E=u("div"),n=u("div"),p=ut("svg"),I=ut("path"),J=w(),F=u("div"),D=m("Page Views"),L=w(),P=u("div"),A=m("2.6M"),K=w(),z=u("div"),O=m("21% more than last month"),C=w(),M=u("div"),T=u("div"),b=u("div"),x=u("div"),G=u("img"),Q=w(),U=u("div"),q=m("86%"),tt=w(),Z=u("div"),S=m("Tasks done"),st=w(),X=u("div"),Y=m("31 tasks remaining"),this.h()},l(et){t=$(et,"DIV",{class:!0});var dt=o(t);i=$(dt,"DIV",{class:!0});var rt=o(i);v=$(rt,"DIV",{class:!0});var Et=o(v);r=$t(Et,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Nt=o(r);c=$t(Nt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(c).forEach(l),Nt.forEach(l),Et.forEach(l),h=g(rt),e=$(rt,"DIV",{class:!0});var Vt=o(e);d=f(Vt,"Total Likes"),Vt.forEach(l),V=g(rt),y=$(rt,"DIV",{class:!0});var vt=o(y);R=f(vt,"25.6K"),vt.forEach(l),N=g(rt),_=$(rt,"DIV",{class:!0});var kt=o(_);j=f(kt,"21% more than last month"),kt.forEach(l),rt.forEach(l),B=g(dt),E=$(dt,"DIV",{class:!0});var ct=o(E);n=$(ct,"DIV",{class:!0});var Dt=o(n);p=$t(Dt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var bt=o(p);I=$t(bt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(I).forEach(l),bt.forEach(l),Dt.forEach(l),J=g(ct),F=$(ct,"DIV",{class:!0});var It=o(F);D=f(It,"Page Views"),It.forEach(l),L=g(ct),P=$(ct,"DIV",{class:!0});var ot=o(P);A=f(ot,"2.6M"),ot.forEach(l),K=g(ct),z=$(ct,"DIV",{class:!0});var xt=o(z);O=f(xt,"21% more than last month"),xt.forEach(l),ct.forEach(l),C=g(dt),M=$(dt,"DIV",{class:!0});var nt=o(M);T=$(nt,"DIV",{class:!0});var yt=o(T);b=$(yt,"DIV",{class:!0});var Mt=o(b);x=$(Mt,"DIV",{class:!0});var Rt=o(x);G=$(Rt,"IMG",{src:!0}),Rt.forEach(l),Mt.forEach(l),yt.forEach(l),Q=g(nt),U=$(nt,"DIV",{class:!0});var Ft=o(U);q=f(Ft,"86%"),Ft.forEach(l),tt=g(nt),Z=$(nt,"DIV",{class:!0});var Lt=o(Z);S=f(Lt,"Tasks done"),Lt.forEach(l),st=g(nt),X=$(nt,"DIV",{class:!0});var Pt=o(X);Y=f(Pt,"31 tasks remaining"),Pt.forEach(l),nt.forEach(l),dt.forEach(l),this.h()},h(){a(c,"stroke-linecap","round"),a(c,"stroke-linejoin","round"),a(c,"stroke-width","2"),a(c,"d","M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"),a(r,"xmlns","http://www.w3.org/2000/svg"),a(r,"fill","none"),a(r,"viewBox","0 0 24 24"),a(r,"class","inline-block w-8 h-8 stroke-current"),a(v,"class","stat-figure text-primary"),a(e,"class","stat-title"),a(y,"class","stat-value text-primary"),a(_,"class","stat-desc"),a(i,"class","stat"),a(I,"stroke-linecap","round"),a(I,"stroke-linejoin","round"),a(I,"stroke-width","2"),a(I,"d","M13 10V3L4 14h7v7l9-11h-7z"),a(p,"xmlns","http://www.w3.org/2000/svg"),a(p,"fill","none"),a(p,"viewBox","0 0 24 24"),a(p,"class","inline-block w-8 h-8 stroke-current"),a(n,"class","stat-figure text-secondary"),a(F,"class","stat-title"),a(P,"class","stat-value text-secondary"),a(z,"class","stat-desc"),a(E,"class","stat"),Wt(G.src,H="https://placeimg.com/128/128/people")||a(G,"src",H),a(x,"class","w-16 rounded-full"),a(b,"class","avatar online"),a(T,"class","stat-figure text-secondary"),a(U,"class","stat-value"),a(Z,"class","stat-title"),a(X,"class","stat-desc text-secondary"),a(M,"class","stat"),a(t,"class","shadow stats")},m(et,dt){W(et,t,dt),s(t,i),s(i,v),s(v,r),s(r,c),s(i,h),s(i,e),s(e,d),s(i,V),s(i,y),s(y,R),s(i,N),s(i,_),s(_,j),s(t,B),s(t,E),s(E,n),s(n,p),s(p,I),s(E,J),s(E,F),s(F,D),s(E,L),s(E,P),s(P,A),s(E,K),s(E,z),s(z,O),s(t,C),s(t,M),s(M,T),s(T,b),s(b,x),s(x,G),s(M,Q),s(M,U),s(U,q),s(M,tt),s(M,Z),s(Z,S),s(M,st),s(M,X),s(X,Y)},d(et){et&&l(t)}}}function Yt(k){let t,i=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="$$stat-title">Total Likes</div>
    <div class="$$stat-value text-primary">25.6K</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="$$stat-title">Page Views</div>
    <div class="$$stat-value text-secondary">2.6M</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <div class="$$avatar $$online">
        <div class="w-16 rounded-full">
          <img src="https://placeimg.com/128/128/people" />
        </div>
      </div>
    </div>
    <div class="$$stat-value">86%</div>
    <div class="$$stat-title">Tasks done</div>
    <div class="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function Zt(k){let t,i=`<div className="$$stats shadow">
  
  <div className="$$stat">
    <div className="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-8 h-8 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div className="$$stat-title">Total Likes</div>
    <div className="$$stat-value text-primary">25.6K</div>
    <div className="$$stat-desc">21% more than last month</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-8 h-8 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div className="$$stat-title">Page Views</div>
    <div className="$$stat-value text-secondary">2.6M</div>
    <div className="$$stat-desc">21% more than last month</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-figure text-secondary">
      <div className="$$avatar $$online">
        <div className="w-16 rounded-full">
          <img src="https://placeimg.com/128/128/people" />
        </div>
      </div>
    </div>
    <div className="$$stat-value">86%</div>
    <div className="$$stat-title">Tasks done</div>
    <div className="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function ts(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A,K,z,O,C,M,T,b,x,G,H,Q,U,q,tt,Z,S,st;return{c(){t=u("div"),i=u("div"),v=u("div"),r=ut("svg"),c=ut("path"),h=w(),e=u("div"),d=m("Downloads"),V=w(),y=u("div"),R=m("31K"),N=w(),_=u("div"),j=m("Jan 1st - Feb 1st"),B=w(),E=u("div"),n=u("div"),p=ut("svg"),I=ut("path"),J=w(),F=u("div"),D=m("New Users"),L=w(),P=u("div"),A=m("4,200"),K=w(),z=u("div"),O=m("\u2197\uFE0E 400 (22%)"),C=w(),M=u("div"),T=u("div"),b=ut("svg"),x=ut("path"),G=w(),H=u("div"),Q=m("New Registers"),U=w(),q=u("div"),tt=m("1,200"),Z=w(),S=u("div"),st=m("\u2198\uFE0E 90 (14%)"),this.h()},l(X){t=$(X,"DIV",{class:!0});var Y=o(t);i=$(Y,"DIV",{class:!0});var et=o(i);v=$(et,"DIV",{class:!0});var dt=o(v);r=$t(dt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var rt=o(r);c=$t(rt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(c).forEach(l),rt.forEach(l),dt.forEach(l),h=g(et),e=$(et,"DIV",{class:!0});var Et=o(e);d=f(Et,"Downloads"),Et.forEach(l),V=g(et),y=$(et,"DIV",{class:!0});var Nt=o(y);R=f(Nt,"31K"),Nt.forEach(l),N=g(et),_=$(et,"DIV",{class:!0});var Vt=o(_);j=f(Vt,"Jan 1st - Feb 1st"),Vt.forEach(l),et.forEach(l),B=g(Y),E=$(Y,"DIV",{class:!0});var vt=o(E);n=$(vt,"DIV",{class:!0});var kt=o(n);p=$t(kt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var ct=o(p);I=$t(ct,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(I).forEach(l),ct.forEach(l),kt.forEach(l),J=g(vt),F=$(vt,"DIV",{class:!0});var Dt=o(F);D=f(Dt,"New Users"),Dt.forEach(l),L=g(vt),P=$(vt,"DIV",{class:!0});var bt=o(P);A=f(bt,"4,200"),bt.forEach(l),K=g(vt),z=$(vt,"DIV",{class:!0});var It=o(z);O=f(It,"\u2197\uFE0E 400 (22%)"),It.forEach(l),vt.forEach(l),C=g(Y),M=$(Y,"DIV",{class:!0});var ot=o(M);T=$(ot,"DIV",{class:!0});var xt=o(T);b=$t(xt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var nt=o(b);x=$t(nt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),o(x).forEach(l),nt.forEach(l),xt.forEach(l),G=g(ot),H=$(ot,"DIV",{class:!0});var yt=o(H);Q=f(yt,"New Registers"),yt.forEach(l),U=g(ot),q=$(ot,"DIV",{class:!0});var Mt=o(q);tt=f(Mt,"1,200"),Mt.forEach(l),Z=g(ot),S=$(ot,"DIV",{class:!0});var Rt=o(S);st=f(Rt,"\u2198\uFE0E 90 (14%)"),Rt.forEach(l),ot.forEach(l),Y.forEach(l),this.h()},h(){a(c,"stroke-linecap","round"),a(c,"stroke-linejoin","round"),a(c,"stroke-width","2"),a(c,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),a(r,"xmlns","http://www.w3.org/2000/svg"),a(r,"fill","none"),a(r,"viewBox","0 0 24 24"),a(r,"class","inline-block w-8 h-8 stroke-current"),a(v,"class","stat-figure text-secondary"),a(e,"class","stat-title"),a(y,"class","stat-value"),a(_,"class","stat-desc"),a(i,"class","stat"),a(I,"stroke-linecap","round"),a(I,"stroke-linejoin","round"),a(I,"stroke-width","2"),a(I,"d","M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"),a(p,"xmlns","http://www.w3.org/2000/svg"),a(p,"fill","none"),a(p,"viewBox","0 0 24 24"),a(p,"class","inline-block w-8 h-8 stroke-current"),a(n,"class","stat-figure text-secondary"),a(F,"class","stat-title"),a(P,"class","stat-value"),a(z,"class","stat-desc"),a(E,"class","stat"),a(x,"stroke-linecap","round"),a(x,"stroke-linejoin","round"),a(x,"stroke-width","2"),a(x,"d","M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"),a(b,"xmlns","http://www.w3.org/2000/svg"),a(b,"fill","none"),a(b,"viewBox","0 0 24 24"),a(b,"class","inline-block w-8 h-8 stroke-current"),a(T,"class","stat-figure text-secondary"),a(H,"class","stat-title"),a(q,"class","stat-value"),a(S,"class","stat-desc"),a(M,"class","stat"),a(t,"class","shadow stats")},m(X,Y){W(X,t,Y),s(t,i),s(i,v),s(v,r),s(r,c),s(i,h),s(i,e),s(e,d),s(i,V),s(i,y),s(y,R),s(i,N),s(i,_),s(_,j),s(t,B),s(t,E),s(E,n),s(n,p),s(p,I),s(E,J),s(E,F),s(F,D),s(E,L),s(E,P),s(P,A),s(E,K),s(E,z),s(z,O),s(t,C),s(t,M),s(M,T),s(T,b),s(b,x),s(M,G),s(M,H),s(H,Q),s(M,U),s(M,q),s(q,tt),s(M,Z),s(M,S),s(S,st)},d(X){X&&l(t)}}}function ss(k){let t,i=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function es(k){let t,i=`<div className="$$stats shadow">
  
  <div className="$$stat">
    <div className="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-8 h-8 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div className="$$stat-title">Downloads</div>
    <div className="$$stat-value">31K</div>
    <div className="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-8 h-8 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div className="$$stat-title">New Users</div>
    <div className="$$stat-value">4,200</div>
    <div className="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-8 h-8 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div className="$$stat-title">New Registers</div>
    <div className="$$stat-value">1,200</div>
    <div className="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function as(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A,K,z,O,C,M;return{c(){t=u("div"),i=u("div"),v=u("div"),r=m("Downloads"),c=w(),h=u("div"),e=m("31K"),d=w(),V=u("div"),y=m("From January 1st to February 1st"),R=w(),N=u("div"),_=u("div"),j=m("Users"),B=w(),E=u("div"),n=m("4,200"),p=w(),I=u("div"),J=m("\u2197\uFE0E 40 (2%)"),F=w(),D=u("div"),L=u("div"),P=m("New Registers"),A=w(),K=u("div"),z=m("1,200"),O=w(),C=u("div"),M=m("\u2198\uFE0E 90 (14%)"),this.h()},l(T){t=$(T,"DIV",{class:!0});var b=o(t);i=$(b,"DIV",{class:!0});var x=o(i);v=$(x,"DIV",{class:!0});var G=o(v);r=f(G,"Downloads"),G.forEach(l),c=g(x),h=$(x,"DIV",{class:!0});var H=o(h);e=f(H,"31K"),H.forEach(l),d=g(x),V=$(x,"DIV",{class:!0});var Q=o(V);y=f(Q,"From January 1st to February 1st"),Q.forEach(l),x.forEach(l),R=g(b),N=$(b,"DIV",{class:!0});var U=o(N);_=$(U,"DIV",{class:!0});var q=o(_);j=f(q,"Users"),q.forEach(l),B=g(U),E=$(U,"DIV",{class:!0});var tt=o(E);n=f(tt,"4,200"),tt.forEach(l),p=g(U),I=$(U,"DIV",{class:!0});var Z=o(I);J=f(Z,"\u2197\uFE0E 40 (2%)"),Z.forEach(l),U.forEach(l),F=g(b),D=$(b,"DIV",{class:!0});var S=o(D);L=$(S,"DIV",{class:!0});var st=o(L);P=f(st,"New Registers"),st.forEach(l),A=g(S),K=$(S,"DIV",{class:!0});var X=o(K);z=f(X,"1,200"),X.forEach(l),O=g(S),C=$(S,"DIV",{class:!0});var Y=o(C);M=f(Y,"\u2198\uFE0E 90 (14%)"),Y.forEach(l),S.forEach(l),b.forEach(l),this.h()},h(){a(v,"class","stat-title"),a(h,"class","stat-value"),a(V,"class","stat-desc"),a(i,"class","stat place-items-center"),a(_,"class","stat-title"),a(E,"class","stat-value text-secondary"),a(I,"class","stat-desc text-secondary"),a(N,"class","stat place-items-center"),a(L,"class","stat-title"),a(K,"class","stat-value"),a(C,"class","stat-desc"),a(D,"class","stat place-items-center"),a(t,"class","shadow stats")},m(T,b){W(T,t,b),s(t,i),s(i,v),s(v,r),s(i,c),s(i,h),s(h,e),s(i,d),s(i,V),s(V,y),s(t,R),s(t,N),s(N,_),s(_,j),s(N,B),s(N,E),s(E,n),s(N,p),s(N,I),s(I,J),s(t,F),s(t,D),s(D,L),s(L,P),s(D,A),s(D,K),s(K,z),s(D,O),s(D,C),s(C,M)},d(T){T&&l(t)}}}function ls(k){let t,i=`<div class="$$stats shadow">
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Users</div>
    <div class="$$stat-value text-secondary">4,200</div>
    <div class="$$stat-desc text-secondary">\u2197\uFE0E 40 (2%)</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function is(k){let t,i=`<div className="$$stats shadow">
  
  <div className="$$stat place-items-center">
    <div className="$$stat-title">Downloads</div>
    <div className="$$stat-value">31K</div>
    <div className="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div className="$$stat place-items-center">
    <div className="$$stat-title">Users</div>
    <div className="$$stat-value text-secondary">4,200</div>
    <div className="$$stat-desc text-secondary">\u2197\uFE0E 40 (2%)</div>
  </div>
  
  <div className="$$stat place-items-center">
    <div className="$$stat-title">New Registers</div>
    <div className="$$stat-value">1,200</div>
    <div className="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function ds(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A,K,z,O,C,M;return{c(){t=u("div"),i=u("div"),v=u("div"),r=m("Downloads"),c=w(),h=u("div"),e=m("31K"),d=w(),V=u("div"),y=m("Jan 1st - Feb 1st"),R=w(),N=u("div"),_=u("div"),j=m("New Users"),B=w(),E=u("div"),n=m("4,200"),p=w(),I=u("div"),J=m("\u2197\uFE0E 400 (22%)"),F=w(),D=u("div"),L=u("div"),P=m("New Registers"),A=w(),K=u("div"),z=m("1,200"),O=w(),C=u("div"),M=m("\u2198\uFE0E 90 (14%)"),this.h()},l(T){t=$(T,"DIV",{class:!0});var b=o(t);i=$(b,"DIV",{class:!0});var x=o(i);v=$(x,"DIV",{class:!0});var G=o(v);r=f(G,"Downloads"),G.forEach(l),c=g(x),h=$(x,"DIV",{class:!0});var H=o(h);e=f(H,"31K"),H.forEach(l),d=g(x),V=$(x,"DIV",{class:!0});var Q=o(V);y=f(Q,"Jan 1st - Feb 1st"),Q.forEach(l),x.forEach(l),R=g(b),N=$(b,"DIV",{class:!0});var U=o(N);_=$(U,"DIV",{class:!0});var q=o(_);j=f(q,"New Users"),q.forEach(l),B=g(U),E=$(U,"DIV",{class:!0});var tt=o(E);n=f(tt,"4,200"),tt.forEach(l),p=g(U),I=$(U,"DIV",{class:!0});var Z=o(I);J=f(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(l),U.forEach(l),F=g(b),D=$(b,"DIV",{class:!0});var S=o(D);L=$(S,"DIV",{class:!0});var st=o(L);P=f(st,"New Registers"),st.forEach(l),A=g(S),K=$(S,"DIV",{class:!0});var X=o(K);z=f(X,"1,200"),X.forEach(l),O=g(S),C=$(S,"DIV",{class:!0});var Y=o(C);M=f(Y,"\u2198\uFE0E 90 (14%)"),Y.forEach(l),S.forEach(l),b.forEach(l),this.h()},h(){a(v,"class","stat-title"),a(h,"class","stat-value"),a(V,"class","stat-desc"),a(i,"class","stat"),a(_,"class","stat-title"),a(E,"class","stat-value"),a(I,"class","stat-desc"),a(N,"class","stat"),a(L,"class","stat-title"),a(K,"class","stat-value"),a(C,"class","stat-desc"),a(D,"class","stat"),a(t,"class","shadow stats stats-vertical")},m(T,b){W(T,t,b),s(t,i),s(i,v),s(v,r),s(i,c),s(i,h),s(h,e),s(i,d),s(i,V),s(V,y),s(t,R),s(t,N),s(N,_),s(_,j),s(N,B),s(N,E),s(E,n),s(N,p),s(N,I),s(I,J),s(t,F),s(t,D),s(D,L),s(L,P),s(D,A),s(D,K),s(K,z),s(D,O),s(D,C),s(C,M)},d(T){T&&l(t)}}}function rs(k){let t,i=`<div class="$$stats $$stats-vertical shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function vs(k){let t,i=`<div className="$$stats $$stats-vertical shadow">
  
  <div className="$$stat">
    <div className="$$stat-title">Downloads</div>
    <div className="$$stat-value">31K</div>
    <div className="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-title">New Users</div>
    <div className="$$stat-value">4,200</div>
    <div className="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-title">New Registers</div>
    <div className="$$stat-value">1,200</div>
    <div className="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function cs(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A,K,z,O,C,M;return{c(){t=u("div"),i=u("div"),v=u("div"),r=m("Downloads"),c=w(),h=u("div"),e=m("31K"),d=w(),V=u("div"),y=m("Jan 1st - Feb 1st"),R=w(),N=u("div"),_=u("div"),j=m("New Users"),B=w(),E=u("div"),n=m("4,200"),p=w(),I=u("div"),J=m("\u2197\uFE0E 400 (22%)"),F=w(),D=u("div"),L=u("div"),P=m("New Registers"),A=w(),K=u("div"),z=m("1,200"),O=w(),C=u("div"),M=m("\u2198\uFE0E 90 (14%)"),this.h()},l(T){t=$(T,"DIV",{class:!0});var b=o(t);i=$(b,"DIV",{class:!0});var x=o(i);v=$(x,"DIV",{class:!0});var G=o(v);r=f(G,"Downloads"),G.forEach(l),c=g(x),h=$(x,"DIV",{class:!0});var H=o(h);e=f(H,"31K"),H.forEach(l),d=g(x),V=$(x,"DIV",{class:!0});var Q=o(V);y=f(Q,"Jan 1st - Feb 1st"),Q.forEach(l),x.forEach(l),R=g(b),N=$(b,"DIV",{class:!0});var U=o(N);_=$(U,"DIV",{class:!0});var q=o(_);j=f(q,"New Users"),q.forEach(l),B=g(U),E=$(U,"DIV",{class:!0});var tt=o(E);n=f(tt,"4,200"),tt.forEach(l),p=g(U),I=$(U,"DIV",{class:!0});var Z=o(I);J=f(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(l),U.forEach(l),F=g(b),D=$(b,"DIV",{class:!0});var S=o(D);L=$(S,"DIV",{class:!0});var st=o(L);P=f(st,"New Registers"),st.forEach(l),A=g(S),K=$(S,"DIV",{class:!0});var X=o(K);z=f(X,"1,200"),X.forEach(l),O=g(S),C=$(S,"DIV",{class:!0});var Y=o(C);M=f(Y,"\u2198\uFE0E 90 (14%)"),Y.forEach(l),S.forEach(l),b.forEach(l),this.h()},h(){a(v,"class","stat-title"),a(h,"class","stat-value"),a(V,"class","stat-desc"),a(i,"class","stat"),a(_,"class","stat-title"),a(E,"class","stat-value"),a(I,"class","stat-desc"),a(N,"class","stat"),a(L,"class","stat-title"),a(K,"class","stat-value"),a(C,"class","stat-desc"),a(D,"class","stat"),a(t,"class","shadow stats stats-vertical lg:stats-horizontal")},m(T,b){W(T,t,b),s(t,i),s(i,v),s(v,r),s(i,c),s(i,h),s(h,e),s(i,d),s(i,V),s(V,y),s(t,R),s(t,N),s(N,_),s(_,j),s(N,B),s(N,E),s(E,n),s(N,p),s(N,I),s(I,J),s(t,F),s(t,D),s(D,L),s(L,P),s(D,A),s(D,K),s(K,z),s(D,O),s(D,C),s(C,M)},d(T){T&&l(t)}}}function os(k){let t,i=`<div class="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function ns(k){let t,i=`<div className="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div className="$$stat">
    <div className="$$stat-title">Downloads</div>
    <div className="$$stat-value">31K</div>
    <div className="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-title">New Users</div>
    <div className="$$stat-value">4,200</div>
    <div className="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-title">New Registers</div>
    <div className="$$stat-value">1,200</div>
    <div className="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function us(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E,n,p,I,J,F,D,L,P,A;return{c(){t=u("div"),i=u("div"),v=u("div"),r=m("Account balance"),c=w(),h=u("div"),e=m("$89,400"),d=w(),V=u("div"),y=u("button"),R=m("Add funds"),N=w(),_=u("div"),j=u("div"),B=m("Current balance"),E=w(),n=u("div"),p=m("$89,400"),I=w(),J=u("div"),F=u("button"),D=m("Withdrawal"),L=w(),P=u("button"),A=m("deposit"),this.h()},l(K){t=$(K,"DIV",{class:!0});var z=o(t);i=$(z,"DIV",{class:!0});var O=o(i);v=$(O,"DIV",{class:!0});var C=o(v);r=f(C,"Account balance"),C.forEach(l),c=g(O),h=$(O,"DIV",{class:!0});var M=o(h);e=f(M,"$89,400"),M.forEach(l),d=g(O),V=$(O,"DIV",{class:!0});var T=o(V);y=$(T,"BUTTON",{class:!0});var b=o(y);R=f(b,"Add funds"),b.forEach(l),T.forEach(l),O.forEach(l),N=g(z),_=$(z,"DIV",{class:!0});var x=o(_);j=$(x,"DIV",{class:!0});var G=o(j);B=f(G,"Current balance"),G.forEach(l),E=g(x),n=$(x,"DIV",{class:!0});var H=o(n);p=f(H,"$89,400"),H.forEach(l),I=g(x),J=$(x,"DIV",{class:!0});var Q=o(J);F=$(Q,"BUTTON",{class:!0});var U=o(F);D=f(U,"Withdrawal"),U.forEach(l),L=g(Q),P=$(Q,"BUTTON",{class:!0});var q=o(P);A=f(q,"deposit"),q.forEach(l),Q.forEach(l),x.forEach(l),z.forEach(l),this.h()},h(){a(v,"class","stat-title"),a(h,"class","stat-value"),a(y,"class","btn btn-sm btn-success"),a(V,"class","stat-actions"),a(i,"class","stat"),a(j,"class","stat-title"),a(n,"class","stat-value"),a(F,"class","btn btn-sm"),a(P,"class","btn btn-sm"),a(J,"class","stat-actions"),a(_,"class","stat"),a(t,"class","stats bg-primary text-primary-content")},m(K,z){W(K,t,z),s(t,i),s(i,v),s(v,r),s(i,c),s(i,h),s(h,e),s(i,d),s(i,V),s(V,y),s(y,R),s(t,N),s(t,_),s(_,j),s(j,B),s(_,E),s(_,n),s(n,p),s(_,I),s(_,J),s(J,F),s(F,D),s(J,L),s(J,P),s(P,A)},d(K){K&&l(t)}}}function $s(k){let t,i=`<div class="$$stats bg-primary text-primary-content">
  
  <div class="$$stat">
    <div class="$$stat-title">Account balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">Current balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm">Withdrawal</button> 
      <button class="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","html")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function hs(k){let t,i=`<div className="$$stats bg-primary text-primary-content">
  
  <div className="$$stat">
    <div className="$$stat-title">Account balance</div>
    <div className="$$stat-value">$89,400</div>
    <div className="$$stat-actions">
      <button className="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div className="$$stat">
    <div className="$$stat-title">Current balance</div>
    <div className="$$stat-value">$89,400</div>
    <div className="$$stat-actions">
      <button className="$$btn $$btn-sm">Withdrawal</button> 
      <button className="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,v,r,c,h;return{c(){t=u("pre"),v=m(i),this.h()},l(e){t=$(e,"PRE",{slot:!0});var d=o(t);v=f(d,i),d.forEach(l),this.h()},h(){a(t,"slot","react")},m(e,d){W(e,t,d),s(t,v),c||(h=at(r=it.call(null,t,{to:k[0]})),c=!0)},p(e,d){r&&lt(r.update)&&d&1&&r.update.call(null,{to:e[0]})},d(e){e&&l(t),c=!1,h()}}}function ms(k){let t,i,v,r,c,h,e,d,V,y,R,N,_,j,B,E;return t=new qt({props:{data:[{type:"component",class:"stats",desc:"Container of multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"component",class:"stat-actions",desc:"For buttons, input, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),v=new gt({props:{title:"Stat",$$slots:{react:[Qt],html:[Ht],default:[Gt]},$$scope:{ctx:k}}}),c=new gt({props:{title:"Stat with icons or image",$$slots:{react:[Zt],html:[Yt],default:[Xt]},$$scope:{ctx:k}}}),e=new gt({props:{title:"Stat",$$slots:{react:[es],html:[ss],default:[ts]},$$scope:{ctx:k}}}),V=new gt({props:{title:"Centered items",$$slots:{react:[is],html:[ls],default:[as]},$$scope:{ctx:k}}}),R=new gt({props:{title:"Vertical",$$slots:{react:[vs],html:[rs],default:[ds]},$$scope:{ctx:k}}}),_=new gt({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{react:[ns],html:[os],default:[cs]},$$scope:{ctx:k}}}),B=new gt({props:{title:"With custom colors and button",$$slots:{react:[hs],html:[$s],default:[us]},$$scope:{ctx:k}}}),{c(){ht(t.$$.fragment),i=w(),ht(v.$$.fragment),r=w(),ht(c.$$.fragment),h=w(),ht(e.$$.fragment),d=w(),ht(V.$$.fragment),y=w(),ht(R.$$.fragment),N=w(),ht(_.$$.fragment),j=w(),ht(B.$$.fragment)},l(n){mt(t.$$.fragment,n),i=g(n),mt(v.$$.fragment,n),r=g(n),mt(c.$$.fragment,n),h=g(n),mt(e.$$.fragment,n),d=g(n),mt(V.$$.fragment,n),y=g(n),mt(R.$$.fragment,n),N=g(n),mt(_.$$.fragment,n),j=g(n),mt(B.$$.fragment,n)},m(n,p){ft(t,n,p),W(n,i,p),ft(v,n,p),W(n,r,p),ft(c,n,p),W(n,h,p),ft(e,n,p),W(n,d,p),ft(V,n,p),W(n,y,p),ft(R,n,p),W(n,N,p),ft(_,n,p),W(n,j,p),ft(B,n,p),E=!0},p(n,p){const I={};p&5&&(I.$$scope={dirty:p,ctx:n}),v.$set(I);const J={};p&5&&(J.$$scope={dirty:p,ctx:n}),c.$set(J);const F={};p&5&&(F.$$scope={dirty:p,ctx:n}),e.$set(F);const D={};p&5&&(D.$$scope={dirty:p,ctx:n}),V.$set(D);const L={};p&5&&(L.$$scope={dirty:p,ctx:n}),R.$set(L);const P={};p&5&&(P.$$scope={dirty:p,ctx:n}),_.$set(P);const A={};p&5&&(A.$$scope={dirty:p,ctx:n}),B.$set(A)},i(n){E||(pt(t.$$.fragment,n),pt(v.$$.fragment,n),pt(c.$$.fragment,n),pt(e.$$.fragment,n),pt(V.$$.fragment,n),pt(R.$$.fragment,n),pt(_.$$.fragment,n),pt(B.$$.fragment,n),E=!0)},o(n){_t(t.$$.fragment,n),_t(v.$$.fragment,n),_t(c.$$.fragment,n),_t(e.$$.fragment,n),_t(V.$$.fragment,n),_t(R.$$.fragment,n),_t(_.$$.fragment,n),_t(B.$$.fragment,n),E=!1},d(n){wt(t,n),n&&l(i),wt(v,n),n&&l(r),wt(c,n),n&&l(h),wt(e,n),n&&l(d),wt(V,n),n&&l(y),wt(R,n),n&&l(N),wt(_,n),n&&l(j),wt(B,n)}}}function fs(k){let t,i;const v=[k[1],Tt];let r={$$slots:{default:[ms]},$$scope:{ctx:k}};for(let c=0;c<v.length;c+=1)r=Bt(r,v[c]);return t=new At({props:r}),{c(){ht(t.$$.fragment)},l(c){mt(t.$$.fragment,c)},m(c,h){ft(t,c,h),i=!0},p(c,[h]){const e=h&2?Ct(v,[h&2&&jt(c[1]),h&0&&jt(Tt)]):{};h&5&&(e.$$scope={dirty:h,ctx:c}),t.$set(e)},i(c){i||(pt(t.$$.fragment,c),i=!0)},o(c){_t(t.$$.fragment,c),i=!1},d(c){wt(t,c)}}}const Tt={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0};function ps(k,t,i){let v;return St(k,Ot,r=>i(0,v=r)),k.$$set=r=>{i(1,t=Bt(Bt({},t),Kt(r)))},t=Kt(t),[v,t]}class Is extends Ut{constructor(t){super();zt(this,t,ps,fs,Jt,{})}}export{Is as default,Tt as metadata};
