import{S as O,i as Q,s as U,C as S,w,x as P,y as Y,z as V,A as K,q as C,o as I,B as M,K as X,ag as G,k as T,m as W,g as p,d as m,e as f,t as $,c as b,a as h,h as _,b as u,F as v,a9 as g,W as y}from"../../chunks/vendor-c5cb7521.js";import{M as Z}from"../../chunks/_markdown-2bb6eb92.js";import{p as ee,C as te,a as R,r as x}from"../../chunks/actions-9cbde582.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-37bcce46.js";import"../../chunks/index-c392802f.js";import"../../chunks/SEO-ab6f9e0c.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-2898e6eb.js";function le(c){let e,n;return{c(){e=f("label"),n=$("open modal"),this.h()},l(o){e=b(o,"LABEL",{for:!0,class:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"for","my-modal"),u(e,"class","btn modal-button")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function oe(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function ae(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal" className="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal" className="$$modal-toggle" />
<div className="$$modal">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div className="$$modal-action">
      <label for="my-modal" className="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function se(c){let e,n;return{c(){e=f("a"),n=$("open modal"),this.h()},l(o){e=b(o,"A",{href:!0,class:!0,rel:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"href","#my-modal-2"),u(e,"class","btn"),u(e,"rel","external")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function ne(c){let e,n=`<!-- The button to open modal -->
<a href="#my-modal-2" class="$$btn">open modal</a>
<!-- Put this part before </body> tag -->
<div class="$$modal" id="my-modal-2">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
     <a href="#" class="$$btn">Yay!</a>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function re(c){let e,n=`<!-- The button to open modal -->
<a href="#my-modal-2" className="$$btn">open modal</a>
<!-- Put this part before </body> tag -->
<div className="$$modal" id="my-modal-2">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div className="$$modal-action">
     <a href="#" className="$$btn">Yay!</a>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function de(c){let e,n;return{c(){e=f("label"),n=$("open modal"),this.h()},l(o){e=b(o,"LABEL",{for:!0,class:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"for","my-modal-3"),u(e,"class","btn modal-button")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function ce(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-3" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-3" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box relative">
    <label for="my-modal-3" class="$$btn $$btn-sm $$btn-circle absolute right-2 top-2">\u2715</label>
    <h3 class="text-lg font-bold">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function me(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-3" className="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-3" className="$$modal-toggle" />
<div className="$$modal">
  <div className="$$modal-box relative">
    <label for="my-modal-3" className="$$btn $$btn-sm $$btn-circle absolute right-2 top-2">\u2715</label>
    <h3 className="text-lg font-bold">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function ie(c){let e,n;return{c(){e=f("label"),n=$("open modal"),this.h()},l(o){e=b(o,"LABEL",{for:!0,class:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"for","my-modal-4"),u(e,"class","btn modal-button")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function ue(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-4" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-4" class="$$modal-toggle" />
<label for="my-modal-4" class="$$modal cursor-pointer">
  <label class="$$modal-box relative" for="">
    <h3 class="text-lg font-bold">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </label>
</label>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function pe(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-4" className="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-4" className="$$modal-toggle" />
<label for="my-modal-4" className="$$modal cursor-pointer">
  <label className="$$modal-box relative" for="">
    <h3 className="text-lg font-bold">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </label>
</label>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function fe(c){let e,n;return{c(){e=f("label"),n=$("open modal"),this.h()},l(o){e=b(o,"LABEL",{for:!0,class:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"for","my-modal-5"),u(e,"class","btn modal-button")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function $e(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-5" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-5" class="$$modal-toggle" />
<div class="$$modal">
  <div class="$$modal-box w-11/12 max-w-5xl">
    <h3 class="font-bold text-lg">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal-5" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function be(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-5" className="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-5" className="$$modal-toggle" />
<div className="$$modal">
  <div className="$$modal-box w-11/12 max-w-5xl">
    <h3 className="font-bold text-lg">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div className="$$modal-action">
      <label for="my-modal-5" className="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function he(c){let e,n;return{c(){e=f("label"),n=$("open modal"),this.h()},l(o){e=b(o,"LABEL",{for:!0,class:!0});var l=h(e);n=_(l,"open modal"),l.forEach(m),this.h()},h(){u(e,"for","my-modal-6"),u(e,"class","btn modal-button")},m(o,l){p(o,e,l),v(e,n)},d(o){o&&m(e)}}}function _e(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-6" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-6" class="$$modal-toggle" />
<div class="$$modal $$modal-bottom sm:$$modal-middle">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Internet user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal-6" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","html")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function ve(c){let e,n=`<!-- The button to open modal -->
<label for="my-modal-6" className="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-6" className="$$modal-toggle" />
<div className="$$modal $$modal-bottom sm:$$modal-middle">
  <div className="$$modal-box">
    <h3 className="font-bold text-lg">Congratulations random Internet user!</h3>
    <p className="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div className="$$modal-action">
      <label for="my-modal-6" className="$$btn">Yay!</label>
    </div>
  </div>
</div>`,o,l,s,d;return{c(){e=f("pre"),o=$(n),this.h()},l(t){e=b(t,"PRE",{slot:!0});var a=h(e);o=_(a,n),a.forEach(m),this.h()},h(){u(e,"slot","react")},m(t,a){p(t,e,a),v(e,o),s||(d=g(l=x.call(null,e,{to:c[0]})),s=!0)},p(t,a){l&&y(l.update)&&a&1&&l.update.call(null,{to:t[0]})},d(t){t&&m(e),s=!1,d()}}}function ge(c){let e,n,o,l,s,d,t,a,N,A,k,L,E,B;return e=new te({props:{data:[{type:"component",class:"modal",desc:"Container element"},{type:"component",class:"modal-box",desc:"The content of modal"},{type:"component",class:"modal-action",desc:"Container for modal buttons"},{type:"component",class:"modal-toggle",desc:"For checkbox that controls modal"},{type:"component",class:"modal-button",desc:"For <label> that checks the checkbox to opens/closes modal"},{type:"modifier",class:"modal-open",desc:"Add/remove this class to open/close the modal using JS"},{type:"responsive",class:"modal-bottom",desc:"Moves the modal to bottom"},{type:"responsive",class:"modal-middle",desc:"Moves the modal to middle (default)"}]}}),o=new R({props:{title:"Modal using label + hidden checkbox",desc:'Make sure each modal you use, has a unique ID. In this example, ID is "my-modal".',$$slots:{react:[ae],html:[oe],default:[le]},$$scope:{ctx:c}}}),s=new R({props:{title:"Modal using anchor link",desc:"Anchor links might not work well on some SPA frameworks so if there are problems, use the first example",$$slots:{react:[re],html:[ne],default:[se]},$$scope:{ctx:c}}}),t=new R({props:{title:"Modal using with a close button at corner",$$slots:{react:[me],html:[ce],default:[de]},$$scope:{ctx:c}}}),N=new R({props:{title:"Modal that closes when clicked outside",desc:"Modal works with a hidden checkbox and labels can toggle the checkbox so we can use a label tag for the whole modal and use another label for modal-box to prevent closing when modal-box is clicked",$$slots:{react:[pe],html:[ue],default:[ie]},$$scope:{ctx:c}}}),k=new R({props:{title:"Modal with custom width",desc:"We remove max-width so we can use a custom size",$$slots:{react:[be],html:[$e],default:[fe]},$$scope:{ctx:c}}}),E=new R({props:{title:"Responsive: Modal goes bottom on mobile screen and goes middle on desktop",$$slots:{react:[ve],html:[_e],default:[he]},$$scope:{ctx:c}}}),{c(){w(e.$$.fragment),n=T(),w(o.$$.fragment),l=T(),w(s.$$.fragment),d=T(),w(t.$$.fragment),a=T(),w(N.$$.fragment),A=T(),w(k.$$.fragment),L=T(),w(E.$$.fragment)},l(r){P(e.$$.fragment,r),n=W(r),P(o.$$.fragment,r),l=W(r),P(s.$$.fragment,r),d=W(r),P(t.$$.fragment,r),a=W(r),P(N.$$.fragment,r),A=W(r),P(k.$$.fragment,r),L=W(r),P(E.$$.fragment,r)},m(r,i){Y(e,r,i),p(r,n,i),Y(o,r,i),p(r,l,i),Y(s,r,i),p(r,d,i),Y(t,r,i),p(r,a,i),Y(N,r,i),p(r,A,i),Y(k,r,i),p(r,L,i),Y(E,r,i),B=!0},p(r,i){const q={};i&5&&(q.$$scope={dirty:i,ctx:r}),o.$set(q);const F={};i&5&&(F.$$scope={dirty:i,ctx:r}),s.$set(F);const z={};i&5&&(z.$$scope={dirty:i,ctx:r}),t.$set(z);const D={};i&5&&(D.$$scope={dirty:i,ctx:r}),N.$set(D);const j={};i&5&&(j.$$scope={dirty:i,ctx:r}),k.$set(j);const J={};i&5&&(J.$$scope={dirty:i,ctx:r}),E.$set(J)},i(r){B||(C(e.$$.fragment,r),C(o.$$.fragment,r),C(s.$$.fragment,r),C(t.$$.fragment,r),C(N.$$.fragment,r),C(k.$$.fragment,r),C(E.$$.fragment,r),B=!0)},o(r){I(e.$$.fragment,r),I(o.$$.fragment,r),I(s.$$.fragment,r),I(t.$$.fragment,r),I(N.$$.fragment,r),I(k.$$.fragment,r),I(E.$$.fragment,r),B=!1},d(r){M(e,r),r&&m(n),M(o,r),r&&m(l),M(s,r),r&&m(d),M(t,r),r&&m(a),M(N,r),r&&m(A),M(k,r),r&&m(L),M(E,r)}}}function ye(c){let e,n;const o=[c[1],H];let l={$$slots:{default:[ge]},$$scope:{ctx:c}};for(let s=0;s<o.length;s+=1)l=S(l,o[s]);return e=new Z({props:l}),{c(){w(e.$$.fragment)},l(s){P(e.$$.fragment,s)},m(s,d){Y(e,s,d),n=!0},p(s,[d]){const t=d&2?V(o,[d&2&&K(s[1]),d&0&&K(H)]):{};d&5&&(t.$$scope={dirty:d,ctx:s}),e.$set(t)},i(s){n||(C(e.$$.fragment,s),n=!0)},o(s){I(e.$$.fragment,s),n=!1},d(s){M(e,s)}}}const H={title:"Modal",desc:"Modal is used to show a dialog or a box when you click a button.",published:!0};function xe(c,e,n){let o;return X(c,ee,l=>n(0,o=l)),c.$$set=l=>{n(1,e=S(S({},e),G(l)))},e=G(e),[o,e]}class Te extends O{constructor(e){super();Q(this,e,xe,ye,U,{})}}export{Te as default,H as metadata};
