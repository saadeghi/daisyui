import{S as ie,i as oe,s as de,C as J,w as q,x,y as j,z as ne,A as ae,q as B,o as F,B as K,K as ce,ag as le,k as z,m as T,g as D,d as o,e as v,t as I,c as u,a as p,h as V,b as _,F as d,a9 as R,W as C}from"../../chunks/vendor-c5cb7521.js";import{M as ve}from"../../chunks/_markdown-86fe9495.js";import{p as ue,C as pe,a as W,r as k}from"../../chunks/actions-0dd8165f.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-bf889088.js";import"../../chunks/index-ea08827d.js";import"../../chunks/SEO-e4f29b8b.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-fc97082e.js";function $e($){let e,i,l,a,r,n;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New message arrived."),this.h()},l(t){e=u(t,"DIV",{class:!0});var s=p(e);i=u(s,"DIV",{class:!0});var f=p(i);l=u(f,"DIV",{class:!0});var h=p(l);a=u(h,"DIV",{});var g=p(a);r=u(g,"SPAN",{});var m=p(r);n=V(m,"New message arrived."),m.forEach(o),g.forEach(o),h.forEach(o),f.forEach(o),s.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(i,"class","toast absolute"),_(e,"class","w-full h-64 relative")},m(t,s){D(t,e,s),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n)},d(t){t&&o(e)}}}function fe($){let e,i=`<div class="$$toast">
  <div class="$$alert $$alert-info">
    <div>
      <span>New message arrived.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function he($){let e,i=`<div className="$$toast">
  <div className="$$alert $$alert-info">
    <div>
      <span>New message arrived.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function me($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-top toast-start absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function _e($){let e,i=`<div class="$$toast $$toast-top $$toast-start">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Ee($){let e,i=`<div className="$$toast $$toast-top $$toast-start">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Ne($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-top toast-center absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function ge($){let e,i=`<div class="$$toast $$toast-top $$toast-center">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function we($){let e,i=`<div className="$$toast $$toast-top $$toast-center">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function De($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-top toast-end absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Ie($){let e,i=`<div class="$$toast $$toast-top $$toast-end">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Ve($){let e,i=`<div className="$$toast $$toast-top $$toast-end">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Pe($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-start toast-middle absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Me($){let e,i=`<div class="$$toast $$toast-start $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function ye($){let e,i=`<div className="$$toast $$toast-start $$toast-middle">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function be($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-center toast-middle absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Se($){let e,i=`<div class="$$toast $$toast-center $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Ae($){let e,i=`<div className="$$toast $$toast-center $$toast-middle">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Re($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-end toast-middle absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Ce($){let e,i=`<div class="$$toast $$toast-end $$toast-middle">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function ke($){let e,i=`<div className="$$toast $$toast-end $$toast-middle">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function ze($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-start absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Te($){let e,i=`<div class="$$toast $$toast-start">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function qe($){let e,i=`<div className="$$toast $$toast-start">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function xe($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-center absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function je($){let e,i=`<div class="$$toast $$toast-center">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Be($){let e,i=`<div className="$$toast $$toast-center">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Fe($){let e,i,l,a,r,n,t,s,f,h,g;return{c(){e=v("div"),i=v("div"),l=v("div"),a=v("div"),r=v("span"),n=I("New mail arrived."),t=z(),s=v("div"),f=v("div"),h=v("span"),g=I("Message sent successfully."),this.h()},l(m){e=u(m,"DIV",{class:!0});var E=p(e);i=u(E,"DIV",{class:!0});var N=p(i);l=u(N,"DIV",{class:!0});var P=p(l);a=u(P,"DIV",{});var b=p(a);r=u(b,"SPAN",{});var M=p(r);n=V(M,"New mail arrived."),M.forEach(o),b.forEach(o),P.forEach(o),t=T(N),s=u(N,"DIV",{class:!0});var S=p(s);f=u(S,"DIV",{});var y=p(f);h=u(y,"SPAN",{});var A=p(h);g=V(A,"Message sent successfully."),A.forEach(o),y.forEach(o),S.forEach(o),N.forEach(o),E.forEach(o),this.h()},h(){_(l,"class","alert alert-info"),_(s,"class","alert alert-success"),_(i,"class","toast toast-end absolute"),_(e,"class","w-full h-64 relative")},m(m,E){D(m,e,E),d(e,i),d(i,l),d(l,a),d(a,r),d(r,n),d(i,t),d(i,s),d(s,f),d(f,h),d(h,g)},d(m){m&&o(e)}}}function Ke($){let e,i=`<div class="$$toast $$toast-end">
  <div class="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div class="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","html")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function We($){let e,i=`<div className="$$toast $$toast-end">
  <div className="$$alert $$alert-info">
    <div>
      <span>New mail arrived.</span>
    </div>
  </div>
  <div className="$$alert $$alert-success">
    <div>
      <span>Message sent successfully.</span>
    </div>
  </div>
</div>`,l,a,r,n;return{c(){e=v("pre"),l=I(i),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=p(e);l=V(s,i),s.forEach(o),this.h()},h(){_(e,"slot","react")},m(t,s){D(t,e,s),d(e,l),r||(n=R(a=k.call(null,e,{to:$[0]})),r=!0)},p(t,s){a&&C(a.update)&&s&1&&a.update.call(null,{to:t[0]})},d(t){t&&o(e),r=!1,n()}}}function Ge($){let e,i,l,a,r,n,t,s,f,h,g,m,E,N,P,b,M,S,y,A,G,H;return e=new pe({props:{data:[{type:"component",class:"toast",desc:"Container element that sticks to the corner of page"},{type:"responsive",class:"toast-start",desc:"align horizontally to the left"},{type:"responsive",class:"toast-center",desc:"align horizontally to the center"},{type:"responsive",class:"toast-end",desc:"align horizontally to the right (default)"},{type:"responsive",class:"toast-top",desc:"align vertically to top"},{type:"responsive",class:"toast-middle",desc:"align vertically to middle"},{type:"responsive",class:"toast-bottom",desc:"align vertically to bottom (default)"}]}}),l=new W({props:{title:"toast with alert inside",$$slots:{react:[he],html:[fe],default:[$e]},$$scope:{ctx:$}}}),r=new W({props:{title:"toast-top toast-start",$$slots:{react:[Ee],html:[_e],default:[me]},$$scope:{ctx:$}}}),t=new W({props:{title:"toast-top toast-center",$$slots:{react:[we],html:[ge],default:[Ne]},$$scope:{ctx:$}}}),f=new W({props:{title:"toast-top toast-end",$$slots:{react:[Ve],html:[Ie],default:[De]},$$scope:{ctx:$}}}),g=new W({props:{title:"toast-start toast-middle",$$slots:{react:[ye],html:[Me],default:[Pe]},$$scope:{ctx:$}}}),E=new W({props:{title:"toast-center toast-middle",$$slots:{react:[Ae],html:[Se],default:[be]},$$scope:{ctx:$}}}),P=new W({props:{title:"toast-end toast-middle",$$slots:{react:[ke],html:[Ce],default:[Re]},$$scope:{ctx:$}}}),M=new W({props:{title:"toast-start toast-bottom (default)",$$slots:{react:[qe],html:[Te],default:[ze]},$$scope:{ctx:$}}}),y=new W({props:{title:"toast-center toast-bottom (default)",$$slots:{react:[Be],html:[je],default:[xe]},$$scope:{ctx:$}}}),G=new W({props:{title:"toast-end (default) toast-bottom (default)",$$slots:{react:[We],html:[Ke],default:[Fe]},$$scope:{ctx:$}}}),{c(){q(e.$$.fragment),i=z(),q(l.$$.fragment),a=z(),q(r.$$.fragment),n=z(),q(t.$$.fragment),s=z(),q(f.$$.fragment),h=z(),q(g.$$.fragment),m=z(),q(E.$$.fragment),N=z(),q(P.$$.fragment),b=z(),q(M.$$.fragment),S=z(),q(y.$$.fragment),A=z(),q(G.$$.fragment)},l(c){x(e.$$.fragment,c),i=T(c),x(l.$$.fragment,c),a=T(c),x(r.$$.fragment,c),n=T(c),x(t.$$.fragment,c),s=T(c),x(f.$$.fragment,c),h=T(c),x(g.$$.fragment,c),m=T(c),x(E.$$.fragment,c),N=T(c),x(P.$$.fragment,c),b=T(c),x(M.$$.fragment,c),S=T(c),x(y.$$.fragment,c),A=T(c),x(G.$$.fragment,c)},m(c,w){j(e,c,w),D(c,i,w),j(l,c,w),D(c,a,w),j(r,c,w),D(c,n,w),j(t,c,w),D(c,s,w),j(f,c,w),D(c,h,w),j(g,c,w),D(c,m,w),j(E,c,w),D(c,N,w),j(P,c,w),D(c,b,w),j(M,c,w),D(c,S,w),j(y,c,w),D(c,A,w),j(G,c,w),H=!0},p(c,w){const L={};w&5&&(L.$$scope={dirty:w,ctx:c}),l.$set(L);const O={};w&5&&(O.$$scope={dirty:w,ctx:c}),r.$set(O);const Q={};w&5&&(Q.$$scope={dirty:w,ctx:c}),t.$set(Q);const U={};w&5&&(U.$$scope={dirty:w,ctx:c}),f.$set(U);const X={};w&5&&(X.$$scope={dirty:w,ctx:c}),g.$set(X);const Y={};w&5&&(Y.$$scope={dirty:w,ctx:c}),E.$set(Y);const Z={};w&5&&(Z.$$scope={dirty:w,ctx:c}),P.$set(Z);const ee={};w&5&&(ee.$$scope={dirty:w,ctx:c}),M.$set(ee);const te={};w&5&&(te.$$scope={dirty:w,ctx:c}),y.$set(te);const se={};w&5&&(se.$$scope={dirty:w,ctx:c}),G.$set(se)},i(c){H||(B(e.$$.fragment,c),B(l.$$.fragment,c),B(r.$$.fragment,c),B(t.$$.fragment,c),B(f.$$.fragment,c),B(g.$$.fragment,c),B(E.$$.fragment,c),B(P.$$.fragment,c),B(M.$$.fragment,c),B(y.$$.fragment,c),B(G.$$.fragment,c),H=!0)},o(c){F(e.$$.fragment,c),F(l.$$.fragment,c),F(r.$$.fragment,c),F(t.$$.fragment,c),F(f.$$.fragment,c),F(g.$$.fragment,c),F(E.$$.fragment,c),F(P.$$.fragment,c),F(M.$$.fragment,c),F(y.$$.fragment,c),F(G.$$.fragment,c),H=!1},d(c){K(e,c),c&&o(i),K(l,c),c&&o(a),K(r,c),c&&o(n),K(t,c),c&&o(s),K(f,c),c&&o(h),K(g,c),c&&o(m),K(E,c),c&&o(N),K(P,c),c&&o(b),K(M,c),c&&o(S),K(y,c),c&&o(A),K(G,c)}}}function He($){let e,i;const l=[$[1],re];let a={$$slots:{default:[Ge]},$$scope:{ctx:$}};for(let r=0;r<l.length;r+=1)a=J(a,l[r]);return e=new ve({props:a}),{c(){q(e.$$.fragment)},l(r){x(e.$$.fragment,r)},m(r,n){j(e,r,n),i=!0},p(r,[n]){const t=n&2?ne(l,[n&2&&ae(r[1]),n&0&&ae(re)]):{};n&5&&(t.$$scope={dirty:n,ctx:r}),e.$set(t)},i(r){i||(B(e.$$.fragment,r),i=!0)},o(r){F(e.$$.fragment,r),i=!1},d(r){K(e,r)}}}const re={title:"Toast",desc:"Toast is a wrapper to stack elements, positioned on the corner of page.",published:!1};function Je($,e,i){let l;return ce($,ue,a=>i(0,l=a)),$.$$set=a=>{i(1,e=J(J({},e),le(a)))},e=le(e),[l,e]}class st extends ie{constructor(e){super();oe(this,e,Je,He,de,{})}}export{st as default,re as metadata};
