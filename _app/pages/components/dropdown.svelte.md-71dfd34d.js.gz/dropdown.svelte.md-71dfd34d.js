import{S as ze,i as Oe,s as qe,C as Ne,w as j,x as H,y as M,z as Se,A as je,q as z,o as O,B as q,K as Ye,ag as He,k as D,e as p,F as fe,t as x,m as B,c as $,a as u,G as he,d as r,h as E,b as m,g as L,H as s,a9 as V,Q as U}from"../../chunks/vendor-40028f80.js";import{M as Fe}from"../../chunks/_markdown-70eedc6d.js";import{p as We,C as Ge,a as W,r as y}from"../../chunks/actions-51af4145.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-8d10949a.js";import"../../chunks/index-76a82928.js";import"../../chunks/SEO-4a8c8d7d.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-268db44d.js";function Ke(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function Qe(h){let e,n=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Te(h){let e,n=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Je(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-end mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function Xe(h){let e,n=`<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ze(h){let e,n=`<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function et(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-top mt-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function tt(h){let e,n=`<div class="$$dropdown $$dropdown-top">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function lt(h){let e,n=`<div className="$$dropdown $$dropdown-top">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function at(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-top dropdown-end mt-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function ot(h){let e,n=`<div class="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function st(h){let e,n=`<div className="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function nt(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-bottom mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function rt(h){let e,n=`<div class="$$dropdown $$dropdown-bottom">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function dt(h){let e,n=`<div className="$$dropdown $$dropdown-bottom">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function it(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-bottom dropdown-end mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function ct(h){let e,n=`<div class="$$dropdown $$dropdown-bottom $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ut(h){let e,n=`<div className="$$dropdown $$dropdown-bottom $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function pt(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-left mb-16")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function $t(h){let e,n=`<div class="$$dropdown $$dropdown-left">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function mt(h){let e,n=`<div className="$$dropdown $$dropdown-left">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ft(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-left dropdown-end mt-16")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function ht(h){let e,n=`<div class="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function bt(h){let e,n=`<div className="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function vt(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-right mb-16")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function _t(h){let e,n=`<div class="$$dropdown $$dropdown-right">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function wt(h){let e,n=`<div className="$$dropdown $$dropdown-right">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function xt(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Click"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-right dropdown-end mt-16")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function Et(h){let e,n=`<div class="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function It(h){let e,n=`<div className="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function gt(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Hover"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Hover"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-hover mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function kt(h){let e,n=`<div class="$$dropdown $$dropdown-hover">
  <label tabindex="0" class="$$btn m-1">Hover</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Lt(h){let e,n=`<div className="$$dropdown $$dropdown-hover">
  <label tabIndex={0} className="$$btn m-1">Hover</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ct(h){let e,n,i,o,l,d,t,a,k,b,_,I;return{c(){e=p("div"),n=p("label"),i=x("Button"),o=D(),l=p("ul"),d=p("li"),t=p("a"),a=x("Item 1"),k=D(),b=p("li"),_=p("a"),I=x("Item 2"),this.h()},l(v){e=$(v,"DIV",{class:!0});var f=u(e);n=$(f,"LABEL",{tabindex:!0,class:!0});var C=u(n);i=E(C,"Button"),C.forEach(r),o=B(f),l=$(f,"UL",{tabindex:!0,class:!0});var w=u(l);d=$(w,"LI",{});var N=u(d);t=$(N,"A",{});var P=u(t);a=E(P,"Item 1"),P.forEach(r),N.forEach(r),k=B(w),b=$(w,"LI",{});var R=u(b);_=$(R,"A",{});var A=u(_);I=E(A,"Item 2"),A.forEach(r),R.forEach(r),w.forEach(r),f.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(l,"tabindex","0"),m(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),m(e,"class","dropdown dropdown-open mb-32")},m(v,f){L(v,e,f),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(l,k),s(l,b),s(b,_),s(_,I)},d(v){v&&r(e)}}}function Nt(h){let e,n=`<div class="$$dropdown $$dropdown-open">
  <label tabindex="0" class="$$btn m-1">Button</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function At(h){let e,n=`<div className="$$dropdown $$dropdown-open">
  <label tabIndex={0} className="$$btn m-1">Button</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Dt(h){let e,n,i,o,l,d,t,a,k,b,_;return{c(){e=p("div"),n=p("label"),i=x("Click"),o=D(),l=p("div"),d=p("div"),t=p("h3"),a=x("Card title!"),k=D(),b=p("p"),_=x("you can use any element as a dropdown."),this.h()},l(I){e=$(I,"DIV",{class:!0});var v=u(e);n=$(v,"LABEL",{tabindex:!0,class:!0});var f=u(n);i=E(f,"Click"),f.forEach(r),o=B(v),l=$(v,"DIV",{tabindex:!0,class:!0});var C=u(l);d=$(C,"DIV",{class:!0});var w=u(d);t=$(w,"H3",{class:!0});var N=u(t);a=E(N,"Card title!"),N.forEach(r),k=B(w),b=$(w,"P",{});var P=u(b);_=E(P,"you can use any element as a dropdown."),P.forEach(r),w.forEach(r),C.forEach(r),v.forEach(r),this.h()},h(){m(n,"tabindex","0"),m(n,"class","m-1 btn"),m(t,"class","card-title"),m(d,"class","card-body"),m(l,"tabindex","0"),m(l,"class","w-64 p-2 shadow card card-compact dropdown-content bg-primary text-primary-content"),m(e,"class","dropdown mb-32")},m(I,v){L(I,e,v),s(e,n),s(n,i),s(e,o),s(e,l),s(l,d),s(d,t),s(t,a),s(d,k),s(d,b),s(b,_)},d(I){I&&r(e)}}}function Bt(h){let e,n=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <div tabindex="0" class="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div class="$$card-body">
      <h3 class="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Pt(h){let e,n=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <div tabIndex={0} className="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div className="$$card-body">
      <h3 className="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Rt(h){let e,n,i,o,l,d,t,a,k,b,_,I,v,f,C,w,N,P,R,A,S,Y;return{c(){e=p("div"),n=p("div"),i=p("a"),o=x("daisyUI"),l=D(),d=p("div"),t=p("div"),a=p("a"),k=x("Button"),b=D(),_=p("div"),I=p("label"),v=x("Dropdown"),f=D(),C=p("ul"),w=p("li"),N=p("a"),P=x("Item 1"),R=D(),A=p("li"),S=p("a"),Y=x("Item 2"),this.h()},l(G){e=$(G,"DIV",{class:!0});var F=u(e);n=$(F,"DIV",{class:!0});var ne=u(n);i=$(ne,"A",{class:!0});var J=u(i);o=E(J,"daisyUI"),J.forEach(r),ne.forEach(r),l=B(F),d=$(F,"DIV",{class:!0});var re=u(d);t=$(re,"DIV",{class:!0});var K=u(t);a=$(K,"A",{class:!0});var de=u(a);k=E(de,"Button"),de.forEach(r),b=B(K),_=$(K,"DIV",{class:!0});var Q=u(_);I=$(Q,"LABEL",{tabindex:!0,class:!0});var ie=u(I);v=E(ie,"Dropdown"),ie.forEach(r),f=B(Q),C=$(Q,"UL",{tabindex:!0,class:!0});var T=u(C);w=$(T,"LI",{});var ce=u(w);N=$(ce,"A",{});var X=u(N);P=E(X,"Item 1"),X.forEach(r),ce.forEach(r),R=B(T),A=$(T,"LI",{});var ue=u(A);S=$(ue,"A",{});var Z=u(S);Y=E(Z,"Item 2"),Z.forEach(r),ue.forEach(r),T.forEach(r),Q.forEach(r),K.forEach(r),re.forEach(r),F.forEach(r),this.h()},h(){m(i,"class","text-lg font-bold"),m(n,"class","flex-1 px-2 lg:flex-none"),m(a,"class","btn btn-ghost rounded-btn"),m(I,"tabindex","0"),m(I,"class","btn btn-ghost rounded-btn"),m(C,"tabindex","0"),m(C,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52 mt-4"),m(_,"class","dropdown dropdown-end"),m(t,"class","flex items-stretch"),m(d,"class","flex justify-end flex-1 px-2"),m(e,"class","navbar mb-40 bg-base-300 rounded-box w-full")},m(G,F){L(G,e,F),s(e,n),s(n,i),s(i,o),s(e,l),s(e,d),s(d,t),s(t,a),s(a,k),s(t,b),s(t,_),s(_,I),s(I,v),s(_,f),s(_,C),s(C,w),s(w,N),s(N,P),s(C,R),s(C,A),s(A,S),s(S,Y)},d(G){G&&r(e)}}}function Vt(h){let e,n=`<div class="$$navbar bg-base-300 rounded-box">
  <div class="flex-1 px-2 lg:flex-none">
    <a class="text-lg font-bold">daisyUI</a>
  </div> 
  <div class="flex justify-end flex-1 px-2">
    <div class="flex items-stretch">
      <a class="$$btn $$btn-ghost rounded-btn">Button</a>
      <div class="$$dropdown $$dropdown-end">
        <label tabindex="0" class="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabindex="0" class="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ut(h){let e,n=`<div className="$$navbar bg-base-300 rounded-box">
  <div className="flex-1 px-2 lg:flex-none">
    <a className="text-lg font-bold">daisyUI</a>
  </div> 
  <div className="flex justify-end flex-1 px-2">
    <div className="flex items-stretch">
      <a className="$$btn $$btn-ghost rounded-btn">Button</a>
      <div className="$$dropdown $$dropdown-end">
        <label tabIndex={0} className="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabIndex={0} className="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function yt(h){let e,n,i,o,l,d,t,a,k,b,_,I,v,f;return{c(){e=p("div"),n=x(`A normal text and a helper dropdown
  `),i=p("div"),o=p("label"),l=fe("svg"),d=fe("path"),t=D(),a=p("div"),k=p("div"),b=p("h2"),_=x("You needed more info?"),I=D(),v=p("p"),f=x("Here is a description!"),this.h()},l(C){e=$(C,"DIV",{class:!0});var w=u(e);n=E(w,`A normal text and a helper dropdown
  `),i=$(w,"DIV",{class:!0});var N=u(i);o=$(N,"LABEL",{tabindex:!0,class:!0});var P=u(o);l=he(P,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var R=u(l);d=he(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),R.forEach(r),P.forEach(r),t=B(N),a=$(N,"DIV",{tabindex:!0,class:!0});var A=u(a);k=$(A,"DIV",{class:!0});var S=u(k);b=$(S,"H2",{class:!0});var Y=u(b);_=E(Y,"You needed more info?"),Y.forEach(r),I=B(S),v=$(S,"P",{});var G=u(v);f=E(G,"Here is a description!"),G.forEach(r),S.forEach(r),A.forEach(r),N.forEach(r),w.forEach(r),this.h()},h(){m(d,"stroke-linecap","round"),m(d,"stroke-linejoin","round"),m(d,"stroke-width","2"),m(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),m(l,"xmlns","http://www.w3.org/2000/svg"),m(l,"fill","none"),m(l,"viewBox","0 0 24 24"),m(l,"class","w-4 h-4 stroke-current"),m(o,"tabindex","0"),m(o,"class","btn btn-circle btn-ghost btn-xs text-info"),m(b,"class","card-title"),m(k,"class","card-body"),m(a,"tabindex","0"),m(a,"class","shadow card compact dropdown-content bg-base-100 rounded-box w-64"),m(i,"class","dropdown dropdown-end"),m(e,"class","mb-28 mt-6 flex gap-1 items-center")},m(C,w){L(C,e,w),s(e,n),s(e,i),s(i,o),s(o,l),s(l,d),s(i,t),s(i,a),s(a,k),s(k,b),s(b,_),s(k,I),s(k,v),s(v,f)},d(C){C&&r(e)}}}function jt(h){let e,n=`A normal text and a helper dropdown
<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabindex="0" class="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div class="$$card-body">
      <h2 class="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","html")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ht(h){let e,n=`A normal text and a helper dropdown
<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabIndex={0} className="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div className="$$card-body">
      <h2 className="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=p("pre"),i=x(n),this.h()},l(t){e=$(t,"PRE",{slot:!0});var a=u(e);i=E(a,n),a.forEach(r),this.h()},h(){m(e,"slot","react")},m(t,a){L(t,e,a),s(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Mt(h){let e,n,i,o,l,d,t,a,k,b,_,I,v,f,C,w,N,P,R,A,S,Y,G,F,ne,J,re,K,de,Q,ie,T,ce,X,ue,Z,xe,ee,Ee,te,Ie,le,ge,ae,ke,oe,Le,se,Ce;return e=new Ge({props:{data:[{type:"component",class:"dropdown",desc:"Container element"},{type:"component",class:"dropdown-content",desc:"Container for content"},{type:"modifier",class:"dropdown-end",desc:"Aligns to end"},{type:"modifier",class:"dropdown-top",desc:"Open from top"},{type:"modifier",class:"dropdown-bottom",desc:"Open from bottom"},{type:"modifier",class:"dropdown-left",desc:"Open from left"},{type:"modifier",class:"dropdown-right",desc:"Open from right"},{type:"modifier",class:"dropdown-hover",desc:"Opens on hover too"},{type:"modifier",class:"dropdown-open",desc:"Force open"}]}}),A=new W({props:{title:"Dropdown menu",$$slots:{react:[Te],html:[Qe],default:[Ke]},$$scope:{ctx:h}}}),Y=new W({props:{title:"Dropdown / aligns to end",$$slots:{react:[Ze],html:[Xe],default:[Je]},$$scope:{ctx:h}}}),F=new W({props:{title:"Dropdown top",$$slots:{react:[lt],html:[tt],default:[et]},$$scope:{ctx:h}}}),J=new W({props:{title:"Dropdown top / aligns to end",$$slots:{react:[st],html:[ot],default:[at]},$$scope:{ctx:h}}}),K=new W({props:{title:"Dropdown bottom",$$slots:{react:[dt],html:[rt],default:[nt]},$$scope:{ctx:h}}}),Q=new W({props:{title:"Dropdown bottom / aligns to end",$$slots:{react:[ut],html:[ct],default:[it]},$$scope:{ctx:h}}}),T=new W({props:{title:"Dropdown left",$$slots:{react:[mt],html:[$t],default:[pt]},$$scope:{ctx:h}}}),X=new W({props:{title:"Dropdown left / aligns to end",$$slots:{react:[bt],html:[ht],default:[ft]},$$scope:{ctx:h}}}),Z=new W({props:{title:"Dropdown right",$$slots:{react:[wt],html:[_t],default:[vt]},$$scope:{ctx:h}}}),ee=new W({props:{title:"Dropdown right / aligns to end",$$slots:{react:[It],html:[Et],default:[xt]},$$scope:{ctx:h}}}),te=new W({props:{title:"Dropdown on hover",$$slots:{react:[Lt],html:[kt],default:[gt]},$$scope:{ctx:h}}}),le=new W({props:{title:"Force open",$$slots:{react:[At],html:[Nt],default:[Ct]},$$scope:{ctx:h}}}),ae=new W({props:{title:"Card as dropdown",$$slots:{react:[Pt],html:[Bt],default:[Dt]},$$scope:{ctx:h}}}),oe=new W({props:{title:"Dropdown in navbar",$$slots:{react:[Ut],html:[Vt],default:[Rt]},$$scope:{ctx:h}}}),se=new W({props:{title:"Helper dropdown",$$slots:{react:[Ht],html:[jt],default:[yt]},$$scope:{ctx:h}}}),{c(){j(e.$$.fragment),n=D(),i=p("div"),o=p("div"),l=fe("svg"),d=fe("path"),t=D(),a=p("div"),k=x('We use a <label tabindex="0"> instead of a <button> because Safari has '),b=p("a"),_=x("a bug"),I=x(" that prevents the button from being focused."),v=D(),f=p("div"),C=p("div"),w=fe("svg"),N=fe("path"),P=x(`
    Using tabindex="0" is required so the dropdown can be focused.`),R=D(),j(A.$$.fragment),S=D(),j(Y.$$.fragment),G=D(),j(F.$$.fragment),ne=D(),j(J.$$.fragment),re=D(),j(K.$$.fragment),de=D(),j(Q.$$.fragment),ie=D(),j(T.$$.fragment),ce=D(),j(X.$$.fragment),ue=D(),j(Z.$$.fragment),xe=D(),j(ee.$$.fragment),Ee=D(),j(te.$$.fragment),Ie=D(),j(le.$$.fragment),ge=D(),j(ae.$$.fragment),ke=D(),j(oe.$$.fragment),Le=D(),j(se.$$.fragment),this.h()},l(c){H(e.$$.fragment,c),n=B(c),i=$(c,"DIV",{class:!0});var g=u(i);o=$(g,"DIV",{});var pe=u(o);l=he(pe,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var be=u(l);d=he(be,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),be.forEach(r),t=B(pe),a=$(pe,"DIV",{});var $e=u(a);k=E($e,'We use a <label tabindex="0"> instead of a <button> because Safari has '),b=$($e,"A",{rel:!0,target:!0,href:!0});var ve=u(b);_=E(ve,"a bug"),ve.forEach(r),I=E($e," that prevents the button from being focused."),$e.forEach(r),pe.forEach(r),g.forEach(r),v=B(c),f=$(c,"DIV",{class:!0});var _e=u(f);C=$(_e,"DIV",{});var me=u(C);w=he(me,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var we=u(w);N=he(we,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(N).forEach(r),we.forEach(r),P=E(me,`
    Using tabindex="0" is required so the dropdown can be focused.`),me.forEach(r),_e.forEach(r),R=B(c),H(A.$$.fragment,c),S=B(c),H(Y.$$.fragment,c),G=B(c),H(F.$$.fragment,c),ne=B(c),H(J.$$.fragment,c),re=B(c),H(K.$$.fragment,c),de=B(c),H(Q.$$.fragment,c),ie=B(c),H(T.$$.fragment,c),ce=B(c),H(X.$$.fragment,c),ue=B(c),H(Z.$$.fragment,c),xe=B(c),H(ee.$$.fragment,c),Ee=B(c),H(te.$$.fragment,c),Ie=B(c),H(le.$$.fragment,c),ge=B(c),H(ae.$$.fragment,c),ke=B(c),H(oe.$$.fragment,c),Le=B(c),H(se.$$.fragment,c),this.h()},h(){m(d,"stroke-linecap","round"),m(d,"stroke-linejoin","round"),m(d,"stroke-width","2"),m(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),m(l,"xmlns","http://www.w3.org/2000/svg"),m(l,"fill","none"),m(l,"viewBox","0 0 24 24"),m(l,"class","stroke-info-content flex-shrink-0 w-6 h-6"),m(b,"rel","noopener noreferrer"),m(b,"target","_blank"),m(b,"href","https://bugs.webkit.org/show_bug.cgi?id=22261"),m(i,"class","alert alert-info text-sm mb-2"),m(N,"stroke-linecap","round"),m(N,"stroke-linejoin","round"),m(N,"stroke-width","2"),m(N,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),m(w,"xmlns","http://www.w3.org/2000/svg"),m(w,"fill","none"),m(w,"viewBox","0 0 24 24"),m(w,"class","stroke-info-content flex-shrink-0 w-6 h-6"),m(f,"class","alert alert-info text-sm")},m(c,g){M(e,c,g),L(c,n,g),L(c,i,g),s(i,o),s(o,l),s(l,d),s(o,t),s(o,a),s(a,k),s(a,b),s(b,_),s(a,I),L(c,v,g),L(c,f,g),s(f,C),s(C,w),s(w,N),s(C,P),L(c,R,g),M(A,c,g),L(c,S,g),M(Y,c,g),L(c,G,g),M(F,c,g),L(c,ne,g),M(J,c,g),L(c,re,g),M(K,c,g),L(c,de,g),M(Q,c,g),L(c,ie,g),M(T,c,g),L(c,ce,g),M(X,c,g),L(c,ue,g),M(Z,c,g),L(c,xe,g),M(ee,c,g),L(c,Ee,g),M(te,c,g),L(c,Ie,g),M(le,c,g),L(c,ge,g),M(ae,c,g),L(c,ke,g),M(oe,c,g),L(c,Le,g),M(se,c,g),Ce=!0},p(c,g){const pe={};g&5&&(pe.$$scope={dirty:g,ctx:c}),A.$set(pe);const be={};g&5&&(be.$$scope={dirty:g,ctx:c}),Y.$set(be);const $e={};g&5&&($e.$$scope={dirty:g,ctx:c}),F.$set($e);const ve={};g&5&&(ve.$$scope={dirty:g,ctx:c}),J.$set(ve);const _e={};g&5&&(_e.$$scope={dirty:g,ctx:c}),K.$set(_e);const me={};g&5&&(me.$$scope={dirty:g,ctx:c}),Q.$set(me);const we={};g&5&&(we.$$scope={dirty:g,ctx:c}),T.$set(we);const Ae={};g&5&&(Ae.$$scope={dirty:g,ctx:c}),X.$set(Ae);const De={};g&5&&(De.$$scope={dirty:g,ctx:c}),Z.$set(De);const Be={};g&5&&(Be.$$scope={dirty:g,ctx:c}),ee.$set(Be);const Pe={};g&5&&(Pe.$$scope={dirty:g,ctx:c}),te.$set(Pe);const Re={};g&5&&(Re.$$scope={dirty:g,ctx:c}),le.$set(Re);const Ve={};g&5&&(Ve.$$scope={dirty:g,ctx:c}),ae.$set(Ve);const Ue={};g&5&&(Ue.$$scope={dirty:g,ctx:c}),oe.$set(Ue);const ye={};g&5&&(ye.$$scope={dirty:g,ctx:c}),se.$set(ye)},i(c){Ce||(z(e.$$.fragment,c),z(A.$$.fragment,c),z(Y.$$.fragment,c),z(F.$$.fragment,c),z(J.$$.fragment,c),z(K.$$.fragment,c),z(Q.$$.fragment,c),z(T.$$.fragment,c),z(X.$$.fragment,c),z(Z.$$.fragment,c),z(ee.$$.fragment,c),z(te.$$.fragment,c),z(le.$$.fragment,c),z(ae.$$.fragment,c),z(oe.$$.fragment,c),z(se.$$.fragment,c),Ce=!0)},o(c){O(e.$$.fragment,c),O(A.$$.fragment,c),O(Y.$$.fragment,c),O(F.$$.fragment,c),O(J.$$.fragment,c),O(K.$$.fragment,c),O(Q.$$.fragment,c),O(T.$$.fragment,c),O(X.$$.fragment,c),O(Z.$$.fragment,c),O(ee.$$.fragment,c),O(te.$$.fragment,c),O(le.$$.fragment,c),O(ae.$$.fragment,c),O(oe.$$.fragment,c),O(se.$$.fragment,c),Ce=!1},d(c){q(e,c),c&&r(n),c&&r(i),c&&r(v),c&&r(f),c&&r(R),q(A,c),c&&r(S),q(Y,c),c&&r(G),q(F,c),c&&r(ne),q(J,c),c&&r(re),q(K,c),c&&r(de),q(Q,c),c&&r(ie),q(T,c),c&&r(ce),q(X,c),c&&r(ue),q(Z,c),c&&r(xe),q(ee,c),c&&r(Ee),q(te,c),c&&r(Ie),q(le,c),c&&r(ge),q(ae,c),c&&r(ke),q(oe,c),c&&r(Le),q(se,c)}}}function zt(h){let e,n;const i=[h[1],Me];let o={$$slots:{default:[Mt]},$$scope:{ctx:h}};for(let l=0;l<i.length;l+=1)o=Ne(o,i[l]);return e=new Fe({props:o}),{c(){j(e.$$.fragment)},l(l){H(e.$$.fragment,l)},m(l,d){M(e,l,d),n=!0},p(l,[d]){const t=d&2?Se(i,[d&2&&je(l[1]),d&0&&je(Me)]):{};d&5&&(t.$$scope={dirty:d,ctx:l}),e.$set(t)},i(l){n||(z(e.$$.fragment,l),n=!0)},o(l){O(e.$$.fragment,l),n=!1},d(l){q(e,l)}}}const Me={title:"Dropdown",desc:"Dropdown can open a menu or any other element when the button is clicked.",published:!0};function Ot(h,e,n){let i;return Ye(h,We,o=>n(0,i=o)),h.$$set=o=>{n(1,e=Ne(Ne({},e),He(o)))},e=He(e),[i,e]}class Jt extends ze{constructor(e){super();Oe(this,e,Ot,zt,qe,{})}}export{Jt as default,Me as metadata};
