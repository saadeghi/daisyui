import{S as ve,i as ue,s as pe,C as X,w as B,x as M,y as S,z as me,A as oe,q,o as G,B as H,K as he,ag as ie,k as I,m as D,g as N,d as n,e as p,t as y,c as m,a as h,h as E,b as u,F as d,a9 as T,Q as R,O as W}from"../../chunks/vendor-3400f70d.js";import{M as fe}from"../../chunks/_markdown-c04d9778.js";import{p as $e,C as _e,a as F,r as Y}from"../../chunks/actions-4642136c.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-053d56f2.js";import"../../chunks/index-4d4c0dab.js";import"../../chunks/SEO-d1fd09d3.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-2f0d0aa0.js";function ge(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("div"),c=y("1"),r=I(),s=p("div"),o=y("2"),t=I(),a=p("div"),b=y("3"),this.h()},l($){e=m($,"DIV",{});var v=h(e);l=m(v,"DIV",{class:!0});var x=h(l);c=E(x,"1"),x.forEach(n),r=D(v),s=m(v,"DIV",{class:!0});var w=h(s);o=E(w,"2"),w.forEach(n),t=D(v),a=m(v,"DIV",{class:!0});var g=h(a);b=E(g,"3"),g.forEach(n),v.forEach(n),this.h()},h(){u(l,"class","grid w-32 h-20 rounded bg-primary text-primary-content place-content-center"),u(s,"class","grid w-32 h-20 rounded bg-accent text-accent-content place-content-center"),u(a,"class","grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center")},m($,v){N($,e,v),d(e,l),d(l,c),d(e,r),d(e,s),d(s,o),d(e,t),d(e,a),d(a,b)},d($){$&&n(e)}}}function be(f){let e,l=`<div>
  <div class="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div class="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div class="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function we(f){let e,l=`<div>
  <div className="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div className="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div className="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function ye(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("div"),c=y("1"),r=I(),s=p("div"),o=y("2"),t=I(),a=p("div"),b=y("3"),this.h()},l($){e=m($,"DIV",{class:!0});var v=h(e);l=m(v,"DIV",{class:!0});var x=h(l);c=E(x,"1"),x.forEach(n),r=D(v),s=m(v,"DIV",{class:!0});var w=h(s);o=E(w,"2"),w.forEach(n),t=D(v),a=m(v,"DIV",{class:!0});var g=h(a);b=E(g,"3"),g.forEach(n),v.forEach(n),this.h()},h(){u(l,"class","grid w-32 h-20 rounded bg-primary text-primary-content place-content-center"),u(s,"class","grid w-32 h-20 rounded bg-accent text-accent-content place-content-center"),u(a,"class","grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center"),u(e,"class","stack mb-4")},m($,v){N($,e,v),d(e,l),d(l,c),d(e,r),d(e,s),d(s,o),d(e,t),d(e,a),d(a,b)},d($){$&&n(e)}}}function Ee(f){let e,l=`<div class="$$stack">
  <div class="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div class="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div class="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function xe(f){let e,l=`<div className="$$stack">
  <div className="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div className="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div className="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ne(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("img"),r=I(),s=p("img"),t=I(),a=p("img"),this.h()},l($){e=m($,"DIV",{class:!0});var v=h(e);l=m(v,"IMG",{src:!0,alt:!0,class:!0}),r=D(v),s=m(v,"IMG",{src:!0,alt:!0,class:!0}),t=D(v),a=m(v,"IMG",{src:!0,alt:!0,class:!0}),v.forEach(n),this.h()},h(){W(l.src,c="https://placeimg.com/224/224/arch")||u(l,"src",c),u(l,"alt","Image 1"),u(l,"class","rounded w-28"),W(s.src,o="https://placeimg.com/224/224/arch")||u(s,"src",o),u(s,"alt","Image 2"),u(s,"class","rounded w-28"),W(a.src,b="https://placeimg.com/224/224/arch")||u(a,"src",b),u(a,"alt","Image 3"),u(a,"class","rounded w-28"),u(e,"class","stack mb-4")},m($,v){N($,e,v),d(e,l),d(e,r),d(e,s),d(e,t),d(e,a)},d($){$&&n(e)}}}function Ie(f){let e,l=`<div class="$$stack">
  <img src="https://placeimg.com/112/112/arch" alt="Image 1" class="rounded" />
  <img src="https://placeimg.com/112/112/arch" alt="Image 2" class="rounded" />
  <img src="https://placeimg.com/112/112/arch" alt="Image 3" class="rounded" />
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function De(f){let e,l=`<div className="$$stack">
  <img src="https://placeimg.com/112/112/arch" alt="Image 1" className="rounded" />
  <img src="https://placeimg.com/112/112/arch" alt="Image 2" className="rounded" />
  <img src="https://placeimg.com/112/112/arch" alt="Image 3" className="rounded" />
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ve(f){let e,l,c,r,s,o,t,a,b,$,v,x;return{c(){e=p("div"),l=p("div"),c=p("div"),r=y("A"),s=I(),o=p("div"),t=p("div"),a=y("B"),b=I(),$=p("div"),v=p("div"),x=y("C"),this.h()},l(w){e=m(w,"DIV",{class:!0});var g=h(e);l=m(g,"DIV",{class:!0});var i=h(l);c=m(i,"DIV",{class:!0});var _=h(c);r=E(_,"A"),_.forEach(n),i.forEach(n),s=D(g),o=m(g,"DIV",{class:!0});var C=h(o);t=m(C,"DIV",{class:!0});var k=h(t);a=E(k,"B"),k.forEach(n),C.forEach(n),b=D(g),$=m(g,"DIV",{class:!0});var V=h($);v=m(V,"DIV",{class:!0});var P=h(v);x=E(P,"C"),P.forEach(n),V.forEach(n),g.forEach(n),this.h()},h(){u(c,"class","card-body"),u(l,"class","text-center border border-base-content card w-36 bg-base-100"),u(t,"class","card-body"),u(o,"class","text-center border border-base-content card w-36 bg-base-100"),u(v,"class","card-body"),u($,"class","text-center border border-base-content card w-36 bg-base-100"),u(e,"class","stack mb-4")},m(w,g){N(w,e,g),d(e,l),d(l,c),d(c,r),d(e,s),d(e,o),d(o,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x)},d(w){w&&n(e)}}}function ke(f){let e,l=`<div class="$$stack">
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">A</div>
  </div> 
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">B</div>
  </div> 
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Pe(f){let e,l=`<div className="$$stack">
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">A</div>
  </div> 
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">B</div>
  </div> 
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ce(f){let e,l,c,r,s,o,t,a,b,$,v,x;return{c(){e=p("div"),l=p("div"),c=p("div"),r=y("A"),s=I(),o=p("div"),t=p("div"),a=y("B"),b=I(),$=p("div"),v=p("div"),x=y("C"),this.h()},l(w){e=m(w,"DIV",{class:!0});var g=h(e);l=m(g,"DIV",{class:!0});var i=h(l);c=m(i,"DIV",{class:!0});var _=h(c);r=E(_,"A"),_.forEach(n),i.forEach(n),s=D(g),o=m(g,"DIV",{class:!0});var C=h(o);t=m(C,"DIV",{class:!0});var k=h(t);a=E(k,"B"),k.forEach(n),C.forEach(n),b=D(g),$=m(g,"DIV",{class:!0});var V=h($);v=m(V,"DIV",{class:!0});var P=h(v);x=E(P,"C"),P.forEach(n),V.forEach(n),g.forEach(n),this.h()},h(){u(c,"class","card-body"),u(l,"class","text-center shadow-md w-36 card bg-base-200"),u(t,"class","card-body"),u(o,"class","text-center shadow w-36 card bg-base-200"),u(v,"class","card-body"),u($,"class","text-center shadow-sm w-36 card bg-base-200"),u(e,"class","stack mb-4")},m(w,g){N(w,e,g),d(e,l),d(l,c),d(c,r),d(e,s),d(e,o),d(o,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x)},d(w){w&&n(e)}}}function Te(f){let e,l=`<div class="$$stack">
  <div class="text-center shadow-md w-36 $$card bg-base-200">
    <div class="$$card-body">A</div>
  </div> 
  <div class="text-center shadow w-36 $$card bg-base-200">
    <div class="$$card-body">B</div>
  </div> 
  <div class="text-center shadow-sm w-36 $$card bg-base-200">
    <div class="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Re(f){let e,l=`<div className="$$stack">
  <div className="text-center shadow-md w-36 $$card bg-base-200">
    <div className="$$card-body">A</div>
  </div> 
  <div className="text-center shadow w-36 $$card bg-base-200">
    <div className="$$card-body">B</div>
  </div> 
  <div className="text-center shadow-sm w-36 $$card bg-base-200">
    <div className="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ye(f){let e,l,c,r,s,o,t,a,b,$,v,x,w,g,i,_,C,k,V,P,j,z,K,U;return{c(){e=p("div"),l=p("div"),c=p("div"),r=p("h2"),s=y("Notification 1"),o=I(),t=p("p"),a=y("You have 3 unread messages. Tap here to see."),b=I(),$=p("div"),v=p("div"),x=p("h2"),w=y("Notification 2"),g=I(),i=p("p"),_=y("You have 3 unread messages. Tap here to see."),C=I(),k=p("div"),V=p("div"),P=p("h2"),j=y("Notification 3"),z=I(),K=p("p"),U=y("You have 3 unread messages. Tap here to see."),this.h()},l(O){e=m(O,"DIV",{class:!0});var A=h(e);l=m(A,"DIV",{class:!0});var Z=h(l);c=m(Z,"DIV",{class:!0});var Q=h(c);r=m(Q,"H2",{class:!0});var ee=h(r);s=E(ee,"Notification 1"),ee.forEach(n),o=D(Q),t=m(Q,"P",{});var te=h(t);a=E(te,"You have 3 unread messages. Tap here to see."),te.forEach(n),Q.forEach(n),Z.forEach(n),b=D(A),$=m(A,"DIV",{class:!0});var ae=h($);v=m(ae,"DIV",{class:!0});var J=h(v);x=m(J,"H2",{class:!0});var se=h(x);w=E(se,"Notification 2"),se.forEach(n),g=D(J),i=m(J,"P",{});var re=h(i);_=E(re,"You have 3 unread messages. Tap here to see."),re.forEach(n),J.forEach(n),ae.forEach(n),C=D(A),k=m(A,"DIV",{class:!0});var ce=h(k);V=m(ce,"DIV",{class:!0});var L=h(V);P=m(L,"H2",{class:!0});var le=h(P);j=E(le,"Notification 3"),le.forEach(n),z=D(L),K=m(L,"P",{});var de=h(K);U=E(de,"You have 3 unread messages. Tap here to see."),de.forEach(n),L.forEach(n),ce.forEach(n),A.forEach(n),this.h()},h(){u(r,"class","card-title"),u(c,"class","card-body"),u(l,"class","shadow-md card bg-primary text-primary-content"),u(x,"class","card-title"),u(v,"class","card-body"),u($,"class","shadow card bg-primary text-primary-content"),u(P,"class","card-title"),u(V,"class","card-body"),u(k,"class","shadow-sm card bg-primary text-primary-content"),u(e,"class","stack mb-4")},m(O,A){N(O,e,A),d(e,l),d(l,c),d(c,r),d(r,s),d(c,o),d(c,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x),d(x,w),d(v,g),d(v,i),d(i,_),d(e,C),d(e,k),d(k,V),d(V,P),d(P,j),d(V,z),d(V,K),d(K,U)},d(O){O&&n(e)}}}function Ae(f){let e,l=`<div class="$$stack">
  <div class="$$card shadow-md bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 1</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div class="$$card shadow bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 2</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div class="$$card shadow-sm bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 3</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Be(f){let e,l=`<div className="$$stack">
  <div className="$$card shadow-md bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 1</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div className="$$card shadow bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 2</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div className="$$card shadow-sm bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 3</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Me(f){let e,l,c,r,s,o,t,a,b,$,v,x,w,g;return e=new _e({props:{data:[{type:"component",class:"stack",desc:"Puts the child elements on top of each other"}]}}),c=new F({props:{title:"3 divs without stack",$$slots:{react:[we],html:[be],default:[ge]},$$scope:{ctx:f}}}),s=new F({props:{title:"3 divs with stack",$$slots:{react:[xe],html:[Ee],default:[ye]},$$scope:{ctx:f}}}),t=new F({props:{title:"stacked images",$$slots:{react:[De],html:[Ie],default:[Ne]},$$scope:{ctx:f}}}),b=new F({props:{title:"stacked cards",$$slots:{react:[Pe],html:[ke],default:[Ve]},$$scope:{ctx:f}}}),v=new F({props:{title:"stacked cards with shadow",$$slots:{react:[Re],html:[Te],default:[Ce]},$$scope:{ctx:f}}}),w=new F({props:{title:"stacked cards",$$slots:{react:[Be],html:[Ae],default:[Ye]},$$scope:{ctx:f}}}),{c(){B(e.$$.fragment),l=I(),B(c.$$.fragment),r=I(),B(s.$$.fragment),o=I(),B(t.$$.fragment),a=I(),B(b.$$.fragment),$=I(),B(v.$$.fragment),x=I(),B(w.$$.fragment)},l(i){M(e.$$.fragment,i),l=D(i),M(c.$$.fragment,i),r=D(i),M(s.$$.fragment,i),o=D(i),M(t.$$.fragment,i),a=D(i),M(b.$$.fragment,i),$=D(i),M(v.$$.fragment,i),x=D(i),M(w.$$.fragment,i)},m(i,_){S(e,i,_),N(i,l,_),S(c,i,_),N(i,r,_),S(s,i,_),N(i,o,_),S(t,i,_),N(i,a,_),S(b,i,_),N(i,$,_),S(v,i,_),N(i,x,_),S(w,i,_),g=!0},p(i,_){const C={};_&5&&(C.$$scope={dirty:_,ctx:i}),c.$set(C);const k={};_&5&&(k.$$scope={dirty:_,ctx:i}),s.$set(k);const V={};_&5&&(V.$$scope={dirty:_,ctx:i}),t.$set(V);const P={};_&5&&(P.$$scope={dirty:_,ctx:i}),b.$set(P);const j={};_&5&&(j.$$scope={dirty:_,ctx:i}),v.$set(j);const z={};_&5&&(z.$$scope={dirty:_,ctx:i}),w.$set(z)},i(i){g||(q(e.$$.fragment,i),q(c.$$.fragment,i),q(s.$$.fragment,i),q(t.$$.fragment,i),q(b.$$.fragment,i),q(v.$$.fragment,i),q(w.$$.fragment,i),g=!0)},o(i){G(e.$$.fragment,i),G(c.$$.fragment,i),G(s.$$.fragment,i),G(t.$$.fragment,i),G(b.$$.fragment,i),G(v.$$.fragment,i),G(w.$$.fragment,i),g=!1},d(i){H(e,i),i&&n(l),H(c,i),i&&n(r),H(s,i),i&&n(o),H(t,i),i&&n(a),H(b,i),i&&n($),H(v,i),i&&n(x),H(w,i)}}}function Se(f){let e,l;const c=[f[1],ne];let r={$$slots:{default:[Me]},$$scope:{ctx:f}};for(let s=0;s<c.length;s+=1)r=X(r,c[s]);return e=new fe({props:r}),{c(){B(e.$$.fragment)},l(s){M(e.$$.fragment,s)},m(s,o){S(e,s,o),l=!0},p(s,[o]){const t=o&2?me(c,[o&2&&oe(s[1]),o&0&&oe(ne)]):{};o&5&&(t.$$scope={dirty:o,ctx:s}),e.$set(t)},i(s){l||(q(e.$$.fragment,s),l=!0)},o(s){G(e.$$.fragment,s),l=!1},d(s){H(e,s)}}}const ne={title:"Stack",desc:"Stack visually puts elements on top of each other.",published:!0};function qe(f,e,l){let c;return he(f,$e,r=>l(0,c=r)),f.$$set=r=>{l(1,e=X(X({},e),ie(r)))},e=ie(e),[c,e]}class Le extends ve{constructor(e){super();ue(this,e,qe,Se,pe,{})}}export{Le as default,ne as metadata};
