import{S as Ce,i as Re,s as Be,C as de,w as q,x as K,y as Q,z as Me,A as ke,q as U,o as X,B as Z,K as We,ag as ye,k as z,m as G,g as N,d as p,e as u,t as d,c as _,a as f,h,b as w,F as s,a9 as B,W as M}from"../../chunks/vendor-c5cb7521.js";import{M as Je}from"../../chunks/_markdown-86fe9495.js";import{p as De,C as ze,a as se,r as W}from"../../chunks/actions-0dd8165f.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-bf889088.js";import"../../chunks/index-ea08827d.js";import"../../chunks/SEO-e4f29b8b.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-fc97082e.js";function Ge(v){let e,a,r,l,i,n,o,t,E,m,g,$,P;return{c(){e=u("select"),a=u("option"),r=d("Pick your favorite Simpson"),l=u("option"),i=d("Homer"),n=u("option"),o=d("Marge"),t=u("option"),E=d("Bart"),m=u("option"),g=d("Lisa"),$=u("option"),P=d("Maggie"),this.h()},l(b){e=_(b,"SELECT",{class:!0});var T=f(e);a=_(T,"OPTION",{});var x=f(a);r=h(x,"Pick your favorite Simpson"),x.forEach(p),l=_(T,"OPTION",{});var A=f(l);i=h(A,"Homer"),A.forEach(p),n=_(T,"OPTION",{});var S=f(n);o=h(S,"Marge"),S.forEach(p),t=_(T,"OPTION",{});var I=f(t);E=h(I,"Bart"),I.forEach(p),m=_(T,"OPTION",{});var L=f(m);g=h(L,"Lisa"),L.forEach(p),$=_(T,"OPTION",{});var k=f($);P=h(k,"Maggie"),k.forEach(p),T.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Pick your favorite Simpson",a.value=a.__value,l.__value="Homer",l.value=l.__value,n.__value="Marge",n.value=n.__value,t.__value="Bart",t.value=t.__value,m.__value="Lisa",m.value=m.__value,$.__value="Maggie",$.value=$.__value,w(e,"class","select w-full max-w-xs")},m(b,T){N(b,e,T),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g),s(e,$),s($,P)},d(b){b&&p(e)}}}function He(v){let e,a=`<select class="$$select w-full max-w-xs">
  <option disabled selected>Pick your favorite Simpson</option>
  <option>Homer</option>
  <option>Marge</option>
  <option>Bart</option>
  <option>Lisa</option>
  <option>Maggie</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Ve(v){let e,a=`<select className="$$select w-full max-w-xs">
  <option disabled selected>Pick your favorite Simpson</option>
  <option>Homer</option>
  <option>Marge</option>
  <option>Bart</option>
  <option>Lisa</option>
  <option>Maggie</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Fe(v){let e,a,r,l,i,n,o;return{c(){e=u("select"),a=u("option"),r=d("Who shot first?"),l=u("option"),i=d("Han Solo"),n=u("option"),o=d("Greedo"),this.h()},l(t){e=_(t,"SELECT",{class:!0});var E=f(e);a=_(E,"OPTION",{});var m=f(a);r=h(m,"Who shot first?"),m.forEach(p),l=_(E,"OPTION",{});var g=f(l);i=h(g,"Han Solo"),g.forEach(p),n=_(E,"OPTION",{});var $=f(n);o=h($,"Greedo"),$.forEach(p),E.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Who shot first?",a.value=a.__value,l.__value="Han Solo",l.value=l.__value,n.__value="Greedo",n.value=n.__value,w(e,"class","select w-full max-w-xs select-bordered")},m(t,E){N(t,e,E),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o)},d(t){t&&p(e)}}}function je(v){let e,a=`<select class="$$select $$select-bordered w-full max-w-xs">
  <option disabled selected>Who shot first?</option>
  <option>Han Solo</option>
  <option>Greedo</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Ye(v){let e,a=`<select className="$$select $$select-bordered w-full max-w-xs">
  <option disabled selected>Who shot first?</option>
  <option>Han Solo</option>
  <option>Greedo</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function qe(v){let e,a,r,l,i,n,o,t,E;return{c(){e=u("select"),a=u("option"),r=d("Pick the best JS framework"),l=u("option"),i=d("Svelte"),n=u("option"),o=d("Vue"),t=u("option"),E=d("React"),this.h()},l(m){e=_(m,"SELECT",{class:!0});var g=f(e);a=_(g,"OPTION",{});var $=f(a);r=h($,"Pick the best JS framework"),$.forEach(p),l=_(g,"OPTION",{});var P=f(l);i=h(P,"Svelte"),P.forEach(p),n=_(g,"OPTION",{});var b=f(n);o=h(b,"Vue"),b.forEach(p),t=_(g,"OPTION",{});var T=f(t);E=h(T,"React"),T.forEach(p),g.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Pick the best JS framework",a.value=a.__value,l.__value="Svelte",l.value=l.__value,n.__value="Vue",n.value=n.__value,t.__value="React",t.value=t.__value,w(e,"class","select w-full max-w-xs select-ghost")},m(m,g){N(m,e,g),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E)},d(m){m&&p(e)}}}function Ke(v){let e,a=`<select class="$$select $$select-ghost w-full max-w-xs">
  <option disabled selected>Pick the best JS framework</option>
  <option>Svelte</option>
  <option>Vue</option>
  <option>React</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Qe(v){let e,a=`<select className="$$select $$select-ghost w-full max-w-xs">
  <option disabled selected>Pick the best JS framework</option>
  <option>Svelte</option>
  <option>Vue</option>
  <option>React</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Ue(v){let e,a,r,l,i,n,o,t,E,m,g,$,P,b,T,x,A,S,I,L,k,J,y,D,R,H,C,j;return{c(){e=u("div"),a=u("label"),r=u("span"),l=d("Pick the best fantasy franchise"),i=z(),n=u("span"),o=d("Alt label"),t=z(),E=u("select"),m=u("option"),g=d("Pick one"),$=u("option"),P=d("Star Wars"),b=u("option"),T=d("Harry Potter"),x=u("option"),A=d("Lord of the Rings"),S=u("option"),I=d("Planet of the Apes"),L=u("option"),k=d("Star Trek"),J=z(),y=u("label"),D=u("span"),R=d("Alt label"),H=z(),C=u("span"),j=d("Alt label"),this.h()},l(c){e=_(c,"DIV",{class:!0});var O=f(e);a=_(O,"LABEL",{class:!0});var ne=f(a);r=_(ne,"SPAN",{class:!0});var Y=f(r);l=h(Y,"Pick the best fantasy franchise"),Y.forEach(p),i=G(ne),n=_(ne,"SPAN",{class:!0});var V=f(n);o=h(V,"Alt label"),V.forEach(p),ne.forEach(p),t=G(O),E=_(O,"SELECT",{class:!0});var ee=f(E);m=_(ee,"OPTION",{});var te=f(m);g=h(te,"Pick one"),te.forEach(p),$=_(ee,"OPTION",{});var re=f($);P=h(re,"Star Wars"),re.forEach(p),b=_(ee,"OPTION",{});var oe=f(b);T=h(oe,"Harry Potter"),oe.forEach(p),x=_(ee,"OPTION",{});var pe=f(x);A=h(pe,"Lord of the Rings"),pe.forEach(p),S=_(ee,"OPTION",{});var le=f(S);I=h(le,"Planet of the Apes"),le.forEach(p),L=_(ee,"OPTION",{});var ce=f(L);k=h(ce,"Star Trek"),ce.forEach(p),ee.forEach(p),J=G(O),y=_(O,"LABEL",{class:!0});var ae=f(y);D=_(ae,"SPAN",{class:!0});var F=f(D);R=h(F,"Alt label"),F.forEach(p),H=G(ae),C=_(ae,"SPAN",{class:!0});var ie=f(C);j=h(ie,"Alt label"),ie.forEach(p),ae.forEach(p),O.forEach(p),this.h()},h(){w(r,"class","label-text"),w(n,"class","label-text-alt"),w(a,"class","label"),m.disabled=!0,m.selected=!0,m.__value="Pick one",m.value=m.__value,$.__value="Star Wars",$.value=$.__value,b.__value="Harry Potter",b.value=b.__value,x.__value="Lord of the Rings",x.value=x.__value,S.__value="Planet of the Apes",S.value=S.__value,L.__value="Star Trek",L.value=L.__value,w(E,"class","select select-bordered"),w(D,"class","label-text-alt"),w(C,"class","label-text-alt"),w(y,"class","label"),w(e,"class","form-control w-full max-w-xs")},m(c,O){N(c,e,O),s(e,a),s(a,r),s(r,l),s(a,i),s(a,n),s(n,o),s(e,t),s(e,E),s(E,m),s(m,g),s(E,$),s($,P),s(E,b),s(b,T),s(E,x),s(x,A),s(E,S),s(S,I),s(E,L),s(L,k),s(e,J),s(e,y),s(y,D),s(D,R),s(y,H),s(y,C),s(C,j)},d(c){c&&p(e)}}}function Xe(v){let e,a=`<div class="$$form-control w-full max-w-xs">
  <label class="$$label">
    <span class="$$label-text">Pick the best fantasy franchise</span>
    <span class="$$label-text-alt">Alt label</span>
  </label>
  <select class="$$select $$select-bordered">
    <option disabled selected>Pick one</option>
    <option>Star Wars</option>
    <option>Harry Potter</option>
    <option>Lord of the Rings</option>
    <option>Planet of the Apes</option>
    <option>Star Trek</option>
  </select>
  <label class="$$label">
    <span class="$$label-text-alt">Alt label</span>
    <span class="$$label-text-alt">Alt label</span>
  </label>
</div>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Ze(v){let e,a=`<div className="$$form-control w-full max-w-xs">
  <label className="$$label">
    <span className="$$label-text">Pick the best fantasy franchise</span>
    <span className="$$label-text-alt">Alt label</span>
  </label>
  <select className="$$select $$select-bordered">
    <option disabled selected>Pick one</option>
    <option>Star Wars</option>
    <option>Harry Potter</option>
    <option>Lord of the Rings</option>
    <option>Planet of the Apes</option>
    <option>Star Trek</option>
  </select>
  <label className="$$label">
    <span className="$$label-text-alt">Alt label</span>
    <span className="$$label-text-alt">Alt label</span>
  </label>
</div>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function et(v){let e,a,r,l,i,n,o,t,E,m,g;return{c(){e=u("select"),a=u("option"),r=d("What is the best TV show?"),l=u("option"),i=d("Game of Thrones"),n=u("option"),o=d("Lost"),t=u("option"),E=d("Breaking Bad"),m=u("option"),g=d("Walking Dead"),this.h()},l($){e=_($,"SELECT",{class:!0});var P=f(e);a=_(P,"OPTION",{});var b=f(a);r=h(b,"What is the best TV show?"),b.forEach(p),l=_(P,"OPTION",{});var T=f(l);i=h(T,"Game of Thrones"),T.forEach(p),n=_(P,"OPTION",{});var x=f(n);o=h(x,"Lost"),x.forEach(p),t=_(P,"OPTION",{});var A=f(t);E=h(A,"Breaking Bad"),A.forEach(p),m=_(P,"OPTION",{});var S=f(m);g=h(S,"Walking Dead"),S.forEach(p),P.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="What is the best TV show?",a.value=a.__value,l.__value="Game of Thrones",l.value=l.__value,n.__value="Lost",n.value=n.__value,t.__value="Breaking Bad",t.value=t.__value,m.__value="Walking Dead",m.value=m.__value,w(e,"class","select w-full max-w-xs select-primary")},m($,P){N($,e,P),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g)},d($){$&&p(e)}}}function tt(v){let e,a=`<select class="$$select $$select-primary w-full max-w-xs">
  <option disabled selected>What is the best TV show?</option>
  <option>Game of Thrones</option>
  <option>Lost</option>
  <option>Breaking Bad</option>
  <option>Walking Dead</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function ot(v){let e,a=`<select className="$$select $$select-primary w-full max-w-xs">
  <option disabled selected>What is the best TV show?</option>
  <option>Game of Thrones</option>
  <option>Lost</option>
  <option>Breaking Bad</option>
  <option>Walking Dead</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function lt(v){let e,a,r,l,i,n,o,t,E,m,g,$,P,b,T,x,A,S,I;return{c(){e=u("select"),a=u("option"),r=d("Pick your favorite language"),l=u("option"),i=d("Java"),n=u("option"),o=d("Go"),t=u("option"),E=d("C"),m=u("option"),g=d("C#"),$=u("option"),P=d("C++"),b=u("option"),T=d("Rust"),x=u("option"),A=d("JavaScript"),S=u("option"),I=d("Python"),this.h()},l(L){e=_(L,"SELECT",{class:!0});var k=f(e);a=_(k,"OPTION",{});var J=f(a);r=h(J,"Pick your favorite language"),J.forEach(p),l=_(k,"OPTION",{});var y=f(l);i=h(y,"Java"),y.forEach(p),n=_(k,"OPTION",{});var D=f(n);o=h(D,"Go"),D.forEach(p),t=_(k,"OPTION",{});var R=f(t);E=h(R,"C"),R.forEach(p),m=_(k,"OPTION",{});var H=f(m);g=h(H,"C#"),H.forEach(p),$=_(k,"OPTION",{});var C=f($);P=h(C,"C++"),C.forEach(p),b=_(k,"OPTION",{});var j=f(b);T=h(j,"Rust"),j.forEach(p),x=_(k,"OPTION",{});var c=f(x);A=h(c,"JavaScript"),c.forEach(p),S=_(k,"OPTION",{});var O=f(S);I=h(O,"Python"),O.forEach(p),k.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Pick your favorite language",a.value=a.__value,l.__value="Java",l.value=l.__value,n.__value="Go",n.value=n.__value,t.__value="C",t.value=t.__value,m.__value="C#",m.value=m.__value,$.__value="C++",$.value=$.__value,b.__value="Rust",b.value=b.__value,x.__value="JavaScript",x.value=x.__value,S.__value="Python",S.value=S.__value,w(e,"class","select w-full max-w-xs select-secondary")},m(L,k){N(L,e,k),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g),s(e,$),s($,P),s(e,b),s(b,T),s(e,x),s(x,A),s(e,S),s(S,I)},d(L){L&&p(e)}}}function at(v){let e,a=`<select class="$$select $$select-secondary w-full max-w-xs">
  <option disabled selected>Pick your favorite language</option>
  <option>Java</option>
  <option>Go</option>
  <option>C</option>
  <option>C#</option>
  <option>C++</option>
  <option>Rust</option>
  <option>JavaScript</option>
  <option>Python</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function st(v){let e,a=`<select className="$$select $$select-secondary w-full max-w-xs">
  <option disabled selected>Pick your favorite language</option>
  <option>Java</option>
  <option>Go</option>
  <option>C</option>
  <option>C#</option>
  <option>C++</option>
  <option>Rust</option>
  <option>JavaScript</option>
  <option>Python</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function nt(v){let e,a,r,l,i,n,o,t,E;return{c(){e=u("select"),a=u("option"),r=d("Dark mode or light mode?"),l=u("option"),i=d("Auto"),n=u("option"),o=d("Dark mode"),t=u("option"),E=d("Light mode"),this.h()},l(m){e=_(m,"SELECT",{class:!0});var g=f(e);a=_(g,"OPTION",{});var $=f(a);r=h($,"Dark mode or light mode?"),$.forEach(p),l=_(g,"OPTION",{});var P=f(l);i=h(P,"Auto"),P.forEach(p),n=_(g,"OPTION",{});var b=f(n);o=h(b,"Dark mode"),b.forEach(p),t=_(g,"OPTION",{});var T=f(t);E=h(T,"Light mode"),T.forEach(p),g.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Dark mode or light mode?",a.value=a.__value,l.__value="Auto",l.value=l.__value,n.__value="Dark mode",n.value=n.__value,t.__value="Light mode",t.value=t.__value,w(e,"class","select w-full max-w-xs select-accent")},m(m,g){N(m,e,g),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E)},d(m){m&&p(e)}}}function it(v){let e,a=`<select class="$$select $$select-accent w-full max-w-xs">
  <option disabled selected>Dark mode or light mode?</option>
  <option>Auto</option>
  <option>Dark mode</option>
  <option>Light mode</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function rt(v){let e,a=`<select className="$$select $$select-accent w-full max-w-xs">
  <option disabled selected>Dark mode or light mode?</option>
  <option>Auto</option>
  <option>Dark mode</option>
  <option>Light mode</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function pt(v){let e,a,r,l,i,n,o,t,E;return{c(){e=u("select"),a=u("option"),r=d("Select language"),l=u("option"),i=d("English"),n=u("option"),o=d("Japanese"),t=u("option"),E=d("Italian"),this.h()},l(m){e=_(m,"SELECT",{class:!0});var g=f(e);a=_(g,"OPTION",{});var $=f(a);r=h($,"Select language"),$.forEach(p),l=_(g,"OPTION",{});var P=f(l);i=h(P,"English"),P.forEach(p),n=_(g,"OPTION",{});var b=f(n);o=h(b,"Japanese"),b.forEach(p),t=_(g,"OPTION",{});var T=f(t);E=h(T,"Italian"),T.forEach(p),g.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Select language",a.value=a.__value,l.__value="English",l.value=l.__value,n.__value="Japanese",n.value=n.__value,t.__value="Italian",t.value=t.__value,w(e,"class","select w-full max-w-xs select-info")},m(m,g){N(m,e,g),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E)},d(m){m&&p(e)}}}function ct(v){let e,a=`<select class="$$select $$select-info w-full max-w-xs">
  <option disabled selected>Select language</option>
  <option>English</option>
  <option>Japanese</option>
  <option>Italian</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function ut(v){let e,a=`<select className="$$select $$select-info w-full max-w-xs">
  <option disabled selected>Select language</option>
  <option>English</option>
  <option>Japanese</option>
  <option>Italian</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function _t(v){let e,a,r,l,i,n,o,t,E,m,g,$,P,b,T,x,A;return{c(){e=u("select"),a=u("option"),r=d("Pick your favorite anime"),l=u("option"),i=d("One Piece"),n=u("option"),o=d("Naruto"),t=u("option"),E=d("Death Note"),m=u("option"),g=d("Attack on Titan"),$=u("option"),P=d("Bleach"),b=u("option"),T=d("Fullmetal Alchemist"),x=u("option"),A=d("Jojo's Bizarre Adventure"),this.h()},l(S){e=_(S,"SELECT",{class:!0});var I=f(e);a=_(I,"OPTION",{});var L=f(a);r=h(L,"Pick your favorite anime"),L.forEach(p),l=_(I,"OPTION",{});var k=f(l);i=h(k,"One Piece"),k.forEach(p),n=_(I,"OPTION",{});var J=f(n);o=h(J,"Naruto"),J.forEach(p),t=_(I,"OPTION",{});var y=f(t);E=h(y,"Death Note"),y.forEach(p),m=_(I,"OPTION",{});var D=f(m);g=h(D,"Attack on Titan"),D.forEach(p),$=_(I,"OPTION",{});var R=f($);P=h(R,"Bleach"),R.forEach(p),b=_(I,"OPTION",{});var H=f(b);T=h(H,"Fullmetal Alchemist"),H.forEach(p),x=_(I,"OPTION",{});var C=f(x);A=h(C,"Jojo's Bizarre Adventure"),C.forEach(p),I.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Pick your favorite anime",a.value=a.__value,l.__value="One Piece",l.value=l.__value,n.__value="Naruto",n.value=n.__value,t.__value="Death Note",t.value=t.__value,m.__value="Attack on Titan",m.value=m.__value,$.__value="Bleach",$.value=$.__value,b.__value="Fullmetal Alchemist",b.value=b.__value,x.__value="Jojo's Bizarre Adventure",x.value=x.__value,w(e,"class","select w-full max-w-xs select-success")},m(S,I){N(S,e,I),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g),s(e,$),s($,P),s(e,b),s(b,T),s(e,x),s(x,A)},d(S){S&&p(e)}}}function ft(v){let e,a=`<select class="$$select $$select-success w-full max-w-xs">
  <option disabled selected>Pick your favorite anime</option>
  <option>One Piece</option>
  <option>Naruto</option>
  <option>Death Note</option>
  <option>Attack on Titan</option>
  <option>Bleach</option>
  <option>Fullmetal Alchemist</option>
  <option>Jojo's Bizarre Adventure</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function dt(v){let e,a=`<select className="$$select $$select-success w-full max-w-xs">
  <option disabled selected>Pick your favorite anime</option>
  <option>One Piece</option>
  <option>Naruto</option>
  <option>Death Note</option>
  <option>Attack on Titan</option>
  <option>Bleach</option>
  <option>Fullmetal Alchemist</option>
  <option>Jojo's Bizarre Adventure</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function ht(v){let e,a,r,l,i,n,o,t,E,m,g,$,P;return{c(){e=u("select"),a=u("option"),r=d("Pick a pizza"),l=u("option"),i=d("Cheese"),n=u("option"),o=d("Veggie"),t=u("option"),E=d("Pepperoni"),m=u("option"),g=d("Margherita"),$=u("option"),P=d("Hawaiian"),this.h()},l(b){e=_(b,"SELECT",{class:!0});var T=f(e);a=_(T,"OPTION",{});var x=f(a);r=h(x,"Pick a pizza"),x.forEach(p),l=_(T,"OPTION",{});var A=f(l);i=h(A,"Cheese"),A.forEach(p),n=_(T,"OPTION",{});var S=f(n);o=h(S,"Veggie"),S.forEach(p),t=_(T,"OPTION",{});var I=f(t);E=h(I,"Pepperoni"),I.forEach(p),m=_(T,"OPTION",{});var L=f(m);g=h(L,"Margherita"),L.forEach(p),$=_(T,"OPTION",{});var k=f($);P=h(k,"Hawaiian"),k.forEach(p),T.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="Pick a pizza",a.value=a.__value,l.__value="Cheese",l.value=l.__value,n.__value="Veggie",n.value=n.__value,t.__value="Pepperoni",t.value=t.__value,m.__value="Margherita",m.value=m.__value,$.__value="Hawaiian",$.value=$.__value,w(e,"class","select w-full max-w-xs select-warning")},m(b,T){N(b,e,T),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g),s(e,$),s($,P)},d(b){b&&p(e)}}}function mt(v){let e,a=`<select class="$$select $$select-warning w-full max-w-xs">
  <option disabled selected>Pick a pizza</option>
  <option>Cheese</option>
  <option>Veggie</option>
  <option>Pepperoni</option>
  <option>Margherita</option>
  <option>Hawaiian</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function vt(v){let e,a=`<select className="$$select $$select-warning w-full max-w-xs">
  <option disabled selected>Pick a pizza</option>
  <option>Cheese</option>
  <option>Veggie</option>
  <option>Pepperoni</option>
  <option>Margherita</option>
  <option>Hawaiian</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function $t(v){let e,a,r,l,i,n,o,t,E,m,g;return{c(){e=u("select"),a=u("option"),r=d("What is the best headless CMS"),l=u("option"),i=d("Strapi"),n=u("option"),o=d("Ghost"),t=u("option"),E=d("Netlify CMS"),m=u("option"),g=d("Sanity"),this.h()},l($){e=_($,"SELECT",{class:!0});var P=f(e);a=_(P,"OPTION",{});var b=f(a);r=h(b,"What is the best headless CMS"),b.forEach(p),l=_(P,"OPTION",{});var T=f(l);i=h(T,"Strapi"),T.forEach(p),n=_(P,"OPTION",{});var x=f(n);o=h(x,"Ghost"),x.forEach(p),t=_(P,"OPTION",{});var A=f(t);E=h(A,"Netlify CMS"),A.forEach(p),m=_(P,"OPTION",{});var S=f(m);g=h(S,"Sanity"),S.forEach(p),P.forEach(p),this.h()},h(){a.disabled=!0,a.selected=!0,a.__value="What is the best headless CMS",a.value=a.__value,l.__value="Strapi",l.value=l.__value,n.__value="Ghost",n.value=n.__value,t.__value="Netlify CMS",t.value=t.__value,m.__value="Sanity",m.value=m.__value,w(e,"class","select w-full max-w-xs select-error")},m($,P){N($,e,P),s(e,a),s(a,r),s(e,l),s(l,i),s(e,n),s(n,o),s(e,t),s(t,E),s(e,m),s(m,g)},d($){$&&p(e)}}}function Et(v){let e,a=`<select class="$$select $$select-error w-full max-w-xs">
  <option disabled selected>What is the best headless CMS</option>
  <option>Strapi</option>
  <option>Ghost</option>
  <option>Netlify CMS</option>
  <option>Sanity</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Ot(v){let e,a=`<select className="$$select $$select-error w-full max-w-xs">
  <option disabled selected>What is the best headless CMS</option>
  <option>Strapi</option>
  <option>Ghost</option>
  <option>Netlify CMS</option>
  <option>Sanity</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function gt(v){let e,a,r,l,i,n,o,t,E,m,g,$,P,b,T,x,A,S,I,L,k,J,y,D,R,H,C,j,c,O,ne,Y,V,ee,te,re,oe,pe,le,ce;return{c(){e=u("div"),a=u("select"),r=u("option"),l=d("Large"),i=u("option"),n=d("Large Apple"),o=u("option"),t=d("Large Orange"),E=u("option"),m=d("Large Tomato"),g=z(),$=u("select"),P=u("option"),b=d("Normal"),T=u("option"),x=d("Normal Apple"),A=u("option"),S=d("Normal Orange"),I=u("option"),L=d("Normal Tomato"),k=z(),J=u("select"),y=u("option"),D=d("Small"),R=u("option"),H=d("Small Apple"),C=u("option"),j=d("Small Orange"),c=u("option"),O=d("Small Tomato"),ne=z(),Y=u("select"),V=u("option"),ee=d("Tiny"),te=u("option"),re=d("Tiny Apple"),oe=u("option"),pe=d("Tiny Orange"),le=u("option"),ce=d("Tiny Tomato"),this.h()},l(ae){e=_(ae,"DIV",{class:!0});var F=f(e);a=_(F,"SELECT",{class:!0});var ie=f(a);r=_(ie,"OPTION",{});var he=f(r);l=h(he,"Large"),he.forEach(p),i=_(ie,"OPTION",{});var me=f(i);n=h(me,"Large Apple"),me.forEach(p),o=_(ie,"OPTION",{});var ve=f(o);t=h(ve,"Large Orange"),ve.forEach(p),E=_(ie,"OPTION",{});var $e=f(E);m=h($e,"Large Tomato"),$e.forEach(p),ie.forEach(p),g=G(F),$=_(F,"SELECT",{class:!0});var ue=f($);P=_(ue,"OPTION",{});var Ee=f(P);b=h(Ee,"Normal"),Ee.forEach(p),T=_(ue,"OPTION",{});var Oe=f(T);x=h(Oe,"Normal Apple"),Oe.forEach(p),A=_(ue,"OPTION",{});var ge=f(A);S=h(ge,"Normal Orange"),ge.forEach(p),I=_(ue,"OPTION",{});var Pe=f(I);L=h(Pe,"Normal Tomato"),Pe.forEach(p),ue.forEach(p),k=G(F),J=_(F,"SELECT",{class:!0});var _e=f(J);y=_(_e,"OPTION",{});var Te=f(y);D=h(Te,"Small"),Te.forEach(p),R=_(_e,"OPTION",{});var be=f(R);H=h(be,"Small Apple"),be.forEach(p),C=_(_e,"OPTION",{});var Ne=f(C);j=h(Ne,"Small Orange"),Ne.forEach(p),c=_(_e,"OPTION",{});var we=f(c);O=h(we,"Small Tomato"),we.forEach(p),_e.forEach(p),ne=G(F),Y=_(F,"SELECT",{class:!0});var fe=f(Y);V=_(fe,"OPTION",{});var xe=f(V);ee=h(xe,"Tiny"),xe.forEach(p),te=_(fe,"OPTION",{});var Se=f(te);re=h(Se,"Tiny Apple"),Se.forEach(p),oe=_(fe,"OPTION",{});var Ie=f(oe);pe=h(Ie,"Tiny Orange"),Ie.forEach(p),le=_(fe,"OPTION",{});var Ae=f(le);ce=h(Ae,"Tiny Tomato"),Ae.forEach(p),fe.forEach(p),F.forEach(p),this.h()},h(){r.disabled=!0,r.selected=!0,r.__value="Large",r.value=r.__value,i.__value="Large Apple",i.value=i.__value,o.__value="Large Orange",o.value=o.__value,E.__value="Large Tomato",E.value=E.__value,w(a,"class","select select-bordered select-lg w-full max-w-xs"),P.disabled=!0,P.selected=!0,P.__value="Normal",P.value=P.__value,T.__value="Normal Apple",T.value=T.__value,A.__value="Normal Orange",A.value=A.__value,I.__value="Normal Tomato",I.value=I.__value,w($,"class","select select-bordered w-full max-w-xs"),y.disabled=!0,y.selected=!0,y.__value="Small",y.value=y.__value,R.__value="Small Apple",R.value=R.__value,C.__value="Small Orange",C.value=C.__value,c.__value="Small Tomato",c.value=c.__value,w(J,"class","select select-bordered select-sm w-full max-w-xs"),V.disabled=!0,V.selected=!0,V.__value="Tiny",V.value=V.__value,te.__value="Tiny Apple",te.value=te.__value,oe.__value="Tiny Orange",oe.value=oe.__value,le.__value="Tiny Tomato",le.value=le.__value,w(Y,"class","select select-bordered select-xs w-full max-w-xs"),w(e,"class","flex flex-col gap-4 w-full items-center")},m(ae,F){N(ae,e,F),s(e,a),s(a,r),s(r,l),s(a,i),s(i,n),s(a,o),s(o,t),s(a,E),s(E,m),s(e,g),s(e,$),s($,P),s(P,b),s($,T),s(T,x),s($,A),s(A,S),s($,I),s(I,L),s(e,k),s(e,J),s(J,y),s(y,D),s(J,R),s(R,H),s(J,C),s(C,j),s(J,c),s(c,O),s(e,ne),s(e,Y),s(Y,V),s(V,ee),s(Y,te),s(te,re),s(Y,oe),s(oe,pe),s(Y,le),s(le,ce)},d(ae){ae&&p(e)}}}function Pt(v){let e,a=`<!-- lg -->
<select class="$$select $$select-bordered $$select-lg w-full max-w-xs">
  <option disabled selected>Large</option>
  <option>Large Apple</option>
  <option>Large Orange</option>
  <option>Large Tomato</option>
</select>
<!-- md -->
<select class="$$select $$select-bordered w-full max-w-xs">
  <option disabled selected>Normal</option>
  <option>Normal Apple</option>
  <option>Normal Orange</option>
  <option>Normal Tomato</option>
</select>
<!-- sm -->
<select class="$$select $$select-bordered $$select-sm w-full max-w-xs">
  <option disabled selected>Small</option>
  <option>Small Apple</option>
  <option>Small Orange</option>
  <option>Small Tomato</option>
</select>
<!-- xs -->
<select class="$$select $$select-bordered $$select-xs w-full max-w-xs">
  <option disabled selected>Tiny</option>
  <option>Tiny Apple</option>
  <option>Tiny Orange</option>
  <option>Tiny Tomato</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function Tt(v){let e,a=`<!-- lg -->
<select className="$$select $$select-bordered $$select-lg w-full max-w-xs">
  <option disabled selected>Large</option>
  <option>Large Apple</option>
  <option>Large Orange</option>
  <option>Large Tomato</option>
</select>
<!-- md -->
<select className="$$select $$select-bordered w-full max-w-xs">
  <option disabled selected>Normal</option>
  <option>Normal Apple</option>
  <option>Normal Orange</option>
  <option>Normal Tomato</option>
</select>
<!-- sm -->
<select className="$$select $$select-bordered $$select-sm w-full max-w-xs">
  <option disabled selected>Small</option>
  <option>Small Apple</option>
  <option>Small Orange</option>
  <option>Small Tomato</option>
</select>
<!-- xs -->
<select className="$$select $$select-bordered $$select-xs w-full max-w-xs">
  <option disabled selected>Tiny</option>
  <option>Tiny Apple</option>
  <option>Tiny Orange</option>
  <option>Tiny Tomato</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function bt(v){let e,a,r;return{c(){e=u("select"),a=u("option"),r=d("You can't touch this"),this.h()},l(l){e=_(l,"SELECT",{class:!0});var i=f(e);a=_(i,"OPTION",{});var n=f(a);r=h(n,"You can't touch this"),n.forEach(p),i.forEach(p),this.h()},h(){a.__value="You can't touch this",a.value=a.__value,w(e,"class","select w-full max-w-xs"),e.disabled=!0},m(l,i){N(l,e,i),s(e,a),s(a,r)},d(l){l&&p(e)}}}function Nt(v){let e,a=`<select class="$$select w-full max-w-xs" disabled>
  <option>You can't touch this</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","html")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function wt(v){let e,a=`<select className="$$select w-full max-w-xs" disabled>
  <option>You can't touch this</option>
</select>`,r,l,i,n;return{c(){e=u("pre"),r=d(a),this.h()},l(o){e=_(o,"PRE",{slot:!0});var t=f(e);r=h(t,a),t.forEach(p),this.h()},h(){w(e,"slot","react")},m(o,t){N(o,e,t),s(e,r),i||(n=B(l=W.call(null,e,{to:v[0]})),i=!0)},p(o,t){l&&M(l.update)&&t&1&&l.update.call(null,{to:o[0]})},d(o){o&&p(e),i=!1,n()}}}function xt(v){let e,a,r,l,i,n,o,t,E,m,g,$,P,b,T,x,A,S,I,L,k,J,y,D,R,H,C,j;return e=new ze({props:{data:[{type:"component",class:"form-control",desc:"Container element"},{type:"component",class:"label",desc:"For helper text"},{type:"component",class:"select",desc:"For <select> element"},{type:"modifier",class:"select-bordered",desc:"Adds border to select"},{type:"modifier",class:"select-ghost",desc:"Adds ghost style to select"},{type:"modifier",class:"select-primary",desc:"Adds `primary` color to select"},{type:"modifier",class:"select-secondary",desc:"Adds `secondary` color to select"},{type:"modifier",class:"select-accent",desc:"Adds `accent` color to select"},{type:"modifier",class:"select-info",desc:"Adds `info` color to select"},{type:"modifier",class:"select-success",desc:"Adds `success` color to select"},{type:"modifier",class:"select-warning",desc:"Adds `warning` color to select"},{type:"modifier",class:"select-error",desc:"Adds `error` color to select"},{type:"responsive",class:"select-lg",desc:"Large size for select"},{type:"responsive",class:"select-md",desc:"Medium (default) size for select"},{type:"responsive",class:"select-sm",desc:"Small size for select"},{type:"responsive",class:"select-xs",desc:"Extra small size for select"}]}}),r=new se({props:{title:"Select",$$slots:{react:[Ve],html:[He],default:[Ge]},$$scope:{ctx:v}}}),i=new se({props:{title:"Select with border",$$slots:{react:[Ye],html:[je],default:[Fe]},$$scope:{ctx:v}}}),o=new se({props:{title:"Ghost (no background)",$$slots:{react:[Qe],html:[Ke],default:[qe]},$$scope:{ctx:v}}}),E=new se({props:{title:"With form-control and labels",$$slots:{react:[Ze],html:[Xe],default:[Ue]},$$scope:{ctx:v}}}),g=new se({props:{title:"Primary color",$$slots:{react:[ot],html:[tt],default:[et]},$$scope:{ctx:v}}}),P=new se({props:{title:"Secondary color",$$slots:{react:[st],html:[at],default:[lt]},$$scope:{ctx:v}}}),T=new se({props:{title:"Accent color",$$slots:{react:[rt],html:[it],default:[nt]},$$scope:{ctx:v}}}),A=new se({props:{title:"Info color",$$slots:{react:[ut],html:[ct],default:[pt]},$$scope:{ctx:v}}}),I=new se({props:{title:"Success color",$$slots:{react:[dt],html:[ft],default:[_t]},$$scope:{ctx:v}}}),k=new se({props:{title:"Warning color",$$slots:{react:[vt],html:[mt],default:[ht]},$$scope:{ctx:v}}}),y=new se({props:{title:"Error color",$$slots:{react:[Ot],html:[Et],default:[$t]},$$scope:{ctx:v}}}),R=new se({props:{title:"Sizes",$$slots:{react:[Tt],html:[Pt],default:[gt]},$$scope:{ctx:v}}}),C=new se({props:{title:"Disabled",$$slots:{react:[wt],html:[Nt],default:[bt]},$$scope:{ctx:v}}}),{c(){q(e.$$.fragment),a=z(),q(r.$$.fragment),l=z(),q(i.$$.fragment),n=z(),q(o.$$.fragment),t=z(),q(E.$$.fragment),m=z(),q(g.$$.fragment),$=z(),q(P.$$.fragment),b=z(),q(T.$$.fragment),x=z(),q(A.$$.fragment),S=z(),q(I.$$.fragment),L=z(),q(k.$$.fragment),J=z(),q(y.$$.fragment),D=z(),q(R.$$.fragment),H=z(),q(C.$$.fragment)},l(c){K(e.$$.fragment,c),a=G(c),K(r.$$.fragment,c),l=G(c),K(i.$$.fragment,c),n=G(c),K(o.$$.fragment,c),t=G(c),K(E.$$.fragment,c),m=G(c),K(g.$$.fragment,c),$=G(c),K(P.$$.fragment,c),b=G(c),K(T.$$.fragment,c),x=G(c),K(A.$$.fragment,c),S=G(c),K(I.$$.fragment,c),L=G(c),K(k.$$.fragment,c),J=G(c),K(y.$$.fragment,c),D=G(c),K(R.$$.fragment,c),H=G(c),K(C.$$.fragment,c)},m(c,O){Q(e,c,O),N(c,a,O),Q(r,c,O),N(c,l,O),Q(i,c,O),N(c,n,O),Q(o,c,O),N(c,t,O),Q(E,c,O),N(c,m,O),Q(g,c,O),N(c,$,O),Q(P,c,O),N(c,b,O),Q(T,c,O),N(c,x,O),Q(A,c,O),N(c,S,O),Q(I,c,O),N(c,L,O),Q(k,c,O),N(c,J,O),Q(y,c,O),N(c,D,O),Q(R,c,O),N(c,H,O),Q(C,c,O),j=!0},p(c,O){const ne={};O&5&&(ne.$$scope={dirty:O,ctx:c}),r.$set(ne);const Y={};O&5&&(Y.$$scope={dirty:O,ctx:c}),i.$set(Y);const V={};O&5&&(V.$$scope={dirty:O,ctx:c}),o.$set(V);const ee={};O&5&&(ee.$$scope={dirty:O,ctx:c}),E.$set(ee);const te={};O&5&&(te.$$scope={dirty:O,ctx:c}),g.$set(te);const re={};O&5&&(re.$$scope={dirty:O,ctx:c}),P.$set(re);const oe={};O&5&&(oe.$$scope={dirty:O,ctx:c}),T.$set(oe);const pe={};O&5&&(pe.$$scope={dirty:O,ctx:c}),A.$set(pe);const le={};O&5&&(le.$$scope={dirty:O,ctx:c}),I.$set(le);const ce={};O&5&&(ce.$$scope={dirty:O,ctx:c}),k.$set(ce);const ae={};O&5&&(ae.$$scope={dirty:O,ctx:c}),y.$set(ae);const F={};O&5&&(F.$$scope={dirty:O,ctx:c}),R.$set(F);const ie={};O&5&&(ie.$$scope={dirty:O,ctx:c}),C.$set(ie)},i(c){j||(U(e.$$.fragment,c),U(r.$$.fragment,c),U(i.$$.fragment,c),U(o.$$.fragment,c),U(E.$$.fragment,c),U(g.$$.fragment,c),U(P.$$.fragment,c),U(T.$$.fragment,c),U(A.$$.fragment,c),U(I.$$.fragment,c),U(k.$$.fragment,c),U(y.$$.fragment,c),U(R.$$.fragment,c),U(C.$$.fragment,c),j=!0)},o(c){X(e.$$.fragment,c),X(r.$$.fragment,c),X(i.$$.fragment,c),X(o.$$.fragment,c),X(E.$$.fragment,c),X(g.$$.fragment,c),X(P.$$.fragment,c),X(T.$$.fragment,c),X(A.$$.fragment,c),X(I.$$.fragment,c),X(k.$$.fragment,c),X(y.$$.fragment,c),X(R.$$.fragment,c),X(C.$$.fragment,c),j=!1},d(c){Z(e,c),c&&p(a),Z(r,c),c&&p(l),Z(i,c),c&&p(n),Z(o,c),c&&p(t),Z(E,c),c&&p(m),Z(g,c),c&&p($),Z(P,c),c&&p(b),Z(T,c),c&&p(x),Z(A,c),c&&p(S),Z(I,c),c&&p(L),Z(k,c),c&&p(J),Z(y,c),c&&p(D),Z(R,c),c&&p(H),Z(C,c)}}}function St(v){let e,a;const r=[v[1],Le];let l={$$slots:{default:[xt]},$$scope:{ctx:v}};for(let i=0;i<r.length;i+=1)l=de(l,r[i]);return e=new Je({props:l}),{c(){q(e.$$.fragment)},l(i){K(e.$$.fragment,i)},m(i,n){Q(e,i,n),a=!0},p(i,[n]){const o=n&2?Me(r,[n&2&&ke(i[1]),n&0&&ke(Le)]):{};n&5&&(o.$$scope={dirty:n,ctx:i}),e.$set(o)},i(i){a||(U(e.$$.fragment,i),a=!0)},o(i){X(e.$$.fragment,i),a=!1},d(i){Z(e,i)}}}const Le={title:"Select",desc:"Select is used to pick a value from a list of options.",published:!0};function It(v,e,a){let r;return We(v,De,l=>a(0,r=l)),v.$$set=l=>{a(1,e=de(de({},e),ye(l)))},e=ye(e),[r,e]}class Jt extends Ce{constructor(e){super();Re(this,e,It,St,Be,{})}}export{Jt as default,Le as metadata};
