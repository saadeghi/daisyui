import{S as ve,i as ue,s as pe,C as X,w as A,x as B,y as M,z as me,A as oe,q as S,o as q,B as G,K as he,ag as ie,k as I,m as k,g as N,d as n,e as p,t as y,c as m,a as h,h as E,b as u,F as d,a9 as T,Q as R,O as W}from"../../chunks/vendor-3400f70d.js";import{M as fe}from"../../chunks/_markdown-614da4d4.js";import{p as $e,C as _e,a as F,r as Y}from"../../chunks/actions-11148842.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-37f3b597.js";import"../../chunks/index-d78d0d53.js";import"../../chunks/SEO-77e76281.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-1487ba87.js";function ge(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("div"),c=y("1"),r=I(),s=p("div"),o=y("2"),t=I(),a=p("div"),b=y("3"),this.h()},l($){e=m($,"DIV",{});var v=h(e);l=m(v,"DIV",{class:!0});var x=h(l);c=E(x,"1"),x.forEach(n),r=k(v),s=m(v,"DIV",{class:!0});var w=h(s);o=E(w,"2"),w.forEach(n),t=k(v),a=m(v,"DIV",{class:!0});var g=h(a);b=E(g,"3"),g.forEach(n),v.forEach(n),this.h()},h(){u(l,"class","grid w-32 h-20 rounded bg-primary text-primary-content place-content-center"),u(s,"class","grid w-32 h-20 rounded bg-accent text-accent-content place-content-center"),u(a,"class","grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center")},m($,v){N($,e,v),d(e,l),d(l,c),d(e,r),d(e,s),d(s,o),d(e,t),d(e,a),d(a,b)},d($){$&&n(e)}}}function be(f){let e,l=`<div>
  <div class="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div class="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div class="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function we(f){let e,l=`<div>
  <div className="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div className="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div className="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function ye(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("div"),c=y("1"),r=I(),s=p("div"),o=y("2"),t=I(),a=p("div"),b=y("3"),this.h()},l($){e=m($,"DIV",{class:!0});var v=h(e);l=m(v,"DIV",{class:!0});var x=h(l);c=E(x,"1"),x.forEach(n),r=k(v),s=m(v,"DIV",{class:!0});var w=h(s);o=E(w,"2"),w.forEach(n),t=k(v),a=m(v,"DIV",{class:!0});var g=h(a);b=E(g,"3"),g.forEach(n),v.forEach(n),this.h()},h(){u(l,"class","grid w-32 h-20 rounded bg-primary text-primary-content place-content-center"),u(s,"class","grid w-32 h-20 rounded bg-accent text-accent-content place-content-center"),u(a,"class","grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center"),u(e,"class","stack mb-4")},m($,v){N($,e,v),d(e,l),d(l,c),d(e,r),d(e,s),d(s,o),d(e,t),d(e,a),d(a,b)},d($){$&&n(e)}}}function Ee(f){let e,l=`<div class="$$stack">
  <div class="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div class="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div class="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function xe(f){let e,l=`<div className="$$stack">
  <div className="grid w-32 h-20 rounded bg-primary text-primary-content place-content-center">1</div> 
  <div className="grid w-32 h-20 rounded bg-accent text-accent-content place-content-center">2</div> 
  <div className="grid w-32 h-20 rounded bg-secondary text-secondary-content place-content-center">3</div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ne(f){let e,l,c,r,s,o,t,a,b;return{c(){e=p("div"),l=p("img"),r=I(),s=p("img"),t=I(),a=p("img"),this.h()},l($){e=m($,"DIV",{class:!0});var v=h(e);l=m(v,"IMG",{src:!0,alt:!0,class:!0}),r=k(v),s=m(v,"IMG",{src:!0,alt:!0,class:!0}),t=k(v),a=m(v,"IMG",{src:!0,alt:!0,class:!0}),v.forEach(n),this.h()},h(){W(l.src,c="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||u(l,"src",c),u(l,"alt","Image 1"),u(l,"class","rounded w-28"),W(s.src,o="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||u(s,"src",o),u(s,"alt","Image 2"),u(s,"class","rounded w-28"),W(a.src,b="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||u(a,"src",b),u(a,"alt","Image 3"),u(a,"class","rounded w-28"),u(e,"class","stack mb-4")},m($,v){N($,e,v),d(e,l),d(e,r),d(e,s),d(e,t),d(e,a)},d($){$&&n(e)}}}function Ie(f){let e,l=`<div class="$$stack">
  <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Image 1" class="rounded" />
  <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Image 2" class="rounded" />
  <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Image 3" class="rounded" />
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function ke(f){let e,l=`<div className="$$stack">
  <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Image 1" className="rounded" />
  <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Image 2" className="rounded" />
  <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Image 3" className="rounded" />
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function De(f){let e,l,c,r,s,o,t,a,b,$,v,x;return{c(){e=p("div"),l=p("div"),c=p("div"),r=y("A"),s=I(),o=p("div"),t=p("div"),a=y("B"),b=I(),$=p("div"),v=p("div"),x=y("C"),this.h()},l(w){e=m(w,"DIV",{class:!0});var g=h(e);l=m(g,"DIV",{class:!0});var i=h(l);c=m(i,"DIV",{class:!0});var _=h(c);r=E(_,"A"),_.forEach(n),i.forEach(n),s=k(g),o=m(g,"DIV",{class:!0});var C=h(o);t=m(C,"DIV",{class:!0});var V=h(t);a=E(V,"B"),V.forEach(n),C.forEach(n),b=k(g),$=m(g,"DIV",{class:!0});var D=h($);v=m(D,"DIV",{class:!0});var P=h(v);x=E(P,"C"),P.forEach(n),D.forEach(n),g.forEach(n),this.h()},h(){u(c,"class","card-body"),u(l,"class","text-center border border-base-content card w-36 bg-base-100"),u(t,"class","card-body"),u(o,"class","text-center border border-base-content card w-36 bg-base-100"),u(v,"class","card-body"),u($,"class","text-center border border-base-content card w-36 bg-base-100"),u(e,"class","stack mb-4")},m(w,g){N(w,e,g),d(e,l),d(l,c),d(c,r),d(e,s),d(e,o),d(o,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x)},d(w){w&&n(e)}}}function Ve(f){let e,l=`<div class="$$stack">
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">A</div>
  </div> 
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">B</div>
  </div> 
  <div class="text-center border border-base-content $$card w-36 bg-base-100">
    <div class="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Pe(f){let e,l=`<div className="$$stack">
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">A</div>
  </div> 
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">B</div>
  </div> 
  <div className="text-center border border-base-content $$card w-36 bg-base-100">
    <div className="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ce(f){let e,l,c,r,s,o,t,a,b,$,v,x;return{c(){e=p("div"),l=p("div"),c=p("div"),r=y("A"),s=I(),o=p("div"),t=p("div"),a=y("B"),b=I(),$=p("div"),v=p("div"),x=y("C"),this.h()},l(w){e=m(w,"DIV",{class:!0});var g=h(e);l=m(g,"DIV",{class:!0});var i=h(l);c=m(i,"DIV",{class:!0});var _=h(c);r=E(_,"A"),_.forEach(n),i.forEach(n),s=k(g),o=m(g,"DIV",{class:!0});var C=h(o);t=m(C,"DIV",{class:!0});var V=h(t);a=E(V,"B"),V.forEach(n),C.forEach(n),b=k(g),$=m(g,"DIV",{class:!0});var D=h($);v=m(D,"DIV",{class:!0});var P=h(v);x=E(P,"C"),P.forEach(n),D.forEach(n),g.forEach(n),this.h()},h(){u(c,"class","card-body"),u(l,"class","text-center shadow-md w-36 card bg-base-200"),u(t,"class","card-body"),u(o,"class","text-center shadow w-36 card bg-base-200"),u(v,"class","card-body"),u($,"class","text-center shadow-sm w-36 card bg-base-200"),u(e,"class","stack mb-4")},m(w,g){N(w,e,g),d(e,l),d(l,c),d(c,r),d(e,s),d(e,o),d(o,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x)},d(w){w&&n(e)}}}function Te(f){let e,l=`<div class="$$stack">
  <div class="text-center shadow-md w-36 $$card bg-base-200">
    <div class="$$card-body">A</div>
  </div> 
  <div class="text-center shadow w-36 $$card bg-base-200">
    <div class="$$card-body">B</div>
  </div> 
  <div class="text-center shadow-sm w-36 $$card bg-base-200">
    <div class="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Re(f){let e,l=`<div className="$$stack">
  <div className="text-center shadow-md w-36 $$card bg-base-200">
    <div className="$$card-body">A</div>
  </div> 
  <div className="text-center shadow w-36 $$card bg-base-200">
    <div className="$$card-body">B</div>
  </div> 
  <div className="text-center shadow-sm w-36 $$card bg-base-200">
    <div className="$$card-body">C</div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ye(f){let e,l,c,r,s,o,t,a,b,$,v,x,w,g,i,_,C,V,D,P,H,z,K,U;return{c(){e=p("div"),l=p("div"),c=p("div"),r=p("h2"),s=y("Notification 1"),o=I(),t=p("p"),a=y("You have 3 unread messages. Tap here to see."),b=I(),$=p("div"),v=p("div"),x=p("h2"),w=y("Notification 2"),g=I(),i=p("p"),_=y("You have 3 unread messages. Tap here to see."),C=I(),V=p("div"),D=p("div"),P=p("h2"),H=y("Notification 3"),z=I(),K=p("p"),U=y("You have 3 unread messages. Tap here to see."),this.h()},l(O){e=m(O,"DIV",{class:!0});var j=h(e);l=m(j,"DIV",{class:!0});var Z=h(l);c=m(Z,"DIV",{class:!0});var Q=h(c);r=m(Q,"H2",{class:!0});var ee=h(r);s=E(ee,"Notification 1"),ee.forEach(n),o=k(Q),t=m(Q,"P",{});var te=h(t);a=E(te,"You have 3 unread messages. Tap here to see."),te.forEach(n),Q.forEach(n),Z.forEach(n),b=k(j),$=m(j,"DIV",{class:!0});var ae=h($);v=m(ae,"DIV",{class:!0});var J=h(v);x=m(J,"H2",{class:!0});var se=h(x);w=E(se,"Notification 2"),se.forEach(n),g=k(J),i=m(J,"P",{});var re=h(i);_=E(re,"You have 3 unread messages. Tap here to see."),re.forEach(n),J.forEach(n),ae.forEach(n),C=k(j),V=m(j,"DIV",{class:!0});var ce=h(V);D=m(ce,"DIV",{class:!0});var L=h(D);P=m(L,"H2",{class:!0});var le=h(P);H=E(le,"Notification 3"),le.forEach(n),z=k(L),K=m(L,"P",{});var de=h(K);U=E(de,"You have 3 unread messages. Tap here to see."),de.forEach(n),L.forEach(n),ce.forEach(n),j.forEach(n),this.h()},h(){u(r,"class","card-title"),u(c,"class","card-body"),u(l,"class","shadow-md card bg-primary text-primary-content"),u(x,"class","card-title"),u(v,"class","card-body"),u($,"class","shadow card bg-primary text-primary-content"),u(P,"class","card-title"),u(D,"class","card-body"),u(V,"class","shadow-sm card bg-primary text-primary-content"),u(e,"class","stack mb-4")},m(O,j){N(O,e,j),d(e,l),d(l,c),d(c,r),d(r,s),d(c,o),d(c,t),d(t,a),d(e,b),d(e,$),d($,v),d(v,x),d(x,w),d(v,g),d(v,i),d(i,_),d(e,C),d(e,V),d(V,D),d(D,P),d(P,H),d(D,z),d(D,K),d(K,U)},d(O){O&&n(e)}}}function je(f){let e,l=`<div class="$$stack">
  <div class="$$card shadow-md bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 1</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div class="$$card shadow bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 2</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div class="$$card shadow-sm bg-primary text-primary-content">
    <div class="$$card-body">
      <h2 class="$$card-title">Notification 3</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","html")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Ae(f){let e,l=`<div className="$$stack">
  <div className="$$card shadow-md bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 1</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div className="$$card shadow bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 2</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div> 
  <div className="$$card shadow-sm bg-primary text-primary-content">
    <div className="$$card-body">
      <h2 className="$$card-title">Notification 3</h2> 
      <p>You have 3 unread messages. Tap here to see.</p>
    </div>
  </div>
</div>`,c,r,s,o;return{c(){e=p("pre"),c=y(l),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=h(e);c=E(a,l),a.forEach(n),this.h()},h(){u(e,"slot","react")},m(t,a){N(t,e,a),d(e,c),s||(o=T(r=Y.call(null,e,{to:f[0]})),s=!0)},p(t,a){r&&R(r.update)&&a&1&&r.update.call(null,{to:t[0]})},d(t){t&&n(e),s=!1,o()}}}function Be(f){let e,l,c,r,s,o,t,a,b,$,v,x,w,g;return e=new _e({props:{data:[{type:"component",class:"stack",desc:"Puts the child elements on top of each other"}]}}),c=new F({props:{title:"3 divs without stack",$$slots:{react:[we],html:[be],default:[ge]},$$scope:{ctx:f}}}),s=new F({props:{title:"3 divs with stack",$$slots:{react:[xe],html:[Ee],default:[ye]},$$scope:{ctx:f}}}),t=new F({props:{title:"stacked images",$$slots:{react:[ke],html:[Ie],default:[Ne]},$$scope:{ctx:f}}}),b=new F({props:{title:"stacked cards",$$slots:{react:[Pe],html:[Ve],default:[De]},$$scope:{ctx:f}}}),v=new F({props:{title:"stacked cards with shadow",$$slots:{react:[Re],html:[Te],default:[Ce]},$$scope:{ctx:f}}}),w=new F({props:{title:"stacked cards",$$slots:{react:[Ae],html:[je],default:[Ye]},$$scope:{ctx:f}}}),{c(){A(e.$$.fragment),l=I(),A(c.$$.fragment),r=I(),A(s.$$.fragment),o=I(),A(t.$$.fragment),a=I(),A(b.$$.fragment),$=I(),A(v.$$.fragment),x=I(),A(w.$$.fragment)},l(i){B(e.$$.fragment,i),l=k(i),B(c.$$.fragment,i),r=k(i),B(s.$$.fragment,i),o=k(i),B(t.$$.fragment,i),a=k(i),B(b.$$.fragment,i),$=k(i),B(v.$$.fragment,i),x=k(i),B(w.$$.fragment,i)},m(i,_){M(e,i,_),N(i,l,_),M(c,i,_),N(i,r,_),M(s,i,_),N(i,o,_),M(t,i,_),N(i,a,_),M(b,i,_),N(i,$,_),M(v,i,_),N(i,x,_),M(w,i,_),g=!0},p(i,_){const C={};_&5&&(C.$$scope={dirty:_,ctx:i}),c.$set(C);const V={};_&5&&(V.$$scope={dirty:_,ctx:i}),s.$set(V);const D={};_&5&&(D.$$scope={dirty:_,ctx:i}),t.$set(D);const P={};_&5&&(P.$$scope={dirty:_,ctx:i}),b.$set(P);const H={};_&5&&(H.$$scope={dirty:_,ctx:i}),v.$set(H);const z={};_&5&&(z.$$scope={dirty:_,ctx:i}),w.$set(z)},i(i){g||(S(e.$$.fragment,i),S(c.$$.fragment,i),S(s.$$.fragment,i),S(t.$$.fragment,i),S(b.$$.fragment,i),S(v.$$.fragment,i),S(w.$$.fragment,i),g=!0)},o(i){q(e.$$.fragment,i),q(c.$$.fragment,i),q(s.$$.fragment,i),q(t.$$.fragment,i),q(b.$$.fragment,i),q(v.$$.fragment,i),q(w.$$.fragment,i),g=!1},d(i){G(e,i),i&&n(l),G(c,i),i&&n(r),G(s,i),i&&n(o),G(t,i),i&&n(a),G(b,i),i&&n($),G(v,i),i&&n(x),G(w,i)}}}function Me(f){let e,l;const c=[f[1],ne];let r={$$slots:{default:[Be]},$$scope:{ctx:f}};for(let s=0;s<c.length;s+=1)r=X(r,c[s]);return e=new fe({props:r}),{c(){A(e.$$.fragment)},l(s){B(e.$$.fragment,s)},m(s,o){M(e,s,o),l=!0},p(s,[o]){const t=o&2?me(c,[o&2&&oe(s[1]),o&0&&oe(ne)]):{};o&5&&(t.$$scope={dirty:o,ctx:s}),e.$set(t)},i(s){l||(S(e.$$.fragment,s),l=!0)},o(s){q(e.$$.fragment,s),l=!1},d(s){G(e,s)}}}const ne={title:"Stack",desc:"Stack visually puts elements on top of each other.",published:!0};function Se(f,e,l){let c;return he(f,$e,r=>l(0,c=r)),f.$$set=r=>{l(1,e=X(X({},e),ie(r)))},e=ie(e),[c,e]}class Le extends ve{constructor(e){super();ue(this,e,Se,Me,pe,{})}}export{Le as default,ne as metadata};
