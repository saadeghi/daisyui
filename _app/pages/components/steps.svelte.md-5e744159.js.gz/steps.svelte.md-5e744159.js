import{S as vt,i as Et,s as Nt,C as De,w as j,x as B,y as D,z as Lt,A as mt,q as H,o as K,B as Q,K as It,ag as ht,k as N,m as L,g as b,d as p,e as u,t as h,c as f,a as d,h as _,b as $,F as t,a9 as U,Q as F}from"../../chunks/vendor-3400f70d.js";import{M as gt}from"../../chunks/_markdown-b539dab8.js";import{p as St,C as yt,a as ue,r as G}from"../../chunks/actions-bd414169.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-0e0d96c3.js";import"../../chunks/index-4eca3783.js";import"../../chunks/SEO-6e60d120.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-3e80dec4.js";function Pt(g){let e,l,c,i,r,n,s,a,y,R,v,P;return{c(){e=u("ul"),l=u("li"),c=h("Register"),i=N(),r=u("li"),n=h("Choose plan"),s=N(),a=u("li"),y=h("Purchase"),R=N(),v=u("li"),P=h("Receive Product"),this.h()},l(S){e=f(S,"UL",{class:!0});var m=d(e);l=f(m,"LI",{class:!0});var o=d(l);c=_(o,"Register"),o.forEach(p),i=L(m),r=f(m,"LI",{class:!0});var I=d(r);n=_(I,"Choose plan"),I.forEach(p),s=L(m),a=f(m,"LI",{class:!0});var w=d(a);y=_(w,"Purchase"),w.forEach(p),R=L(m),v=f(m,"LI",{class:!0});var C=d(v);P=_(C,"Receive Product"),C.forEach(p),m.forEach(p),this.h()},h(){$(l,"class","step step-primary"),$(r,"class","step step-primary"),$(a,"class","step"),$(v,"class","step"),$(e,"class","steps")},m(S,m){b(S,e,m),t(e,l),t(l,c),t(e,i),t(e,r),t(r,n),t(e,s),t(e,a),t(a,y),t(e,R),t(e,v),t(v,P)},d(S){S&&p(e)}}}function Rt(g){let e,l=`<ul class="$$steps">
  <li class="$$step $$step-primary">Register</li>
  <li class="$$step $$step-primary">Choose plan</li>
  <li class="$$step">Purchase</li>
  <li class="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function wt(g){let e,l=`<ul className="$$steps">
  <li className="$$step $$step-primary">Register</li>
  <li className="$$step $$step-primary">Choose plan</li>
  <li className="$$step">Purchase</li>
  <li className="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Ct(g){let e,l,c,i,r,n,s,a,y,R,v,P;return{c(){e=u("ul"),l=u("li"),c=h("Register"),i=N(),r=u("li"),n=h("Choose plan"),s=N(),a=u("li"),y=h("Purchase"),R=N(),v=u("li"),P=h("Receive Product"),this.h()},l(S){e=f(S,"UL",{class:!0});var m=d(e);l=f(m,"LI",{class:!0});var o=d(l);c=_(o,"Register"),o.forEach(p),i=L(m),r=f(m,"LI",{class:!0});var I=d(r);n=_(I,"Choose plan"),I.forEach(p),s=L(m),a=f(m,"LI",{class:!0});var w=d(a);y=_(w,"Purchase"),w.forEach(p),R=L(m),v=f(m,"LI",{class:!0});var C=d(v);P=_(C,"Receive Product"),C.forEach(p),m.forEach(p),this.h()},h(){$(l,"class","step step-primary"),$(r,"class","step step-primary"),$(a,"class","step"),$(v,"class","step"),$(e,"class","steps steps-vertical")},m(S,m){b(S,e,m),t(e,l),t(l,c),t(e,i),t(e,r),t(r,n),t(e,s),t(e,a),t(a,y),t(e,R),t(e,v),t(v,P)},d(S){S&&p(e)}}}function bt(g){let e,l=`<ul class="$$steps $$steps-vertical">
  <li class="$$step $$step-primary">Register</li>
  <li class="$$step $$step-primary">Choose plan</li>
  <li class="$$step">Purchase</li>
  <li class="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function xt(g){let e,l=`<ul className="$$steps $$steps-vertical">
  <li className="$$step $$step-primary">Register</li>
  <li className="$$step $$step-primary">Choose plan</li>
  <li className="$$step">Purchase</li>
  <li className="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function At(g){let e,l,c,i,r,n,s,a,y,R,v,P;return{c(){e=u("ul"),l=u("li"),c=h("Register"),i=N(),r=u("li"),n=h("Choose plan"),s=N(),a=u("li"),y=h("Purchase"),R=N(),v=u("li"),P=h("Receive Product"),this.h()},l(S){e=f(S,"UL",{class:!0});var m=d(e);l=f(m,"LI",{class:!0});var o=d(l);c=_(o,"Register"),o.forEach(p),i=L(m),r=f(m,"LI",{class:!0});var I=d(r);n=_(I,"Choose plan"),I.forEach(p),s=L(m),a=f(m,"LI",{class:!0});var w=d(a);y=_(w,"Purchase"),w.forEach(p),R=L(m),v=f(m,"LI",{class:!0});var C=d(v);P=_(C,"Receive Product"),C.forEach(p),m.forEach(p),this.h()},h(){$(l,"class","step step-primary"),$(r,"class","step step-primary"),$(a,"class","step"),$(v,"class","step"),$(e,"class","steps steps-vertical lg:steps-horizontal")},m(S,m){b(S,e,m),t(e,l),t(l,c),t(e,i),t(e,r),t(r,n),t(e,s),t(e,a),t(a,y),t(e,R),t(e,v),t(v,P)},d(S){S&&p(e)}}}function kt(g){let e,l=`<ul class="$$steps $$steps-vertical lg:$$steps-horizontal">
  <li class="$$step $$step-primary">Register</li>
  <li class="$$step $$step-primary">Choose plan</li>
  <li class="$$step">Purchase</li>
  <li class="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function zt(g){let e,l=`<ul className="$$steps $$steps-vertical lg:$$steps-horizontal">
  <li className="$$step $$step-primary">Register</li>
  <li className="$$step $$step-primary">Choose plan</li>
  <li className="$$step">Purchase</li>
  <li className="$$step">Receive Product</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Ut(g){let e,l,c,i,r,n,s,a,y,R,v,P,S,m,o,I,w,C,q,A,k;return{c(){e=u("ul"),l=u("li"),c=h("Step 1"),i=N(),r=u("li"),n=h("Step 2"),s=N(),a=u("li"),y=h("Step 3"),R=N(),v=u("li"),P=h("Step 4"),S=N(),m=u("li"),o=h("Step 5"),I=N(),w=u("li"),C=h("Step 6"),q=N(),A=u("li"),k=h("Step 7"),this.h()},l(z){e=f(z,"UL",{class:!0});var x=d(e);l=f(x,"LI",{"data-content":!0,class:!0});var M=d(l);c=_(M,"Step 1"),M.forEach(p),i=L(x),r=f(x,"LI",{"data-content":!0,class:!0});var T=d(r);n=_(T,"Step 2"),T.forEach(p),s=L(x),a=f(x,"LI",{"data-content":!0,class:!0});var J=d(a);y=_(J,"Step 3"),J.forEach(p),R=L(x),v=f(x,"LI",{"data-content":!0,class:!0});var V=d(v);P=_(V,"Step 4"),V.forEach(p),S=L(x),m=f(x,"LI",{"data-content":!0,class:!0});var O=d(m);o=_(O,"Step 5"),O.forEach(p),I=L(x),w=f(x,"LI",{"data-content":!0,class:!0});var X=d(w);C=_(X,"Step 6"),X.forEach(p),q=L(x),A=f(x,"LI",{"data-content":!0,class:!0});var W=d(A);k=_(W,"Step 7"),W.forEach(p),x.forEach(p),this.h()},h(){$(l,"data-content","?"),$(l,"class","step step-neutral"),$(r,"data-content","!"),$(r,"class","step step-neutral"),$(a,"data-content","\u2713"),$(a,"class","step step-neutral"),$(v,"data-content","\u2715"),$(v,"class","step step-neutral"),$(m,"data-content","\u2605"),$(m,"class","step step-neutral"),$(w,"data-content",""),$(w,"class","step step-neutral"),$(A,"data-content","\u25CF"),$(A,"class","step step-neutral"),$(e,"class","steps")},m(z,x){b(z,e,x),t(e,l),t(l,c),t(e,i),t(e,r),t(r,n),t(e,s),t(e,a),t(a,y),t(e,R),t(e,v),t(v,P),t(e,S),t(e,m),t(m,o),t(e,I),t(e,w),t(w,C),t(e,q),t(e,A),t(A,k)},d(z){z&&p(e)}}}function Ft(g){let e,l=`<ul class="$$steps">
  <li data-content="?" class="$$step $$step-neutral">Step 1</li>
  <li data-content="!" class="$$step $$step-neutral">Step 2</li>
  <li data-content="\u2713" class="$$step $$step-neutral">Step 3</li>
  <li data-content="\u2715" class="$$step $$step-neutral">Step 4</li>
  <li data-content="\u2605" class="$$step $$step-neutral">Step 5</li>
  <li data-content="" class="$$step $$step-neutral">Step 6</li>
  <li data-content="\u25CF" class="$$step $$step-neutral">Step 7</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Gt(g){let e,l=`<ul className="$$steps">
  <li data-content="?" className="$$step $$step-neutral">Step 1</li>
  <li data-content="!" className="$$step $$step-neutral">Step 2</li>
  <li data-content="\u2713" className="$$step $$step-neutral">Step 3</li>
  <li data-content="\u2715" className="$$step $$step-neutral">Step 4</li>
  <li data-content="\u2605" className="$$step $$step-neutral">Step 5</li>
  <li data-content="" className="$$step $$step-neutral">Step 6</li>
  <li data-content="\u25CF" className="$$step $$step-neutral">Step 7</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function qt(g){let e,l,c,i,r,n,s,a,y,R,v,P;return{c(){e=u("ul"),l=u("li"),c=h("Fly to moon"),i=N(),r=u("li"),n=h("Shrink the moon"),s=N(),a=u("li"),y=h("Grab the moon"),R=N(),v=u("li"),P=h("Sit on toilet"),this.h()},l(S){e=f(S,"UL",{class:!0});var m=d(e);l=f(m,"LI",{class:!0});var o=d(l);c=_(o,"Fly to moon"),o.forEach(p),i=L(m),r=f(m,"LI",{class:!0});var I=d(r);n=_(I,"Shrink the moon"),I.forEach(p),s=L(m),a=f(m,"LI",{class:!0});var w=d(a);y=_(w,"Grab the moon"),w.forEach(p),R=L(m),v=f(m,"LI",{"data-content":!0,class:!0});var C=d(v);P=_(C,"Sit on toilet"),C.forEach(p),m.forEach(p),this.h()},h(){$(l,"class","step step-info"),$(r,"class","step step-info"),$(a,"class","step step-info"),$(v,"data-content","?"),$(v,"class","step step-error"),$(e,"class","steps")},m(S,m){b(S,e,m),t(e,l),t(l,c),t(e,i),t(e,r),t(r,n),t(e,s),t(e,a),t(a,y),t(e,R),t(e,v),t(v,P)},d(S){S&&p(e)}}}function Mt(g){let e,l=`<ul class="$$steps">
  <li class="$$step $$step-info">Fly to moon</li>
  <li class="$$step $$step-info">Shrink the moon</li>
  <li class="$$step $$step-info">Grab the moon</li>
  <li class="$$step $$step-error" data-content="?">Sit on toilet</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Vt(g){let e,l=`<ul className="$$steps">
  <li className="$$step $$step-info">Fly to moon</li>
  <li className="$$step $$step-info">Shrink the moon</li>
  <li className="$$step $$step-info">Grab the moon</li>
  <li className="$$step $$step-error" data-content="?">Sit on toilet</li>
</ul>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Wt(g){let e,l,c,i,r,n,s,a,y,R,v,P,S,m,o,I,w,C,q,A,k,z,x,M,T,J,V,O,X,W,me,he,Y,_e,ve,Z,Ee,Ne,ee,Le,Ie,te,ge,Se,le,ye,Pe,se,Re,we,ae,Ce,be,re,xe,Ae,ie,ke,ze,ce,Ue,Fe,pe,Ge,qe,oe,Me,Ve,ne,We,je,$e,Be;return{c(){e=u("div"),l=u("ul"),c=u("li"),i=h("start"),r=N(),n=u("li"),s=h("2"),a=N(),y=u("li"),R=h("3"),v=N(),P=u("li"),S=h("4"),m=N(),o=u("li"),I=h("5"),w=N(),C=u("li"),q=h("6"),A=N(),k=u("li"),z=h("7"),x=N(),M=u("li"),T=h("8"),J=N(),V=u("li"),O=h("9"),X=N(),W=u("li"),me=h("10"),he=N(),Y=u("li"),_e=h("11"),ve=N(),Z=u("li"),Ee=h("12"),Ne=N(),ee=u("li"),Le=h("13"),Ie=N(),te=u("li"),ge=h("14"),Se=N(),le=u("li"),ye=h("15"),Pe=N(),se=u("li"),Re=h("16"),we=N(),ae=u("li"),Ce=h("17"),be=N(),re=u("li"),xe=h("18"),Ae=N(),ie=u("li"),ke=h("19"),ze=N(),ce=u("li"),Ue=h("20"),Fe=N(),pe=u("li"),Ge=h("21"),qe=N(),oe=u("li"),Me=h("22"),Ve=N(),ne=u("li"),We=h("23"),je=N(),$e=u("li"),Be=h("end"),this.h()},l(fe){e=f(fe,"DIV",{class:!0});var de=d(e);l=f(de,"UL",{class:!0});var E=d(l);c=f(E,"LI",{class:!0});var He=d(c);i=_(He,"start"),He.forEach(p),r=L(E),n=f(E,"LI",{class:!0});var Ke=d(n);s=_(Ke,"2"),Ke.forEach(p),a=L(E),y=f(E,"LI",{class:!0});var Qe=d(y);R=_(Qe,"3"),Qe.forEach(p),v=L(E),P=f(E,"LI",{class:!0});var Te=d(P);S=_(Te,"4"),Te.forEach(p),m=L(E),o=f(E,"LI",{class:!0});var Je=d(o);I=_(Je,"5"),Je.forEach(p),w=L(E),C=f(E,"LI",{class:!0});var Oe=d(C);q=_(Oe,"6"),Oe.forEach(p),A=L(E),k=f(E,"LI",{class:!0});var Xe=d(k);z=_(Xe,"7"),Xe.forEach(p),x=L(E),M=f(E,"LI",{class:!0});var Ye=d(M);T=_(Ye,"8"),Ye.forEach(p),J=L(E),V=f(E,"LI",{class:!0});var Ze=d(V);O=_(Ze,"9"),Ze.forEach(p),X=L(E),W=f(E,"LI",{class:!0});var et=d(W);me=_(et,"10"),et.forEach(p),he=L(E),Y=f(E,"LI",{class:!0});var tt=d(Y);_e=_(tt,"11"),tt.forEach(p),ve=L(E),Z=f(E,"LI",{class:!0});var lt=d(Z);Ee=_(lt,"12"),lt.forEach(p),Ne=L(E),ee=f(E,"LI",{class:!0});var st=d(ee);Le=_(st,"13"),st.forEach(p),Ie=L(E),te=f(E,"LI",{class:!0});var at=d(te);ge=_(at,"14"),at.forEach(p),Se=L(E),le=f(E,"LI",{class:!0});var rt=d(le);ye=_(rt,"15"),rt.forEach(p),Pe=L(E),se=f(E,"LI",{class:!0});var it=d(se);Re=_(it,"16"),it.forEach(p),we=L(E),ae=f(E,"LI",{class:!0});var ct=d(ae);Ce=_(ct,"17"),ct.forEach(p),be=L(E),re=f(E,"LI",{class:!0});var pt=d(re);xe=_(pt,"18"),pt.forEach(p),Ae=L(E),ie=f(E,"LI",{class:!0});var ot=d(ie);ke=_(ot,"19"),ot.forEach(p),ze=L(E),ce=f(E,"LI",{class:!0});var nt=d(ce);Ue=_(nt,"20"),nt.forEach(p),Fe=L(E),pe=f(E,"LI",{class:!0});var $t=d(pe);Ge=_($t,"21"),$t.forEach(p),qe=L(E),oe=f(E,"LI",{class:!0});var ut=d(oe);Me=_(ut,"22"),ut.forEach(p),Ve=L(E),ne=f(E,"LI",{class:!0});var ft=d(ne);We=_(ft,"23"),ft.forEach(p),je=L(E),$e=f(E,"LI",{class:!0});var dt=d($e);Be=_(dt,"end"),dt.forEach(p),E.forEach(p),de.forEach(p),this.h()},h(){$(c,"class","step"),$(n,"class","step step-secondary"),$(y,"class","step step-secondary"),$(P,"class","step step-secondary"),$(o,"class","step"),$(C,"class","step step-accent"),$(k,"class","step step-accent"),$(M,"class","step"),$(V,"class","step step-error"),$(W,"class","step step-error"),$(Y,"class","step"),$(Z,"class","step"),$(ee,"class","step step-warning"),$(te,"class","step step-warning"),$(le,"class","step"),$(se,"class","step step-neutral"),$(ae,"class","step step-neutral"),$(re,"class","step step-neutral"),$(ie,"class","step step-neutral"),$(ce,"class","step step-neutral"),$(pe,"class","step step-neutral"),$(oe,"class","step step-neutral"),$(ne,"class","step step-neutral"),$($e,"class","step step-neutral"),$(l,"class","steps"),$(e,"class","overflow-x-auto")},m(fe,de){b(fe,e,de),t(e,l),t(l,c),t(c,i),t(l,r),t(l,n),t(n,s),t(l,a),t(l,y),t(y,R),t(l,v),t(l,P),t(P,S),t(l,m),t(l,o),t(o,I),t(l,w),t(l,C),t(C,q),t(l,A),t(l,k),t(k,z),t(l,x),t(l,M),t(M,T),t(l,J),t(l,V),t(V,O),t(l,X),t(l,W),t(W,me),t(l,he),t(l,Y),t(Y,_e),t(l,ve),t(l,Z),t(Z,Ee),t(l,Ne),t(l,ee),t(ee,Le),t(l,Ie),t(l,te),t(te,ge),t(l,Se),t(l,le),t(le,ye),t(l,Pe),t(l,se),t(se,Re),t(l,we),t(l,ae),t(ae,Ce),t(l,be),t(l,re),t(re,xe),t(l,Ae),t(l,ie),t(ie,ke),t(l,ze),t(l,ce),t(ce,Ue),t(l,Fe),t(l,pe),t(pe,Ge),t(l,qe),t(l,oe),t(oe,Me),t(l,Ve),t(l,ne),t(ne,We),t(l,je),t(l,$e),t($e,Be)},d(fe){fe&&p(e)}}}function jt(g){let e,l=`<div class="overflow-x-auto">
  <ul class="$$steps">
    <li class="$$step">start</li>
    <li class="$$step $$step-secondary">2</li>
    <li class="$$step $$step-secondary">3</li>
    <li class="$$step $$step-secondary">4</li>
    <li class="$$step">5</li>
    <li class="$$step $$step-accent">6</li>
    <li class="$$step $$step-accent">7</li>
    <li class="$$step">8</li>
    <li class="$$step $$step-error">9</li>
    <li class="$$step $$step-error">10</li>
    <li class="$$step">11</li>
    <li class="$$step">12</li>
    <li class="$$step $$step-warning">13</li>
    <li class="$$step $$step-warning">14</li>
    <li class="$$step">15</li>
    <li class="$$step $$step-neutral">16</li>
    <li class="$$step $$step-neutral">17</li>
    <li class="$$step $$step-neutral">18</li>
    <li class="$$step $$step-neutral">19</li>
    <li class="$$step $$step-neutral">20</li>
    <li class="$$step $$step-neutral">21</li>
    <li class="$$step $$step-neutral">22</li>
    <li class="$$step $$step-neutral">23</li>
    <li class="$$step $$step-neutral">end</li>
  </ul>
</div>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","html")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Bt(g){let e,l=`<div className="overflow-x-auto">
  <ul className="$$steps">
    <li className="$$step">start</li>
    <li className="$$step $$step-secondary">2</li>
    <li className="$$step $$step-secondary">3</li>
    <li className="$$step $$step-secondary">4</li>
    <li className="$$step">5</li>
    <li className="$$step $$step-accent">6</li>
    <li className="$$step $$step-accent">7</li>
    <li className="$$step">8</li>
    <li className="$$step $$step-error">9</li>
    <li className="$$step $$step-error">10</li>
    <li className="$$step">11</li>
    <li className="$$step">12</li>
    <li className="$$step $$step-warning">13</li>
    <li className="$$step $$step-warning">14</li>
    <li className="$$step">15</li>
    <li className="$$step $$step-neutral">16</li>
    <li className="$$step $$step-neutral">17</li>
    <li className="$$step $$step-neutral">18</li>
    <li className="$$step $$step-neutral">19</li>
    <li className="$$step $$step-neutral">20</li>
    <li className="$$step $$step-neutral">21</li>
    <li className="$$step $$step-neutral">22</li>
    <li className="$$step $$step-neutral">23</li>
    <li className="$$step $$step-neutral">end</li>
  </ul>
</div>`,c,i,r,n;return{c(){e=u("pre"),c=h(l),this.h()},l(s){e=f(s,"PRE",{slot:!0});var a=d(e);c=_(a,l),a.forEach(p),this.h()},h(){$(e,"slot","react")},m(s,a){b(s,e,a),t(e,c),r||(n=U(i=G.call(null,e,{to:g[0]})),r=!0)},p(s,a){i&&F(i.update)&&a&1&&i.update.call(null,{to:s[0]})},d(s){s&&p(e),r=!1,n()}}}function Dt(g){let e,l,c,i,r,n,s,a,y,R,v,P,S,m;return e=new yt({props:{data:[{type:"component",class:"steps",desc:"Container of step items"},{type:"component",class:"step",desc:"A step item"},{type:"modifier",class:"step-primary",desc:"Adds `primary` color to step"},{type:"modifier",class:"step-secondary",desc:"Adds `secondary` color to step"},{type:"modifier",class:"step-accent",desc:"Adds `accent` color to step"},{type:"modifier",class:"step-info",desc:"Adds `info` color to step"},{type:"modifier",class:"step-success",desc:"Adds `success` color to step"},{type:"modifier",class:"step-warning",desc:"Adds `warning` color to step"},{type:"modifier",class:"step-error",desc:"Adds `error` color to step"},{type:"responsive",class:"steps-vertical",desc:"makes `steps` vertical"},{type:"responsive",class:"steps-horizontal",desc:"makes `steps` horizontal"}]}}),c=new ue({props:{title:"Horizontal",$$slots:{react:[wt],html:[Rt],default:[Pt]},$$scope:{ctx:g}}}),r=new ue({props:{title:"Vertical",$$slots:{react:[xt],html:[bt],default:[Ct]},$$scope:{ctx:g}}}),s=new ue({props:{title:"responsive (vertical on small screen, horizontal on large screen)",$$slots:{react:[zt],html:[kt],default:[At]},$$scope:{ctx:g}}}),y=new ue({props:{title:"With data-content",$$slots:{react:[Gt],html:[Ft],default:[Ut]},$$scope:{ctx:g}}}),v=new ue({props:{title:"Custom colors",$$slots:{react:[Vt],html:[Mt],default:[qt]},$$scope:{ctx:g}}}),S=new ue({props:{title:"With scrollable wrapper",$$slots:{react:[Bt],html:[jt],default:[Wt]},$$scope:{ctx:g}}}),{c(){j(e.$$.fragment),l=N(),j(c.$$.fragment),i=N(),j(r.$$.fragment),n=N(),j(s.$$.fragment),a=N(),j(y.$$.fragment),R=N(),j(v.$$.fragment),P=N(),j(S.$$.fragment)},l(o){B(e.$$.fragment,o),l=L(o),B(c.$$.fragment,o),i=L(o),B(r.$$.fragment,o),n=L(o),B(s.$$.fragment,o),a=L(o),B(y.$$.fragment,o),R=L(o),B(v.$$.fragment,o),P=L(o),B(S.$$.fragment,o)},m(o,I){D(e,o,I),b(o,l,I),D(c,o,I),b(o,i,I),D(r,o,I),b(o,n,I),D(s,o,I),b(o,a,I),D(y,o,I),b(o,R,I),D(v,o,I),b(o,P,I),D(S,o,I),m=!0},p(o,I){const w={};I&5&&(w.$$scope={dirty:I,ctx:o}),c.$set(w);const C={};I&5&&(C.$$scope={dirty:I,ctx:o}),r.$set(C);const q={};I&5&&(q.$$scope={dirty:I,ctx:o}),s.$set(q);const A={};I&5&&(A.$$scope={dirty:I,ctx:o}),y.$set(A);const k={};I&5&&(k.$$scope={dirty:I,ctx:o}),v.$set(k);const z={};I&5&&(z.$$scope={dirty:I,ctx:o}),S.$set(z)},i(o){m||(H(e.$$.fragment,o),H(c.$$.fragment,o),H(r.$$.fragment,o),H(s.$$.fragment,o),H(y.$$.fragment,o),H(v.$$.fragment,o),H(S.$$.fragment,o),m=!0)},o(o){K(e.$$.fragment,o),K(c.$$.fragment,o),K(r.$$.fragment,o),K(s.$$.fragment,o),K(y.$$.fragment,o),K(v.$$.fragment,o),K(S.$$.fragment,o),m=!1},d(o){Q(e,o),o&&p(l),Q(c,o),o&&p(i),Q(r,o),o&&p(n),Q(s,o),o&&p(a),Q(y,o),o&&p(R),Q(v,o),o&&p(P),Q(S,o)}}}function Ht(g){let e,l;const c=[g[1],_t];let i={$$slots:{default:[Dt]},$$scope:{ctx:g}};for(let r=0;r<c.length;r+=1)i=De(i,c[r]);return e=new gt({props:i}),{c(){j(e.$$.fragment)},l(r){B(e.$$.fragment,r)},m(r,n){D(e,r,n),l=!0},p(r,[n]){const s=n&2?Lt(c,[n&2&&mt(r[1]),n&0&&mt(_t)]):{};n&5&&(s.$$scope={dirty:n,ctx:r}),e.$set(s)},i(r){l||(H(e.$$.fragment,r),l=!0)},o(r){K(e.$$.fragment,r),l=!1},d(r){Q(e,r)}}}const _t={title:"Steps",desc:"Steps can be used to show a list of steps in a process.",published:!0};function Kt(g,e,l){let c;return It(g,St,i=>l(0,c=i)),g.$$set=i=>{l(1,e=De(De({},e),ht(i)))},e=ht(e),[c,e]}class ll extends vt{constructor(e){super();Et(this,e,Kt,Ht,Nt,{})}}export{ll as default,_t as metadata};
