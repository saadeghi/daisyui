import{S as ea,i as ta,s as sa,w as B,k as T,x as H,m as M,y as j,g as w,q as F,o as L,B as Q,d as l,J as la,e as n,c as p,a as f,N as G,b as r,H as u,t as K,h as O,a1 as W,P as Y}from"../../chunks/vendor-df54b326.js";import{C as ia,a as U,r as Z}from"../../chunks/actions-3c65db6c.js";import{p as ra}from"../../chunks/PrefixEdit-657e5948.js";import"../../chunks/preload-helper-ec9aa979.js";function ca(b){let a,c,i,v;return{c(){a=n("div"),c=n("div"),i=n("img"),this.h()},l(d){a=p(d,"DIV",{class:!0});var o=f(a);c=p(o,"DIV",{class:!0});var e=f(c);i=p(e,"IMG",{src:!0,alt:!0}),e.forEach(l),o.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=75101")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 rounded bg-base-300"),r(a,"class","avatar")},m(d,o){w(d,a,o),u(a,c),u(c,i)},d(d){d&&l(a)}}}function oa(b){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="https://api.lorem.space/image/face?hash=92048">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function va(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x,I,V,S,A,C;return{c(){a=n("div"),c=n("div"),i=n("img"),d=T(),o=n("div"),e=n("div"),s=n("img"),_=T(),$=n("div"),E=n("div"),g=n("img"),I=T(),V=n("div"),S=n("div"),A=n("img"),this.h()},l(h){a=p(h,"DIV",{class:!0});var t=f(a);c=p(t,"DIV",{class:!0});var m=f(c);i=p(m,"IMG",{src:!0,alt:!0}),m.forEach(l),t.forEach(l),d=M(h),o=p(h,"DIV",{class:!0});var P=f(o);e=p(P,"DIV",{class:!0});var k=f(e);s=p(k,"IMG",{src:!0,alt:!0}),k.forEach(l),P.forEach(l),_=M(h),$=p(h,"DIV",{class:!0});var R=f($);E=p(R,"DIV",{class:!0});var N=f(E);g=p(N,"IMG",{src:!0,alt:!0}),N.forEach(l),R.forEach(l),I=M(h),V=p(h,"DIV",{class:!0});var q=f(V);S=p(q,"DIV",{class:!0});var J=f(S);A=p(J,"IMG",{src:!0,alt:!0}),J.forEach(l),q.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=71470")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 rounded bg-base-300"),r(a,"class","avatar"),G(s.src,D="https://api.lorem.space/image/face?hash=88712")||r(s,"src",D),r(s,"alt","Tailwind-CSS-Avatar-component"),r(e,"class","w-16 rounded bg-base-300"),r(o,"class","avatar"),G(g.src,x="https://api.lorem.space/image/face?hash=15164")||r(g,"src",x),r(g,"alt","Tailwind-CSS-Avatar-component"),r(E,"class","w-12 rounded bg-base-300"),r($,"class","avatar"),G(A.src,C="https://api.lorem.space/image/face?hash=79498")||r(A,"src",C),r(A,"alt","Tailwind-CSS-Avatar-component"),r(S,"class","w-8 rounded bg-base-300"),r(V,"class","avatar")},m(h,t){w(h,a,t),u(a,c),u(c,i),w(h,d,t),w(h,o,t),u(o,e),u(e,s),w(h,_,t),w(h,$,t),u($,E),u(E,g),w(h,I,t),w(h,V,t),u(V,S),u(S,A)},d(h){h&&l(a),h&&l(d),h&&l(o),h&&l(_),h&&l($),h&&l(I),h&&l(V)}}}function da(b){let a,c=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="https://api.lorem.space/image/face?hash=88560">
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="https://api.lorem.space/image/face?hash=80245" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="https://api.lorem.space/image/face?hash=77703" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="https://api.lorem.space/image/face?hash=33791" alt="Tailwind-CSS-Avatar-component">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function na(b){let a,c,i,v,d,o,e,s,D;return{c(){a=n("div"),c=n("div"),i=n("img"),d=T(),o=n("div"),e=n("div"),s=n("img"),this.h()},l(_){a=p(_,"DIV",{class:!0});var $=f(a);c=p($,"DIV",{class:!0});var E=f(c);i=p(E,"IMG",{src:!0,alt:!0}),E.forEach(l),$.forEach(l),d=M(_),o=p(_,"DIV",{class:!0});var g=f(o);e=p(g,"DIV",{class:!0});var x=f(e);s=p(x,"IMG",{src:!0,alt:!0}),x.forEach(l),g.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=71060")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 rounded-xl bg-base-300"),r(a,"class","avatar"),G(s.src,D="https://api.lorem.space/image/face?hash=70084")||r(s,"src",D),r(s,"alt","Tailwind-CSS-Avatar-component"),r(e,"class","w-24 rounded-full bg-base-300"),r(o,"class","avatar")},m(_,$){w(_,a,$),u(a,c),u(c,i),w(_,d,$),w(_,o,$),u(o,e),u(e,s)},d(_){_&&l(a),_&&l(d),_&&l(o)}}}function pa(b){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="https://api.lorem.space/image/face?hash=64318">
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=92310">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function ua(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x;return{c(){a=n("div"),c=n("div"),i=n("img"),d=T(),o=n("div"),e=n("div"),s=n("img"),_=T(),$=n("div"),E=n("div"),g=n("img"),this.h()},l(I){a=p(I,"DIV",{class:!0});var V=f(a);c=p(V,"DIV",{class:!0});var S=f(c);i=p(S,"IMG",{src:!0,alt:!0}),S.forEach(l),V.forEach(l),d=M(I),o=p(I,"DIV",{class:!0});var A=f(o);e=p(A,"DIV",{class:!0});var C=f(e);s=p(C,"IMG",{src:!0,alt:!0}),C.forEach(l),A.forEach(l),_=M(I),$=p(I,"DIV",{class:!0});var h=f($);E=p(h,"DIV",{class:!0});var t=f(E);g=p(t,"IMG",{src:!0,alt:!0}),t.forEach(l),h.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=8877")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 mask mask-squircle bg-base-300"),r(a,"class","avatar"),G(s.src,D="https://api.lorem.space/image/face?hash=79960")||r(s,"src",D),r(s,"alt","Tailwind-CSS-Avatar-component"),r(e,"class","w-24 mask mask-hexagon bg-base-300"),r(o,"class","avatar"),G(g.src,x="https://api.lorem.space/image/face?hash=70860")||r(g,"src",x),r(g,"alt","Tailwind-CSS-Avatar-component"),r(E,"class","w-24 mask mask-triangle bg-base-300"),r($,"class","avatar")},m(I,V){w(I,a,V),u(a,c),u(c,i),w(I,d,V),w(I,o,V),u(o,e),u(e,s),w(I,_,V),w(I,$,V),u($,E),u(E,g)},d(I){I&&l(a),I&&l(d),I&&l(o),I&&l(_),I&&l($)}}}function ma(b){let a,c=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="https://api.lorem.space/image/face?hash=47449">
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="https://api.lorem.space/image/face?hash=55350">
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="https://api.lorem.space/image/face?hash=60857">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function fa(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x,I,V,S,A,C,h;return{c(){a=n("div"),c=n("div"),i=n("div"),v=n("img"),o=T(),e=n("div"),s=n("div"),D=n("img"),$=T(),E=n("div"),g=n("div"),x=n("img"),V=T(),S=n("div"),A=n("div"),C=n("img"),this.h()},l(t){a=p(t,"DIV",{class:!0});var m=f(a);c=p(m,"DIV",{class:!0});var P=f(c);i=p(P,"DIV",{class:!0});var k=f(i);v=p(k,"IMG",{src:!0,alt:!0}),k.forEach(l),P.forEach(l),o=M(m),e=p(m,"DIV",{class:!0});var R=f(e);s=p(R,"DIV",{class:!0});var N=f(s);D=p(N,"IMG",{src:!0,alt:!0}),N.forEach(l),R.forEach(l),$=M(m),E=p(m,"DIV",{class:!0});var q=f(E);g=p(q,"DIV",{class:!0});var J=f(g);x=p(J,"IMG",{src:!0,alt:!0}),J.forEach(l),q.forEach(l),V=M(m),S=p(m,"DIV",{class:!0});var X=f(S);A=p(X,"DIV",{class:!0});var z=f(A);C=p(z,"IMG",{src:!0,alt:!0}),z.forEach(l),X.forEach(l),m.forEach(l),this.h()},h(){G(v.src,d="https://api.lorem.space/image/face?hash=11722")||r(v,"src",d),r(v,"alt","Tailwind-CSS-Avatar-component"),r(i,"class","w-12 bg-base-300"),r(c,"class","avatar"),G(D.src,_="https://api.lorem.space/image/face?hash=75704")||r(D,"src",_),r(D,"alt","Tailwind-CSS-Avatar-component"),r(s,"class","w-12 bg-base-300"),r(e,"class","avatar"),G(x.src,I="https://api.lorem.space/image/face?hash=86780")||r(x,"src",I),r(x,"alt","Tailwind-CSS-Avatar-component"),r(g,"class","w-12 bg-base-300"),r(E,"class","avatar"),G(C.src,h="https://api.lorem.space/image/face?hash=92365")||r(C,"src",h),r(C,"alt","Tailwind-CSS-Avatar-component"),r(A,"class","w-12 bg-base-300"),r(S,"class","avatar"),r(a,"class","avatar-group -space-x-6")},m(t,m){w(t,a,m),u(a,c),u(c,i),u(i,v),u(a,o),u(a,e),u(e,s),u(s,D),u(a,$),u(a,E),u(E,g),u(g,x),u(a,V),u(a,S),u(S,A),u(A,C)},d(t){t&&l(a)}}}function ha(b){let a,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=53273">
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=91831">
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=27312">
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=26448">
    </div>
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function $a(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x,I,V,S,A,C,h;return{c(){a=n("div"),c=n("div"),i=n("div"),v=n("img"),o=T(),e=n("div"),s=n("div"),D=n("img"),$=T(),E=n("div"),g=n("div"),x=n("img"),V=T(),S=n("div"),A=n("div"),C=n("span"),h=K("+99"),this.h()},l(t){a=p(t,"DIV",{class:!0});var m=f(a);c=p(m,"DIV",{class:!0});var P=f(c);i=p(P,"DIV",{class:!0});var k=f(i);v=p(k,"IMG",{src:!0,alt:!0}),k.forEach(l),P.forEach(l),o=M(m),e=p(m,"DIV",{class:!0});var R=f(e);s=p(R,"DIV",{class:!0});var N=f(s);D=p(N,"IMG",{src:!0,alt:!0}),N.forEach(l),R.forEach(l),$=M(m),E=p(m,"DIV",{class:!0});var q=f(E);g=p(q,"DIV",{class:!0});var J=f(g);x=p(J,"IMG",{src:!0,alt:!0}),J.forEach(l),q.forEach(l),V=M(m),S=p(m,"DIV",{class:!0});var X=f(S);A=p(X,"DIV",{class:!0});var z=f(A);C=p(z,"SPAN",{});var y=f(C);h=O(y,"+99"),y.forEach(l),z.forEach(l),X.forEach(l),m.forEach(l),this.h()},h(){G(v.src,d="https://api.lorem.space/image/face?hash=71251")||r(v,"src",d),r(v,"alt","Tailwind-CSS-Avatar-component"),r(i,"class","w-12 bg-base-300"),r(c,"class","avatar"),G(D.src,_="https://api.lorem.space/image/face?hash=58372")||r(D,"src",_),r(D,"alt","Tailwind-CSS-Avatar-component"),r(s,"class","w-12 bg-base-300"),r(e,"class","avatar"),G(x.src,I="https://api.lorem.space/image/face?hash=26576")||r(x,"src",I),r(x,"alt","Tailwind-CSS-Avatar-component"),r(g,"class","w-12 bg-base-300"),r(E,"class","avatar"),r(A,"class","w-12 bg-neutral-focus text-neutral-content"),r(S,"class","avatar placeholder"),r(a,"class","avatar-group -space-x-6")},m(t,m){w(t,a,m),u(a,c),u(c,i),u(i,v),u(a,o),u(a,e),u(e,s),u(s,D),u(a,$),u(a,E),u(E,g),u(g,x),u(a,V),u(a,S),u(S,A),u(A,C),u(C,h)},d(t){t&&l(a)}}}function _a(b){let a,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=4818">
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=40311">
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="https://api.lorem.space/image/face?hash=84348">
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function ga(b){let a,c,i,v;return{c(){a=n("div"),c=n("div"),i=n("img"),this.h()},l(d){a=p(d,"DIV",{class:!0});var o=f(a);c=p(o,"DIV",{class:!0});var e=f(c);i=p(e,"IMG",{src:!0,alt:!0}),e.forEach(l),o.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=558")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"),r(a,"class","avatar")},m(d,o){w(d,a,o),u(a,c),u(c,i)},d(d){d&&l(a)}}}function wa(b){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="https://api.lorem.space/image/face?hash=3174">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function Ea(b){let a,c,i,v,d,o,e,s,D;return{c(){a=n("div"),c=n("div"),i=n("img"),d=T(),o=n("div"),e=n("div"),s=n("img"),this.h()},l(_){a=p(_,"DIV",{class:!0});var $=f(a);c=p($,"DIV",{class:!0});var E=f(c);i=p(E,"IMG",{src:!0,alt:!0}),E.forEach(l),$.forEach(l),d=M(_),o=p(_,"DIV",{class:!0});var g=f(o);e=p(g,"DIV",{class:!0});var x=f(e);s=p(x,"IMG",{src:!0,alt:!0}),x.forEach(l),g.forEach(l),this.h()},h(){G(i.src,v="https://api.lorem.space/image/face?hash=67053")||r(i,"src",v),r(i,"alt","Tailwind-CSS-Avatar-component"),r(c,"class","w-24 rounded-full bg-base-300"),r(a,"class","avatar online"),G(s.src,D="https://api.lorem.space/image/face?hash=92699")||r(s,"src",D),r(s,"alt","Tailwind-CSS-Avatar-component"),r(e,"class","w-24 rounded-full bg-base-300"),r(o,"class","avatar offline")},m(_,$){w(_,a,$),u(a,c),u(c,i),w(_,d,$),w(_,o,$),u(o,e),u(e,s)},d(_){_&&l(a),_&&l(d),_&&l(o)}}}function Ia(b){let a,c=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=28212">
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="https://api.lorem.space/image/face?hash=40361">
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function ba(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x,I,V,S,A,C;return{c(){a=n("div"),c=n("div"),i=n("span"),v=K("K"),d=T(),o=n("div"),e=n("div"),s=n("span"),D=K("JO"),_=T(),$=n("div"),E=n("div"),g=n("span"),x=K("MX"),I=T(),V=n("div"),S=n("div"),A=n("span"),C=K("AA"),this.h()},l(h){a=p(h,"DIV",{class:!0});var t=f(a);c=p(t,"DIV",{class:!0});var m=f(c);i=p(m,"SPAN",{class:!0});var P=f(i);v=O(P,"K"),P.forEach(l),m.forEach(l),t.forEach(l),d=M(h),o=p(h,"DIV",{class:!0});var k=f(o);e=p(k,"DIV",{class:!0});var R=f(e);s=p(R,"SPAN",{class:!0});var N=f(s);D=O(N,"JO"),N.forEach(l),R.forEach(l),k.forEach(l),_=M(h),$=p(h,"DIV",{class:!0});var q=f($);E=p(q,"DIV",{class:!0});var J=f(E);g=p(J,"SPAN",{});var X=f(g);x=O(X,"MX"),X.forEach(l),J.forEach(l),q.forEach(l),I=M(h),V=p(h,"DIV",{class:!0});var z=f(V);S=p(z,"DIV",{class:!0});var y=f(S);A=p(y,"SPAN",{class:!0});var aa=f(A);C=O(aa,"AA"),aa.forEach(l),y.forEach(l),z.forEach(l),this.h()},h(){r(i,"class","text-3xl"),r(c,"class","bg-neutral-focus text-neutral-content rounded-full w-24"),r(a,"class","avatar placeholder"),r(s,"class","text-xl"),r(e,"class","bg-neutral-focus text-neutral-content rounded-full w-16"),r(o,"class","avatar online placeholder"),r(E,"class","bg-neutral-focus text-neutral-content rounded-full w-12"),r($,"class","avatar placeholder"),r(A,"class","text-xs"),r(S,"class","bg-neutral-focus text-neutral-content rounded-full w-8"),r(V,"class","avatar placeholder")},m(h,t){w(h,a,t),u(a,c),u(c,i),u(i,v),w(h,d,t),w(h,o,t),u(o,e),u(e,s),u(s,D),w(h,_,t),w(h,$,t),u($,E),u(E,g),u(g,x),w(h,I,t),w(h,V,t),u(V,S),u(S,A),u(A,C)},d(h){h&&l(a),h&&l(d),h&&l(o),h&&l(_),h&&l($),h&&l(I),h&&l(V)}}}function Sa(b){let a,c=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,i,v,d,o;return{c(){a=n("pre"),i=K(c),this.h()},l(e){a=p(e,"PRE",{slot:!0});var s=f(a);i=O(s,c),s.forEach(l),this.h()},h(){r(a,"slot","html")},m(e,s){w(e,a,s),u(a,i),d||(o=W(v=Z.call(null,a,{to:b[0]})),d=!0)},p(e,s){v&&Y(v.update)&&s&1&&v.update.call(null,{to:e[0]})},d(e){e&&l(a),d=!1,o()}}}function Da(b){let a,c,i,v,d,o,e,s,D,_,$,E,g,x,I,V,S,A,C,h;return a=new ia({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as online indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),i=new U({props:{title:"Avatar",$$slots:{html:[oa],default:[ca]},$$scope:{ctx:b}}}),d=new U({props:{title:"Avatar in custom sizes",$$slots:{html:[da],default:[va]},$$scope:{ctx:b}}}),e=new U({props:{title:"Avatar rounded",$$slots:{html:[pa],default:[na]},$$scope:{ctx:b}}}),D=new U({props:{title:"Avatar with mask",$$slots:{html:[ma],default:[ua]},$$scope:{ctx:b}}}),$=new U({props:{title:"Avatar group",$$slots:{html:[ha],default:[fa]},$$scope:{ctx:b}}}),g=new U({props:{title:"Avatar group with counter",$$slots:{html:[_a],default:[$a]},$$scope:{ctx:b}}}),I=new U({props:{title:"Avatar with ring",$$slots:{html:[wa],default:[ga]},$$scope:{ctx:b}}}),S=new U({props:{title:"Avatar with presence indicator",$$slots:{html:[Ia],default:[Ea]},$$scope:{ctx:b}}}),C=new U({props:{title:"Avatar placeholder",$$slots:{html:[Sa],default:[ba]},$$scope:{ctx:b}}}),{c(){B(a.$$.fragment),c=T(),B(i.$$.fragment),v=T(),B(d.$$.fragment),o=T(),B(e.$$.fragment),s=T(),B(D.$$.fragment),_=T(),B($.$$.fragment),E=T(),B(g.$$.fragment),x=T(),B(I.$$.fragment),V=T(),B(S.$$.fragment),A=T(),B(C.$$.fragment)},l(t){H(a.$$.fragment,t),c=M(t),H(i.$$.fragment,t),v=M(t),H(d.$$.fragment,t),o=M(t),H(e.$$.fragment,t),s=M(t),H(D.$$.fragment,t),_=M(t),H($.$$.fragment,t),E=M(t),H(g.$$.fragment,t),x=M(t),H(I.$$.fragment,t),V=M(t),H(S.$$.fragment,t),A=M(t),H(C.$$.fragment,t)},m(t,m){j(a,t,m),w(t,c,m),j(i,t,m),w(t,v,m),j(d,t,m),w(t,o,m),j(e,t,m),w(t,s,m),j(D,t,m),w(t,_,m),j($,t,m),w(t,E,m),j(g,t,m),w(t,x,m),j(I,t,m),w(t,V,m),j(S,t,m),w(t,A,m),j(C,t,m),h=!0},p(t,[m]){const P={};m&3&&(P.$$scope={dirty:m,ctx:t}),i.$set(P);const k={};m&3&&(k.$$scope={dirty:m,ctx:t}),d.$set(k);const R={};m&3&&(R.$$scope={dirty:m,ctx:t}),e.$set(R);const N={};m&3&&(N.$$scope={dirty:m,ctx:t}),D.$set(N);const q={};m&3&&(q.$$scope={dirty:m,ctx:t}),$.$set(q);const J={};m&3&&(J.$$scope={dirty:m,ctx:t}),g.$set(J);const X={};m&3&&(X.$$scope={dirty:m,ctx:t}),I.$set(X);const z={};m&3&&(z.$$scope={dirty:m,ctx:t}),S.$set(z);const y={};m&3&&(y.$$scope={dirty:m,ctx:t}),C.$set(y)},i(t){h||(F(a.$$.fragment,t),F(i.$$.fragment,t),F(d.$$.fragment,t),F(e.$$.fragment,t),F(D.$$.fragment,t),F($.$$.fragment,t),F(g.$$.fragment,t),F(I.$$.fragment,t),F(S.$$.fragment,t),F(C.$$.fragment,t),h=!0)},o(t){L(a.$$.fragment,t),L(i.$$.fragment,t),L(d.$$.fragment,t),L(e.$$.fragment,t),L(D.$$.fragment,t),L($.$$.fragment,t),L(g.$$.fragment,t),L(I.$$.fragment,t),L(S.$$.fragment,t),L(C.$$.fragment,t),h=!1},d(t){Q(a,t),t&&l(c),Q(i,t),t&&l(v),Q(d,t),t&&l(o),Q(e,t),t&&l(s),Q(D,t),t&&l(_),Q($,t),t&&l(E),Q(g,t),t&&l(x),Q(I,t),t&&l(V),Q(S,t),t&&l(A),Q(C,t)}}}const Ma={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0};function Va(b,a,c){let i;return la(b,ra,v=>c(0,i=v)),[i]}class Ga extends ea{constructor(a){super();ta(this,a,Va,Da,sa,{})}}export{Ga as default,Ma as metadata};
