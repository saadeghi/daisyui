import{S as lt,i as ot,s as pt,C as tt,w as B,x as F,y as K,z as ct,A as st,q as O,o as W,B as G,K as ut,v as rt,ag as nt,e as f,t as S,k as R,c as d,a as i,h as b,d as p,m as k,g as N,F as c,f as P,b as h,a9 as Q,j as U,W as X}from"../../chunks/vendor-c5cb7521.js";import{M as ft}from"../../chunks/_markdown-ff23e93a.js";import{p as dt,C as it,a as H,r as Z}from"../../chunks/actions-e5102403.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-bceec4f6.js";import"../../chunks/index-4bc55944.js";import"../../chunks/SEO-65c840d7.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-df5a8365.js";function vt(v){let t,s;return{c(){t=f("span"),s=f("span"),this.h()},l(a){t=d(a,"SPAN",{class:!0});var l=i(t);s=d(l,"SPAN",{style:!0}),i(s).forEach(p),l.forEach(p),this.h()},h(){P(s,"--value",v[0]),h(t,"class","countdown")},m(a,l){N(a,t,l),c(t,s)},p(a,l){l&1&&P(s,"--value",a[0])},d(a){a&&p(t)}}}function mt(v){let t,s=`<span class="$$countdown">
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown">
  <span style="--value:${e[0]};"></span>
</span>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function $t(v){let t,s;return{c(){t=f("span"),s=f("span"),this.h()},l(a){t=d(a,"SPAN",{class:!0});var l=i(t);s=d(l,"SPAN",{style:!0}),i(s).forEach(p),l.forEach(p),this.h()},h(){P(s,"--value",v[0]),h(t,"class","countdown font-mono text-6xl")},m(a,l){N(a,t,l),c(t,s)},p(a,l){l&1&&P(s,"--value",a[0])},d(a){a&&p(t)}}}function xt(v){let t,s=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${e[0]};"></span>
</span>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function ht(v){let t,s,a,l,u,r,e;return{c(){t=f("span"),s=f("span"),a=S(`h
  `),l=f("span"),u=S(`m
  `),r=f("span"),e=S("s"),this.h()},l(n){t=d(n,"SPAN",{class:!0});var x=i(t);s=d(x,"SPAN",{style:!0}),i(s).forEach(p),a=b(x,`h
  `),l=d(x,"SPAN",{style:!0}),i(l).forEach(p),u=b(x,`m
  `),r=d(x,"SPAN",{style:!0}),i(r).forEach(p),e=b(x,"s"),x.forEach(p),this.h()},h(){P(s,"--value","10"),P(l,"--value","24"),P(r,"--value",v[0]),h(t,"class","font-mono text-2xl countdown")},m(n,x){N(n,t,x),c(t,s),c(t,a),c(t,l),c(t,u),c(t,r),c(t,e)},p(n,x){x&1&&P(r,"--value",n[0])},d(n){n&&p(t)}}}function _t(v){let t,s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${v[0]};"></span>s
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${e[0]};"></span>s
</span>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function wt(v){let t,s,a,l,u,r;return{c(){t=f("span"),s=f("span"),a=S(`:
  `),l=f("span"),u=S(`:
  `),r=f("span"),this.h()},l(e){t=d(e,"SPAN",{class:!0});var n=i(t);s=d(n,"SPAN",{style:!0}),i(s).forEach(p),a=b(n,`:
  `),l=d(n,"SPAN",{style:!0}),i(l).forEach(p),u=b(n,`:
  `),r=d(n,"SPAN",{style:!0}),i(r).forEach(p),n.forEach(p),this.h()},h(){P(s,"--value","10"),P(l,"--value","24"),P(r,"--value",v[0]),h(t,"class","font-mono text-2xl countdown")},m(e,n){N(e,t,n),c(t,s),c(t,a),c(t,l),c(t,u),c(t,r)},p(e,n){n&1&&P(r,"--value",e[0])},d(e){e&&p(t)}}}function Et(v){let t,s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${e[0]};"></span>
</span>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function gt(v){let t,s,a,l,u,r,e,n,x,L,D,y,E,V,I,M,w,A,g,T;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),L=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    minutes`),M=R(),w=f("div"),A=f("span"),g=f("span"),T=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{});var C=i(e);n=d(C,"SPAN",{class:!0});var J=i(n);x=d(J,"SPAN",{style:!0}),i(x).forEach(p),J.forEach(p),L=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{});var j=i(y);E=d(j,"SPAN",{class:!0});var Y=i(E);V=d(Y,"SPAN",{style:!0}),i(V).forEach(p),Y.forEach(p),I=b(j,`
    minutes`),j.forEach(p),M=k($),w=d($,"DIV",{});var q=i(w);A=d(q,"SPAN",{class:!0});var z=i(A);g=d(z,"SPAN",{style:!0}),i(g).forEach(p),z.forEach(p),T=b(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-4xl countdown"),P(x,"--value","10"),h(n,"class","font-mono text-4xl countdown"),P(V,"--value","24"),h(E,"class","font-mono text-4xl countdown"),P(g,"--value",v[0]),h(A,"class","font-mono text-4xl countdown"),h(t,"class","flex gap-5")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,L),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,M),c(t,w),c(w,A),c(A,g),c(w,T)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function yt(v){let t,s=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function Pt(v){let t,s,a,l,u,r,e,n,x,L,D,y,E,V,I,M,w,A,g,T;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),L=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    min`),M=R(),w=f("div"),A=f("span"),g=f("span"),T=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{class:!0});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{class:!0});var C=i(e);n=d(C,"SPAN",{class:!0});var J=i(n);x=d(J,"SPAN",{style:!0}),i(x).forEach(p),J.forEach(p),L=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{class:!0});var j=i(y);E=d(j,"SPAN",{class:!0});var Y=i(E);V=d(Y,"SPAN",{style:!0}),i(V).forEach(p),Y.forEach(p),I=b(j,`
    min`),j.forEach(p),M=k($),w=d($,"DIV",{class:!0});var q=i(w);A=d(q,"SPAN",{class:!0});var z=i(A);g=d(z,"SPAN",{style:!0}),i(g).forEach(p),z.forEach(p),T=b(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(s,"class","flex flex-col"),P(x,"--value","10"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(y,"class","flex flex-col"),P(g,"--value",v[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,L),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,M),c(t,w),c(w,A),c(A,g),c(w,T)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function St(v){let t,s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function bt(v){let t,s,a,l,u,r,e,n,x,L,D,y,E,V,I,M,w,A,g,T;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),L=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    min`),M=R(),w=f("div"),A=f("span"),g=f("span"),T=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{class:!0});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{class:!0});var C=i(e);n=d(C,"SPAN",{class:!0});var J=i(n);x=d(J,"SPAN",{style:!0}),i(x).forEach(p),J.forEach(p),L=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{class:!0});var j=i(y);E=d(j,"SPAN",{class:!0});var Y=i(E);V=d(Y,"SPAN",{style:!0}),i(V).forEach(p),Y.forEach(p),I=b(j,`
    min`),j.forEach(p),M=k($),w=d($,"DIV",{class:!0});var q=i(w);A=d(q,"SPAN",{class:!0});var z=i(A);g=d(z,"SPAN",{style:!0}),i(g).forEach(p),z.forEach(p),T=b(q,`
    sec`),q.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(s,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(x,"--value","10"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(y,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(g,"--value",v[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,L),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,M),c(t,w),c(w,A),c(A,g),c(w,T)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function At(v){let t,s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=Q(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&U(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function Nt(v){let t,s,a,l,u,r,e,n,x,L,D,y,E,V,I,M,w,A,g,T,_,$;return e=new it({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),x=new H({props:{title:"Countdown",$$slots:{html:[mt],default:[vt]},$$scope:{ctx:v}}}),D=new H({props:{title:"Large text",$$slots:{html:[xt],default:[$t]},$$scope:{ctx:v}}}),E=new H({props:{title:"Clock countdown",$$slots:{html:[_t],default:[ht]},$$scope:{ctx:v}}}),I=new H({props:{title:"Clock countdown with colons",$$slots:{html:[Et],default:[wt]},$$scope:{ctx:v}}}),w=new H({props:{title:"Large text with labels",$$slots:{html:[yt],default:[gt]},$$scope:{ctx:v}}}),g=new H({props:{title:"Large text with labels under",$$slots:{html:[St],default:[Pt]},$$scope:{ctx:v}}}),_=new H({props:{title:"In boxes",$$slots:{html:[At],default:[bt]},$$scope:{ctx:v}}}),{c(){t=f("p"),s=S("You need to change to "),a=f("code"),l=S("--value"),u=S(" CSS variable using JS. Value must be a number between 0 and 99"),r=R(),B(e.$$.fragment),n=R(),B(x.$$.fragment),L=R(),B(D.$$.fragment),y=R(),B(E.$$.fragment),V=R(),B(I.$$.fragment),M=R(),B(w.$$.fragment),A=R(),B(g.$$.fragment),T=R(),B(_.$$.fragment)},l(o){t=d(o,"P",{});var m=i(t);s=b(m,"You need to change to "),a=d(m,"CODE",{});var C=i(a);l=b(C,"--value"),C.forEach(p),u=b(m," CSS variable using JS. Value must be a number between 0 and 99"),m.forEach(p),r=k(o),F(e.$$.fragment,o),n=k(o),F(x.$$.fragment,o),L=k(o),F(D.$$.fragment,o),y=k(o),F(E.$$.fragment,o),V=k(o),F(I.$$.fragment,o),M=k(o),F(w.$$.fragment,o),A=k(o),F(g.$$.fragment,o),T=k(o),F(_.$$.fragment,o)},m(o,m){N(o,t,m),c(t,s),c(t,a),c(a,l),c(t,u),N(o,r,m),K(e,o,m),N(o,n,m),K(x,o,m),N(o,L,m),K(D,o,m),N(o,y,m),K(E,o,m),N(o,V,m),K(I,o,m),N(o,M,m),K(w,o,m),N(o,A,m),K(g,o,m),N(o,T,m),K(_,o,m),$=!0},p(o,m){const C={};m&19&&(C.$$scope={dirty:m,ctx:o}),x.$set(C);const J={};m&19&&(J.$$scope={dirty:m,ctx:o}),D.$set(J);const j={};m&19&&(j.$$scope={dirty:m,ctx:o}),E.$set(j);const Y={};m&19&&(Y.$$scope={dirty:m,ctx:o}),I.$set(Y);const q={};m&19&&(q.$$scope={dirty:m,ctx:o}),w.$set(q);const z={};m&19&&(z.$$scope={dirty:m,ctx:o}),g.$set(z);const et={};m&19&&(et.$$scope={dirty:m,ctx:o}),_.$set(et)},i(o){$||(O(e.$$.fragment,o),O(x.$$.fragment,o),O(D.$$.fragment,o),O(E.$$.fragment,o),O(I.$$.fragment,o),O(w.$$.fragment,o),O(g.$$.fragment,o),O(_.$$.fragment,o),$=!0)},o(o){W(e.$$.fragment,o),W(x.$$.fragment,o),W(D.$$.fragment,o),W(E.$$.fragment,o),W(I.$$.fragment,o),W(w.$$.fragment,o),W(g.$$.fragment,o),W(_.$$.fragment,o),$=!1},d(o){o&&p(t),o&&p(r),G(e,o),o&&p(n),G(x,o),o&&p(L),G(D,o),o&&p(y),G(E,o),o&&p(V),G(I,o),o&&p(M),G(w,o),o&&p(A),G(g,o),o&&p(T),G(_,o)}}}function Vt(v){let t,s;const a=[v[2],at];let l={$$slots:{default:[Nt]},$$scope:{ctx:v}};for(let u=0;u<a.length;u+=1)l=tt(l,a[u]);return t=new ft({props:l}),{c(){B(t.$$.fragment)},l(u){F(t.$$.fragment,u)},m(u,r){K(t,u,r),s=!0},p(u,[r]){const e=r&4?ct(a,[r&4&&st(u[2]),r&0&&st(at)]):{};r&19&&(e.$$scope={dirty:r,ctx:u}),t.$set(e)},i(u){s||(O(t.$$.fragment,u),s=!0)},o(u){W(t.$$.fragment,u),s=!1},d(u){G(t,u)}}}const at={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers",published:!0};function Dt(v,t,s){let a;ut(v,dt,r=>s(1,a=r));let l=59;function u(){l>0?(s(0,l--,l),setTimeout(u,1e3)):(s(0,l=59),setTimeout(u,1e3))}return rt(()=>{u()}),v.$$set=r=>{s(2,t=tt(tt({},t),nt(r)))},t=nt(t),[l,a,t]}class Jt extends lt{constructor(t){super();ot(this,t,Dt,Vt,pt,{})}}export{Jt as default,at as metadata};
