import{S as be,i as _e,s as ge,C as Z,w as H,x as L,y as W,z as we,A as pe,q as F,o as O,B as A,K as Ee,ag as fe,k as C,m as D,g as S,d,e as h,t as N,c as u,a as f,h as I,O as X,b as p,H as i,a9 as U,Q as M,F as $e,G as ve}from"../../chunks/vendor-40028f80.js";import{M as ye}from"../../chunks/_markdown-9efdc8c6.js";import{p as Ne,C as Ie,a as q,r as G}from"../../chunks/actions-fd84554f.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-72a0f3b6.js";import"../../chunks/index-78663a61.js";import"../../chunks/SEO-4b3b2a73.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-b1943c0a.js";function ke(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("Shoes!"),g=C(),m=h("p"),j=N("If a dog chews shoes whose shoes does he choose?"),y=C(),$=h("div"),b=h("button"),k=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"If a dog chews shoes whose shoes does he choose?"),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Buy Now"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function je(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function xe(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Se(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("Shoes!"),g=C(),m=h("p"),j=N("If a dog chews shoes whose shoes does he choose?"),y=C(),$=h("div"),b=h("button"),k=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"If a dog chews shoes whose shoes does he choose?"),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Buy Now"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 card-compact shadow-xl")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function Ce(v){let e,l=`<div class="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function De(v){let e,l=`<div className="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Pe(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k,w,_,P,E,R;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N(`Shoes!
      `),g=h("div"),m=N("NEW"),j=C(),y=h("p"),$=N("If a dog chews shoes whose shoes does he choose?"),b=C(),k=h("div"),w=h("div"),_=N("Fashion"),P=C(),E=h("div"),R=N("Products"),this.h()},l(B){e=u(B,"DIV",{class:!0});var V=f(e);l=u(V,"FIGURE",{});var T=f(l);a=u(T,"IMG",{src:!0,alt:!0}),T.forEach(d),c=D(V),o=u(V,"DIV",{class:!0});var z=f(o);t=u(z,"H2",{class:!0});var J=f(t);s=I(J,`Shoes!
      `),g=u(J,"DIV",{class:!0});var Y=f(g);m=I(Y,"NEW"),Y.forEach(d),J.forEach(d),j=D(z),y=u(z,"P",{});var K=f(y);$=I(K,"If a dog chews shoes whose shoes does he choose?"),K.forEach(d),b=D(z),k=u(z,"DIV",{class:!0});var Q=f(k);w=u(Q,"DIV",{class:!0});var n=f(w);_=I(n,"Fashion"),n.forEach(d),P=D(Q),E=u(Q,"DIV",{class:!0});var x=f(E);R=I(x,"Products"),x.forEach(d),Q.forEach(d),z.forEach(d),V.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","Shoes"),p(g,"class","badge badge-secondary"),p(t,"class","card-title"),p(w,"class","badge badge-outline"),p(E,"class","badge badge-outline"),p(k,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(B,V){S(B,e,V),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(t,g),i(g,m),i(o,j),i(o,y),i(y,$),i(o,b),i(o,k),i(k,w),i(w,_),i(k,P),i(k,E),i(E,R)},d(B){B&&d(e)}}}function Be(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">
      Shoes!
      <div class="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <div class="$$badge $$badge-outline">Fashion</div> 
      <div class="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Ve(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">
      Shoes!
      <div className="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <div className="$$badge $$badge-outline">Fashion</div> 
      <div className="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Re(v){let e,l,a,r,c,o,t,s,g,m,j;return{c(){e=h("div"),l=h("div"),a=h("h2"),r=N("Shoes!"),c=C(),o=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=C(),g=h("figure"),m=h("img"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);l=u($,"DIV",{class:!0});var b=f(l);a=u(b,"H2",{class:!0});var k=f(a);r=I(k,"Shoes!"),k.forEach(d),c=D(b),o=u(b,"P",{});var w=f(o);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),b.forEach(d),s=D($),g=u($,"FIGURE",{});var _=f(g);m=u(_,"IMG",{src:!0,alt:!0}),_.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(l,"class","card-body"),X(m.src,j="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(m,"src",j),p(m,"alt","Shoes"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(y,$){S(y,e,$),i(e,l),i(l,a),i(a,r),i(l,c),i(l,o),i(o,t),i(e,s),i(e,g),i(g,m)},d(y){y&&d(e)}}}function Te(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Ue(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Me(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("Shoes!"),g=C(),m=h("p"),j=N("If a dog chews shoes whose shoes does he choose?"),y=C(),$=h("div"),b=h("button"),k=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{class:!0});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0,class:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"If a dog chews shoes whose shoes does he choose?"),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Buy Now"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","Shoes"),p(a,"class","rounded-xl"),p(l,"class","px-10 pt-10"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","card-actions"),p(o,"class","card-body items-center text-center"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function Ge(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure class="px-10 pt-10">
    <img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" class="rounded-xl" />
  </figure>
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function He(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure className="px-10 pt-10">
    <img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" className="rounded-xl" />
  </figure>
  <div className="$$card-body items-center text-center">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Le(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("Shoes!"),g=C(),m=h("p"),j=N("If a dog chews shoes whose shoes does he choose?"),y=C(),$=h("div"),b=h("button"),k=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"If a dog chews shoes whose shoes does he choose?"),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Buy Now"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl image-full")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function We(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Fe(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Oe(v){let e,l,a,r,c,o,t,s,g,m,j;return{c(){e=h("div"),l=h("div"),a=h("h2"),r=N("Card title!"),c=C(),o=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=C(),g=h("div"),m=h("button"),j=N("Buy Now"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);l=u($,"DIV",{class:!0});var b=f(l);a=u(b,"H2",{class:!0});var k=f(a);r=I(k,"Card title!"),k.forEach(d),c=D(b),o=u(b,"P",{});var w=f(o);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),s=D(b),g=u(b,"DIV",{class:!0});var _=f(g);m=u(_,"BUTTON",{class:!0});var P=f(m);j=I(P,"Buy Now"),P.forEach(d),_.forEach(d),b.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(m,"class","btn btn-primary"),p(g,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(y,$){S(y,e,$),i(e,l),i(l,a),i(a,r),i(l,c),i(l,o),i(o,t),i(l,s),i(l,g),i(g,m),i(m,j)},d(y){y&&d(e)}}}function Ae(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function qe(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <h2 className="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Je(v){let e,l,a,r,c,o,t,s,g,m,j;return{c(){e=h("div"),l=h("div"),a=h("h2"),r=N("Card title!"),c=C(),o=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=C(),g=h("div"),m=h("button"),j=N("Buy Now"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);l=u($,"DIV",{class:!0});var b=f(l);a=u(b,"H2",{class:!0});var k=f(a);r=I(k,"Card title!"),k.forEach(d),c=D(b),o=u(b,"P",{});var w=f(o);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),s=D(b),g=u(b,"DIV",{class:!0});var _=f(g);m=u(_,"BUTTON",{class:!0});var P=f(m);j=I(P,"Buy Now"),P.forEach(d),_.forEach(d),b.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(m,"class","btn"),p(g,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-primary text-primary-content")},m(y,$){S(y,e,$),i(e,l),i(l,a),i(a,r),i(l,c),i(l,o),i(o,t),i(l,s),i(l,g),i(g,m),i(m,j)},d(y){y&&d(e)}}}function ze(v){let e,l=`<div class="$$card w-96 bg-primary text-primary-content">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Ke(v){let e,l=`<div className="$$card w-96 bg-primary text-primary-content">
  <div className="$$card-body">
    <h2 className="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Qe(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b;return{c(){e=h("div"),l=h("div"),a=h("h2"),r=N("Cookies!"),c=C(),o=h("p"),t=N("We are using cookies for no reason."),s=C(),g=h("div"),m=h("button"),j=N("Accept"),y=C(),$=h("button"),b=N("Deny"),this.h()},l(k){e=u(k,"DIV",{class:!0});var w=f(e);l=u(w,"DIV",{class:!0});var _=f(l);a=u(_,"H2",{class:!0});var P=f(a);r=I(P,"Cookies!"),P.forEach(d),c=D(_),o=u(_,"P",{});var E=f(o);t=I(E,"We are using cookies for no reason."),E.forEach(d),s=D(_),g=u(_,"DIV",{class:!0});var R=f(g);m=u(R,"BUTTON",{class:!0});var B=f(m);j=I(B,"Accept"),B.forEach(d),y=D(R),$=u(R,"BUTTON",{class:!0});var V=f($);b=I(V,"Deny"),V.forEach(d),R.forEach(d),_.forEach(d),w.forEach(d),this.h()},h(){p(a,"class","card-title"),p(m,"class","btn btn-primary"),p($,"class","btn btn-ghost"),p(g,"class","justify-end card-actions"),p(l,"class","card-body items-center text-center"),p(e,"class","card w-96 bg-neutral text-neutral-content")},m(k,w){S(k,e,w),i(e,l),i(l,a),i(a,r),i(l,c),i(l,o),i(o,t),i(l,s),i(l,g),i(g,m),i(m,j),i(g,y),i(g,$),i($,b)},d(k){k&&d(e)}}}function Xe(v){let e,l=`<div class="$$card w-96 bg-neutral text-neutral-content">
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Accept</button>
      <button class="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Ye(v){let e,l=`<div className="$$card w-96 bg-neutral text-neutral-content">
  <div className="$$card-body items-center text-center">
    <h2 className="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Accept</button>
      <button className="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function Ze(v){let e,l,a,r,c,o,t,s,g;return{c(){e=h("div"),l=h("div"),a=h("div"),r=h("button"),c=$e("svg"),o=$e("path"),t=C(),s=h("p"),g=N("We are using cookies for no reason."),this.h()},l(m){e=u(m,"DIV",{class:!0});var j=f(e);l=u(j,"DIV",{class:!0});var y=f(l);a=u(y,"DIV",{class:!0});var $=f(a);r=u($,"BUTTON",{class:!0});var b=f(r);c=ve(b,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var k=f(c);o=ve(k,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),f(o).forEach(d),k.forEach(d),b.forEach(d),$.forEach(d),t=D(y),s=u(y,"P",{});var w=f(s);g=I(w,"We are using cookies for no reason."),w.forEach(d),y.forEach(d),j.forEach(d),this.h()},h(){p(o,"stroke-linecap","round"),p(o,"stroke-linejoin","round"),p(o,"stroke-width","2"),p(o,"d","M6 18L18 6M6 6l12 12"),p(c,"xmlns","http://www.w3.org/2000/svg"),p(c,"class","h-6 w-6"),p(c,"fill","none"),p(c,"viewBox","0 0 24 24"),p(c,"stroke","currentColor"),p(r,"class","btn btn-square btn-sm"),p(a,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(m,j){S(m,e,j),i(e,l),i(l,a),i(a,r),i(r,c),i(c,o),i(l,t),i(l,s),i(s,g)},d(m){m&&d(e)}}}function et(v){let e,l=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function tt(v){let e,l=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function st(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("Life hack"),g=C(),m=h("p"),j=N("How to park your car at your garage?"),y=C(),$=h("div"),b=h("button"),k=N("Learn now!"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Life hack"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"How to park your car at your garage?"),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Learn now!"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg")||p(a,"src",r),p(a,"alt","car!"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 glass")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function at(v){let e,l=`<div class="$$card w-96 glass">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function ot(v){let e,l=`<div className="$$card w-96 glass">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function lt(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("New movie is released!"),g=C(),m=h("p"),j=N("Click the button to watch on Jetflix app."),y=C(),$=h("div"),b=h("button"),k=N("Watch"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"New movie is released!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"Click the button to watch on Jetflix app."),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Watch"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1635805737707-575885ab0820.jpg")||p(a,"src",r),p(a,"alt","Movie"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card card-side bg-base-100 shadow-xl")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function rt(v){let e,l=`<div class="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function ct(v){let e,l=`<div className="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function it(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k;return{c(){e=h("div"),l=h("figure"),a=h("img"),c=C(),o=h("div"),t=h("h2"),s=N("New album is released!"),g=C(),m=h("p"),j=N("Click the button to listen on Spotiwhy app."),y=C(),$=h("div"),b=h("button"),k=N("Listen"),this.h()},l(w){e=u(w,"DIV",{class:!0});var _=f(e);l=u(_,"FIGURE",{});var P=f(l);a=u(P,"IMG",{src:!0,alt:!0}),P.forEach(d),c=D(_),o=u(_,"DIV",{class:!0});var E=f(o);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"New album is released!"),R.forEach(d),g=D(E),m=u(E,"P",{});var B=f(m);j=I(B,"Click the button to listen on Spotiwhy app."),B.forEach(d),y=D(E),$=u(E,"DIV",{class:!0});var V=f($);b=u(V,"BUTTON",{class:!0});var T=f(b);k=I(T,"Listen"),T.forEach(d),V.forEach(d),E.forEach(d),_.forEach(d),this.h()},h(){X(a.src,r="/images/stock/photo-1494232410401-ad00d5433cfa.jpg")||p(a,"src",r),p(a,"alt","Album"),p(t,"class","card-title"),p(b,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card lg:card-side bg-base-100 shadow-xl")},m(w,_){S(w,e,_),i(e,l),i(l,a),i(e,c),i(e,o),i(o,t),i(t,s),i(o,g),i(o,m),i(m,j),i(o,y),i(o,$),i($,b),i(b,k)},d(w){w&&d(e)}}}function dt(v){let e,l=`<div class="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function nt(v){let e,l=`<div className="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,a,r,c,o;return{c(){e=h("pre"),a=N(l),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,l),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){S(t,e,s),i(e,a),c||(o=U(r=G.call(null,e,{to:v[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,o()}}}function ht(v){let e,l,a,r,c,o,t,s,g,m,j,y,$,b,k,w,_,P,E,R,B,V,T,z,J,Y,K,Q;return e=new Ie({props:{data:[{type:"component",class:"card",desc:"Container element"},{type:"component",class:"card-title",desc:"Title of card"},{type:"component",class:"card-body",desc:"Container for content"},{type:"component",class:"card-actions",desc:"Container for buttons"},{type:"modifier",class:"card-bordered",desc:"Adds border to <card>"},{type:"modifier",class:"image-full",desc:"The image in <figure> element will be the background"},{type:"responsive",class:"card-normal",desc:"Applies default paddings"},{type:"responsive",class:"card-compact",desc:"Applies smaller padding"},{type:"responsive",class:"card-side",desc:"The image in <figure> will be on to the side"}]}}),a=new q({props:{title:"Card",$$slots:{react:[xe],html:[je],default:[ke]},$$scope:{ctx:v}}}),c=new q({props:{title:"Compact card (less padding for `card-body`)",$$slots:{react:[De],html:[Ce],default:[Se]},$$scope:{ctx:v}}}),t=new q({props:{title:"Card with badge",$$slots:{react:[Ve],html:[Be],default:[Pe]},$$scope:{ctx:v}}}),g=new q({props:{title:"Card with bottom image",$$slots:{react:[Ue],html:[Te],default:[Re]},$$scope:{ctx:v}}}),j=new q({props:{title:"Card with centered content and paddings",$$slots:{react:[He],html:[Ge],default:[Me]},$$scope:{ctx:v}}}),$=new q({props:{title:"Card with image overlay",$$slots:{react:[Fe],html:[We],default:[Le]},$$scope:{ctx:v}}}),k=new q({props:{title:"Card with no image",$$slots:{react:[qe],html:[Ae],default:[Oe]},$$scope:{ctx:v}}}),_=new q({props:{title:"Card with custom color",$$slots:{react:[Ke],html:[ze],default:[Je]},$$scope:{ctx:v}}}),E=new q({props:{title:"Centered card with neutral color",$$slots:{react:[Ye],html:[Xe],default:[Qe]},$$scope:{ctx:v}}}),B=new q({props:{title:"Card with action on top",$$slots:{react:[tt],html:[et],default:[Ze]},$$scope:{ctx:v}}}),T=new q({props:{title:"Card glass",bg:"/images/stock/photo-1481026469463-66327c86e544.jpg",$$slots:{react:[ot],html:[at],default:[st]},$$scope:{ctx:v}}}),J=new q({props:{title:"Card with image on side",$$slots:{react:[ct],html:[rt],default:[lt]},$$scope:{ctx:v}}}),K=new q({props:{title:"Responsive card (vertical on small screen, horizontal on large screen)",$$slots:{react:[nt],html:[dt],default:[it]},$$scope:{ctx:v}}}),{c(){H(e.$$.fragment),l=C(),H(a.$$.fragment),r=C(),H(c.$$.fragment),o=C(),H(t.$$.fragment),s=C(),H(g.$$.fragment),m=C(),H(j.$$.fragment),y=C(),H($.$$.fragment),b=C(),H(k.$$.fragment),w=C(),H(_.$$.fragment),P=C(),H(E.$$.fragment),R=C(),H(B.$$.fragment),V=C(),H(T.$$.fragment),z=C(),H(J.$$.fragment),Y=C(),H(K.$$.fragment)},l(n){L(e.$$.fragment,n),l=D(n),L(a.$$.fragment,n),r=D(n),L(c.$$.fragment,n),o=D(n),L(t.$$.fragment,n),s=D(n),L(g.$$.fragment,n),m=D(n),L(j.$$.fragment,n),y=D(n),L($.$$.fragment,n),b=D(n),L(k.$$.fragment,n),w=D(n),L(_.$$.fragment,n),P=D(n),L(E.$$.fragment,n),R=D(n),L(B.$$.fragment,n),V=D(n),L(T.$$.fragment,n),z=D(n),L(J.$$.fragment,n),Y=D(n),L(K.$$.fragment,n)},m(n,x){W(e,n,x),S(n,l,x),W(a,n,x),S(n,r,x),W(c,n,x),S(n,o,x),W(t,n,x),S(n,s,x),W(g,n,x),S(n,m,x),W(j,n,x),S(n,y,x),W($,n,x),S(n,b,x),W(k,n,x),S(n,w,x),W(_,n,x),S(n,P,x),W(E,n,x),S(n,R,x),W(B,n,x),S(n,V,x),W(T,n,x),S(n,z,x),W(J,n,x),S(n,Y,x),W(K,n,x),Q=!0},p(n,x){const ee={};x&5&&(ee.$$scope={dirty:x,ctx:n}),a.$set(ee);const te={};x&5&&(te.$$scope={dirty:x,ctx:n}),c.$set(te);const se={};x&5&&(se.$$scope={dirty:x,ctx:n}),t.$set(se);const ae={};x&5&&(ae.$$scope={dirty:x,ctx:n}),g.$set(ae);const oe={};x&5&&(oe.$$scope={dirty:x,ctx:n}),j.$set(oe);const le={};x&5&&(le.$$scope={dirty:x,ctx:n}),$.$set(le);const re={};x&5&&(re.$$scope={dirty:x,ctx:n}),k.$set(re);const ce={};x&5&&(ce.$$scope={dirty:x,ctx:n}),_.$set(ce);const ie={};x&5&&(ie.$$scope={dirty:x,ctx:n}),E.$set(ie);const de={};x&5&&(de.$$scope={dirty:x,ctx:n}),B.$set(de);const ne={};x&5&&(ne.$$scope={dirty:x,ctx:n}),T.$set(ne);const he={};x&5&&(he.$$scope={dirty:x,ctx:n}),J.$set(he);const ue={};x&5&&(ue.$$scope={dirty:x,ctx:n}),K.$set(ue)},i(n){Q||(F(e.$$.fragment,n),F(a.$$.fragment,n),F(c.$$.fragment,n),F(t.$$.fragment,n),F(g.$$.fragment,n),F(j.$$.fragment,n),F($.$$.fragment,n),F(k.$$.fragment,n),F(_.$$.fragment,n),F(E.$$.fragment,n),F(B.$$.fragment,n),F(T.$$.fragment,n),F(J.$$.fragment,n),F(K.$$.fragment,n),Q=!0)},o(n){O(e.$$.fragment,n),O(a.$$.fragment,n),O(c.$$.fragment,n),O(t.$$.fragment,n),O(g.$$.fragment,n),O(j.$$.fragment,n),O($.$$.fragment,n),O(k.$$.fragment,n),O(_.$$.fragment,n),O(E.$$.fragment,n),O(B.$$.fragment,n),O(T.$$.fragment,n),O(J.$$.fragment,n),O(K.$$.fragment,n),Q=!1},d(n){A(e,n),n&&d(l),A(a,n),n&&d(r),A(c,n),n&&d(o),A(t,n),n&&d(s),A(g,n),n&&d(m),A(j,n),n&&d(y),A($,n),n&&d(b),A(k,n),n&&d(w),A(_,n),n&&d(P),A(E,n),n&&d(R),A(B,n),n&&d(V),A(T,n),n&&d(z),A(J,n),n&&d(Y),A(K,n)}}}function ut(v){let e,l;const a=[v[1],me];let r={$$slots:{default:[ht]},$$scope:{ctx:v}};for(let c=0;c<a.length;c+=1)r=Z(r,a[c]);return e=new ye({props:r}),{c(){H(e.$$.fragment)},l(c){L(e.$$.fragment,c)},m(c,o){W(e,c,o),l=!0},p(c,[o]){const t=o&2?we(a,[o&2&&pe(c[1]),o&0&&pe(me)]):{};o&5&&(t.$$scope={dirty:o,ctx:c}),e.$set(t)},i(c){l||(F(e.$$.fragment,c),l=!0)},o(c){O(e.$$.fragment,c),l=!1},d(c){A(e,c)}}}const me={title:"Card",desc:"Cards are used to group and display content in a way that is easily readable.",published:!0};function pt(v,e,l){let a;return Ee(v,Ne,r=>l(0,a=r)),v.$$set=r=>{l(1,e=Z(Z({},e),fe(r)))},e=fe(e),[a,e]}class yt extends be{constructor(e){super();_e(this,e,pt,ut,ge,{})}}export{yt as default,me as metadata};
