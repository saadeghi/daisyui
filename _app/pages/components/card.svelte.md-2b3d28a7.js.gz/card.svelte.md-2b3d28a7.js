import{S as _e,i as ge,s as be,C as Z,w as H,x as L,y as W,z as we,A as pe,q as F,o as O,B as A,K as Ee,ag as fe,k as D,m as P,g as C,d,e as h,t as N,c as u,a as f,h as I,O as X,b as p,F as i,a9 as U,Q as M,H as $e,I as me}from"../../chunks/vendor-3400f70d.js";import{M as ye}from"../../chunks/_markdown-4e49dabe.js";import{p as Ne,C as Ie,a as q,r as G}from"../../chunks/actions-09118302.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-90d9d476.js";import"../../chunks/index-1e7bf932.js";import"../../chunks/SEO-552723f9.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-c93027b8.js";function xe(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("Shoes!"),b=D(),v=h("p"),S=N("If a dog chews shoes whose shoes does he choose?"),y=D(),$=h("div"),_=h("button"),x=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"If a dog chews shoes whose shoes does he choose?"),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Buy Now"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function Se(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function ke(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Ce(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("Shoes!"),b=D(),v=h("p"),S=N("If a dog chews shoes whose shoes does he choose?"),y=D(),$=h("div"),_=h("button"),x=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"If a dog chews shoes whose shoes does he choose?"),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Buy Now"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 card-compact shadow-xl")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function De(m){let e,o=`<div class="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Pe(m){let e,o=`<div className="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Be(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x,w,g,B,E,R;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N(`Shoes!
      `),b=h("div"),v=N("NEW"),S=D(),y=h("p"),$=N("If a dog chews shoes whose shoes does he choose?"),_=D(),x=h("div"),w=h("div"),g=N("Fashion"),B=D(),E=h("div"),R=N("Products"),this.h()},l(V){e=u(V,"DIV",{class:!0});var j=f(e);o=u(j,"FIGURE",{});var T=f(o);a=u(T,"IMG",{src:!0,alt:!0}),T.forEach(d),c=P(j),l=u(j,"DIV",{class:!0});var z=f(l);t=u(z,"H2",{class:!0});var J=f(t);s=I(J,`Shoes!
      `),b=u(J,"DIV",{class:!0});var Y=f(b);v=I(Y,"NEW"),Y.forEach(d),J.forEach(d),S=P(z),y=u(z,"P",{});var K=f(y);$=I(K,"If a dog chews shoes whose shoes does he choose?"),K.forEach(d),_=P(z),x=u(z,"DIV",{class:!0});var Q=f(x);w=u(Q,"DIV",{class:!0});var n=f(w);g=I(n,"Fashion"),n.forEach(d),B=P(Q),E=u(Q,"DIV",{class:!0});var k=f(E);R=I(k,"Products"),k.forEach(d),Q.forEach(d),z.forEach(d),j.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","Shoes"),p(b,"class","badge badge-secondary"),p(t,"class","card-title"),p(w,"class","badge badge-outline"),p(E,"class","badge badge-outline"),p(x,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(V,j){C(V,e,j),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(t,b),i(b,v),i(l,S),i(l,y),i(y,$),i(l,_),i(l,x),i(x,w),i(w,g),i(x,B),i(x,E),i(E,R)},d(V){V&&d(e)}}}function Ve(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">
      Shoes!
      <div class="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <div class="$$badge $$badge-outline">Fashion</div> 
      <div class="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function je(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">
      Shoes!
      <div className="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <div className="$$badge $$badge-outline">Fashion</div> 
      <div className="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Re(m){let e,o,a,r,c,l,t,s,b,v,S;return{c(){e=h("div"),o=h("div"),a=h("h2"),r=N("Shoes!"),c=D(),l=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=D(),b=h("figure"),v=h("img"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);o=u($,"DIV",{class:!0});var _=f(o);a=u(_,"H2",{class:!0});var x=f(a);r=I(x,"Shoes!"),x.forEach(d),c=P(_),l=u(_,"P",{});var w=f(l);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),_.forEach(d),s=P($),b=u($,"FIGURE",{});var g=f(b);v=u(g,"IMG",{src:!0,alt:!0}),g.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(o,"class","card-body"),X(v.src,S="https://placeimg.com/400/225/arch")||p(v,"src",S),p(v,"alt","Shoes"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(y,$){C(y,e,$),i(e,o),i(o,a),i(a,r),i(o,c),i(o,l),i(l,t),i(e,s),i(e,b),i(b,v)},d(y){y&&d(e)}}}function Te(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Ue(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Me(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("Shoes!"),b=D(),v=h("p"),S=N("If a dog chews shoes whose shoes does he choose?"),y=D(),$=h("div"),_=h("button"),x=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{class:!0});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0,class:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"If a dog chews shoes whose shoes does he choose?"),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Buy Now"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","Shoes"),p(a,"class","rounded-xl"),p(o,"class","px-10 pt-10"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","card-actions"),p(l,"class","card-body items-center text-center"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function Ge(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure class="px-10 pt-10">
    <img src="https://placeimg.com/400/225/arch" alt="Shoes" class="rounded-xl" />
  </figure>
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function He(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <figure className="px-10 pt-10">
    <img src="https://placeimg.com/400/225/arch" alt="Shoes" className="rounded-xl" />
  </figure>
  <div className="$$card-body items-center text-center">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Le(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("Shoes!"),b=D(),v=h("p"),S=N("If a dog chews shoes whose shoes does he choose?"),y=D(),$=h("div"),_=h("button"),x=N("Buy Now"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Shoes!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"If a dog chews shoes whose shoes does he choose?"),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Buy Now"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","Shoes"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl image-full")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function We(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Fe(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="https://placeimg.com/400/225/arch" alt="Shoes" /></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Oe(m){let e,o,a,r,c,l,t,s,b,v,S;return{c(){e=h("div"),o=h("div"),a=h("h2"),r=N("Card title!"),c=D(),l=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=D(),b=h("div"),v=h("button"),S=N("Buy Now"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);o=u($,"DIV",{class:!0});var _=f(o);a=u(_,"H2",{class:!0});var x=f(a);r=I(x,"Card title!"),x.forEach(d),c=P(_),l=u(_,"P",{});var w=f(l);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),s=P(_),b=u(_,"DIV",{class:!0});var g=f(b);v=u(g,"BUTTON",{class:!0});var B=f(v);S=I(B,"Buy Now"),B.forEach(d),g.forEach(d),_.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(v,"class","btn btn-primary"),p(b,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(y,$){C(y,e,$),i(e,o),i(o,a),i(a,r),i(o,c),i(o,l),i(l,t),i(o,s),i(o,b),i(b,v),i(v,S)},d(y){y&&d(e)}}}function Ae(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function qe(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <h2 className="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Je(m){let e,o,a,r,c,l,t,s,b,v,S;return{c(){e=h("div"),o=h("div"),a=h("h2"),r=N("Card title!"),c=D(),l=h("p"),t=N("If a dog chews shoes whose shoes does he choose?"),s=D(),b=h("div"),v=h("button"),S=N("Buy Now"),this.h()},l(y){e=u(y,"DIV",{class:!0});var $=f(e);o=u($,"DIV",{class:!0});var _=f(o);a=u(_,"H2",{class:!0});var x=f(a);r=I(x,"Card title!"),x.forEach(d),c=P(_),l=u(_,"P",{});var w=f(l);t=I(w,"If a dog chews shoes whose shoes does he choose?"),w.forEach(d),s=P(_),b=u(_,"DIV",{class:!0});var g=f(b);v=u(g,"BUTTON",{class:!0});var B=f(v);S=I(B,"Buy Now"),B.forEach(d),g.forEach(d),_.forEach(d),$.forEach(d),this.h()},h(){p(a,"class","card-title"),p(v,"class","btn"),p(b,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-primary text-primary-content")},m(y,$){C(y,e,$),i(e,o),i(o,a),i(a,r),i(o,c),i(o,l),i(l,t),i(o,s),i(o,b),i(b,v),i(v,S)},d(y){y&&d(e)}}}function ze(m){let e,o=`<div class="$$card w-96 bg-primary text-primary-content">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Ke(m){let e,o=`<div className="$$card w-96 bg-primary text-primary-content">
  <div className="$$card-body">
    <h2 className="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Qe(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_;return{c(){e=h("div"),o=h("div"),a=h("h2"),r=N("Cookies!"),c=D(),l=h("p"),t=N("We are using cookies for no reason."),s=D(),b=h("div"),v=h("button"),S=N("Accept"),y=D(),$=h("button"),_=N("Deny"),this.h()},l(x){e=u(x,"DIV",{class:!0});var w=f(e);o=u(w,"DIV",{class:!0});var g=f(o);a=u(g,"H2",{class:!0});var B=f(a);r=I(B,"Cookies!"),B.forEach(d),c=P(g),l=u(g,"P",{});var E=f(l);t=I(E,"We are using cookies for no reason."),E.forEach(d),s=P(g),b=u(g,"DIV",{class:!0});var R=f(b);v=u(R,"BUTTON",{class:!0});var V=f(v);S=I(V,"Accept"),V.forEach(d),y=P(R),$=u(R,"BUTTON",{class:!0});var j=f($);_=I(j,"Deny"),j.forEach(d),R.forEach(d),g.forEach(d),w.forEach(d),this.h()},h(){p(a,"class","card-title"),p(v,"class","btn btn-primary"),p($,"class","btn btn-ghost"),p(b,"class","justify-end card-actions"),p(o,"class","card-body items-center text-center"),p(e,"class","card w-96 bg-neutral text-neutral-content")},m(x,w){C(x,e,w),i(e,o),i(o,a),i(a,r),i(o,c),i(o,l),i(l,t),i(o,s),i(o,b),i(b,v),i(v,S),i(b,y),i(b,$),i($,_)},d(x){x&&d(e)}}}function Xe(m){let e,o=`<div class="$$card w-96 bg-neutral text-neutral-content">
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Accept</button>
      <button class="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Ye(m){let e,o=`<div className="$$card w-96 bg-neutral text-neutral-content">
  <div className="$$card-body items-center text-center">
    <h2 className="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Accept</button>
      <button className="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function Ze(m){let e,o,a,r,c,l,t,s,b;return{c(){e=h("div"),o=h("div"),a=h("div"),r=h("button"),c=$e("svg"),l=$e("path"),t=D(),s=h("p"),b=N("We are using cookies for no reason."),this.h()},l(v){e=u(v,"DIV",{class:!0});var S=f(e);o=u(S,"DIV",{class:!0});var y=f(o);a=u(y,"DIV",{class:!0});var $=f(a);r=u($,"BUTTON",{class:!0});var _=f(r);c=me(_,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var x=f(c);l=me(x,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),f(l).forEach(d),x.forEach(d),_.forEach(d),$.forEach(d),t=P(y),s=u(y,"P",{});var w=f(s);b=I(w,"We are using cookies for no reason."),w.forEach(d),y.forEach(d),S.forEach(d),this.h()},h(){p(l,"stroke-linecap","round"),p(l,"stroke-linejoin","round"),p(l,"stroke-width","2"),p(l,"d","M6 18L18 6M6 6l12 12"),p(c,"xmlns","http://www.w3.org/2000/svg"),p(c,"class","h-6 w-6"),p(c,"fill","none"),p(c,"viewBox","0 0 24 24"),p(c,"stroke","currentColor"),p(r,"class","btn btn-square btn-sm"),p(a,"class","justify-end card-actions"),p(o,"class","card-body"),p(e,"class","card w-96 bg-base-100 shadow-xl")},m(v,S){C(v,e,S),i(e,o),i(o,a),i(a,r),i(r,c),i(c,l),i(o,t),i(o,s),i(s,b)},d(v){v&&d(e)}}}function et(m){let e,o=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function tt(m){let e,o=`<div className="$$card w-96 bg-base-100 shadow-xl">
  <div className="$$card-body">
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function st(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("Life hack"),b=D(),v=h("p"),S=N("How to park your car at your garage?"),y=D(),$=h("div"),_=h("button"),x=N("Learn now!"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"Life hack"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"How to park your car at your garage?"),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Learn now!"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/225/arch")||p(a,"src",r),p(a,"alt","car!"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card w-96 glass")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function at(m){let e,o=`<div class="$$card w-96 glass">
  <figure><img src="https://placeimg.com/400/225/arch" alt="car!"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function lt(m){let e,o=`<div className="$$card w-96 glass">
  <figure><img src="https://placeimg.com/400/225/arch" alt="car!"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function ot(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("New movie is released!"),b=D(),v=h("p"),S=N("Click the button to watch on Jetflix app."),y=D(),$=h("div"),_=h("button"),x=N("Watch"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"New movie is released!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"Click the button to watch on Jetflix app."),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Watch"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/200/280/arch")||p(a,"src",r),p(a,"alt","Movie"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card card-side bg-base-100 shadow-xl")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function rt(m){let e,o=`<div class="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/200/280/arch" alt="Movie"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function ct(m){let e,o=`<div className="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/200/280/arch" alt="Movie"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function it(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x;return{c(){e=h("div"),o=h("figure"),a=h("img"),c=D(),l=h("div"),t=h("h2"),s=N("New album is released!"),b=D(),v=h("p"),S=N("Click the button to listen on Spotiwhy app."),y=D(),$=h("div"),_=h("button"),x=N("Listen"),this.h()},l(w){e=u(w,"DIV",{class:!0});var g=f(e);o=u(g,"FIGURE",{});var B=f(o);a=u(B,"IMG",{src:!0,alt:!0}),B.forEach(d),c=P(g),l=u(g,"DIV",{class:!0});var E=f(l);t=u(E,"H2",{class:!0});var R=f(t);s=I(R,"New album is released!"),R.forEach(d),b=P(E),v=u(E,"P",{});var V=f(v);S=I(V,"Click the button to listen on Spotiwhy app."),V.forEach(d),y=P(E),$=u(E,"DIV",{class:!0});var j=f($);_=u(j,"BUTTON",{class:!0});var T=f(_);x=I(T,"Listen"),T.forEach(d),j.forEach(d),E.forEach(d),g.forEach(d),this.h()},h(){X(a.src,r="https://placeimg.com/400/400/arch")||p(a,"src",r),p(a,"alt","Album"),p(t,"class","card-title"),p(_,"class","btn btn-primary"),p($,"class","justify-end card-actions"),p(l,"class","card-body"),p(e,"class","card lg:card-side bg-base-100 shadow-xl")},m(w,g){C(w,e,g),i(e,o),i(o,a),i(e,c),i(e,l),i(l,t),i(t,s),i(l,b),i(l,v),i(v,S),i(l,y),i(l,$),i($,_),i(_,x)},d(w){w&&d(e)}}}function dt(m){let e,o=`<div class="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/400/arch" alt="Album"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","html")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function nt(m){let e,o=`<div className="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="https://placeimg.com/400/400/arch" alt="Album"/></figure>
  <div className="$$card-body">
    <h2 className="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div className="$$card-actions justify-end">
      <button className="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,a,r,c,l;return{c(){e=h("pre"),a=N(o),this.h()},l(t){e=u(t,"PRE",{slot:!0});var s=f(e);a=I(s,o),s.forEach(d),this.h()},h(){p(e,"slot","react")},m(t,s){C(t,e,s),i(e,a),c||(l=U(r=G.call(null,e,{to:m[0]})),c=!0)},p(t,s){r&&M(r.update)&&s&1&&r.update.call(null,{to:t[0]})},d(t){t&&d(e),c=!1,l()}}}function ht(m){let e,o,a,r,c,l,t,s,b,v,S,y,$,_,x,w,g,B,E,R,V,j,T,z,J,Y,K,Q;return e=new Ie({props:{data:[{type:"component",class:"card",desc:"Container element"},{type:"component",class:"card-title",desc:"Title of card"},{type:"component",class:"card-body",desc:"Container for content"},{type:"component",class:"card-actions",desc:"Container for buttons"},{type:"modifier",class:"card-bordered",desc:"Adds border to <card>"},{type:"modifier",class:"image-full",desc:"The image in <figure> element will be the background"},{type:"responsive",class:"card-normal",desc:"Applies default paddings"},{type:"responsive",class:"card-compact",desc:"Applies smaller padding"},{type:"responsive",class:"card-side",desc:"The image in <figure> will be on to the side"}]}}),a=new q({props:{title:"Card",$$slots:{react:[ke],html:[Se],default:[xe]},$$scope:{ctx:m}}}),c=new q({props:{title:"Compact card (less padding for `card-body`)",$$slots:{react:[Pe],html:[De],default:[Ce]},$$scope:{ctx:m}}}),t=new q({props:{title:"Card with badge",$$slots:{react:[je],html:[Ve],default:[Be]},$$scope:{ctx:m}}}),b=new q({props:{title:"Card with bottom image",$$slots:{react:[Ue],html:[Te],default:[Re]},$$scope:{ctx:m}}}),S=new q({props:{title:"Card with centered content and paddings",$$slots:{react:[He],html:[Ge],default:[Me]},$$scope:{ctx:m}}}),$=new q({props:{title:"Card with image overlay",$$slots:{react:[Fe],html:[We],default:[Le]},$$scope:{ctx:m}}}),x=new q({props:{title:"Card with no image",$$slots:{react:[qe],html:[Ae],default:[Oe]},$$scope:{ctx:m}}}),g=new q({props:{title:"Card with custom color",$$slots:{react:[Ke],html:[ze],default:[Je]},$$scope:{ctx:m}}}),E=new q({props:{title:"Centered card with neutral color",$$slots:{react:[Ye],html:[Xe],default:[Qe]},$$scope:{ctx:m}}}),V=new q({props:{title:"Card with action on top",$$slots:{react:[tt],html:[et],default:[Ze]},$$scope:{ctx:m}}}),T=new q({props:{title:"Card glass",bg:"https://placeimg.com/1000/500/arch",$$slots:{react:[lt],html:[at],default:[st]},$$scope:{ctx:m}}}),J=new q({props:{title:"Card with image on side",$$slots:{react:[ct],html:[rt],default:[ot]},$$scope:{ctx:m}}}),K=new q({props:{title:"Responsive card (vertical on small screen, horizontal on large screen)",$$slots:{react:[nt],html:[dt],default:[it]},$$scope:{ctx:m}}}),{c(){H(e.$$.fragment),o=D(),H(a.$$.fragment),r=D(),H(c.$$.fragment),l=D(),H(t.$$.fragment),s=D(),H(b.$$.fragment),v=D(),H(S.$$.fragment),y=D(),H($.$$.fragment),_=D(),H(x.$$.fragment),w=D(),H(g.$$.fragment),B=D(),H(E.$$.fragment),R=D(),H(V.$$.fragment),j=D(),H(T.$$.fragment),z=D(),H(J.$$.fragment),Y=D(),H(K.$$.fragment)},l(n){L(e.$$.fragment,n),o=P(n),L(a.$$.fragment,n),r=P(n),L(c.$$.fragment,n),l=P(n),L(t.$$.fragment,n),s=P(n),L(b.$$.fragment,n),v=P(n),L(S.$$.fragment,n),y=P(n),L($.$$.fragment,n),_=P(n),L(x.$$.fragment,n),w=P(n),L(g.$$.fragment,n),B=P(n),L(E.$$.fragment,n),R=P(n),L(V.$$.fragment,n),j=P(n),L(T.$$.fragment,n),z=P(n),L(J.$$.fragment,n),Y=P(n),L(K.$$.fragment,n)},m(n,k){W(e,n,k),C(n,o,k),W(a,n,k),C(n,r,k),W(c,n,k),C(n,l,k),W(t,n,k),C(n,s,k),W(b,n,k),C(n,v,k),W(S,n,k),C(n,y,k),W($,n,k),C(n,_,k),W(x,n,k),C(n,w,k),W(g,n,k),C(n,B,k),W(E,n,k),C(n,R,k),W(V,n,k),C(n,j,k),W(T,n,k),C(n,z,k),W(J,n,k),C(n,Y,k),W(K,n,k),Q=!0},p(n,k){const ee={};k&5&&(ee.$$scope={dirty:k,ctx:n}),a.$set(ee);const te={};k&5&&(te.$$scope={dirty:k,ctx:n}),c.$set(te);const se={};k&5&&(se.$$scope={dirty:k,ctx:n}),t.$set(se);const ae={};k&5&&(ae.$$scope={dirty:k,ctx:n}),b.$set(ae);const le={};k&5&&(le.$$scope={dirty:k,ctx:n}),S.$set(le);const oe={};k&5&&(oe.$$scope={dirty:k,ctx:n}),$.$set(oe);const re={};k&5&&(re.$$scope={dirty:k,ctx:n}),x.$set(re);const ce={};k&5&&(ce.$$scope={dirty:k,ctx:n}),g.$set(ce);const ie={};k&5&&(ie.$$scope={dirty:k,ctx:n}),E.$set(ie);const de={};k&5&&(de.$$scope={dirty:k,ctx:n}),V.$set(de);const ne={};k&5&&(ne.$$scope={dirty:k,ctx:n}),T.$set(ne);const he={};k&5&&(he.$$scope={dirty:k,ctx:n}),J.$set(he);const ue={};k&5&&(ue.$$scope={dirty:k,ctx:n}),K.$set(ue)},i(n){Q||(F(e.$$.fragment,n),F(a.$$.fragment,n),F(c.$$.fragment,n),F(t.$$.fragment,n),F(b.$$.fragment,n),F(S.$$.fragment,n),F($.$$.fragment,n),F(x.$$.fragment,n),F(g.$$.fragment,n),F(E.$$.fragment,n),F(V.$$.fragment,n),F(T.$$.fragment,n),F(J.$$.fragment,n),F(K.$$.fragment,n),Q=!0)},o(n){O(e.$$.fragment,n),O(a.$$.fragment,n),O(c.$$.fragment,n),O(t.$$.fragment,n),O(b.$$.fragment,n),O(S.$$.fragment,n),O($.$$.fragment,n),O(x.$$.fragment,n),O(g.$$.fragment,n),O(E.$$.fragment,n),O(V.$$.fragment,n),O(T.$$.fragment,n),O(J.$$.fragment,n),O(K.$$.fragment,n),Q=!1},d(n){A(e,n),n&&d(o),A(a,n),n&&d(r),A(c,n),n&&d(l),A(t,n),n&&d(s),A(b,n),n&&d(v),A(S,n),n&&d(y),A($,n),n&&d(_),A(x,n),n&&d(w),A(g,n),n&&d(B),A(E,n),n&&d(R),A(V,n),n&&d(j),A(T,n),n&&d(z),A(J,n),n&&d(Y),A(K,n)}}}function ut(m){let e,o;const a=[m[1],ve];let r={$$slots:{default:[ht]},$$scope:{ctx:m}};for(let c=0;c<a.length;c+=1)r=Z(r,a[c]);return e=new ye({props:r}),{c(){H(e.$$.fragment)},l(c){L(e.$$.fragment,c)},m(c,l){W(e,c,l),o=!0},p(c,[l]){const t=l&2?we(a,[l&2&&pe(c[1]),l&0&&pe(ve)]):{};l&5&&(t.$$scope={dirty:l,ctx:c}),e.$set(t)},i(c){o||(F(e.$$.fragment,c),o=!0)},o(c){O(e.$$.fragment,c),o=!1},d(c){A(e,c)}}}const ve={title:"Card",desc:"Cards are used to group and display content in a way that is easily readable.",published:!0};function pt(m,e,o){let a;return Ee(m,Ne,r=>o(0,a=r)),m.$$set=r=>{o(1,e=Z(Z({},e),fe(r)))},e=fe(e),[a,e]}class yt extends _e{constructor(e){super();ge(this,e,pt,ut,be,{})}}export{yt as default,ve as metadata};
