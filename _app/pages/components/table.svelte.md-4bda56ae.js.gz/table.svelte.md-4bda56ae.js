import{S as Qi,i as Ui,s as qi,C as Zn,w as cl,x as il,y as vl,z as Yi,A as Wi,q as fl,o as _l,B as ul,K as Zi,ag as Ji,k as d,m as o,g as Ot,d as e,e as a,t as s,c as l,a as r,h as n,b as E,F as t,a9 as Hr,W as wr,O as ao}from"../../chunks/vendor-c5cb7521.js";import{M as ji}from"../../chunks/_markdown-01d00466.js";import{p as Xi,C as t1,a as Sr,r as Cr}from"../../chunks/actions-db32d709.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-d526198e.js";import"../../chunks/index-c56cf16b.js";import"../../chunks/SEO-e90a962a.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-9b6f5415.js";function e1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=d(),i=a("th"),p=s("Name"),N=d(),I=a("th"),q=s("Job"),j=d(),R=a("th"),rt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),dt=s("1"),M=d(),H=a("td"),X=s("Cy Ganderton"),ht=d(),J=a("td"),m=s("Quality Control Specialist"),x=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),tt=a("th"),$t=s("2"),et=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),y=a("tr"),W=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),_t=d(),Q=a("td"),nt=s("Tax Accountant"),ut=d(),Z=a("td"),U=s("Red"),this.h()},l(F){h=l(F,"DIV",{class:!0});var at=r(h);f=l(at,"TABLE",{class:!0});var lt=r(f);T=l(lt,"THEAD",{});var kt=r(T);c=l(kt,"TR",{});var g=r(c);_=l(g,"TH",{}),r(_).forEach(e),$=o(g),i=l(g,"TH",{});var Tt=r(i);p=n(Tt,"Name"),Tt.forEach(e),N=o(g),I=l(g,"TH",{});var pt=r(I);q=n(pt,"Job"),pt.forEach(e),j=o(g),R=l(g,"TH",{});var Rt=r(R);rt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(lt),u=l(lt,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);dt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);X=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),J=l(w,"TD",{});var Et=r(J);m=n(Et,"Quality Control Specialist"),Et.forEach(e),x=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{});var C=r(b);tt=l(C,"TH",{});var V=r(tt);$t=n(V,"2"),V.forEach(e),et=o(C),z=l(C,"TD",{});var xt=r(z);yt=n(xt,"Hart Hagerty"),xt.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),y=l(P,"TR",{});var S=r(y);W=l(S,"TH",{});var Nt=r(W);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),_t=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),ut=o(S),Z=l(S,"TD",{});var zt=r(Z);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),lt.forEach(e),at.forEach(e),this.h()},h(){E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Ot(F,h,at),t(h,f),t(f,T),t(T,c),t(c,_),t(c,$),t(c,i),t(i,p),t(c,N),t(c,I),t(I,q),t(c,j),t(c,R),t(R,rt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,dt),t(D,M),t(D,H),t(H,X),t(D,ht),t(D,J),t(J,m),t(D,x),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,tt),t(tt,$t),t(b,et),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,y),t(y,W),t(W,ft),t(y,Ht),t(y,K),t(K,B),t(y,_t),t(y,Q),t(Q,nt),t(y,ut),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function a1(Y){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function l1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=d(),i=a("th"),p=s("Name"),N=d(),I=a("th"),q=s("Job"),j=d(),R=a("th"),rt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),dt=s("1"),M=d(),H=a("td"),X=s("Cy Ganderton"),ht=d(),J=a("td"),m=s("Quality Control Specialist"),x=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),tt=a("th"),$t=s("2"),et=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),y=a("tr"),W=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),_t=d(),Q=a("td"),nt=s("Tax Accountant"),ut=d(),Z=a("td"),U=s("Red"),this.h()},l(F){h=l(F,"DIV",{class:!0});var at=r(h);f=l(at,"TABLE",{class:!0});var lt=r(f);T=l(lt,"THEAD",{});var kt=r(T);c=l(kt,"TR",{});var g=r(c);_=l(g,"TH",{}),r(_).forEach(e),$=o(g),i=l(g,"TH",{});var Tt=r(i);p=n(Tt,"Name"),Tt.forEach(e),N=o(g),I=l(g,"TH",{});var pt=r(I);q=n(pt,"Job"),pt.forEach(e),j=o(g),R=l(g,"TH",{});var Rt=r(R);rt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(lt),u=l(lt,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);dt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);X=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),J=l(w,"TD",{});var Et=r(J);m=n(Et,"Quality Control Specialist"),Et.forEach(e),x=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{class:!0});var C=r(b);tt=l(C,"TH",{});var V=r(tt);$t=n(V,"2"),V.forEach(e),et=o(C),z=l(C,"TD",{});var xt=r(z);yt=n(xt,"Hart Hagerty"),xt.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),y=l(P,"TR",{});var S=r(y);W=l(S,"TH",{});var Nt=r(W);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),_t=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),ut=o(S),Z=l(S,"TD",{});var zt=r(Z);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),lt.forEach(e),at.forEach(e),this.h()},h(){E(b,"class","active"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Ot(F,h,at),t(h,f),t(f,T),t(T,c),t(c,_),t(c,$),t(c,i),t(i,p),t(c,N),t(c,I),t(I,q),t(c,j),t(c,R),t(R,rt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,dt),t(D,M),t(D,H),t(H,X),t(D,ht),t(D,J),t(J,m),t(D,x),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,tt),t(tt,$t),t(b,et),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,y),t(y,W),t(W,ft),t(y,Ht),t(y,K),t(K,B),t(y,_t),t(y,Q),t(Q,nt),t(y,ut),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function r1(Y){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$active">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function d1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=d(),i=a("th"),p=s("Name"),N=d(),I=a("th"),q=s("Job"),j=d(),R=a("th"),rt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),dt=s("1"),M=d(),H=a("td"),X=s("Cy Ganderton"),ht=d(),J=a("td"),m=s("Quality Control Specialist"),x=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),tt=a("th"),$t=s("2"),et=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),y=a("tr"),W=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),_t=d(),Q=a("td"),nt=s("Tax Accountant"),ut=d(),Z=a("td"),U=s("Red"),this.h()},l(F){h=l(F,"DIV",{class:!0});var at=r(h);f=l(at,"TABLE",{class:!0});var lt=r(f);T=l(lt,"THEAD",{});var kt=r(T);c=l(kt,"TR",{});var g=r(c);_=l(g,"TH",{}),r(_).forEach(e),$=o(g),i=l(g,"TH",{});var Tt=r(i);p=n(Tt,"Name"),Tt.forEach(e),N=o(g),I=l(g,"TH",{});var pt=r(I);q=n(pt,"Job"),pt.forEach(e),j=o(g),R=l(g,"TH",{});var Rt=r(R);rt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(lt),u=l(lt,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);dt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);X=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),J=l(w,"TD",{});var Et=r(J);m=n(Et,"Quality Control Specialist"),Et.forEach(e),x=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{class:!0});var C=r(b);tt=l(C,"TH",{});var V=r(tt);$t=n(V,"2"),V.forEach(e),et=o(C),z=l(C,"TD",{});var xt=r(z);yt=n(xt,"Hart Hagerty"),xt.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),y=l(P,"TR",{});var S=r(y);W=l(S,"TH",{});var Nt=r(W);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),_t=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),ut=o(S),Z=l(S,"TD",{});var zt=r(Z);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),lt.forEach(e),at.forEach(e),this.h()},h(){E(b,"class","hover"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Ot(F,h,at),t(h,f),t(f,T),t(T,c),t(c,_),t(c,$),t(c,i),t(i,p),t(c,N),t(c,I),t(I,q),t(c,j),t(c,R),t(R,rt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,dt),t(D,M),t(D,H),t(H,X),t(D,ht),t(D,J),t(J,m),t(D,x),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,tt),t(tt,$t),t(b,et),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,y),t(y,W),t(W,ft),t(y,Ht),t(y,K),t(K,B),t(y,_t),t(y,Q),t(Q,nt),t(y,ut),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function o1(Y){let h,f=`<div class="overflow-x-auto">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function s1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=d(),i=a("th"),p=s("Name"),N=d(),I=a("th"),q=s("Job"),j=d(),R=a("th"),rt=s("Favorite Color"),v=d(),u=a("tbody"),D=a("tr"),G=a("th"),dt=s("1"),M=d(),H=a("td"),X=s("Cy Ganderton"),ht=d(),J=a("td"),m=s("Quality Control Specialist"),x=d(),A=a("td"),ot=s("Blue"),st=d(),b=a("tr"),tt=a("th"),$t=s("2"),et=d(),z=a("td"),yt=s("Hart Hagerty"),ct=d(),O=a("td"),gt=s("Desktop Support Technician"),it=d(),L=a("td"),St=s("Purple"),vt=d(),y=a("tr"),W=a("th"),ft=s("3"),Ht=d(),K=a("td"),B=s("Brice Swyre"),_t=d(),Q=a("td"),nt=s("Tax Accountant"),ut=d(),Z=a("td"),U=s("Red"),this.h()},l(F){h=l(F,"DIV",{class:!0});var at=r(h);f=l(at,"TABLE",{class:!0});var lt=r(f);T=l(lt,"THEAD",{});var kt=r(T);c=l(kt,"TR",{});var g=r(c);_=l(g,"TH",{}),r(_).forEach(e),$=o(g),i=l(g,"TH",{});var Tt=r(i);p=n(Tt,"Name"),Tt.forEach(e),N=o(g),I=l(g,"TH",{});var pt=r(I);q=n(pt,"Job"),pt.forEach(e),j=o(g),R=l(g,"TH",{});var Rt=r(R);rt=n(Rt,"Favorite Color"),Rt.forEach(e),g.forEach(e),kt.forEach(e),v=o(lt),u=l(lt,"TBODY",{});var P=r(u);D=l(P,"TR",{});var w=r(D);G=l(w,"TH",{});var Vt=r(G);dt=n(Vt,"1"),Vt.forEach(e),M=o(w),H=l(w,"TD",{});var wt=r(H);X=n(wt,"Cy Ganderton"),wt.forEach(e),ht=o(w),J=l(w,"TD",{});var Et=r(J);m=n(Et,"Quality Control Specialist"),Et.forEach(e),x=o(w),A=l(w,"TD",{});var Gt=r(A);ot=n(Gt,"Blue"),Gt.forEach(e),w.forEach(e),st=o(P),b=l(P,"TR",{});var C=r(b);tt=l(C,"TH",{});var V=r(tt);$t=n(V,"2"),V.forEach(e),et=o(C),z=l(C,"TD",{});var xt=r(z);yt=n(xt,"Hart Hagerty"),xt.forEach(e),ct=o(C),O=l(C,"TD",{});var Ft=r(O);gt=n(Ft,"Desktop Support Technician"),Ft.forEach(e),it=o(C),L=l(C,"TD",{});var mt=r(L);St=n(mt,"Purple"),mt.forEach(e),C.forEach(e),vt=o(P),y=l(P,"TR",{});var S=r(y);W=l(S,"TH",{});var Nt=r(W);ft=n(Nt,"3"),Nt.forEach(e),Ht=o(S),K=l(S,"TD",{});var Mt=r(K);B=n(Mt,"Brice Swyre"),Mt.forEach(e),_t=o(S),Q=l(S,"TD",{});var bt=r(Q);nt=n(bt,"Tax Accountant"),bt.forEach(e),ut=o(S),Z=l(S,"TD",{});var zt=r(Z);U=n(zt,"Red"),zt.forEach(e),S.forEach(e),P.forEach(e),lt.forEach(e),at.forEach(e),this.h()},h(){E(f,"class","table table-zebra w-full"),E(h,"class","overflow-x-auto w-full")},m(F,at){Ot(F,h,at),t(h,f),t(f,T),t(T,c),t(c,_),t(c,$),t(c,i),t(i,p),t(c,N),t(c,I),t(I,q),t(c,j),t(c,R),t(R,rt),t(f,v),t(f,u),t(u,D),t(D,G),t(G,dt),t(D,M),t(D,H),t(H,X),t(D,ht),t(D,J),t(J,m),t(D,x),t(D,A),t(A,ot),t(u,st),t(u,b),t(b,tt),t(tt,$t),t(b,et),t(b,z),t(z,yt),t(b,ct),t(b,O),t(O,gt),t(b,it),t(b,L),t(L,St),t(u,vt),t(u,y),t(y,W),t(W,ft),t(y,Ht),t(y,K),t(K,B),t(y,_t),t(y,Q),t(Q,nt),t(y,ut),t(y,Z),t(Z,U)},d(F){F&&e(h)}}}function n1(Y){let h,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-zebra w-full">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function h1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U,F,at,lt,kt,g,Tt,pt,Rt,P,w,Vt,wt,Et,Gt,C,V,xt,Ft,mt,S,Nt,Mt,bt,zt,Tl,ze,pl,El,Oe,Ze,ml,va,Wt,fa,We,_a,bl,Ct,oe,je,Xe,Be,zl,Dl,Pe,ta,$l,ua,ea,yl,Ta,Le,gl,pa,Sl,aa,Ea,Hl,ma,It,ba,Da,la,$a,wl,Jt,Je,ya,ga,Sa,Ha,Ve,Ge,ra,da,Na,Cl,Ke,Fe,Rl,kl,Dt,wa,xl,Ne,Ca,Il,Al,Me,Pl,Bl,Qe,Ll,Vl,Ue,oa,Gl,Ra,ka,Kt,sa,Fl,xa,At,Ia,Aa,Nl,Pa,Ba,Ml,La,Ma;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=a("label"),i=a("input"),p=d(),N=a("th"),I=s("Name"),q=d(),j=a("th"),R=s("Job"),rt=d(),v=a("th"),u=s("Favorite Color"),D=d(),G=a("th"),dt=d(),M=a("tbody"),H=a("tr"),X=a("th"),ht=a("label"),J=a("input"),m=d(),x=a("td"),A=a("div"),ot=a("div"),st=a("div"),b=a("img"),$t=d(),et=a("div"),z=a("div"),yt=s("Hart Hagerty"),ct=d(),O=a("div"),gt=s("United States"),it=d(),L=a("td"),St=s(`Zemlak, Daniel and Leannon
          `),vt=a("br"),y=d(),W=a("span"),ft=s("Desktop Support Technician"),Ht=d(),K=a("td"),B=s("Purple"),_t=d(),Q=a("th"),nt=a("button"),ut=s("details"),Z=d(),U=a("tr"),F=a("th"),at=a("label"),lt=a("input"),kt=d(),g=a("td"),Tt=a("div"),pt=a("div"),Rt=a("div"),P=a("img"),Vt=d(),wt=a("div"),Et=a("div"),Gt=s("Brice Swyre"),C=d(),V=a("div"),xt=s("China"),Ft=d(),mt=a("td"),S=s(`Carroll Group
          `),Nt=a("br"),Mt=d(),bt=a("span"),zt=s("Tax Accountant"),Tl=d(),ze=a("td"),pl=s("Red"),El=d(),Oe=a("th"),Ze=a("button"),ml=s("details"),va=d(),Wt=a("tr"),fa=a("th"),We=a("label"),_a=a("input"),bl=d(),Ct=a("td"),oe=a("div"),je=a("div"),Xe=a("div"),Be=a("img"),Dl=d(),Pe=a("div"),ta=a("div"),$l=s("Marjy Ferencz"),ua=d(),ea=a("div"),yl=s("Russia"),Ta=d(),Le=a("td"),gl=s(`Rowe-Schoen
          `),pa=a("br"),Sl=d(),aa=a("span"),Ea=s("Office Assistant I"),Hl=d(),ma=a("td"),It=s("Crimson"),ba=d(),Da=a("th"),la=a("button"),$a=s("details"),wl=d(),Jt=a("tr"),Je=a("th"),ya=a("label"),ga=a("input"),Sa=d(),Ha=a("td"),Ve=a("div"),Ge=a("div"),ra=a("div"),da=a("img"),Cl=d(),Ke=a("div"),Fe=a("div"),Rl=s("Yancy Tear"),kl=d(),Dt=a("div"),wa=s("Brazil"),xl=d(),Ne=a("td"),Ca=s(`Wyman-Ledner
          `),Il=a("br"),Al=d(),Me=a("span"),Pl=s("Community Outreach Specialist"),Bl=d(),Qe=a("td"),Ll=s("Indigo"),Vl=d(),Ue=a("th"),oa=a("button"),Gl=s("details"),Ra=d(),ka=a("tfoot"),Kt=a("tr"),sa=a("th"),Fl=d(),xa=a("th"),At=s("Name"),Ia=d(),Aa=a("th"),Nl=s("Job"),Pa=d(),Ba=a("th"),Ml=s("Favorite Color"),La=d(),Ma=a("th"),this.h()},l(Va){h=l(Va,"DIV",{class:!0});var na=r(h);f=l(na,"TABLE",{class:!0});var ha=r(f);T=l(ha,"THEAD",{});var Ol=r(T);c=l(Ol,"TR",{});var re=r(c);_=l(re,"TH",{});var Wl=r(_);$=l(Wl,"LABEL",{});var Jl=r($);i=l(Jl,"INPUT",{type:!0,class:!0}),Jl.forEach(e),Wl.forEach(e),p=o(re),N=l(re,"TH",{});var za=r(N);I=n(za,"Name"),za.forEach(e),q=o(re),j=l(re,"TH",{});var Kl=r(j);R=n(Kl,"Job"),Kl.forEach(e),rt=o(re),v=l(re,"TH",{});var Ql=r(v);u=n(Ql,"Favorite Color"),Ql.forEach(e),D=o(re),G=l(re,"TH",{}),r(G).forEach(e),re.forEach(e),Ol.forEach(e),dt=o(ha),M=l(ha,"TBODY",{});var se=r(M);H=l(se,"TR",{});var ne=r(H);X=l(ne,"TH",{});var Ul=r(X);ht=l(Ul,"LABEL",{});var Pt=r(ht);J=l(Pt,"INPUT",{type:!0,class:!0}),Pt.forEach(e),Ul.forEach(e),m=o(ne),x=l(ne,"TD",{});var Oa=r(x);A=l(Oa,"DIV",{class:!0});var Wa=r(A);ot=l(Wa,"DIV",{class:!0});var ql=r(ot);st=l(ql,"DIV",{class:!0});var Ja=r(st);b=l(Ja,"IMG",{src:!0,alt:!0}),Ja.forEach(e),ql.forEach(e),$t=o(Wa),et=l(Wa,"DIV",{});var Ka=r(et);z=l(Ka,"DIV",{class:!0});var Yl=r(z);yt=n(Yl,"Hart Hagerty"),Yl.forEach(e),ct=o(Ka),O=l(Ka,"DIV",{class:!0});var Qa=r(O);gt=n(Qa,"United States"),Qa.forEach(e),Ka.forEach(e),Wa.forEach(e),Oa.forEach(e),it=o(ne),L=l(ne,"TD",{});var Ga=r(L);St=n(Ga,`Zemlak, Daniel and Leannon
          `),vt=l(Ga,"BR",{}),y=o(Ga),W=l(Ga,"SPAN",{class:!0});var Zl=r(W);ft=n(Zl,"Desktop Support Technician"),Zl.forEach(e),Ga.forEach(e),Ht=o(ne),K=l(ne,"TD",{});var Ua=r(K);B=n(Ua,"Purple"),Ua.forEach(e),_t=o(ne),Q=l(ne,"TH",{});var jl=r(Q);nt=l(jl,"BUTTON",{class:!0});var Xl=r(nt);ut=n(Xl,"details"),Xl.forEach(e),jl.forEach(e),ne.forEach(e),Z=o(se),U=l(se,"TR",{});var de=r(U);F=l(de,"TH",{});var tr=r(F);at=l(tr,"LABEL",{});var er=r(at);lt=l(er,"INPUT",{type:!0,class:!0}),er.forEach(e),tr.forEach(e),kt=o(de),g=l(de,"TD",{});var qa=r(g);Tt=l(qa,"DIV",{class:!0});var Ya=r(Tt);pt=l(Ya,"DIV",{class:!0});var ar=r(pt);Rt=l(ar,"DIV",{class:!0});var Za=r(Rt);P=l(Za,"IMG",{src:!0,alt:!0}),Za.forEach(e),ar.forEach(e),Vt=o(Ya),wt=l(Ya,"DIV",{});var ja=r(wt);Et=l(ja,"DIV",{class:!0});var lr=r(Et);Gt=n(lr,"Brice Swyre"),lr.forEach(e),C=o(ja),V=l(ja,"DIV",{class:!0});var Bt=r(V);xt=n(Bt,"China"),Bt.forEach(e),ja.forEach(e),Ya.forEach(e),qa.forEach(e),Ft=o(de),mt=l(de,"TD",{});var qe=r(mt);S=n(qe,`Carroll Group
          `),Nt=l(qe,"BR",{}),Mt=o(qe),bt=l(qe,"SPAN",{class:!0});var rr=r(bt);zt=n(rr,"Tax Accountant"),rr.forEach(e),qe.forEach(e),Tl=o(de),ze=l(de,"TD",{});var dr=r(ze);pl=n(dr,"Red"),dr.forEach(e),El=o(de),Oe=l(de,"TH",{});var Xa=r(Oe);Ze=l(Xa,"BUTTON",{class:!0});var or=r(Ze);ml=n(or,"details"),or.forEach(e),Xa.forEach(e),de.forEach(e),va=o(se),Wt=l(se,"TR",{});var he=r(Wt);fa=l(he,"TH",{});var tl=r(fa);We=l(tl,"LABEL",{});var sr=r(We);_a=l(sr,"INPUT",{type:!0,class:!0}),sr.forEach(e),tl.forEach(e),bl=o(he),Ct=l(he,"TD",{});var nr=r(Ct);oe=l(nr,"DIV",{class:!0});var ca=r(oe);je=l(ca,"DIV",{class:!0});var hr=r(je);Xe=l(hr,"DIV",{class:!0});var cr=r(Xe);Be=l(cr,"IMG",{src:!0,alt:!0}),cr.forEach(e),hr.forEach(e),Dl=o(ca),Pe=l(ca,"DIV",{});var ia=r(Pe);ta=l(ia,"DIV",{class:!0});var ir=r(ta);$l=n(ir,"Marjy Ferencz"),ir.forEach(e),ua=o(ia),ea=l(ia,"DIV",{class:!0});var vr=r(ea);yl=n(vr,"Russia"),vr.forEach(e),ia.forEach(e),ca.forEach(e),nr.forEach(e),Ta=o(he),Le=l(he,"TD",{});var Ye=r(Le);gl=n(Ye,`Rowe-Schoen
          `),pa=l(Ye,"BR",{}),Sl=o(Ye),aa=l(Ye,"SPAN",{class:!0});var fr=r(aa);Ea=n(fr,"Office Assistant I"),fr.forEach(e),Ye.forEach(e),Hl=o(he),ma=l(he,"TD",{});var _r=r(ma);It=n(_r,"Crimson"),_r.forEach(e),ba=o(he),Da=l(he,"TH",{});var el=r(Da);la=l(el,"BUTTON",{class:!0});var ur=r(la);$a=n(ur,"details"),ur.forEach(e),el.forEach(e),he.forEach(e),wl=o(se),Jt=l(se,"TR",{});var ce=r(Jt);Je=l(ce,"TH",{});var Lt=r(Je);ya=l(Lt,"LABEL",{});var al=r(ya);ga=l(al,"INPUT",{type:!0,class:!0}),al.forEach(e),Lt.forEach(e),Sa=o(ce),Ha=l(ce,"TD",{});var Tr=r(Ha);Ve=l(Tr,"DIV",{class:!0});var ll=r(Ve);Ge=l(ll,"DIV",{class:!0});var rl=r(Ge);ra=l(rl,"DIV",{class:!0});var pr=r(ra);da=l(pr,"IMG",{src:!0,alt:!0}),pr.forEach(e),rl.forEach(e),Cl=o(ll),Ke=l(ll,"DIV",{});var dl=r(Ke);Fe=l(dl,"DIV",{class:!0});var ol=r(Fe);Rl=n(ol,"Yancy Tear"),ol.forEach(e),kl=o(dl),Dt=l(dl,"DIV",{class:!0});var Er=r(Dt);wa=n(Er,"Brazil"),Er.forEach(e),dl.forEach(e),ll.forEach(e),Tr.forEach(e),xl=o(ce),Ne=l(ce,"TD",{});var Fa=r(Ne);Ca=n(Fa,`Wyman-Ledner
          `),Il=l(Fa,"BR",{}),Al=o(Fa),Me=l(Fa,"SPAN",{class:!0});var sl=r(Me);Pl=n(sl,"Community Outreach Specialist"),sl.forEach(e),Fa.forEach(e),Bl=o(ce),Qe=l(ce,"TD",{});var mr=r(Qe);Ll=n(mr,"Indigo"),mr.forEach(e),Vl=o(ce),Ue=l(ce,"TH",{});var br=r(Ue);oa=l(br,"BUTTON",{class:!0});var nl=r(oa);Gl=n(nl,"details"),nl.forEach(e),br.forEach(e),ce.forEach(e),se.forEach(e),Ra=o(ha),ka=l(ha,"TFOOT",{});var Dr=r(ka);Kt=l(Dr,"TR",{});var ie=r(Kt);sa=l(ie,"TH",{}),r(sa).forEach(e),Fl=o(ie),xa=l(ie,"TH",{});var hl=r(xa);At=n(hl,"Name"),hl.forEach(e),Ia=o(ie),Aa=l(ie,"TH",{});var $r=r(Aa);Nl=n($r,"Job"),$r.forEach(e),Pa=o(ie),Ba=l(ie,"TH",{});var yr=r(Ba);Ml=n(yr,"Favorite Color"),yr.forEach(e),La=o(ie),Ma=l(ie,"TH",{}),r(Ma).forEach(e),ie.forEach(e),Dr.forEach(e),ha.forEach(e),na.forEach(e),this.h()},h(){E(i,"type","checkbox"),E(i,"class","checkbox"),E(J,"type","checkbox"),E(J,"class","checkbox"),ao(b.src,tt="/tailwind-css-component-profile-2@56w.png")||E(b,"src",tt),E(b,"alt","Avatar Tailwind CSS Component"),E(st,"class","w-12 h-12 mask mask-squircle"),E(ot,"class","avatar"),E(z,"class","font-bold"),E(O,"class","text-sm opacity-50"),E(A,"class","flex items-center space-x-3"),E(W,"class","badge badge-ghost badge-sm"),E(nt,"class","btn btn-ghost btn-xs"),E(lt,"type","checkbox"),E(lt,"class","checkbox"),ao(P.src,w="/tailwind-css-component-profile-3@56w.png")||E(P,"src",w),E(P,"alt","Avatar Tailwind CSS Component"),E(Rt,"class","w-12 h-12 mask mask-squircle"),E(pt,"class","avatar"),E(Et,"class","font-bold"),E(V,"class","text-sm opacity-50"),E(Tt,"class","flex items-center space-x-3"),E(bt,"class","badge badge-ghost badge-sm"),E(Ze,"class","btn btn-ghost btn-xs"),E(_a,"type","checkbox"),E(_a,"class","checkbox"),ao(Be.src,zl="/tailwind-css-component-profile-4@56w.png")||E(Be,"src",zl),E(Be,"alt","Avatar Tailwind CSS Component"),E(Xe,"class","w-12 h-12 mask mask-squircle"),E(je,"class","avatar"),E(ta,"class","font-bold"),E(ea,"class","text-sm opacity-50"),E(oe,"class","flex items-center space-x-3"),E(aa,"class","badge badge-ghost badge-sm"),E(la,"class","btn btn-ghost btn-xs"),E(ga,"type","checkbox"),E(ga,"class","checkbox"),ao(da.src,Na="/tailwind-css-component-profile-5@56w.png")||E(da,"src",Na),E(da,"alt","Avatar Tailwind CSS Component"),E(ra,"class","w-12 h-12 mask mask-squircle"),E(Ge,"class","avatar"),E(Fe,"class","font-bold"),E(Dt,"class","text-sm opacity-50"),E(Ve,"class","flex items-center space-x-3"),E(Me,"class","badge badge-ghost badge-sm"),E(oa,"class","btn btn-ghost btn-xs"),E(f,"class","table w-full"),E(h,"class","overflow-x-auto w-full")},m(Va,na){Ot(Va,h,na),t(h,f),t(f,T),t(T,c),t(c,_),t(_,$),t($,i),t(c,p),t(c,N),t(N,I),t(c,q),t(c,j),t(j,R),t(c,rt),t(c,v),t(v,u),t(c,D),t(c,G),t(f,dt),t(f,M),t(M,H),t(H,X),t(X,ht),t(ht,J),t(H,m),t(H,x),t(x,A),t(A,ot),t(ot,st),t(st,b),t(A,$t),t(A,et),t(et,z),t(z,yt),t(et,ct),t(et,O),t(O,gt),t(H,it),t(H,L),t(L,St),t(L,vt),t(L,y),t(L,W),t(W,ft),t(H,Ht),t(H,K),t(K,B),t(H,_t),t(H,Q),t(Q,nt),t(nt,ut),t(M,Z),t(M,U),t(U,F),t(F,at),t(at,lt),t(U,kt),t(U,g),t(g,Tt),t(Tt,pt),t(pt,Rt),t(Rt,P),t(Tt,Vt),t(Tt,wt),t(wt,Et),t(Et,Gt),t(wt,C),t(wt,V),t(V,xt),t(U,Ft),t(U,mt),t(mt,S),t(mt,Nt),t(mt,Mt),t(mt,bt),t(bt,zt),t(U,Tl),t(U,ze),t(ze,pl),t(U,El),t(U,Oe),t(Oe,Ze),t(Ze,ml),t(M,va),t(M,Wt),t(Wt,fa),t(fa,We),t(We,_a),t(Wt,bl),t(Wt,Ct),t(Ct,oe),t(oe,je),t(je,Xe),t(Xe,Be),t(oe,Dl),t(oe,Pe),t(Pe,ta),t(ta,$l),t(Pe,ua),t(Pe,ea),t(ea,yl),t(Wt,Ta),t(Wt,Le),t(Le,gl),t(Le,pa),t(Le,Sl),t(Le,aa),t(aa,Ea),t(Wt,Hl),t(Wt,ma),t(ma,It),t(Wt,ba),t(Wt,Da),t(Da,la),t(la,$a),t(M,wl),t(M,Jt),t(Jt,Je),t(Je,ya),t(ya,ga),t(Jt,Sa),t(Jt,Ha),t(Ha,Ve),t(Ve,Ge),t(Ge,ra),t(ra,da),t(Ve,Cl),t(Ve,Ke),t(Ke,Fe),t(Fe,Rl),t(Ke,kl),t(Ke,Dt),t(Dt,wa),t(Jt,xl),t(Jt,Ne),t(Ne,Ca),t(Ne,Il),t(Ne,Al),t(Ne,Me),t(Me,Pl),t(Jt,Bl),t(Jt,Qe),t(Qe,Ll),t(Jt,Vl),t(Jt,Ue),t(Ue,oa),t(oa,Gl),t(f,Ra),t(f,ka),t(ka,Kt),t(Kt,sa),t(Kt,Fl),t(Kt,xa),t(xa,At),t(Kt,Ia),t(Kt,Aa),t(Aa,Nl),t(Kt,Pa),t(Kt,Ba),t(Ba,Ml),t(Kt,La),t(Kt,Ma)},d(Va){Va&&e(h)}}}function c1(Y){let h,f=`<div class="overflow-x-auto w-full">
  <table class="$$table w-full">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Hart Hagerty</div>
              <div class="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Brice Swyre</div>
              <div class="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Marjy Ferencz</div>
              <div class="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Yancy Tear</div>
              <div class="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br>
          <span class="$$badge $$badge-ghost $$badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function i1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt,v,u,D,G,dt,M,H,X,ht,J,m,x,A,ot,st,b,tt,$t,et,z,yt,ct,O,gt,it,L,St,vt,y,W,ft,Ht,K,B,_t,Q,nt,ut,Z,U,F,at,lt,kt,g,Tt,pt,Rt,P,w,Vt,wt,Et,Gt,C,V,xt,Ft,mt,S,Nt,Mt,bt,zt,Tl,ze,pl,El,Oe,Ze,ml,va,Wt,fa,We,_a,bl,Ct,oe,je,Xe,Be,zl,Dl,Pe,ta,$l,ua,ea,yl,Ta,Le,gl,pa,Sl,aa,Ea,Hl,ma,It,ba,Da,la,$a,wl,Jt,Je,ya,ga,Sa,Ha,Ve,Ge,ra,da,Na,Cl,Ke,Fe,Rl,kl,Dt,wa,xl,Ne,Ca,Il,Al,Me,Pl,Bl,Qe,Ll,Vl,Ue,oa,Gl,Ra,ka,Kt,sa,Fl,xa,At,Ia,Aa,Nl,Pa,Ba,Ml,La,Ma,Va,na,ha,Ol,re,Wl,Jl,za,Kl,Ql,se,ne,Ul,Pt,Oa,Wa,ql,Ja,Ka,Yl,Qa,Ga,Zl,Ua,jl,Xl,de,tr,er,qa,Ya,ar,Za,ja,lr,Bt,qe,rr,dr,Xa,or,he,tl,sr,nr,ca,hr,cr,ia,ir,vr,Ye,fr,_r,el,ur,ce,Lt,al,Tr,ll,rl,pr,dl,ol,Er,Fa,sl,mr,br,nl,Dr,ie,hl,$r,yr,Rr,lo,ro,Qt,kr,oo,so,xr,no,ho,Ir,co,io,Ar,vo,fo,Pr,_o,uo,Br,To,po,Lr,Eo,mo,Ut,Vr,bo,Do,Gr,$o,yo,Fr,go,So,Nr,Ho,wo,Mr,Co,Ro,zr,ko,xo,Or,Io,Ao,qt,Wr,Po,Bo,Jr,Lo,Vo,Kr,Go,Fo,Qr,No,Mo,Ur,zo,Oo,qr,Wo,Jo,Yr,Ko,Qo,Yt,Zr,Uo,qo,jr,Yo,Zo,Xr,jo,Xo,td,ts,es,ed,as,ls,ad,rs,ds,ld,os,ss,Zt,rd,ns,hs,dd,cs,is,od,vs,fs,sd,_s,us,nd,Ts,ps,hd,Es,ms,cd,bs,Ds,jt,id,$s,ys,vd,gs,Ss,fd,Hs,ws,_d,Cs,Rs,ud,ks,xs,Td,Is,As,pd,Ps,Bs,Xt,Ed,Ls,Vs,md,Gs,Fs,bd,Ns,Ms,Dd,zs,Os,$d,Ws,Js,yd,Ks,Qs,gd,Us,qs,te,Sd,Ys,Zs,Hd,js,Xs,wd,tn,en,Cd,an,ln,Rd,rn,dn,kd,on,sn,xd,nn,hn,ee,Id,cn,vn,Ad,fn,_n,Pd,un,Tn,Bd,pn,En,Ld,mn,bn,Vd,Dn,$n,Gd,yn,gn,ae,Fd,Sn,Hn,Nd,wn,Cn,Md,Rn,kn,zd,xn,In,Od,An,Pn,Wd,Bn,Ln,Jd,Vn,Gn,Kd,le,to,Fn,Qd,Nn,Mn,Ud,zn,On,qd,Wn,Jn,Yd,Kn,Qn,Zd,Un,qn,jd,Yn;return{c(){h=a("div"),f=a("table"),T=a("thead"),c=a("tr"),_=a("th"),$=d(),i=a("th"),p=s("Name"),N=d(),I=a("th"),q=s("Job"),j=d(),R=a("th"),rt=s("company"),v=d(),u=a("th"),D=s("location"),G=d(),dt=a("th"),M=s("Last Login"),H=d(),X=a("th"),ht=s("Favorite Color"),J=d(),m=a("tbody"),x=a("tr"),A=a("th"),ot=s("1"),st=d(),b=a("td"),tt=s("Cy Ganderton"),$t=d(),et=a("td"),z=s("Quality Control Specialist"),yt=d(),ct=a("td"),O=s("Littel, Schaden and Vandervort"),gt=d(),it=a("td"),L=s("Canada"),St=d(),vt=a("td"),y=s("12/16/2020"),W=d(),ft=a("td"),Ht=s("Blue"),K=d(),B=a("tr"),_t=a("th"),Q=s("2"),nt=d(),ut=a("td"),Z=s("Hart Hagerty"),U=d(),F=a("td"),at=s("Desktop Support Technician"),lt=d(),kt=a("td"),g=s("Zemlak, Daniel and Leannon"),Tt=d(),pt=a("td"),Rt=s("United States"),P=d(),w=a("td"),Vt=s("12/5/2020"),wt=d(),Et=a("td"),Gt=s("Purple"),C=d(),V=a("tr"),xt=a("th"),Ft=s("3"),mt=d(),S=a("td"),Nt=s("Brice Swyre"),Mt=d(),bt=a("td"),zt=s("Tax Accountant"),Tl=d(),ze=a("td"),pl=s("Carroll Group"),El=d(),Oe=a("td"),Ze=s("China"),ml=d(),va=a("td"),Wt=s("8/15/2020"),fa=d(),We=a("td"),_a=s("Red"),bl=d(),Ct=a("tr"),oe=a("th"),je=s("4"),Xe=d(),Be=a("td"),zl=s("Marjy Ferencz"),Dl=d(),Pe=a("td"),ta=s("Office Assistant I"),$l=d(),ua=a("td"),ea=s("Rowe-Schoen"),yl=d(),Ta=a("td"),Le=s("Russia"),gl=d(),pa=a("td"),Sl=s("3/25/2021"),aa=d(),Ea=a("td"),Hl=s("Crimson"),ma=d(),It=a("tr"),ba=a("th"),Da=s("5"),la=d(),$a=a("td"),wl=s("Yancy Tear"),Jt=d(),Je=a("td"),ya=s("Community Outreach Specialist"),ga=d(),Sa=a("td"),Ha=s("Wyman-Ledner"),Ve=d(),Ge=a("td"),ra=s("Brazil"),da=d(),Na=a("td"),Cl=s("5/22/2020"),Ke=d(),Fe=a("td"),Rl=s("Indigo"),kl=d(),Dt=a("tr"),wa=a("th"),xl=s("6"),Ne=d(),Ca=a("td"),Il=s("Irma Vasilik"),Al=d(),Me=a("td"),Pl=s("Editor"),Bl=d(),Qe=a("td"),Ll=s("Wiza, Bins and Emard"),Vl=d(),Ue=a("td"),oa=s("Venezuela"),Gl=d(),Ra=a("td"),ka=s("12/8/2020"),Kt=d(),sa=a("td"),Fl=s("Purple"),xa=d(),At=a("tr"),Ia=a("th"),Aa=s("7"),Nl=d(),Pa=a("td"),Ba=s("Meghann Durtnal"),Ml=d(),La=a("td"),Ma=s("Staff Accountant IV"),Va=d(),na=a("td"),ha=s("Schuster-Schimmel"),Ol=d(),re=a("td"),Wl=s("Philippines"),Jl=d(),za=a("td"),Kl=s("2/17/2021"),Ql=d(),se=a("td"),ne=s("Yellow"),Ul=d(),Pt=a("tr"),Oa=a("th"),Wa=s("8"),ql=d(),Ja=a("td"),Ka=s("Sammy Seston"),Yl=d(),Qa=a("td"),Ga=s("Accountant I"),Zl=d(),Ua=a("td"),jl=s("O'Hara, Welch and Keebler"),Xl=d(),de=a("td"),tr=s("Indonesia"),er=d(),qa=a("td"),Ya=s("5/23/2020"),ar=d(),Za=a("td"),ja=s("Crimson"),lr=d(),Bt=a("tr"),qe=a("th"),rr=s("9"),dr=d(),Xa=a("td"),or=s("Lesya Tinham"),he=d(),tl=a("td"),sr=s("Safety Technician IV"),nr=d(),ca=a("td"),hr=s("Turner-Kuhlman"),cr=d(),ia=a("td"),ir=s("Philippines"),vr=d(),Ye=a("td"),fr=s("2/21/2021"),_r=d(),el=a("td"),ur=s("Maroon"),ce=d(),Lt=a("tr"),al=a("th"),Tr=s("10"),ll=d(),rl=a("td"),pr=s("Zaneta Tewkesbury"),dl=d(),ol=a("td"),Er=s("VP Marketing"),Fa=d(),sl=a("td"),mr=s("Sauer LLC"),br=d(),nl=a("td"),Dr=s("Chad"),ie=d(),hl=a("td"),$r=s("6/23/2020"),yr=d(),Rr=a("td"),lo=s("Green"),ro=d(),Qt=a("tr"),kr=a("th"),oo=s("11"),so=d(),xr=a("td"),no=s("Andy Tipple"),ho=d(),Ir=a("td"),co=s("Librarian"),io=d(),Ar=a("td"),vo=s("Hilpert Group"),fo=d(),Pr=a("td"),_o=s("Poland"),uo=d(),Br=a("td"),To=s("7/9/2020"),po=d(),Lr=a("td"),Eo=s("Indigo"),mo=d(),Ut=a("tr"),Vr=a("th"),bo=s("12"),Do=d(),Gr=a("td"),$o=s("Sophi Biles"),yo=d(),Fr=a("td"),go=s("Recruiting Manager"),So=d(),Nr=a("td"),Ho=s("Gutmann Inc"),wo=d(),Mr=a("td"),Co=s("Indonesia"),Ro=d(),zr=a("td"),ko=s("2/12/2021"),xo=d(),Or=a("td"),Io=s("Maroon"),Ao=d(),qt=a("tr"),Wr=a("th"),Po=s("13"),Bo=d(),Jr=a("td"),Lo=s("Florida Garces"),Vo=d(),Kr=a("td"),Go=s("Web Developer IV"),Fo=d(),Qr=a("td"),No=s("Gaylord, Pacocha and Baumbach"),Mo=d(),Ur=a("td"),zo=s("Poland"),Oo=d(),qr=a("td"),Wo=s("5/31/2020"),Jo=d(),Yr=a("td"),Ko=s("Purple"),Qo=d(),Yt=a("tr"),Zr=a("th"),Uo=s("14"),qo=d(),jr=a("td"),Yo=s("Maribeth Popping"),Zo=d(),Xr=a("td"),jo=s("Analyst Programmer"),Xo=d(),td=a("td"),ts=s("Deckow-Pouros"),es=d(),ed=a("td"),as=s("Portugal"),ls=d(),ad=a("td"),rs=s("4/27/2021"),ds=d(),ld=a("td"),os=s("Aquamarine"),ss=d(),Zt=a("tr"),rd=a("th"),ns=s("15"),hs=d(),dd=a("td"),cs=s("Moritz Dryburgh"),is=d(),od=a("td"),vs=s("Dental Hygienist"),fs=d(),sd=a("td"),_s=s("Schiller, Cole and Hackett"),us=d(),nd=a("td"),Ts=s("Sri Lanka"),ps=d(),hd=a("td"),Es=s("8/8/2020"),ms=d(),cd=a("td"),bs=s("Crimson"),Ds=d(),jt=a("tr"),id=a("th"),$s=s("16"),ys=d(),vd=a("td"),gs=s("Reid Semiras"),Ss=d(),fd=a("td"),Hs=s("Teacher"),ws=d(),_d=a("td"),Cs=s("Sporer, Sipes and Rogahn"),Rs=d(),ud=a("td"),ks=s("Poland"),xs=d(),Td=a("td"),Is=s("7/30/2020"),As=d(),pd=a("td"),Ps=s("Green"),Bs=d(),Xt=a("tr"),Ed=a("th"),Ls=s("17"),Vs=d(),md=a("td"),Gs=s("Alec Lethby"),Fs=d(),bd=a("td"),Ns=s("Teacher"),Ms=d(),Dd=a("td"),zs=s("Reichel, Glover and Hamill"),Os=d(),$d=a("td"),Ws=s("China"),Js=d(),yd=a("td"),Ks=s("2/28/2021"),Qs=d(),gd=a("td"),Us=s("Khaki"),qs=d(),te=a("tr"),Sd=a("th"),Ys=s("18"),Zs=d(),Hd=a("td"),js=s("Aland Wilber"),Xs=d(),wd=a("td"),tn=s("Quality Control Specialist"),en=d(),Cd=a("td"),an=s("Kshlerin, Rogahn and Swaniawski"),ln=d(),Rd=a("td"),rn=s("Czech Republic"),dn=d(),kd=a("td"),on=s("9/29/2020"),sn=d(),xd=a("td"),nn=s("Purple"),hn=d(),ee=a("tr"),Id=a("th"),cn=s("19"),vn=d(),Ad=a("td"),fn=s("Teddie Duerden"),_n=d(),Pd=a("td"),un=s("Staff Accountant III"),Tn=d(),Bd=a("td"),pn=s("Pouros, Ullrich and Windler"),En=d(),Ld=a("td"),mn=s("France"),bn=d(),Vd=a("td"),Dn=s("10/27/2020"),$n=d(),Gd=a("td"),yn=s("Aquamarine"),gn=d(),ae=a("tr"),Fd=a("th"),Sn=s("20"),Hn=d(),Nd=a("td"),wn=s("Lorelei Blackstone"),Cn=d(),Md=a("td"),Rn=s("Data Coordinator"),kn=d(),zd=a("td"),xn=s("Witting, Kutch and Greenfelder"),In=d(),Od=a("td"),An=s("Kazakhstan"),Pn=d(),Wd=a("td"),Bn=s("6/3/2020"),Ln=d(),Jd=a("td"),Vn=s("Red"),Gn=d(),Kd=a("tfoot"),le=a("tr"),to=a("th"),Fn=d(),Qd=a("th"),Nn=s("Name"),Mn=d(),Ud=a("th"),zn=s("Job"),On=d(),qd=a("th"),Wn=s("company"),Jn=d(),Yd=a("th"),Kn=s("location"),Qn=d(),Zd=a("th"),Un=s("Last Login"),qn=d(),jd=a("th"),Yn=s("Favorite Color"),this.h()},l(Xd){h=l(Xd,"DIV",{class:!0});var eo=r(h);f=l(eo,"TABLE",{class:!0});var gr=r(f);T=l(gr,"THEAD",{});var jn=r(T);c=l(jn,"TR",{});var ve=r(c);_=l(ve,"TH",{}),r(_).forEach(e),$=o(ve),i=l(ve,"TH",{});var Xn=r(i);p=n(Xn,"Name"),Xn.forEach(e),N=o(ve),I=l(ve,"TH",{});var th=r(I);q=n(th,"Job"),th.forEach(e),j=o(ve),R=l(ve,"TH",{});var eh=r(R);rt=n(eh,"company"),eh.forEach(e),v=o(ve),u=l(ve,"TH",{});var ah=r(u);D=n(ah,"location"),ah.forEach(e),G=o(ve),dt=l(ve,"TH",{});var lh=r(dt);M=n(lh,"Last Login"),lh.forEach(e),H=o(ve),X=l(ve,"TH",{});var rh=r(X);ht=n(rh,"Favorite Color"),rh.forEach(e),ve.forEach(e),jn.forEach(e),J=o(gr),m=l(gr,"TBODY",{});var k=r(m);x=l(k,"TR",{});var fe=r(x);A=l(fe,"TH",{});var dh=r(A);ot=n(dh,"1"),dh.forEach(e),st=o(fe),b=l(fe,"TD",{});var oh=r(b);tt=n(oh,"Cy Ganderton"),oh.forEach(e),$t=o(fe),et=l(fe,"TD",{});var sh=r(et);z=n(sh,"Quality Control Specialist"),sh.forEach(e),yt=o(fe),ct=l(fe,"TD",{});var nh=r(ct);O=n(nh,"Littel, Schaden and Vandervort"),nh.forEach(e),gt=o(fe),it=l(fe,"TD",{});var hh=r(it);L=n(hh,"Canada"),hh.forEach(e),St=o(fe),vt=l(fe,"TD",{});var ch=r(vt);y=n(ch,"12/16/2020"),ch.forEach(e),W=o(fe),ft=l(fe,"TD",{});var ih=r(ft);Ht=n(ih,"Blue"),ih.forEach(e),fe.forEach(e),K=o(k),B=l(k,"TR",{});var _e=r(B);_t=l(_e,"TH",{});var vh=r(_t);Q=n(vh,"2"),vh.forEach(e),nt=o(_e),ut=l(_e,"TD",{});var fh=r(ut);Z=n(fh,"Hart Hagerty"),fh.forEach(e),U=o(_e),F=l(_e,"TD",{});var _h=r(F);at=n(_h,"Desktop Support Technician"),_h.forEach(e),lt=o(_e),kt=l(_e,"TD",{});var uh=r(kt);g=n(uh,"Zemlak, Daniel and Leannon"),uh.forEach(e),Tt=o(_e),pt=l(_e,"TD",{});var Th=r(pt);Rt=n(Th,"United States"),Th.forEach(e),P=o(_e),w=l(_e,"TD",{});var ph=r(w);Vt=n(ph,"12/5/2020"),ph.forEach(e),wt=o(_e),Et=l(_e,"TD",{});var Eh=r(Et);Gt=n(Eh,"Purple"),Eh.forEach(e),_e.forEach(e),C=o(k),V=l(k,"TR",{});var ue=r(V);xt=l(ue,"TH",{});var mh=r(xt);Ft=n(mh,"3"),mh.forEach(e),mt=o(ue),S=l(ue,"TD",{});var bh=r(S);Nt=n(bh,"Brice Swyre"),bh.forEach(e),Mt=o(ue),bt=l(ue,"TD",{});var Dh=r(bt);zt=n(Dh,"Tax Accountant"),Dh.forEach(e),Tl=o(ue),ze=l(ue,"TD",{});var $h=r(ze);pl=n($h,"Carroll Group"),$h.forEach(e),El=o(ue),Oe=l(ue,"TD",{});var yh=r(Oe);Ze=n(yh,"China"),yh.forEach(e),ml=o(ue),va=l(ue,"TD",{});var gh=r(va);Wt=n(gh,"8/15/2020"),gh.forEach(e),fa=o(ue),We=l(ue,"TD",{});var Sh=r(We);_a=n(Sh,"Red"),Sh.forEach(e),ue.forEach(e),bl=o(k),Ct=l(k,"TR",{});var Te=r(Ct);oe=l(Te,"TH",{});var Hh=r(oe);je=n(Hh,"4"),Hh.forEach(e),Xe=o(Te),Be=l(Te,"TD",{});var wh=r(Be);zl=n(wh,"Marjy Ferencz"),wh.forEach(e),Dl=o(Te),Pe=l(Te,"TD",{});var Ch=r(Pe);ta=n(Ch,"Office Assistant I"),Ch.forEach(e),$l=o(Te),ua=l(Te,"TD",{});var Rh=r(ua);ea=n(Rh,"Rowe-Schoen"),Rh.forEach(e),yl=o(Te),Ta=l(Te,"TD",{});var kh=r(Ta);Le=n(kh,"Russia"),kh.forEach(e),gl=o(Te),pa=l(Te,"TD",{});var xh=r(pa);Sl=n(xh,"3/25/2021"),xh.forEach(e),aa=o(Te),Ea=l(Te,"TD",{});var Ih=r(Ea);Hl=n(Ih,"Crimson"),Ih.forEach(e),Te.forEach(e),ma=o(k),It=l(k,"TR",{});var pe=r(It);ba=l(pe,"TH",{});var Ah=r(ba);Da=n(Ah,"5"),Ah.forEach(e),la=o(pe),$a=l(pe,"TD",{});var Ph=r($a);wl=n(Ph,"Yancy Tear"),Ph.forEach(e),Jt=o(pe),Je=l(pe,"TD",{});var Bh=r(Je);ya=n(Bh,"Community Outreach Specialist"),Bh.forEach(e),ga=o(pe),Sa=l(pe,"TD",{});var Lh=r(Sa);Ha=n(Lh,"Wyman-Ledner"),Lh.forEach(e),Ve=o(pe),Ge=l(pe,"TD",{});var Vh=r(Ge);ra=n(Vh,"Brazil"),Vh.forEach(e),da=o(pe),Na=l(pe,"TD",{});var Gh=r(Na);Cl=n(Gh,"5/22/2020"),Gh.forEach(e),Ke=o(pe),Fe=l(pe,"TD",{});var Fh=r(Fe);Rl=n(Fh,"Indigo"),Fh.forEach(e),pe.forEach(e),kl=o(k),Dt=l(k,"TR",{});var Ee=r(Dt);wa=l(Ee,"TH",{});var Nh=r(wa);xl=n(Nh,"6"),Nh.forEach(e),Ne=o(Ee),Ca=l(Ee,"TD",{});var Mh=r(Ca);Il=n(Mh,"Irma Vasilik"),Mh.forEach(e),Al=o(Ee),Me=l(Ee,"TD",{});var zh=r(Me);Pl=n(zh,"Editor"),zh.forEach(e),Bl=o(Ee),Qe=l(Ee,"TD",{});var Oh=r(Qe);Ll=n(Oh,"Wiza, Bins and Emard"),Oh.forEach(e),Vl=o(Ee),Ue=l(Ee,"TD",{});var Wh=r(Ue);oa=n(Wh,"Venezuela"),Wh.forEach(e),Gl=o(Ee),Ra=l(Ee,"TD",{});var Jh=r(Ra);ka=n(Jh,"12/8/2020"),Jh.forEach(e),Kt=o(Ee),sa=l(Ee,"TD",{});var Kh=r(sa);Fl=n(Kh,"Purple"),Kh.forEach(e),Ee.forEach(e),xa=o(k),At=l(k,"TR",{});var me=r(At);Ia=l(me,"TH",{});var Qh=r(Ia);Aa=n(Qh,"7"),Qh.forEach(e),Nl=o(me),Pa=l(me,"TD",{});var Uh=r(Pa);Ba=n(Uh,"Meghann Durtnal"),Uh.forEach(e),Ml=o(me),La=l(me,"TD",{});var qh=r(La);Ma=n(qh,"Staff Accountant IV"),qh.forEach(e),Va=o(me),na=l(me,"TD",{});var Yh=r(na);ha=n(Yh,"Schuster-Schimmel"),Yh.forEach(e),Ol=o(me),re=l(me,"TD",{});var Zh=r(re);Wl=n(Zh,"Philippines"),Zh.forEach(e),Jl=o(me),za=l(me,"TD",{});var jh=r(za);Kl=n(jh,"2/17/2021"),jh.forEach(e),Ql=o(me),se=l(me,"TD",{});var Xh=r(se);ne=n(Xh,"Yellow"),Xh.forEach(e),me.forEach(e),Ul=o(k),Pt=l(k,"TR",{});var be=r(Pt);Oa=l(be,"TH",{});var tc=r(Oa);Wa=n(tc,"8"),tc.forEach(e),ql=o(be),Ja=l(be,"TD",{});var ec=r(Ja);Ka=n(ec,"Sammy Seston"),ec.forEach(e),Yl=o(be),Qa=l(be,"TD",{});var ac=r(Qa);Ga=n(ac,"Accountant I"),ac.forEach(e),Zl=o(be),Ua=l(be,"TD",{});var lc=r(Ua);jl=n(lc,"O'Hara, Welch and Keebler"),lc.forEach(e),Xl=o(be),de=l(be,"TD",{});var rc=r(de);tr=n(rc,"Indonesia"),rc.forEach(e),er=o(be),qa=l(be,"TD",{});var dc=r(qa);Ya=n(dc,"5/23/2020"),dc.forEach(e),ar=o(be),Za=l(be,"TD",{});var oc=r(Za);ja=n(oc,"Crimson"),oc.forEach(e),be.forEach(e),lr=o(k),Bt=l(k,"TR",{});var De=r(Bt);qe=l(De,"TH",{});var sc=r(qe);rr=n(sc,"9"),sc.forEach(e),dr=o(De),Xa=l(De,"TD",{});var nc=r(Xa);or=n(nc,"Lesya Tinham"),nc.forEach(e),he=o(De),tl=l(De,"TD",{});var hc=r(tl);sr=n(hc,"Safety Technician IV"),hc.forEach(e),nr=o(De),ca=l(De,"TD",{});var cc=r(ca);hr=n(cc,"Turner-Kuhlman"),cc.forEach(e),cr=o(De),ia=l(De,"TD",{});var ic=r(ia);ir=n(ic,"Philippines"),ic.forEach(e),vr=o(De),Ye=l(De,"TD",{});var vc=r(Ye);fr=n(vc,"2/21/2021"),vc.forEach(e),_r=o(De),el=l(De,"TD",{});var fc=r(el);ur=n(fc,"Maroon"),fc.forEach(e),De.forEach(e),ce=o(k),Lt=l(k,"TR",{});var $e=r(Lt);al=l($e,"TH",{});var _c=r(al);Tr=n(_c,"10"),_c.forEach(e),ll=o($e),rl=l($e,"TD",{});var uc=r(rl);pr=n(uc,"Zaneta Tewkesbury"),uc.forEach(e),dl=o($e),ol=l($e,"TD",{});var Tc=r(ol);Er=n(Tc,"VP Marketing"),Tc.forEach(e),Fa=o($e),sl=l($e,"TD",{});var pc=r(sl);mr=n(pc,"Sauer LLC"),pc.forEach(e),br=o($e),nl=l($e,"TD",{});var Ec=r(nl);Dr=n(Ec,"Chad"),Ec.forEach(e),ie=o($e),hl=l($e,"TD",{});var mc=r(hl);$r=n(mc,"6/23/2020"),mc.forEach(e),yr=o($e),Rr=l($e,"TD",{});var bc=r(Rr);lo=n(bc,"Green"),bc.forEach(e),$e.forEach(e),ro=o(k),Qt=l(k,"TR",{});var ye=r(Qt);kr=l(ye,"TH",{});var Dc=r(kr);oo=n(Dc,"11"),Dc.forEach(e),so=o(ye),xr=l(ye,"TD",{});var $c=r(xr);no=n($c,"Andy Tipple"),$c.forEach(e),ho=o(ye),Ir=l(ye,"TD",{});var yc=r(Ir);co=n(yc,"Librarian"),yc.forEach(e),io=o(ye),Ar=l(ye,"TD",{});var gc=r(Ar);vo=n(gc,"Hilpert Group"),gc.forEach(e),fo=o(ye),Pr=l(ye,"TD",{});var Sc=r(Pr);_o=n(Sc,"Poland"),Sc.forEach(e),uo=o(ye),Br=l(ye,"TD",{});var Hc=r(Br);To=n(Hc,"7/9/2020"),Hc.forEach(e),po=o(ye),Lr=l(ye,"TD",{});var wc=r(Lr);Eo=n(wc,"Indigo"),wc.forEach(e),ye.forEach(e),mo=o(k),Ut=l(k,"TR",{});var ge=r(Ut);Vr=l(ge,"TH",{});var Cc=r(Vr);bo=n(Cc,"12"),Cc.forEach(e),Do=o(ge),Gr=l(ge,"TD",{});var Rc=r(Gr);$o=n(Rc,"Sophi Biles"),Rc.forEach(e),yo=o(ge),Fr=l(ge,"TD",{});var kc=r(Fr);go=n(kc,"Recruiting Manager"),kc.forEach(e),So=o(ge),Nr=l(ge,"TD",{});var xc=r(Nr);Ho=n(xc,"Gutmann Inc"),xc.forEach(e),wo=o(ge),Mr=l(ge,"TD",{});var Ic=r(Mr);Co=n(Ic,"Indonesia"),Ic.forEach(e),Ro=o(ge),zr=l(ge,"TD",{});var Ac=r(zr);ko=n(Ac,"2/12/2021"),Ac.forEach(e),xo=o(ge),Or=l(ge,"TD",{});var Pc=r(Or);Io=n(Pc,"Maroon"),Pc.forEach(e),ge.forEach(e),Ao=o(k),qt=l(k,"TR",{});var Se=r(qt);Wr=l(Se,"TH",{});var Bc=r(Wr);Po=n(Bc,"13"),Bc.forEach(e),Bo=o(Se),Jr=l(Se,"TD",{});var Lc=r(Jr);Lo=n(Lc,"Florida Garces"),Lc.forEach(e),Vo=o(Se),Kr=l(Se,"TD",{});var Vc=r(Kr);Go=n(Vc,"Web Developer IV"),Vc.forEach(e),Fo=o(Se),Qr=l(Se,"TD",{});var Gc=r(Qr);No=n(Gc,"Gaylord, Pacocha and Baumbach"),Gc.forEach(e),Mo=o(Se),Ur=l(Se,"TD",{});var Fc=r(Ur);zo=n(Fc,"Poland"),Fc.forEach(e),Oo=o(Se),qr=l(Se,"TD",{});var Nc=r(qr);Wo=n(Nc,"5/31/2020"),Nc.forEach(e),Jo=o(Se),Yr=l(Se,"TD",{});var Mc=r(Yr);Ko=n(Mc,"Purple"),Mc.forEach(e),Se.forEach(e),Qo=o(k),Yt=l(k,"TR",{});var He=r(Yt);Zr=l(He,"TH",{});var zc=r(Zr);Uo=n(zc,"14"),zc.forEach(e),qo=o(He),jr=l(He,"TD",{});var Oc=r(jr);Yo=n(Oc,"Maribeth Popping"),Oc.forEach(e),Zo=o(He),Xr=l(He,"TD",{});var Wc=r(Xr);jo=n(Wc,"Analyst Programmer"),Wc.forEach(e),Xo=o(He),td=l(He,"TD",{});var Jc=r(td);ts=n(Jc,"Deckow-Pouros"),Jc.forEach(e),es=o(He),ed=l(He,"TD",{});var Kc=r(ed);as=n(Kc,"Portugal"),Kc.forEach(e),ls=o(He),ad=l(He,"TD",{});var Qc=r(ad);rs=n(Qc,"4/27/2021"),Qc.forEach(e),ds=o(He),ld=l(He,"TD",{});var Uc=r(ld);os=n(Uc,"Aquamarine"),Uc.forEach(e),He.forEach(e),ss=o(k),Zt=l(k,"TR",{});var we=r(Zt);rd=l(we,"TH",{});var qc=r(rd);ns=n(qc,"15"),qc.forEach(e),hs=o(we),dd=l(we,"TD",{});var Yc=r(dd);cs=n(Yc,"Moritz Dryburgh"),Yc.forEach(e),is=o(we),od=l(we,"TD",{});var Zc=r(od);vs=n(Zc,"Dental Hygienist"),Zc.forEach(e),fs=o(we),sd=l(we,"TD",{});var jc=r(sd);_s=n(jc,"Schiller, Cole and Hackett"),jc.forEach(e),us=o(we),nd=l(we,"TD",{});var Xc=r(nd);Ts=n(Xc,"Sri Lanka"),Xc.forEach(e),ps=o(we),hd=l(we,"TD",{});var ti=r(hd);Es=n(ti,"8/8/2020"),ti.forEach(e),ms=o(we),cd=l(we,"TD",{});var ei=r(cd);bs=n(ei,"Crimson"),ei.forEach(e),we.forEach(e),Ds=o(k),jt=l(k,"TR",{});var Ce=r(jt);id=l(Ce,"TH",{});var ai=r(id);$s=n(ai,"16"),ai.forEach(e),ys=o(Ce),vd=l(Ce,"TD",{});var li=r(vd);gs=n(li,"Reid Semiras"),li.forEach(e),Ss=o(Ce),fd=l(Ce,"TD",{});var ri=r(fd);Hs=n(ri,"Teacher"),ri.forEach(e),ws=o(Ce),_d=l(Ce,"TD",{});var di=r(_d);Cs=n(di,"Sporer, Sipes and Rogahn"),di.forEach(e),Rs=o(Ce),ud=l(Ce,"TD",{});var oi=r(ud);ks=n(oi,"Poland"),oi.forEach(e),xs=o(Ce),Td=l(Ce,"TD",{});var si=r(Td);Is=n(si,"7/30/2020"),si.forEach(e),As=o(Ce),pd=l(Ce,"TD",{});var ni=r(pd);Ps=n(ni,"Green"),ni.forEach(e),Ce.forEach(e),Bs=o(k),Xt=l(k,"TR",{});var Re=r(Xt);Ed=l(Re,"TH",{});var hi=r(Ed);Ls=n(hi,"17"),hi.forEach(e),Vs=o(Re),md=l(Re,"TD",{});var ci=r(md);Gs=n(ci,"Alec Lethby"),ci.forEach(e),Fs=o(Re),bd=l(Re,"TD",{});var ii=r(bd);Ns=n(ii,"Teacher"),ii.forEach(e),Ms=o(Re),Dd=l(Re,"TD",{});var vi=r(Dd);zs=n(vi,"Reichel, Glover and Hamill"),vi.forEach(e),Os=o(Re),$d=l(Re,"TD",{});var fi=r($d);Ws=n(fi,"China"),fi.forEach(e),Js=o(Re),yd=l(Re,"TD",{});var _i=r(yd);Ks=n(_i,"2/28/2021"),_i.forEach(e),Qs=o(Re),gd=l(Re,"TD",{});var ui=r(gd);Us=n(ui,"Khaki"),ui.forEach(e),Re.forEach(e),qs=o(k),te=l(k,"TR",{});var ke=r(te);Sd=l(ke,"TH",{});var Ti=r(Sd);Ys=n(Ti,"18"),Ti.forEach(e),Zs=o(ke),Hd=l(ke,"TD",{});var pi=r(Hd);js=n(pi,"Aland Wilber"),pi.forEach(e),Xs=o(ke),wd=l(ke,"TD",{});var Ei=r(wd);tn=n(Ei,"Quality Control Specialist"),Ei.forEach(e),en=o(ke),Cd=l(ke,"TD",{});var mi=r(Cd);an=n(mi,"Kshlerin, Rogahn and Swaniawski"),mi.forEach(e),ln=o(ke),Rd=l(ke,"TD",{});var bi=r(Rd);rn=n(bi,"Czech Republic"),bi.forEach(e),dn=o(ke),kd=l(ke,"TD",{});var Di=r(kd);on=n(Di,"9/29/2020"),Di.forEach(e),sn=o(ke),xd=l(ke,"TD",{});var $i=r(xd);nn=n($i,"Purple"),$i.forEach(e),ke.forEach(e),hn=o(k),ee=l(k,"TR",{});var xe=r(ee);Id=l(xe,"TH",{});var yi=r(Id);cn=n(yi,"19"),yi.forEach(e),vn=o(xe),Ad=l(xe,"TD",{});var gi=r(Ad);fn=n(gi,"Teddie Duerden"),gi.forEach(e),_n=o(xe),Pd=l(xe,"TD",{});var Si=r(Pd);un=n(Si,"Staff Accountant III"),Si.forEach(e),Tn=o(xe),Bd=l(xe,"TD",{});var Hi=r(Bd);pn=n(Hi,"Pouros, Ullrich and Windler"),Hi.forEach(e),En=o(xe),Ld=l(xe,"TD",{});var wi=r(Ld);mn=n(wi,"France"),wi.forEach(e),bn=o(xe),Vd=l(xe,"TD",{});var Ci=r(Vd);Dn=n(Ci,"10/27/2020"),Ci.forEach(e),$n=o(xe),Gd=l(xe,"TD",{});var Ri=r(Gd);yn=n(Ri,"Aquamarine"),Ri.forEach(e),xe.forEach(e),gn=o(k),ae=l(k,"TR",{});var Ie=r(ae);Fd=l(Ie,"TH",{});var ki=r(Fd);Sn=n(ki,"20"),ki.forEach(e),Hn=o(Ie),Nd=l(Ie,"TD",{});var xi=r(Nd);wn=n(xi,"Lorelei Blackstone"),xi.forEach(e),Cn=o(Ie),Md=l(Ie,"TD",{});var Ii=r(Md);Rn=n(Ii,"Data Coordinator"),Ii.forEach(e),kn=o(Ie),zd=l(Ie,"TD",{});var Ai=r(zd);xn=n(Ai,"Witting, Kutch and Greenfelder"),Ai.forEach(e),In=o(Ie),Od=l(Ie,"TD",{});var Pi=r(Od);An=n(Pi,"Kazakhstan"),Pi.forEach(e),Pn=o(Ie),Wd=l(Ie,"TD",{});var Bi=r(Wd);Bn=n(Bi,"6/3/2020"),Bi.forEach(e),Ln=o(Ie),Jd=l(Ie,"TD",{});var Li=r(Jd);Vn=n(Li,"Red"),Li.forEach(e),Ie.forEach(e),k.forEach(e),Gn=o(gr),Kd=l(gr,"TFOOT",{});var Vi=r(Kd);le=l(Vi,"TR",{});var Ae=r(le);to=l(Ae,"TH",{}),r(to).forEach(e),Fn=o(Ae),Qd=l(Ae,"TH",{});var Gi=r(Qd);Nn=n(Gi,"Name"),Gi.forEach(e),Mn=o(Ae),Ud=l(Ae,"TH",{});var Fi=r(Ud);zn=n(Fi,"Job"),Fi.forEach(e),On=o(Ae),qd=l(Ae,"TH",{});var Ni=r(qd);Wn=n(Ni,"company"),Ni.forEach(e),Jn=o(Ae),Yd=l(Ae,"TH",{});var Mi=r(Yd);Kn=n(Mi,"location"),Mi.forEach(e),Qn=o(Ae),Zd=l(Ae,"TH",{});var zi=r(Zd);Un=n(zi,"Last Login"),zi.forEach(e),qn=o(Ae),jd=l(Ae,"TH",{});var Oi=r(jd);Yn=n(Oi,"Favorite Color"),Oi.forEach(e),Ae.forEach(e),Vi.forEach(e),gr.forEach(e),eo.forEach(e),this.h()},h(){E(f,"class","table table-compact w-full"),E(h,"class","overflow-x-auto")},m(Xd,eo){Ot(Xd,h,eo),t(h,f),t(f,T),t(T,c),t(c,_),t(c,$),t(c,i),t(i,p),t(c,N),t(c,I),t(I,q),t(c,j),t(c,R),t(R,rt),t(c,v),t(c,u),t(u,D),t(c,G),t(c,dt),t(dt,M),t(c,H),t(c,X),t(X,ht),t(f,J),t(f,m),t(m,x),t(x,A),t(A,ot),t(x,st),t(x,b),t(b,tt),t(x,$t),t(x,et),t(et,z),t(x,yt),t(x,ct),t(ct,O),t(x,gt),t(x,it),t(it,L),t(x,St),t(x,vt),t(vt,y),t(x,W),t(x,ft),t(ft,Ht),t(m,K),t(m,B),t(B,_t),t(_t,Q),t(B,nt),t(B,ut),t(ut,Z),t(B,U),t(B,F),t(F,at),t(B,lt),t(B,kt),t(kt,g),t(B,Tt),t(B,pt),t(pt,Rt),t(B,P),t(B,w),t(w,Vt),t(B,wt),t(B,Et),t(Et,Gt),t(m,C),t(m,V),t(V,xt),t(xt,Ft),t(V,mt),t(V,S),t(S,Nt),t(V,Mt),t(V,bt),t(bt,zt),t(V,Tl),t(V,ze),t(ze,pl),t(V,El),t(V,Oe),t(Oe,Ze),t(V,ml),t(V,va),t(va,Wt),t(V,fa),t(V,We),t(We,_a),t(m,bl),t(m,Ct),t(Ct,oe),t(oe,je),t(Ct,Xe),t(Ct,Be),t(Be,zl),t(Ct,Dl),t(Ct,Pe),t(Pe,ta),t(Ct,$l),t(Ct,ua),t(ua,ea),t(Ct,yl),t(Ct,Ta),t(Ta,Le),t(Ct,gl),t(Ct,pa),t(pa,Sl),t(Ct,aa),t(Ct,Ea),t(Ea,Hl),t(m,ma),t(m,It),t(It,ba),t(ba,Da),t(It,la),t(It,$a),t($a,wl),t(It,Jt),t(It,Je),t(Je,ya),t(It,ga),t(It,Sa),t(Sa,Ha),t(It,Ve),t(It,Ge),t(Ge,ra),t(It,da),t(It,Na),t(Na,Cl),t(It,Ke),t(It,Fe),t(Fe,Rl),t(m,kl),t(m,Dt),t(Dt,wa),t(wa,xl),t(Dt,Ne),t(Dt,Ca),t(Ca,Il),t(Dt,Al),t(Dt,Me),t(Me,Pl),t(Dt,Bl),t(Dt,Qe),t(Qe,Ll),t(Dt,Vl),t(Dt,Ue),t(Ue,oa),t(Dt,Gl),t(Dt,Ra),t(Ra,ka),t(Dt,Kt),t(Dt,sa),t(sa,Fl),t(m,xa),t(m,At),t(At,Ia),t(Ia,Aa),t(At,Nl),t(At,Pa),t(Pa,Ba),t(At,Ml),t(At,La),t(La,Ma),t(At,Va),t(At,na),t(na,ha),t(At,Ol),t(At,re),t(re,Wl),t(At,Jl),t(At,za),t(za,Kl),t(At,Ql),t(At,se),t(se,ne),t(m,Ul),t(m,Pt),t(Pt,Oa),t(Oa,Wa),t(Pt,ql),t(Pt,Ja),t(Ja,Ka),t(Pt,Yl),t(Pt,Qa),t(Qa,Ga),t(Pt,Zl),t(Pt,Ua),t(Ua,jl),t(Pt,Xl),t(Pt,de),t(de,tr),t(Pt,er),t(Pt,qa),t(qa,Ya),t(Pt,ar),t(Pt,Za),t(Za,ja),t(m,lr),t(m,Bt),t(Bt,qe),t(qe,rr),t(Bt,dr),t(Bt,Xa),t(Xa,or),t(Bt,he),t(Bt,tl),t(tl,sr),t(Bt,nr),t(Bt,ca),t(ca,hr),t(Bt,cr),t(Bt,ia),t(ia,ir),t(Bt,vr),t(Bt,Ye),t(Ye,fr),t(Bt,_r),t(Bt,el),t(el,ur),t(m,ce),t(m,Lt),t(Lt,al),t(al,Tr),t(Lt,ll),t(Lt,rl),t(rl,pr),t(Lt,dl),t(Lt,ol),t(ol,Er),t(Lt,Fa),t(Lt,sl),t(sl,mr),t(Lt,br),t(Lt,nl),t(nl,Dr),t(Lt,ie),t(Lt,hl),t(hl,$r),t(Lt,yr),t(Lt,Rr),t(Rr,lo),t(m,ro),t(m,Qt),t(Qt,kr),t(kr,oo),t(Qt,so),t(Qt,xr),t(xr,no),t(Qt,ho),t(Qt,Ir),t(Ir,co),t(Qt,io),t(Qt,Ar),t(Ar,vo),t(Qt,fo),t(Qt,Pr),t(Pr,_o),t(Qt,uo),t(Qt,Br),t(Br,To),t(Qt,po),t(Qt,Lr),t(Lr,Eo),t(m,mo),t(m,Ut),t(Ut,Vr),t(Vr,bo),t(Ut,Do),t(Ut,Gr),t(Gr,$o),t(Ut,yo),t(Ut,Fr),t(Fr,go),t(Ut,So),t(Ut,Nr),t(Nr,Ho),t(Ut,wo),t(Ut,Mr),t(Mr,Co),t(Ut,Ro),t(Ut,zr),t(zr,ko),t(Ut,xo),t(Ut,Or),t(Or,Io),t(m,Ao),t(m,qt),t(qt,Wr),t(Wr,Po),t(qt,Bo),t(qt,Jr),t(Jr,Lo),t(qt,Vo),t(qt,Kr),t(Kr,Go),t(qt,Fo),t(qt,Qr),t(Qr,No),t(qt,Mo),t(qt,Ur),t(Ur,zo),t(qt,Oo),t(qt,qr),t(qr,Wo),t(qt,Jo),t(qt,Yr),t(Yr,Ko),t(m,Qo),t(m,Yt),t(Yt,Zr),t(Zr,Uo),t(Yt,qo),t(Yt,jr),t(jr,Yo),t(Yt,Zo),t(Yt,Xr),t(Xr,jo),t(Yt,Xo),t(Yt,td),t(td,ts),t(Yt,es),t(Yt,ed),t(ed,as),t(Yt,ls),t(Yt,ad),t(ad,rs),t(Yt,ds),t(Yt,ld),t(ld,os),t(m,ss),t(m,Zt),t(Zt,rd),t(rd,ns),t(Zt,hs),t(Zt,dd),t(dd,cs),t(Zt,is),t(Zt,od),t(od,vs),t(Zt,fs),t(Zt,sd),t(sd,_s),t(Zt,us),t(Zt,nd),t(nd,Ts),t(Zt,ps),t(Zt,hd),t(hd,Es),t(Zt,ms),t(Zt,cd),t(cd,bs),t(m,Ds),t(m,jt),t(jt,id),t(id,$s),t(jt,ys),t(jt,vd),t(vd,gs),t(jt,Ss),t(jt,fd),t(fd,Hs),t(jt,ws),t(jt,_d),t(_d,Cs),t(jt,Rs),t(jt,ud),t(ud,ks),t(jt,xs),t(jt,Td),t(Td,Is),t(jt,As),t(jt,pd),t(pd,Ps),t(m,Bs),t(m,Xt),t(Xt,Ed),t(Ed,Ls),t(Xt,Vs),t(Xt,md),t(md,Gs),t(Xt,Fs),t(Xt,bd),t(bd,Ns),t(Xt,Ms),t(Xt,Dd),t(Dd,zs),t(Xt,Os),t(Xt,$d),t($d,Ws),t(Xt,Js),t(Xt,yd),t(yd,Ks),t(Xt,Qs),t(Xt,gd),t(gd,Us),t(m,qs),t(m,te),t(te,Sd),t(Sd,Ys),t(te,Zs),t(te,Hd),t(Hd,js),t(te,Xs),t(te,wd),t(wd,tn),t(te,en),t(te,Cd),t(Cd,an),t(te,ln),t(te,Rd),t(Rd,rn),t(te,dn),t(te,kd),t(kd,on),t(te,sn),t(te,xd),t(xd,nn),t(m,hn),t(m,ee),t(ee,Id),t(Id,cn),t(ee,vn),t(ee,Ad),t(Ad,fn),t(ee,_n),t(ee,Pd),t(Pd,un),t(ee,Tn),t(ee,Bd),t(Bd,pn),t(ee,En),t(ee,Ld),t(Ld,mn),t(ee,bn),t(ee,Vd),t(Vd,Dn),t(ee,$n),t(ee,Gd),t(Gd,yn),t(m,gn),t(m,ae),t(ae,Fd),t(Fd,Sn),t(ae,Hn),t(ae,Nd),t(Nd,wn),t(ae,Cn),t(ae,Md),t(Md,Rn),t(ae,kn),t(ae,zd),t(zd,xn),t(ae,In),t(ae,Od),t(Od,An),t(ae,Pn),t(ae,Wd),t(Wd,Bn),t(ae,Ln),t(ae,Jd),t(Jd,Vn),t(f,Gn),t(f,Kd),t(Kd,le),t(le,to),t(le,Fn),t(le,Qd),t(Qd,Nn),t(le,Mn),t(le,Ud),t(Ud,zn),t(le,On),t(le,qd),t(qd,Wn),t(le,Jn),t(le,Yd),t(Yd,Kn),t(le,Qn),t(le,Zd),t(Zd,Un),t(le,qn),t(le,jd),t(jd,Yn)},d(Xd){Xd&&e(h)}}}function v1(Y){let h,f=`<div class="overflow-x-auto">
  <table class="$$table $$table-compact w-full">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,T,c,_,$;return{c(){h=a("pre"),T=s(f),this.h()},l(i){h=l(i,"PRE",{slot:!0});var p=r(h);T=n(p,f),p.forEach(e),this.h()},h(){E(h,"slot","html")},m(i,p){Ot(i,h,p),t(h,T),_||($=Hr(c=Cr.call(null,h,{to:Y[0]})),_=!0)},p(i,p){c&&wr(c.update)&&p&1&&c.update.call(null,{to:i[0]})},d(i){i&&e(h),_=!1,$()}}}function f1(Y){let h,f,T,c,_,$,i,p,N,I,q,j,R,rt;return h=new t1({props:{data:[{type:"component",class:"table",desc:"For <table> element"},{type:"modifier",class:"table-zebra",desc:"For the active tab"},{type:"modifier",class:"active",desc:"For <tr> to highlight current row"},{type:"modifier",class:"hover",desc:"For <tr> to highlight current row on hover"},{type:"responsive",class:"table-normal",desc:"Normal paddings"},{type:"responsive",class:"table-compact",desc:"Compact paddings"}]}}),T=new Sr({props:{title:"Table",$$slots:{html:[a1],default:[e1]},$$scope:{ctx:Y}}}),_=new Sr({props:{title:"Table with an active row",$$slots:{html:[r1],default:[l1]},$$scope:{ctx:Y}}}),i=new Sr({props:{title:"Table with a row that highlights on hover",$$slots:{html:[o1],default:[d1]},$$scope:{ctx:Y}}}),N=new Sr({props:{title:"Zebra",$$slots:{html:[n1],default:[s1]},$$scope:{ctx:Y}}}),q=new Sr({props:{title:"Table with visual elements",$$slots:{html:[c1],default:[h1]},$$scope:{ctx:Y}}}),R=new Sr({props:{title:"Compact table",$$slots:{html:[v1],default:[i1]},$$scope:{ctx:Y}}}),{c(){cl(h.$$.fragment),f=d(),cl(T.$$.fragment),c=d(),cl(_.$$.fragment),$=d(),cl(i.$$.fragment),p=d(),cl(N.$$.fragment),I=d(),cl(q.$$.fragment),j=d(),cl(R.$$.fragment)},l(v){il(h.$$.fragment,v),f=o(v),il(T.$$.fragment,v),c=o(v),il(_.$$.fragment,v),$=o(v),il(i.$$.fragment,v),p=o(v),il(N.$$.fragment,v),I=o(v),il(q.$$.fragment,v),j=o(v),il(R.$$.fragment,v)},m(v,u){vl(h,v,u),Ot(v,f,u),vl(T,v,u),Ot(v,c,u),vl(_,v,u),Ot(v,$,u),vl(i,v,u),Ot(v,p,u),vl(N,v,u),Ot(v,I,u),vl(q,v,u),Ot(v,j,u),vl(R,v,u),rt=!0},p(v,u){const D={};u&5&&(D.$$scope={dirty:u,ctx:v}),T.$set(D);const G={};u&5&&(G.$$scope={dirty:u,ctx:v}),_.$set(G);const dt={};u&5&&(dt.$$scope={dirty:u,ctx:v}),i.$set(dt);const M={};u&5&&(M.$$scope={dirty:u,ctx:v}),N.$set(M);const H={};u&5&&(H.$$scope={dirty:u,ctx:v}),q.$set(H);const X={};u&5&&(X.$$scope={dirty:u,ctx:v}),R.$set(X)},i(v){rt||(fl(h.$$.fragment,v),fl(T.$$.fragment,v),fl(_.$$.fragment,v),fl(i.$$.fragment,v),fl(N.$$.fragment,v),fl(q.$$.fragment,v),fl(R.$$.fragment,v),rt=!0)},o(v){_l(h.$$.fragment,v),_l(T.$$.fragment,v),_l(_.$$.fragment,v),_l(i.$$.fragment,v),_l(N.$$.fragment,v),_l(q.$$.fragment,v),_l(R.$$.fragment,v),rt=!1},d(v){ul(h,v),v&&e(f),ul(T,v),v&&e(c),ul(_,v),v&&e($),ul(i,v),v&&e(p),ul(N,v),v&&e(I),ul(q,v),v&&e(j),ul(R,v)}}}function _1(Y){let h,f;const T=[Y[1],Ki];let c={$$slots:{default:[f1]},$$scope:{ctx:Y}};for(let _=0;_<T.length;_+=1)c=Zn(c,T[_]);return h=new ji({props:c}),{c(){cl(h.$$.fragment)},l(_){il(h.$$.fragment,_)},m(_,$){vl(h,_,$),f=!0},p(_,[$]){const i=$&2?Yi(T,[$&2&&Wi(_[1]),$&0&&Wi(Ki)]):{};$&5&&(i.$$scope={dirty:$,ctx:_}),h.$set(i)},i(_){f||(fl(h.$$.fragment,_),f=!0)},o(_){_l(h.$$.fragment,_),f=!1},d(_){ul(h,_)}}}const Ki={title:"Table",desc:"Table can be used to show a list of data in a table format.",published:!0};function u1(Y,h,f){let T;return Zi(Y,Xi,c=>f(0,T=c)),Y.$$set=c=>{f(1,h=Zn(Zn({},h),Ji(c)))},h=Ji(h),[T,h]}class S1 extends Qi{constructor(h){super();Ui(this,h,u1,_1,qi,{})}}export{S1 as default,Ki as metadata};
