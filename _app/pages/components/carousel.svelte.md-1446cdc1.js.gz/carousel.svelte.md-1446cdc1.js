import{S as ze,i as Pe,s as ye,C as je,w as ee,x as se,y as te,z as Be,A as Me,q as le,o as ae,B as ce,K as Re,ag as Ge,k as j,m as I,g as y,d as o,e as c,c as i,a as n,O as x,b as s,H as l,t as O,h as Q,a9 as W,Q as X}from"../../chunks/vendor-40028f80.js";import{M as Ae}from"../../chunks/_markdown-838d0ca0.js";import{p as qe,C as Fe,a as oe,r as Y}from"../../chunks/actions-aa558049.js";import"../../chunks/stores-1979741f.js";import"../../chunks/Ads-1858268c.js";import"../../chunks/index-48bceede.js";import"../../chunks/SEO-87ce5779.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-75b50054.js";function He(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"alt","Burger"),s(d,"class","carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"alt","Burger"),s(f,"class","carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"alt","Burger"),s(w,"class","carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Burger"),s(k,"class","carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"alt","Burger"),s(h,"class","carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Burger"),s(p,"class","carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"alt","Burger"),s(D,"class","carousel-item"),s(e,"class","carousel rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function Ke(S){let e,d=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Oe(S){let e,d=`<div className="$$carousel rounded-box">
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Qe(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"alt","Pizza"),s(d,"class","carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"alt","Pizza"),s(f,"class","carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"alt","Pizza"),s(w,"class","carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Pizza"),s(k,"class","carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"alt","Pizza"),s(h,"class","carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Pizza"),s(p,"class","carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"alt","Pizza"),s(D,"class","carousel-item"),s(e,"class","carousel carousel-center rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function Je(S){let e,d=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Le(S){let e,d=`<div className="$$carousel $$carousel-center rounded-box">
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Ue(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"alt","Drink"),s(d,"class","carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"alt","Drink"),s(f,"class","carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"alt","Drink"),s(w,"class","carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Drink"),s(k,"class","carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"alt","Drink"),s(h,"class","carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Drink"),s(p,"class","carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"alt","Drink"),s(D,"class","carousel-item"),s(e,"class","carousel carousel-end rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function We(S){let e,d=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Xe(S){let e,d=`<div className="$$carousel $$carousel-end rounded-box">
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function Ye(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,class:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,class:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"class","w-full"),s(r,"alt","Tailwind CSS carousel component"),s(d,"class","w-full carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"class","w-full"),s(t,"alt","Tailwind CSS carousel component"),s(f,"class","w-full carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"class","w-full"),s($,"alt","Tailwind CSS carousel component"),s(w,"class","w-full carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS carousel component"),s(k,"class","w-full carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"class","w-full"),s(_,"alt","Tailwind CSS carousel component"),s(h,"class","w-full carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","w-full"),s(E,"alt","Tailwind CSS carousel component"),s(p,"class","w-full carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"class","w-full"),s(N,"alt","Tailwind CSS carousel component"),s(D,"class","w-full carousel-item"),s(e,"class","w-64 carousel rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function Ze(S){let e,d=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function es(S){let e,d=`<div className="w-64 $$carousel rounded-box">
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div className="$$carousel-item w-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" className="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function ss(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"alt","Tailwind Image slider"),s(d,"class","carousel-item h-full"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"alt","Tailwind Image slider"),s(f,"class","carousel-item h-full"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"alt","Tailwind Image slider"),s(w,"class","carousel-item h-full"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Tailwind Image slider"),s(k,"class","carousel-item h-full"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"alt","Tailwind Image slider"),s(h,"class","carousel-item h-full"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Tailwind Image slider"),s(p,"class","carousel-item h-full"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"alt","Tailwind Image slider"),s(D,"class","carousel-item h-full"),s(e,"class","h-96 carousel carousel-vertical rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function ts(S){let e,d=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function ls(S){let e,d=`<div className="h-96 $$carousel $$carousel-vertical rounded-box">
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" />
  </div> 
  <div className="$$carousel-item h-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function as(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,class:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,class:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"class","w-full"),s(r,"alt","Tailwind CSS Image slider"),s(d,"class","w-1/2 carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"class","w-full"),s(t,"alt","Tailwind CSS Image slider"),s(f,"class","w-1/2 carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"class","w-full"),s($,"alt","Tailwind CSS Image slider"),s(w,"class","w-1/2 carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS Image slider"),s(k,"class","w-1/2 carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"class","w-full"),s(_,"alt","Tailwind CSS Image slider"),s(h,"class","w-1/2 carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","w-full"),s(E,"alt","Tailwind CSS Image slider"),s(p,"class","w-1/2 carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"class","w-full"),s(N,"alt","Tailwind CSS Image slider"),s(D,"class","w-1/2 carousel-item"),s(e,"class","w-96 carousel rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function cs(S){let e,d=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function is(S){let e,d=`<div className="$$carousel rounded-box w-96">
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" className="w-full" />
  </div> 
  <div className="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" className="w-full" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function rs(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("img"),g=j(),p=c("div"),E=c("img"),G=j(),D=c("div"),N=c("img"),this.h()},l(V){e=i(V,"DIV",{class:!0});var u=n(e);d=i(u,"DIV",{class:!0});var P=n(d);r=i(P,"IMG",{src:!0,class:!0,alt:!0}),P.forEach(o),m=I(u),f=i(u,"DIV",{class:!0});var K=n(f);t=i(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=I(u),w=i(u,"DIV",{class:!0});var J=n(w);$=i(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=I(u),k=i(u,"DIV",{class:!0});var L=n(k);b=i(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var q=n(h);_=i(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),g=I(u),p=i(u,"DIV",{class:!0});var R=n(p);E=i(R,"IMG",{src:!0,class:!0,alt:!0}),R.forEach(o),G=I(u),D=i(u,"DIV",{class:!0});var U=n(D);N=i(U,"IMG",{src:!0,class:!0,alt:!0}),U.forEach(o),u.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(r,"src",v),s(r,"class","rounded-box"),s(r,"alt","Tailwind CSS component"),s(d,"class","carousel-item"),x(t.src,a="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(t,"src",a),s(t,"class","rounded-box"),s(t,"alt","Tailwind CSS component"),s(f,"class","carousel-item"),x($.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s($,"src",F),s($,"class","rounded-box"),s($,"alt","Tailwind CSS component"),s(w,"class","carousel-item"),x(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","rounded-box"),s(b,"alt","Tailwind CSS component"),s(k,"class","carousel-item"),x(_.src,A="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s(_,"src",A),s(_,"class","rounded-box"),s(_,"alt","Tailwind CSS component"),s(h,"class","carousel-item"),x(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","rounded-box"),s(E,"alt","Tailwind CSS component"),s(p,"class","carousel-item"),x(N.src,z="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(N,"src",z),s(N,"class","rounded-box"),s(N,"alt","Tailwind CSS component"),s(D,"class","carousel-item"),s(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(V,u){y(V,e,u),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),l(e,M),l(e,h),l(h,_),l(e,g),l(e,p),l(p,E),l(e,G),l(e,D),l(D,N)},d(V){V&&o(e)}}}function os(S){let e,d=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function us(S){let e,d=`<div className="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" className="rounded-box" />
  </div> 
  <div className="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" className="rounded-box" />
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function ds(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z,V;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("img"),T=j(),w=c("div"),$=c("img"),C=j(),k=c("div"),b=c("img"),M=j(),h=c("div"),_=c("a"),A=O("1"),g=j(),p=c("a"),E=O("2"),B=j(),G=c("a"),D=O("3"),N=j(),z=c("a"),V=O("4"),this.h()},l(u){e=i(u,"DIV",{class:!0});var P=n(e);d=i(P,"DIV",{id:!0,class:!0});var K=n(d);r=i(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),m=I(P),f=i(P,"DIV",{id:!0,class:!0});var J=n(f);t=i(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),T=I(P),w=i(P,"DIV",{id:!0,class:!0});var L=n(w);$=i(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),C=I(P),k=i(P,"DIV",{id:!0,class:!0});var q=n(k);b=i(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),P.forEach(o),M=I(u),h=i(u,"DIV",{class:!0});var R=n(h);_=i(R,"A",{href:!0,class:!0});var U=n(_);A=Q(U,"1"),U.forEach(o),g=I(R),p=i(R,"A",{href:!0,class:!0});var de=n(p);E=Q(de,"2"),de.forEach(o),B=I(R),G=i(R,"A",{href:!0,class:!0});var Z=n(G);D=Q(Z,"3"),Z.forEach(o),N=I(R),z=i(R,"A",{href:!0,class:!0});var ie=n(z);V=Q(ie,"4"),ie.forEach(o),R.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg")||s(r,"src",v),s(r,"class","w-full"),s(r,"alt","Tailwind CSS image gallery"),s(d,"id","item1"),s(d,"class","w-full carousel-item"),x(t.src,a="/images/stock/photo-1609621838510-5ad474b7d25d.jpg")||s(t,"src",a),s(t,"class","w-full"),s(t,"alt","Tailwind CSS image gallery"),s(f,"id","item2"),s(f,"class","w-full carousel-item"),x($.src,F="/images/stock/photo-1414694762283-acccc27bca85.jpg")||s($,"src",F),s($,"class","w-full"),s($,"alt","Tailwind CSS image gallery"),s(w,"id","item3"),s(w,"class","w-full carousel-item"),x(b.src,H="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS image gallery"),s(k,"id","item4"),s(k,"class","w-full carousel-item"),s(e,"class","w-full carousel"),s(_,"href","#item1"),s(_,"class","btn btn-xs"),s(p,"href","#item2"),s(p,"class","btn btn-xs"),s(G,"href","#item3"),s(G,"class","btn btn-xs"),s(z,"href","#item4"),s(z,"class","btn btn-xs"),s(h,"class","flex justify-center w-full py-2 gap-2")},m(u,P){y(u,e,P),l(e,d),l(d,r),l(e,m),l(e,f),l(f,t),l(e,T),l(e,w),l(w,$),l(e,C),l(e,k),l(k,b),y(u,M,P),y(u,h,P),l(h,_),l(_,A),l(h,g),l(h,p),l(p,E),l(h,B),l(h,G),l(G,D),l(h,N),l(h,z),l(z,V)},d(u){u&&o(e),u&&o(M),u&&o(h)}}}function ms(S){let e,d=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function fs(S){let e,d=`<div className="$$carousel w-full">
  <div id="item1" className="$$carousel-item w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" className="w-full" />
  </div> 
  <div id="item2" className="$$carousel-item w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" className="w-full" />
  </div> 
  <div id="item3" className="$$carousel-item w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" className="w-full" />
  </div> 
  <div id="item4" className="$$carousel-item w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" className="w-full" />
  </div>
</div> 
<div className="flex justify-center w-full py-2 gap-2">
  <a href="#item1" className="$$btn $$btn-xs">1</a> 
  <a href="#item2" className="$$btn $$btn-xs">2</a> 
  <a href="#item3" className="$$btn $$btn-xs">3</a> 
  <a href="#item4" className="$$btn $$btn-xs">4</a>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function gs(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A,g,p,E,B,G,D,N,z,V,u,P,K,J,L,q,R,U,de,Z,ie,be,we,ue,ke;return{c(){e=c("div"),d=c("div"),r=c("img"),m=j(),f=c("div"),t=c("a"),a=O("\u276E"),T=j(),w=c("a"),$=O("\u276F"),F=j(),C=c("div"),k=c("img"),H=j(),M=c("div"),h=c("a"),_=O("\u276E"),A=j(),g=c("a"),p=O("\u276F"),E=j(),B=c("div"),G=c("img"),N=j(),z=c("div"),V=c("a"),u=O("\u276E"),P=j(),K=c("a"),J=O("\u276F"),L=j(),q=c("div"),R=c("img"),de=j(),Z=c("div"),ie=c("a"),be=O("\u276E"),we=j(),ue=c("a"),ke=O("\u276F"),this.h()},l(me){e=i(me,"DIV",{class:!0});var re=n(e);d=i(re,"DIV",{id:!0,class:!0});var fe=n(d);r=i(fe,"IMG",{src:!0,class:!0,alt:!0}),m=I(fe),f=i(fe,"DIV",{class:!0});var ge=n(f);t=i(ge,"A",{href:!0,class:!0});var Ie=n(t);a=Q(Ie,"\u276E"),Ie.forEach(o),T=I(ge),w=i(ge,"A",{href:!0,class:!0});var Ee=n(w);$=Q(Ee,"\u276F"),Ee.forEach(o),ge.forEach(o),fe.forEach(o),F=I(re),C=i(re,"DIV",{id:!0,class:!0});var ve=n(C);k=i(ve,"IMG",{src:!0,class:!0,alt:!0}),H=I(ve),M=i(ve,"DIV",{class:!0});var ne=n(M);h=i(ne,"A",{href:!0,class:!0});var Ne=n(h);_=Q(Ne,"\u276E"),Ne.forEach(o),A=I(ne),g=i(ne,"A",{href:!0,class:!0});var Se=n(g);p=Q(Se,"\u276F"),Se.forEach(o),ne.forEach(o),ve.forEach(o),E=I(re),B=i(re,"DIV",{id:!0,class:!0});var pe=n(B);G=i(pe,"IMG",{src:!0,class:!0,alt:!0}),N=I(pe),z=i(pe,"DIV",{class:!0});var he=n(z);V=i(he,"A",{href:!0,class:!0});var De=n(V);u=Q(De,"\u276E"),De.forEach(o),P=I(he),K=i(he,"A",{href:!0,class:!0});var xe=n(K);J=Q(xe,"\u276F"),xe.forEach(o),he.forEach(o),pe.forEach(o),L=I(re),q=i(re,"DIV",{id:!0,class:!0});var $e=n(q);R=i($e,"IMG",{src:!0,class:!0,alt:!0}),de=I($e),Z=i($e,"DIV",{class:!0});var _e=n(Z);ie=i(_e,"A",{href:!0,class:!0});var Ve=n(ie);be=Q(Ve,"\u276E"),Ve.forEach(o),we=I(_e),ue=i(_e,"A",{href:!0,class:!0});var Ce=n(ue);ke=Q(Ce,"\u276F"),Ce.forEach(o),_e.forEach(o),$e.forEach(o),re.forEach(o),this.h()},h(){x(r.src,v="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg")||s(r,"src",v),s(r,"class","w-full"),s(r,"alt","Tailwind CSS image slide"),s(t,"href","#slide4"),s(t,"class","btn btn-circle"),s(w,"href","#slide2"),s(w,"class","btn btn-circle"),s(f,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(d,"id","slide1"),s(d,"class","relative w-full carousel-item"),x(k.src,b="/images/stock/photo-1609621838510-5ad474b7d25d.jpg")||s(k,"src",b),s(k,"class","w-full"),s(k,"alt","Tailwind CSS image slide"),s(h,"href","#slide1"),s(h,"class","btn btn-circle"),s(g,"href","#slide3"),s(g,"class","btn btn-circle"),s(M,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(C,"id","slide2"),s(C,"class","relative w-full carousel-item"),x(G.src,D="/images/stock/photo-1414694762283-acccc27bca85.jpg")||s(G,"src",D),s(G,"class","w-full"),s(G,"alt","Tailwind CSS image slide"),s(V,"href","#slide2"),s(V,"class","btn btn-circle"),s(K,"href","#slide4"),s(K,"class","btn btn-circle"),s(z,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(B,"id","slide3"),s(B,"class","relative w-full carousel-item"),x(R.src,U="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg")||s(R,"src",U),s(R,"class","w-full"),s(R,"alt","Tailwind CSS image slide"),s(ie,"href","#slide3"),s(ie,"class","btn btn-circle"),s(ue,"href","#slide1"),s(ue,"class","btn btn-circle"),s(Z,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(q,"id","slide4"),s(q,"class","relative w-full carousel-item"),s(e,"class","w-full carousel")},m(me,re){y(me,e,re),l(e,d),l(d,r),l(d,m),l(d,f),l(f,t),l(t,a),l(f,T),l(f,w),l(w,$),l(e,F),l(e,C),l(C,k),l(C,H),l(C,M),l(M,h),l(h,_),l(M,A),l(M,g),l(g,p),l(e,E),l(e,B),l(B,G),l(B,N),l(B,z),l(z,V),l(V,u),l(z,P),l(z,K),l(K,J),l(e,L),l(e,q),l(q,R),l(q,de),l(q,Z),l(Z,ie),l(ie,be),l(Z,we),l(Z,ue),l(ue,ke)},d(me){me&&o(e)}}}function vs(S){let e,d=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","html")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function ns(S){let e,d=`<div className="$$carousel w-full">
  <div id="slide1" className="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" className="btn btn-circle">\u276E</a> 
      <a href="#slide2" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" className="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" className="btn btn-circle">\u276E</a> 
      <a href="#slide3" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" className="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" className="btn btn-circle">\u276E</a> 
      <a href="#slide4" className="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" className="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" className="w-full" />
    <div className="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" className="btn btn-circle">\u276E</a> 
      <a href="#slide1" className="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,r,v,m,f;return{c(){e=c("pre"),r=O(d),this.h()},l(t){e=i(t,"PRE",{slot:!0});var a=n(e);r=Q(a,d),a.forEach(o),this.h()},h(){s(e,"slot","react")},m(t,a){y(t,e,a),l(e,r),m||(f=W(v=Y.call(null,e,{to:S[0]})),m=!0)},p(t,a){v&&X(v.update)&&a&1&&v.update.call(null,{to:t[0]})},d(t){t&&o(e),m=!1,f()}}}function ps(S){let e,d,r,v,m,f,t,a,T,w,$,F,C,k,b,H,M,h,_,A;return e=new Fe({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),r=new oe({props:{title:"Snap to start (default)",$$slots:{react:[Oe],html:[Ke],default:[He]},$$scope:{ctx:S}}}),m=new oe({props:{title:"Snap to center",$$slots:{react:[Le],html:[Je],default:[Qe]},$$scope:{ctx:S}}}),t=new oe({props:{title:"Snap to end",$$slots:{react:[Xe],html:[We],default:[Ue]},$$scope:{ctx:S}}}),T=new oe({props:{title:"Carousel with full width items",$$slots:{react:[es],html:[Ze],default:[Ye]},$$scope:{ctx:S}}}),$=new oe({props:{title:"Vertical carousel",$$slots:{react:[ls],html:[ts],default:[ss]},$$scope:{ctx:S}}}),C=new oe({props:{title:"Carousel with half width items",$$slots:{react:[is],html:[cs],default:[as]},$$scope:{ctx:S}}}),b=new oe({props:{title:"Full-bleed carousel",$$slots:{react:[us],html:[os],default:[rs]},$$scope:{ctx:S}}}),M=new oe({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{react:[fs],html:[ms],default:[ds]},$$scope:{ctx:S}}}),_=new oe({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{react:[ns],html:[vs],default:[gs]},$$scope:{ctx:S}}}),{c(){ee(e.$$.fragment),d=j(),ee(r.$$.fragment),v=j(),ee(m.$$.fragment),f=j(),ee(t.$$.fragment),a=j(),ee(T.$$.fragment),w=j(),ee($.$$.fragment),F=j(),ee(C.$$.fragment),k=j(),ee(b.$$.fragment),H=j(),ee(M.$$.fragment),h=j(),ee(_.$$.fragment)},l(g){se(e.$$.fragment,g),d=I(g),se(r.$$.fragment,g),v=I(g),se(m.$$.fragment,g),f=I(g),se(t.$$.fragment,g),a=I(g),se(T.$$.fragment,g),w=I(g),se($.$$.fragment,g),F=I(g),se(C.$$.fragment,g),k=I(g),se(b.$$.fragment,g),H=I(g),se(M.$$.fragment,g),h=I(g),se(_.$$.fragment,g)},m(g,p){te(e,g,p),y(g,d,p),te(r,g,p),y(g,v,p),te(m,g,p),y(g,f,p),te(t,g,p),y(g,a,p),te(T,g,p),y(g,w,p),te($,g,p),y(g,F,p),te(C,g,p),y(g,k,p),te(b,g,p),y(g,H,p),te(M,g,p),y(g,h,p),te(_,g,p),A=!0},p(g,p){const E={};p&5&&(E.$$scope={dirty:p,ctx:g}),r.$set(E);const B={};p&5&&(B.$$scope={dirty:p,ctx:g}),m.$set(B);const G={};p&5&&(G.$$scope={dirty:p,ctx:g}),t.$set(G);const D={};p&5&&(D.$$scope={dirty:p,ctx:g}),T.$set(D);const N={};p&5&&(N.$$scope={dirty:p,ctx:g}),$.$set(N);const z={};p&5&&(z.$$scope={dirty:p,ctx:g}),C.$set(z);const V={};p&5&&(V.$$scope={dirty:p,ctx:g}),b.$set(V);const u={};p&5&&(u.$$scope={dirty:p,ctx:g}),M.$set(u);const P={};p&5&&(P.$$scope={dirty:p,ctx:g}),_.$set(P)},i(g){A||(le(e.$$.fragment,g),le(r.$$.fragment,g),le(m.$$.fragment,g),le(t.$$.fragment,g),le(T.$$.fragment,g),le($.$$.fragment,g),le(C.$$.fragment,g),le(b.$$.fragment,g),le(M.$$.fragment,g),le(_.$$.fragment,g),A=!0)},o(g){ae(e.$$.fragment,g),ae(r.$$.fragment,g),ae(m.$$.fragment,g),ae(t.$$.fragment,g),ae(T.$$.fragment,g),ae($.$$.fragment,g),ae(C.$$.fragment,g),ae(b.$$.fragment,g),ae(M.$$.fragment,g),ae(_.$$.fragment,g),A=!1},d(g){ce(e,g),g&&o(d),ce(r,g),g&&o(v),ce(m,g),g&&o(f),ce(t,g),g&&o(a),ce(T,g),g&&o(w),ce($,g),g&&o(F),ce(C,g),g&&o(k),ce(b,g),g&&o(H),ce(M,g),g&&o(h),ce(_,g)}}}function hs(S){let e,d;const r=[S[1],Te];let v={$$slots:{default:[ps]},$$scope:{ctx:S}};for(let m=0;m<r.length;m+=1)v=je(v,r[m]);return e=new Ae({props:v}),{c(){ee(e.$$.fragment)},l(m){se(e.$$.fragment,m)},m(m,f){te(e,m,f),d=!0},p(m,[f]){const t=f&2?Be(r,[f&2&&Me(m[1]),f&0&&Me(Te)]):{};f&5&&(t.$$scope={dirty:f,ctx:m}),e.$set(t)},i(m){d||(le(e.$$.fragment,m),d=!0)},o(m){ae(e.$$.fragment,m),d=!1},d(m){ce(e,m)}}}const Te={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function $s(S,e,d){let r;return Re(S,qe,v=>d(0,r=v)),S.$$set=v=>{d(1,e=je(je({},e),Ge(v)))},e=Ge(e),[r,e]}class Ds extends ze{constructor(e){super();Pe(this,e,$s,hs,ye,{})}}export{Ds as default,Te as metadata};
