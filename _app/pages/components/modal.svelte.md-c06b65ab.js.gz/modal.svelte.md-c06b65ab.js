import{S as z,i as J,s as O,C as R,w as y,x,y as k,z as G,A as D,q as w,o as E,B as C,O as H,ae as F,k as P,m as A,g as p,d,e as $,t as h,c as b,a as _,h as g,b as u,I as v,a6 as L,R as T}from"../../chunks/vendor-eca5a9d7.js";import{M as K}from"../../chunks/_markdown-1469c252.js";import{p as N,C as Q,a as I,r as Y}from"../../chunks/actions-4916a6b1.js";import"../../chunks/stores-a83c67c1.js";import"../../chunks/Ads-afdd016f.js";import"../../chunks/util-332ae5d2.js";import"../../chunks/index-b47ba10b.js";import"../../chunks/SEO-53df5772.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-30f2437e.js";function U(m){let e,n;return{c(){e=$("label"),n=h("open modal"),this.h()},l(t){e=b(t,"LABEL",{for:!0,class:!0});var o=_(e);n=g(o,"open modal"),o.forEach(d),this.h()},h(){u(e,"for","my-modal"),u(e,"class","btn modal-button")},m(t,o){p(t,e,o),v(e,n)},d(t){t&&d(e)}}}function V(m){let e,n=`<!-- The button to open modal -->
<label for="my-modal" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal" class="$$modal-toggle">
<div class="$$modal">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
      <label for="my-modal" class="$$btn">Yay!</label>
    </div>
  </div>
</div>`,t,o,s,c;return{c(){e=$("pre"),t=h(n),this.h()},l(a){e=b(a,"PRE",{slot:!0});var r=_(e);t=g(r,n),r.forEach(d),this.h()},h(){u(e,"slot","html")},m(a,r){p(a,e,r),v(e,t),s||(c=L(o=Y.call(null,e,{to:m[0]})),s=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),s=!1,c()}}}function X(m){let e,n;return{c(){e=$("a"),n=h("open modal"),this.h()},l(t){e=b(t,"A",{href:!0,class:!0,rel:!0});var o=_(e);n=g(o,"open modal"),o.forEach(d),this.h()},h(){u(e,"href","#my-modal-2"),u(e,"class","btn"),u(e,"rel","external")},m(t,o){p(t,e,o),v(e,n)},d(t){t&&d(e)}}}function Z(m){let e,n=`<!-- The button to open modal -->
<a href="#my-modal-2" class="$$btn">open modal</a>
<!-- Put this part before </body> tag -->
<div class="$$modal" id="my-modal-2">
  <div class="$$modal-box">
    <h3 class="font-bold text-lg">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
    <div class="$$modal-action">
     <a href="#" class="$$btn">Yay!</a>
    </div>
  </div>
</div>`,t,o,s,c;return{c(){e=$("pre"),t=h(n),this.h()},l(a){e=b(a,"PRE",{slot:!0});var r=_(e);t=g(r,n),r.forEach(d),this.h()},h(){u(e,"slot","html")},m(a,r){p(a,e,r),v(e,t),s||(c=L(o=Y.call(null,e,{to:m[0]})),s=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),s=!1,c()}}}function ee(m){let e,n;return{c(){e=$("label"),n=h("open modal"),this.h()},l(t){e=b(t,"LABEL",{for:!0,class:!0});var o=_(e);n=g(o,"open modal"),o.forEach(d),this.h()},h(){u(e,"for","my-modal-3"),u(e,"class","btn modal-button")},m(t,o){p(t,e,o),v(e,n)},d(t){t&&d(e)}}}function te(m){let e,n=`<!-- The button to open modal -->
<label for="my-modal-3" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-3" class="$$modal-toggle">
<div class="$$modal">
  <div class="$$modal-box relative">
    <label for="my-modal-3" class="$$btn $$btn-sm $$btn-circle absolute right-2 top-2">\u2715</label>
    <h3 class="text-lg font-bold">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </div>
</div>`,t,o,s,c;return{c(){e=$("pre"),t=h(n),this.h()},l(a){e=b(a,"PRE",{slot:!0});var r=_(e);t=g(r,n),r.forEach(d),this.h()},h(){u(e,"slot","html")},m(a,r){p(a,e,r),v(e,t),s||(c=L(o=Y.call(null,e,{to:m[0]})),s=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),s=!1,c()}}}function oe(m){let e,n;return{c(){e=$("label"),n=h("open modal"),this.h()},l(t){e=b(t,"LABEL",{for:!0,class:!0});var o=_(e);n=g(o,"open modal"),o.forEach(d),this.h()},h(){u(e,"for","my-modal-4"),u(e,"class","btn modal-button")},m(t,o){p(t,e,o),v(e,n)},d(t){t&&d(e)}}}function le(m){let e,n=`<!-- The button to open modal -->
<label for="my-modal-4" class="$$btn $$modal-button">open modal</label>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal-4" class="$$modal-toggle">
<label for="my-modal-4" class="$$modal cursor-pointer">
  <label class="$$modal-box relative" for="">
    <h3 class="text-lg font-bold">Congratulations random Interner user!</h3>
    <p class="py-4">You've been selected for a chance to get one year of subscription to use Wikipedia for free!</p>
  </label>
</label>`,t,o,s,c;return{c(){e=$("pre"),t=h(n),this.h()},l(a){e=b(a,"PRE",{slot:!0});var r=_(e);t=g(r,n),r.forEach(d),this.h()},h(){u(e,"slot","html")},m(a,r){p(a,e,r),v(e,t),s||(c=L(o=Y.call(null,e,{to:m[0]})),s=!0)},p(a,r){o&&T(o.update)&&r&1&&o.update.call(null,{to:a[0]})},d(a){a&&d(e),s=!1,c()}}}function ae(m){let e,n,t,o,s,c,a,r,f,M;return e=new Q({props:{data:[{type:"component",class:"modal",desc:"Container element"},{type:"component",class:"modal-box",desc:"The content of modal"},{type:"component",class:"modal-action",desc:"Container for modal buttons"},{type:"component",class:"modal-toggle",desc:"For checkbox that controls modal"},{type:"component",class:"modal-button",desc:"For <label> that checks the checkbox to opens/closes modal"},{type:"modifier",class:"modal-open",desc:"Add/remove this class to open/close the modal using JS"}]}}),t=new I({props:{title:"Modal using label + hidden checkbox",desc:'Make sure each modal you use, has a unique ID. In this example, ID is "my-modal".',$$slots:{html:[V],default:[U]},$$scope:{ctx:m}}}),s=new I({props:{title:"Modal using anchor link",desc:"Anchor links might not work well on some SPA frameworks so if there are problems, use the first example",$$slots:{html:[Z],default:[X]},$$scope:{ctx:m}}}),a=new I({props:{title:"Modal using with a close button at corner",$$slots:{html:[te],default:[ee]},$$scope:{ctx:m}}}),f=new I({props:{title:"Modal that closes when clicked outside",desc:"Modal works with a hidden checkbox and labels can toggle the checkbox so we can use a label tag for the whole modal and use another label for modal-box to prevent closing when modal-box is clicked",$$slots:{html:[le],default:[oe]},$$scope:{ctx:m}}}),{c(){y(e.$$.fragment),n=P(),y(t.$$.fragment),o=P(),y(s.$$.fragment),c=P(),y(a.$$.fragment),r=P(),y(f.$$.fragment)},l(l){x(e.$$.fragment,l),n=A(l),x(t.$$.fragment,l),o=A(l),x(s.$$.fragment,l),c=A(l),x(a.$$.fragment,l),r=A(l),x(f.$$.fragment,l)},m(l,i){k(e,l,i),p(l,n,i),k(t,l,i),p(l,o,i),k(s,l,i),p(l,c,i),k(a,l,i),p(l,r,i),k(f,l,i),M=!0},p(l,i){const B={};i&5&&(B.$$scope={dirty:i,ctx:l}),t.$set(B);const S={};i&5&&(S.$$scope={dirty:i,ctx:l}),s.$set(S);const W={};i&5&&(W.$$scope={dirty:i,ctx:l}),a.$set(W);const q={};i&5&&(q.$$scope={dirty:i,ctx:l}),f.$set(q)},i(l){M||(w(e.$$.fragment,l),w(t.$$.fragment,l),w(s.$$.fragment,l),w(a.$$.fragment,l),w(f.$$.fragment,l),M=!0)},o(l){E(e.$$.fragment,l),E(t.$$.fragment,l),E(s.$$.fragment,l),E(a.$$.fragment,l),E(f.$$.fragment,l),M=!1},d(l){C(e,l),l&&d(n),C(t,l),l&&d(o),C(s,l),l&&d(c),C(a,l),l&&d(r),C(f,l)}}}function se(m){let e,n;const t=[m[1],j];let o={$$slots:{default:[ae]},$$scope:{ctx:m}};for(let s=0;s<t.length;s+=1)o=R(o,t[s]);return e=new K({props:o}),{c(){y(e.$$.fragment)},l(s){x(e.$$.fragment,s)},m(s,c){k(e,s,c),n=!0},p(s,[c]){const a=c&2?G(t,[c&2&&D(s[1]),c&0&&D(j)]):{};c&5&&(a.$$scope={dirty:c,ctx:s}),e.$set(a)},i(s){n||(w(e.$$.fragment,s),n=!0)},o(s){E(e.$$.fragment,s),n=!1},d(s){C(e,s)}}}const j={title:"Modal",desc:"Modal is used to show a dialog or a box when you click a button.",published:!0};function ne(m,e,n){let t;return H(m,N,o=>n(0,t=o)),m.$$set=o=>{n(1,e=R(R({},e),F(o)))},e=F(e),[t,e]}class be extends z{constructor(e){super();J(this,e,ne,se,O,{})}}export{be as default,j as metadata};
