import{S as jt,i as Kt,s as Ut,w as nt,k as w,x as ut,m as E,y as $t,g as Y,q as ht,o as ft,B as mt,d as a,J as Pt,e as v,t as m,c,a as i,h as p,b as e,H as t,a0 as _t,P as wt,F as ct,G as ot,N as Jt}from"../../chunks/vendor-3cc82a89.js";import{C as zt,a as pt,r as Et,p as St}from"../../chunks/actions-5947a762.js";import"../../chunks/preload-helper-ec9aa979.js";function Ct(z){let s,l,o,n,$,h,r,u,D,y;return{c(){s=v("div"),l=v("div"),o=v("div"),n=m("Total Page Views"),$=w(),h=v("div"),r=m("89,400"),u=w(),D=v("div"),y=m("21% more than last month"),this.h()},l(M){s=c(M,"DIV",{class:!0});var V=i(s);l=c(V,"DIV",{class:!0});var _=i(l);o=c(_,"DIV",{class:!0});var j=i(o);n=p(j,"Total Page Views"),j.forEach(a),$=E(_),h=c(_,"DIV",{class:!0});var R=i(h);r=p(R,"89,400"),R.forEach(a),u=E(_),D=c(_,"DIV",{class:!0});var g=i(D);y=p(g,"21% more than last month"),g.forEach(a),_.forEach(a),V.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(s,"class","shadow stats")},m(M,V){Y(M,s,V),t(s,l),t(l,o),t(o,n),t(l,$),t(l,h),t(h,r),t(l,u),t(l,D),t(D,y)},d(M){M&&a(s)}}}function Lt(z){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Total Page Views</div>
    <div class="$$stat-value">89,400</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function At(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A,K,J,O,C,N,U,k,x,q,G,H,P,W,tt,Z,L,st,Q,X;return{c(){s=v("div"),l=v("div"),o=v("div"),n=ct("svg"),$=ct("path"),h=w(),r=v("div"),u=m("Total Likes"),D=w(),y=v("div"),M=m("25.6K"),V=w(),_=v("div"),j=m("21% more than last month"),R=w(),g=v("div"),d=v("div"),f=ct("svg"),b=ct("path"),S=w(),B=v("div"),I=m("Page Views"),F=w(),T=v("div"),A=m("2.6M"),K=w(),J=v("div"),O=m("21% more than last month"),C=w(),N=v("div"),U=v("div"),k=v("div"),x=v("div"),q=v("img"),H=w(),P=v("div"),W=m("86%"),tt=w(),Z=v("div"),L=m("Tasks done"),st=w(),Q=v("div"),X=m("31 tasks remaining"),this.h()},l(et){s=c(et,"DIV",{class:!0});var at=i(s);l=c(at,"DIV",{class:!0});var lt=i(l);o=c(lt,"DIV",{class:!0});var gt=i(o);n=ot(gt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Vt=i(n);$=ot(Vt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i($).forEach(a),Vt.forEach(a),gt.forEach(a),h=E(lt),r=c(lt,"DIV",{class:!0});var Dt=i(r);u=p(Dt,"Total Likes"),Dt.forEach(a),D=E(lt),y=c(lt,"DIV",{class:!0});var it=i(y);M=p(it,"25.6K"),it.forEach(a),V=E(lt),_=c(lt,"DIV",{class:!0});var It=i(_);j=p(It,"21% more than last month"),It.forEach(a),lt.forEach(a),R=E(at),g=c(at,"DIV",{class:!0});var dt=i(g);d=c(dt,"DIV",{class:!0});var kt=i(d);f=ot(kt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var bt=i(f);b=ot(bt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),bt.forEach(a),kt.forEach(a),S=E(dt),B=c(dt,"DIV",{class:!0});var xt=i(B);I=p(xt,"Page Views"),xt.forEach(a),F=E(dt),T=c(dt,"DIV",{class:!0});var rt=i(T);A=p(rt,"2.6M"),rt.forEach(a),K=E(dt),J=c(dt,"DIV",{class:!0});var yt=i(J);O=p(yt,"21% more than last month"),yt.forEach(a),dt.forEach(a),C=E(at),N=c(at,"DIV",{class:!0});var vt=i(N);U=c(vt,"DIV",{class:!0});var Nt=i(U);k=c(Nt,"DIV",{class:!0});var Mt=i(k);x=c(Mt,"DIV",{class:!0});var Rt=i(x);q=c(Rt,"IMG",{src:!0}),Rt.forEach(a),Mt.forEach(a),Nt.forEach(a),H=E(vt),P=c(vt,"DIV",{class:!0});var Bt=i(P);W=p(Bt,"86%"),Bt.forEach(a),tt=E(vt),Z=c(vt,"DIV",{class:!0});var Ft=i(Z);L=p(Ft,"Tasks done"),Ft.forEach(a),st=E(vt),Q=c(vt,"DIV",{class:!0});var Tt=i(Q);X=p(Tt,"31 tasks remaining"),Tt.forEach(a),vt.forEach(a),at.forEach(a),this.h()},h(){e($,"stroke-linecap","round"),e($,"stroke-linejoin","round"),e($,"stroke-width","2"),e($,"d","M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"),e(n,"xmlns","http://www.w3.org/2000/svg"),e(n,"fill","none"),e(n,"viewBox","0 0 24 24"),e(n,"class","inline-block w-8 h-8 stroke-current"),e(o,"class","stat-figure text-primary"),e(r,"class","stat-title"),e(y,"class","stat-value text-primary"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M13 10V3L4 14h7v7l9-11h-7z"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(B,"class","stat-title"),e(T,"class","stat-value text-secondary"),e(J,"class","stat-desc"),e(g,"class","stat"),Jt(q.src,G="https://api.lorem.space/image/face?w=128&h=128")||e(q,"src",G),e(x,"class","w-16 rounded-full"),e(k,"class","avatar online"),e(U,"class","stat-figure text-secondary"),e(P,"class","stat-value"),e(Z,"class","stat-title"),e(Q,"class","stat-desc text-secondary"),e(N,"class","stat"),e(s,"class","shadow stats")},m(et,at){Y(et,s,at),t(s,l),t(l,o),t(o,n),t(n,$),t(l,h),t(l,r),t(r,u),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,j),t(s,R),t(s,g),t(g,d),t(d,f),t(f,b),t(g,S),t(g,B),t(B,I),t(g,F),t(g,T),t(T,A),t(g,K),t(g,J),t(J,O),t(s,C),t(s,N),t(N,U),t(U,k),t(k,x),t(x,q),t(N,H),t(N,P),t(P,W),t(N,tt),t(N,Z),t(Z,L),t(N,st),t(N,Q),t(Q,X)},d(et){et&&a(s)}}}function Ot(z){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="$$stat-title">Total Likes</div>
    <div class="$$stat-value text-primary">25.6K</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="$$stat-title">Page Views</div>
    <div class="$$stat-value text-secondary">2.6M</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <div class="$$avatar $$online">
        <div class="w-16 rounded-full">
          <img src="https://api.lorem.space/image/face?w=128&h=128">
        </div>
      </div>
    </div>
    <div class="$$stat-value">86%</div>
    <div class="$$stat-title">Tasks done</div>
    <div class="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function Wt(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A,K,J,O,C,N,U,k,x,q,G,H,P,W,tt,Z,L,st;return{c(){s=v("div"),l=v("div"),o=v("div"),n=ct("svg"),$=ct("path"),h=w(),r=v("div"),u=m("Downloads"),D=w(),y=v("div"),M=m("31K"),V=w(),_=v("div"),j=m("Jan 1st - Feb 1st"),R=w(),g=v("div"),d=v("div"),f=ct("svg"),b=ct("path"),S=w(),B=v("div"),I=m("New Users"),F=w(),T=v("div"),A=m("4,200"),K=w(),J=v("div"),O=m("\u2197\uFE0E 400 (22%)"),C=w(),N=v("div"),U=v("div"),k=ct("svg"),x=ct("path"),q=w(),G=v("div"),H=m("New Registers"),P=w(),W=v("div"),tt=m("1,200"),Z=w(),L=v("div"),st=m("\u2198\uFE0E 90 (14%)"),this.h()},l(Q){s=c(Q,"DIV",{class:!0});var X=i(s);l=c(X,"DIV",{class:!0});var et=i(l);o=c(et,"DIV",{class:!0});var at=i(o);n=ot(at,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var lt=i(n);$=ot(lt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i($).forEach(a),lt.forEach(a),at.forEach(a),h=E(et),r=c(et,"DIV",{class:!0});var gt=i(r);u=p(gt,"Downloads"),gt.forEach(a),D=E(et),y=c(et,"DIV",{class:!0});var Vt=i(y);M=p(Vt,"31K"),Vt.forEach(a),V=E(et),_=c(et,"DIV",{class:!0});var Dt=i(_);j=p(Dt,"Jan 1st - Feb 1st"),Dt.forEach(a),et.forEach(a),R=E(X),g=c(X,"DIV",{class:!0});var it=i(g);d=c(it,"DIV",{class:!0});var It=i(d);f=ot(It,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var dt=i(f);b=ot(dt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),dt.forEach(a),It.forEach(a),S=E(it),B=c(it,"DIV",{class:!0});var kt=i(B);I=p(kt,"New Users"),kt.forEach(a),F=E(it),T=c(it,"DIV",{class:!0});var bt=i(T);A=p(bt,"4,200"),bt.forEach(a),K=E(it),J=c(it,"DIV",{class:!0});var xt=i(J);O=p(xt,"\u2197\uFE0E 400 (22%)"),xt.forEach(a),it.forEach(a),C=E(X),N=c(X,"DIV",{class:!0});var rt=i(N);U=c(rt,"DIV",{class:!0});var yt=i(U);k=ot(yt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var vt=i(k);x=ot(vt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(x).forEach(a),vt.forEach(a),yt.forEach(a),q=E(rt),G=c(rt,"DIV",{class:!0});var Nt=i(G);H=p(Nt,"New Registers"),Nt.forEach(a),P=E(rt),W=c(rt,"DIV",{class:!0});var Mt=i(W);tt=p(Mt,"1,200"),Mt.forEach(a),Z=E(rt),L=c(rt,"DIV",{class:!0});var Rt=i(L);st=p(Rt,"\u2198\uFE0E 90 (14%)"),Rt.forEach(a),rt.forEach(a),X.forEach(a),this.h()},h(){e($,"stroke-linecap","round"),e($,"stroke-linejoin","round"),e($,"stroke-width","2"),e($,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),e(n,"xmlns","http://www.w3.org/2000/svg"),e(n,"fill","none"),e(n,"viewBox","0 0 24 24"),e(n,"class","inline-block w-8 h-8 stroke-current"),e(o,"class","stat-figure text-secondary"),e(r,"class","stat-title"),e(y,"class","stat-value"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(B,"class","stat-title"),e(T,"class","stat-value"),e(J,"class","stat-desc"),e(g,"class","stat"),e(x,"stroke-linecap","round"),e(x,"stroke-linejoin","round"),e(x,"stroke-width","2"),e(x,"d","M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"),e(k,"xmlns","http://www.w3.org/2000/svg"),e(k,"fill","none"),e(k,"viewBox","0 0 24 24"),e(k,"class","inline-block w-8 h-8 stroke-current"),e(U,"class","stat-figure text-secondary"),e(G,"class","stat-title"),e(W,"class","stat-value"),e(L,"class","stat-desc"),e(N,"class","stat"),e(s,"class","shadow stats")},m(Q,X){Y(Q,s,X),t(s,l),t(l,o),t(o,n),t(n,$),t(l,h),t(l,r),t(r,u),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,j),t(s,R),t(s,g),t(g,d),t(d,f),t(f,b),t(g,S),t(g,B),t(B,I),t(g,F),t(g,T),t(T,A),t(g,K),t(g,J),t(J,O),t(s,C),t(s,N),t(N,U),t(U,k),t(k,x),t(N,q),t(N,G),t(G,H),t(N,P),t(N,W),t(W,tt),t(N,Z),t(N,L),t(L,st)},d(Q){Q&&a(s)}}}function qt(z){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function Gt(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A,K,J,O,C,N;return{c(){s=v("div"),l=v("div"),o=v("div"),n=m("Downloads"),$=w(),h=v("div"),r=m("31K"),u=w(),D=v("div"),y=m("From January 1st to February 1st"),M=w(),V=v("div"),_=v("div"),j=m("Users"),R=w(),g=v("div"),d=m("4,200"),f=w(),b=v("div"),S=m("\u2197\uFE0E 40 (2%)"),B=w(),I=v("div"),F=v("div"),T=m("New Registers"),A=w(),K=v("div"),J=m("1,200"),O=w(),C=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(U){s=c(U,"DIV",{class:!0});var k=i(s);l=c(k,"DIV",{class:!0});var x=i(l);o=c(x,"DIV",{class:!0});var q=i(o);n=p(q,"Downloads"),q.forEach(a),$=E(x),h=c(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),u=E(x),D=c(x,"DIV",{class:!0});var H=i(D);y=p(H,"From January 1st to February 1st"),H.forEach(a),x.forEach(a),M=E(k),V=c(k,"DIV",{class:!0});var P=i(V);_=c(P,"DIV",{class:!0});var W=i(_);j=p(W,"Users"),W.forEach(a),R=E(P),g=c(P,"DIV",{class:!0});var tt=i(g);d=p(tt,"4,200"),tt.forEach(a),f=E(P),b=c(P,"DIV",{class:!0});var Z=i(b);S=p(Z,"\u2197\uFE0E 40 (2%)"),Z.forEach(a),P.forEach(a),B=E(k),I=c(k,"DIV",{class:!0});var L=i(I);F=c(L,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=E(L),K=c(L,"DIV",{class:!0});var Q=i(K);J=p(Q,"1,200"),Q.forEach(a),O=E(L),C=c(L,"DIV",{class:!0});var X=i(C);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat place-items-center"),e(_,"class","stat-title"),e(g,"class","stat-value text-secondary"),e(b,"class","stat-desc text-secondary"),e(V,"class","stat place-items-center"),e(F,"class","stat-title"),e(K,"class","stat-value"),e(C,"class","stat-desc"),e(I,"class","stat place-items-center"),e(s,"class","shadow stats")},m(U,k){Y(U,s,k),t(s,l),t(l,o),t(o,n),t(l,$),t(l,h),t(h,r),t(l,u),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,j),t(V,R),t(V,g),t(g,d),t(V,f),t(V,b),t(b,S),t(s,B),t(s,I),t(I,F),t(F,T),t(I,A),t(I,K),t(K,J),t(I,O),t(I,C),t(C,N)},d(U){U&&a(s)}}}function Ht(z){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Users</div>
    <div class="$$stat-value text-secondary">4,200</div>
    <div class="$$stat-desc text-secondary">\u2197\uFE0E 40 (2%)</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function Qt(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A,K,J,O,C,N;return{c(){s=v("div"),l=v("div"),o=v("div"),n=m("Downloads"),$=w(),h=v("div"),r=m("31K"),u=w(),D=v("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=v("div"),_=v("div"),j=m("New Users"),R=w(),g=v("div"),d=m("4,200"),f=w(),b=v("div"),S=m("\u2197\uFE0E 400 (22%)"),B=w(),I=v("div"),F=v("div"),T=m("New Registers"),A=w(),K=v("div"),J=m("1,200"),O=w(),C=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(U){s=c(U,"DIV",{class:!0});var k=i(s);l=c(k,"DIV",{class:!0});var x=i(l);o=c(x,"DIV",{class:!0});var q=i(o);n=p(q,"Downloads"),q.forEach(a),$=E(x),h=c(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),u=E(x),D=c(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=E(k),V=c(k,"DIV",{class:!0});var P=i(V);_=c(P,"DIV",{class:!0});var W=i(_);j=p(W,"New Users"),W.forEach(a),R=E(P),g=c(P,"DIV",{class:!0});var tt=i(g);d=p(tt,"4,200"),tt.forEach(a),f=E(P),b=c(P,"DIV",{class:!0});var Z=i(b);S=p(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),P.forEach(a),B=E(k),I=c(k,"DIV",{class:!0});var L=i(I);F=c(L,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=E(L),K=c(L,"DIV",{class:!0});var Q=i(K);J=p(Q,"1,200"),Q.forEach(a),O=E(L),C=c(L,"DIV",{class:!0});var X=i(C);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(g,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(F,"class","stat-title"),e(K,"class","stat-value"),e(C,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical")},m(U,k){Y(U,s,k),t(s,l),t(l,o),t(o,n),t(l,$),t(l,h),t(h,r),t(l,u),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,j),t(V,R),t(V,g),t(g,d),t(V,f),t(V,b),t(b,S),t(s,B),t(s,I),t(I,F),t(F,T),t(I,A),t(I,K),t(K,J),t(I,O),t(I,C),t(C,N)},d(U){U&&a(s)}}}function Xt(z){let s,l=`<div class="$$stats $$stats-vertical shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function Yt(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A,K,J,O,C,N;return{c(){s=v("div"),l=v("div"),o=v("div"),n=m("Downloads"),$=w(),h=v("div"),r=m("31K"),u=w(),D=v("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=v("div"),_=v("div"),j=m("New Users"),R=w(),g=v("div"),d=m("4,200"),f=w(),b=v("div"),S=m("\u2197\uFE0E 400 (22%)"),B=w(),I=v("div"),F=v("div"),T=m("New Registers"),A=w(),K=v("div"),J=m("1,200"),O=w(),C=v("div"),N=m("\u2198\uFE0E 90 (14%)"),this.h()},l(U){s=c(U,"DIV",{class:!0});var k=i(s);l=c(k,"DIV",{class:!0});var x=i(l);o=c(x,"DIV",{class:!0});var q=i(o);n=p(q,"Downloads"),q.forEach(a),$=E(x),h=c(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),u=E(x),D=c(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=E(k),V=c(k,"DIV",{class:!0});var P=i(V);_=c(P,"DIV",{class:!0});var W=i(_);j=p(W,"New Users"),W.forEach(a),R=E(P),g=c(P,"DIV",{class:!0});var tt=i(g);d=p(tt,"4,200"),tt.forEach(a),f=E(P),b=c(P,"DIV",{class:!0});var Z=i(b);S=p(Z,"\u2197\uFE0E 400 (22%)"),Z.forEach(a),P.forEach(a),B=E(k),I=c(k,"DIV",{class:!0});var L=i(I);F=c(L,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=E(L),K=c(L,"DIV",{class:!0});var Q=i(K);J=p(Q,"1,200"),Q.forEach(a),O=E(L),C=c(L,"DIV",{class:!0});var X=i(C);N=p(X,"\u2198\uFE0E 90 (14%)"),X.forEach(a),L.forEach(a),k.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(g,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(F,"class","stat-title"),e(K,"class","stat-value"),e(C,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical lg:stats-horizontal")},m(U,k){Y(U,s,k),t(s,l),t(l,o),t(o,n),t(l,$),t(l,h),t(h,r),t(l,u),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,j),t(V,R),t(V,g),t(g,d),t(V,f),t(V,b),t(b,S),t(s,B),t(s,I),t(I,F),t(F,T),t(I,A),t(I,K),t(K,J),t(I,O),t(I,C),t(C,N)},d(U){U&&a(s)}}}function Zt(z){let s,l=`<div class="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">\u2197\uFE0E 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">\u2198\uFE0E 90 (14%)</div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function ts(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g,d,f,b,S,B,I,F,T,A;return{c(){s=v("div"),l=v("div"),o=v("div"),n=m("Account balance"),$=w(),h=v("div"),r=m("$89,400"),u=w(),D=v("div"),y=v("button"),M=m("Add funds"),V=w(),_=v("div"),j=v("div"),R=m("Current balance"),g=w(),d=v("div"),f=m("$89,400"),b=w(),S=v("div"),B=v("button"),I=m("Withdrawal"),F=w(),T=v("button"),A=m("deposit"),this.h()},l(K){s=c(K,"DIV",{class:!0});var J=i(s);l=c(J,"DIV",{class:!0});var O=i(l);o=c(O,"DIV",{class:!0});var C=i(o);n=p(C,"Account balance"),C.forEach(a),$=E(O),h=c(O,"DIV",{class:!0});var N=i(h);r=p(N,"$89,400"),N.forEach(a),u=E(O),D=c(O,"DIV",{class:!0});var U=i(D);y=c(U,"BUTTON",{class:!0});var k=i(y);M=p(k,"Add funds"),k.forEach(a),U.forEach(a),O.forEach(a),V=E(J),_=c(J,"DIV",{class:!0});var x=i(_);j=c(x,"DIV",{class:!0});var q=i(j);R=p(q,"Current balance"),q.forEach(a),g=E(x),d=c(x,"DIV",{class:!0});var G=i(d);f=p(G,"$89,400"),G.forEach(a),b=E(x),S=c(x,"DIV",{class:!0});var H=i(S);B=c(H,"BUTTON",{class:!0});var P=i(B);I=p(P,"Withdrawal"),P.forEach(a),F=E(H),T=c(H,"BUTTON",{class:!0});var W=i(T);A=p(W,"deposit"),W.forEach(a),H.forEach(a),x.forEach(a),J.forEach(a),this.h()},h(){e(o,"class","stat-title"),e(h,"class","stat-value"),e(y,"class","btn btn-sm btn-success"),e(D,"class","stat-actions"),e(l,"class","stat"),e(j,"class","stat-title"),e(d,"class","stat-value"),e(B,"class","btn btn-sm"),e(T,"class","btn btn-sm"),e(S,"class","stat-actions"),e(_,"class","stat"),e(s,"class","stats bg-primary text-primary-content")},m(K,J){Y(K,s,J),t(s,l),t(l,o),t(o,n),t(l,$),t(l,h),t(h,r),t(l,u),t(l,D),t(D,y),t(y,M),t(s,V),t(s,_),t(_,j),t(j,R),t(_,g),t(_,d),t(d,f),t(_,b),t(_,S),t(S,B),t(B,I),t(S,F),t(S,T),t(T,A)},d(K){K&&a(s)}}}function ss(z){let s,l=`<div class="$$stats bg-primary text-primary-content">
  
  <div class="$$stat">
    <div class="$$stat-title">Account balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">Current balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm">Withdrawal</button> 
      <button class="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,o,n,$,h;return{c(){s=v("pre"),o=m(l),this.h()},l(r){s=c(r,"PRE",{slot:!0});var u=i(s);o=p(u,l),u.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,u){Y(r,s,u),t(s,o),$||(h=_t(n=Et.call(null,s,{to:z[0]})),$=!0)},p(r,u){n&&wt(n.update)&&u&1&&n.update.call(null,{to:r[0]})},d(r){r&&a(s),$=!1,h()}}}function es(z){let s,l,o,n,$,h,r,u,D,y,M,V,_,j,R,g;return s=new zt({props:{data:[{type:"component",class:"stats",desc:"Container of multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),o=new pt({props:{title:"Stat",$$slots:{html:[Lt],default:[Ct]},$$scope:{ctx:z}}}),$=new pt({props:{title:"Stat with icons or image",$$slots:{html:[Ot],default:[At]},$$scope:{ctx:z}}}),r=new pt({props:{title:"Stat",$$slots:{html:[qt],default:[Wt]},$$scope:{ctx:z}}}),D=new pt({props:{title:"Centered items",$$slots:{html:[Ht],default:[Gt]},$$scope:{ctx:z}}}),M=new pt({props:{title:"Vertical",$$slots:{html:[Xt],default:[Qt]},$$scope:{ctx:z}}}),_=new pt({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{html:[Zt],default:[Yt]},$$scope:{ctx:z}}}),R=new pt({props:{title:"With custom colors and button",$$slots:{html:[ss],default:[ts]},$$scope:{ctx:z}}}),{c(){nt(s.$$.fragment),l=w(),nt(o.$$.fragment),n=w(),nt($.$$.fragment),h=w(),nt(r.$$.fragment),u=w(),nt(D.$$.fragment),y=w(),nt(M.$$.fragment),V=w(),nt(_.$$.fragment),j=w(),nt(R.$$.fragment)},l(d){ut(s.$$.fragment,d),l=E(d),ut(o.$$.fragment,d),n=E(d),ut($.$$.fragment,d),h=E(d),ut(r.$$.fragment,d),u=E(d),ut(D.$$.fragment,d),y=E(d),ut(M.$$.fragment,d),V=E(d),ut(_.$$.fragment,d),j=E(d),ut(R.$$.fragment,d)},m(d,f){$t(s,d,f),Y(d,l,f),$t(o,d,f),Y(d,n,f),$t($,d,f),Y(d,h,f),$t(r,d,f),Y(d,u,f),$t(D,d,f),Y(d,y,f),$t(M,d,f),Y(d,V,f),$t(_,d,f),Y(d,j,f),$t(R,d,f),g=!0},p(d,[f]){const b={};f&3&&(b.$$scope={dirty:f,ctx:d}),o.$set(b);const S={};f&3&&(S.$$scope={dirty:f,ctx:d}),$.$set(S);const B={};f&3&&(B.$$scope={dirty:f,ctx:d}),r.$set(B);const I={};f&3&&(I.$$scope={dirty:f,ctx:d}),D.$set(I);const F={};f&3&&(F.$$scope={dirty:f,ctx:d}),M.$set(F);const T={};f&3&&(T.$$scope={dirty:f,ctx:d}),_.$set(T);const A={};f&3&&(A.$$scope={dirty:f,ctx:d}),R.$set(A)},i(d){g||(ht(s.$$.fragment,d),ht(o.$$.fragment,d),ht($.$$.fragment,d),ht(r.$$.fragment,d),ht(D.$$.fragment,d),ht(M.$$.fragment,d),ht(_.$$.fragment,d),ht(R.$$.fragment,d),g=!0)},o(d){ft(s.$$.fragment,d),ft(o.$$.fragment,d),ft($.$$.fragment,d),ft(r.$$.fragment,d),ft(D.$$.fragment,d),ft(M.$$.fragment,d),ft(_.$$.fragment,d),ft(R.$$.fragment,d),g=!1},d(d){mt(s,d),d&&a(l),mt(o,d),d&&a(n),mt($,d),d&&a(h),mt(r,d),d&&a(u),mt(D,d),d&&a(y),mt(M,d),d&&a(V),mt(_,d),d&&a(j),mt(R,d)}}}const rs={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0};function as(z,s,l){let o;return Pt(z,St,n=>l(0,o=n)),[o]}class vs extends jt{constructor(s){super();Kt(this,s,as,es,Ut,{})}}export{vs as default,rs as metadata};
