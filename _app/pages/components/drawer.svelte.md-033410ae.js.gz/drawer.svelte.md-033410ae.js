import{S as Ae,i as Ve,s as Te,C as me,w as Y,x as K,y as G,z as je,A as Ne,q as Q,o as X,B as Z,K as Be,ag as Se,k as E,e as d,t as I,m as x,c,a as u,h as k,d as l,b as i,g as V,F as a,a9 as q,W as H,H as Le,I as De}from"../../chunks/vendor-c5cb7521.js";import{M as Me}from"../../chunks/_markdown-ccb01ec8.js";import{p as Oe,C as Ce,a as ie,r as J}from"../../chunks/actions-c884b8b1.js";import"../../chunks/stores-596c3501.js";import"../../chunks/Ads-481d1ba6.js";import"../../chunks/index-0b983a57.js";import"../../chunks/SEO-8fcf5e14.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-24eafc58.js";function Fe(w){let e,m,p,n,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),n=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var b=u(e);m=c(b,"INPUT",{id:!0,type:!0,class:!0}),p=x(b),n=c(b,"DIV",{class:!0});var M=u(n);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(b),t=c(b,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var o=u(L);D=k(o,"Sidebar Item 1"),o.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var v=u(N);y=c(v,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),v.forEach(l),g.forEach(l),T.forEach(l),b.forEach(l),this.h()},h(){i(m,"id","my-drawer"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer"),i(s,"class","btn btn-primary drawer-button"),i(n,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 overflow-y-auto w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer h-56 rounded")},m(S,b){V(S,e,b),a(e,m),a(e,p),a(e,n),a(n,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function Re(w){let e,m=`<div class="$$drawer">
  <input id="my-drawer" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content">
    <!-- Page content here -->
    <label for="my-drawer" class="$$btn $$btn-primary $$drawer-button">Open drawer</label>
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer" class="$$drawer-overlay"></label>
    <ul class="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function ze(w){let e,m=`<div className="$$drawer">
  <input id="my-drawer" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content">
    <!-- Page content here -->
    <label htmlFor="my-drawer" className="$$btn $$btn-primary $$drawer-button">Open drawer</label>
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer" className="$$drawer-overlay"></label>
    <ul className="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ue(w){let e,m,p,n,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),n=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var b=u(e);m=c(b,"INPUT",{id:!0,type:!0,class:!0}),p=x(b),n=c(b,"DIV",{class:!0});var M=u(n);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(b),t=c(b,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var o=u(L);D=k(o,"Sidebar Item 1"),o.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var v=u(N);y=c(v,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),v.forEach(l),g.forEach(l),T.forEach(l),b.forEach(l),this.h()},h(){i(m,"id","my-drawer-2"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer-2"),i(s,"class","btn btn-primary drawer-button lg:hidden"),i(n,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer-2"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 overflow-y-auto w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer drawer-mobile h-56 rounded")},m(S,b){V(S,e,b),a(e,m),a(e,p),a(e,n),a(n,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function qe(w){let e,m=`<div class="$$drawer $$drawer-mobile">
  <input id="my-drawer-2" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content flex flex-col items-center justify-center">
    <!-- Page content here -->
    <label for="my-drawer-2" class="$$btn $$btn-primary $$drawer-button lg:hidden">Open drawer</label>
  
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-2" class="$$drawer-overlay"></label> 
    <ul class="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function He(w){let e,m=`<div className="$$drawer $$drawer-mobile">
  <input id="my-drawer-2" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content flex flex-col items-center justify-center">
    <!-- Page content here -->
    <label htmlFor="my-drawer-2" className="$$btn $$btn-primary $$drawer-button lg:hidden">Open drawer</label>
  
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-2" className="$$drawer-overlay"></label> 
    <ul className="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Je(w){let e,m,p,n,s,f,r,t,$,O,h,_,L,D,P,N,y,A,S,b,M,j,T,g,C,o,v,B,z,F,R,ee,de,ce,ae,te,ue;return{c(){e=d("div"),m=d("input"),p=E(),n=d("div"),s=d("div"),f=d("div"),r=d("label"),t=Le("svg"),$=Le("path"),O=E(),h=d("div"),_=I("Navbar Title"),L=E(),D=d("div"),P=d("ul"),N=d("li"),y=d("a"),A=I("Navbar Item 1"),S=E(),b=d("li"),M=d("a"),j=I("Navbar Item 2"),T=E(),g=d("div"),C=I("Content"),o=E(),v=d("div"),B=d("label"),z=E(),F=d("ul"),R=d("li"),ee=d("a"),de=I("Sidebar Item 1"),ce=E(),ae=d("li"),te=d("a"),ue=I("Sidebar Item 2"),this.h()},l(re){e=c(re,"DIV",{class:!0});var U=u(e);m=c(U,"INPUT",{id:!0,type:!0,class:!0}),p=x(U),n=c(U,"DIV",{class:!0});var le=u(n);s=c(le,"DIV",{class:!0});var W=u(s);f=c(W,"DIV",{class:!0});var pe=u(f);r=c(pe,"LABEL",{for:!0,class:!0});var fe=u(r);t=De(fe,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var ve=u(t);$=De(ve,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u($).forEach(l),ve.forEach(l),fe.forEach(l),pe.forEach(l),O=x(W),h=c(W,"DIV",{class:!0});var be=u(h);_=k(be,"Navbar Title"),be.forEach(l),L=x(W),D=c(W,"DIV",{class:!0});var he=u(D);P=c(he,"UL",{class:!0});var se=u(P);N=c(se,"LI",{});var $e=u(N);y=c($e,"A",{});var we=u(y);A=k(we,"Navbar Item 1"),we.forEach(l),$e.forEach(l),S=x(se),b=c(se,"LI",{});var _e=u(b);M=c(_e,"A",{});var ge=u(M);j=k(ge,"Navbar Item 2"),ge.forEach(l),_e.forEach(l),se.forEach(l),he.forEach(l),W.forEach(l),T=x(le),g=c(le,"DIV",{class:!0});var ye=u(g);C=k(ye,"Content"),ye.forEach(l),le.forEach(l),o=x(U),v=c(U,"DIV",{class:!0});var oe=u(v);B=c(oe,"LABEL",{for:!0,class:!0}),u(B).forEach(l),z=x(oe),F=c(oe,"UL",{class:!0});var ne=u(F);R=c(ne,"LI",{});var Ee=u(R);ee=c(Ee,"A",{});var xe=u(ee);de=k(xe,"Sidebar Item 1"),xe.forEach(l),Ee.forEach(l),ce=x(ne),ae=c(ne,"LI",{});var Ie=u(ae);te=c(Ie,"A",{});var ke=u(te);ue=k(ke,"Sidebar Item 2"),ke.forEach(l),Ie.forEach(l),ne.forEach(l),oe.forEach(l),U.forEach(l),this.h()},h(){i(m,"id","my-drawer-3"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i($,"stroke-linecap","round"),i($,"stroke-linejoin","round"),i($,"stroke-width","2"),i($,"d","M4 6h16M4 12h16M4 18h16"),i(t,"xmlns","http://www.w3.org/2000/svg"),i(t,"fill","none"),i(t,"viewBox","0 0 24 24"),i(t,"class","inline-block w-6 h-6 stroke-current"),i(r,"for","my-drawer-3"),i(r,"class","btn btn-square btn-ghost"),i(f,"class","flex-none lg:hidden"),i(h,"class","flex-1 px-2 mx-2"),i(P,"class","menu menu-horizontal"),i(D,"class","flex-none hidden lg:block"),i(s,"class","w-full navbar bg-base-300"),i(g,"class","flex justify-center items-center flex-grow"),i(n,"class","flex flex-col drawer-content"),i(B,"for","my-drawer-3"),i(B,"class","drawer-overlay"),i(F,"class","p-4 overflow-y-auto menu w-60 md:w-80 bg-base-100"),i(v,"class","drawer-side"),i(e,"class","drawer h-56 rounded")},m(re,U){V(re,e,U),a(e,m),a(e,p),a(e,n),a(n,s),a(s,f),a(f,r),a(r,t),a(t,$),a(s,O),a(s,h),a(h,_),a(s,L),a(s,D),a(D,P),a(P,N),a(N,y),a(y,A),a(P,S),a(P,b),a(b,M),a(M,j),a(n,T),a(n,g),a(g,C),a(e,o),a(e,v),a(v,B),a(v,z),a(v,F),a(F,R),a(R,ee),a(ee,de),a(F,ce),a(F,ae),a(ae,te),a(te,ue)},d(re){re&&l(e)}}}function We(w){let e,m=`<div class="$$drawer">
  <input id="my-drawer-3" type="checkbox" class="$$drawer-toggle" /> 
  <div class="$$drawer-content flex flex-col">
    <!-- Navbar -->
    <div class="w-full $$navbar bg-base-300">
      <div class="flex-none lg:hidden">
        <label for="my-drawer-3" class="$$btn $$btn-square $$btn-ghost">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-6 h-6 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
        </label>
      </div> 
      <div class="flex-1 px-2 mx-2">Navbar Title</div>
      <div class="flex-none hidden lg:block">
        <ul class="$$menu $$menu-horizontal">
          <!-- Navbar menu content here -->
          <li><a>Navbar Item 1</a></li>
          <li><a>Navbar Item 2</a></li>
        </ul>
      </div>
    </div>
    <!-- Page content here -->
    Content
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-3" class="$$drawer-overlay"></label> 
    <ul class="$$menu p-4 overflow-y-auto w-80 bg-base-100">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
    
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ye(w){let e,m=`<div className="$$drawer">
  <input id="my-drawer-3" type="checkbox" className="$$drawer-toggle" /> 
  <div className="$$drawer-content flex flex-col">
    <!-- Navbar -->
    <div className="w-full $$navbar bg-base-300">
      <div className="flex-none lg:hidden">
        <label htmlFor="my-drawer-3" className="$$btn $$btn-square $$btn-ghost">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-6 h-6 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
        </label>
      </div> 
      <div className="flex-1 px-2 mx-2">Navbar Title</div>
      <div className="flex-none hidden lg:block">
        <ul className="$$menu $$menu-horizontal">
          <!-- Navbar menu content here -->
          <li><a>Navbar Item 1</a></li>
          <li><a>Navbar Item 2</a></li>
        </ul>
      </div>
    </div>
    <!-- Page content here -->
    Content
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-3" className="$$drawer-overlay"></label> 
    <ul className="$$menu p-4 overflow-y-auto w-80 bg-base-100">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
      
    </ul>
    
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Ke(w){let e,m,p,n,s,f,r,t,$,O,h,_,L,D,P,N,y,A;return{c(){e=d("div"),m=d("input"),p=E(),n=d("div"),s=d("label"),f=I("Open drawer"),r=E(),t=d("div"),$=d("label"),O=E(),h=d("ul"),_=d("li"),L=d("a"),D=I("Sidebar Item 1"),P=E(),N=d("li"),y=d("a"),A=I("Sidebar Item 2"),this.h()},l(S){e=c(S,"DIV",{class:!0});var b=u(e);m=c(b,"INPUT",{id:!0,type:!0,class:!0}),p=x(b),n=c(b,"DIV",{class:!0});var M=u(n);s=c(M,"LABEL",{for:!0,class:!0});var j=u(s);f=k(j,"Open drawer"),j.forEach(l),M.forEach(l),r=x(b),t=c(b,"DIV",{class:!0});var T=u(t);$=c(T,"LABEL",{for:!0,class:!0}),u($).forEach(l),O=x(T),h=c(T,"UL",{class:!0});var g=u(h);_=c(g,"LI",{});var C=u(_);L=c(C,"A",{});var o=u(L);D=k(o,"Sidebar Item 1"),o.forEach(l),C.forEach(l),P=x(g),N=c(g,"LI",{});var v=u(N);y=c(v,"A",{});var B=u(y);A=k(B,"Sidebar Item 2"),B.forEach(l),v.forEach(l),g.forEach(l),T.forEach(l),b.forEach(l),this.h()},h(){i(m,"id","my-drawer-4"),i(m,"type","checkbox"),i(m,"class","drawer-toggle"),i(s,"for","my-drawer-4"),i(s,"class","btn btn-primary drawer-button"),i(n,"class","flex flex-col items-center justify-center drawer-content"),i($,"for","my-drawer-4"),i($,"class","drawer-overlay"),i(h,"class","menu p-4 overflow-y-auto w-60 md:w-80 bg-base-100 text-base-content"),i(t,"class","drawer-side"),i(e,"class","drawer drawer-end h-56 rounded")},m(S,b){V(S,e,b),a(e,m),a(e,p),a(e,n),a(n,s),a(s,f),a(e,r),a(e,t),a(t,$),a(t,O),a(t,h),a(h,_),a(_,L),a(L,D),a(h,P),a(h,N),a(N,y),a(y,A)},d(S){S&&l(e)}}}function Ge(w){let e,m=`<div class="$$drawer $$drawer-end">
  <input id="my-drawer-4" type="checkbox" class="$$drawer-toggle" />
  <div class="$$drawer-content">
    <!-- Page content here -->
    <label for="my-drawer-4" class="$$drawer-button $$btn $$btn-primary">Open drawer</label>
  </div> 
  <div class="$$drawer-side">
    <label for="my-drawer-4" class="$$drawer-overlay"></label>
    <ul class="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","html")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Qe(w){let e,m=`<div className="$$drawer $$drawer-end">
  <input id="my-drawer-4" type="checkbox" className="$$drawer-toggle" />
  <div className="$$drawer-content">
    <!-- Page content here -->
    <label htmlFor="my-drawer-4" className="$$drawer-button $$btn $$btn-primary">Open drawer</label>
  </div> 
  <div className="$$drawer-side">
    <label htmlFor="my-drawer-4" className="$$drawer-overlay"></label>
    <ul className="$$menu p-4 overflow-y-auto w-80 bg-base-100 text-base-content">
      <!-- Sidebar content here -->
      <li><a>Sidebar Item 1</a></li>
      <li><a>Sidebar Item 2</a></li>
    </ul>
  </div>
</div>`,p,n,s,f;return{c(){e=d("pre"),p=I(m),this.h()},l(r){e=c(r,"PRE",{slot:!0});var t=u(e);p=k(t,m),t.forEach(l),this.h()},h(){i(e,"slot","react")},m(r,t){V(r,e,t),a(e,p),s||(f=q(n=J.call(null,e,{to:w[0]})),s=!0)},p(r,t){n&&H(n.update)&&t&1&&n.update.call(null,{to:r[0]})},d(r){r&&l(e),s=!1,f()}}}function Xe(w){let e,m,p,n,s,f,r,t,$,O=`<code class="language-js"><span class="token punctuation">.</span>drawer <span class="token comment">// The root container</span>
  \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>toggle <span class="token comment">// A hidden checkbox to toggle the visibility of the sidebar</span>
  \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>content <span class="token comment">// All your page content goes here</span>
  \u2502    \u251C\u2500\u2500 <span class="token comment">// navbar</span>
  \u2502    \u251C\u2500\u2500 <span class="token comment">// content</span>
  \u2502    \u2514\u2500\u2500 <span class="token comment">// footer</span>
  \u2514\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>side <span class="token comment">// Sidebar wrapper</span>
       \u251C\u2500\u2500 <span class="token punctuation">.</span>drawer<span class="token operator">-</span>overlay <span class="token comment">// A dark overlay that covers the whole page when the drawer is open</span>
       \u2514\u2500\u2500 <span class="token comment">// Sidebar content (menu or anything)</span></code>`,h,_,L,D,P,N,y,A,S,b,M,j,T,g,C;return e=new Ce({props:{data:[{type:"component",class:"drawer",desc:"Container element"},{type:"component",class:"drawer-toggle",desc:"For checkbox element that controls the drawer"},{type:"component",class:"drawer-content",desc:"The content container"},{type:"component",class:"drawer-side",desc:"The sidebar container"},{type:"component",class:"drawer-overlay",desc:"The label covers the content when drawer is open"},{type:"modifier",class:"drawer-mobile",desc:"Makes drawer to open/close on mobile but will be always visible on desktop"},{type:"modifier",class:"drawer-end",desc:"puts drawer to the right"}]}}),A=new ie({props:{title:"Drawer",$$slots:{react:[ze],html:[Re],default:[Fe]},$$scope:{ctx:w}}}),b=new ie({props:{title:"Drawer for mobile + fixed sidebar for desktop",desc:"Drawer is always open on desktop size. Drawer can be toggled on mobile size. Resize the browser to see toggle button on mobile size",$$slots:{react:[He],html:[qe],default:[Ue]},$$scope:{ctx:w}}}),j=new ie({props:{title:"Navbar menu for desktop + sidebar drawer for mobile",desc:"Change screen size to show/hide menu",$$slots:{react:[Ye],html:[We],default:[Je]},$$scope:{ctx:w}}}),g=new ie({props:{title:"Drawer that opens from right side of page",$$slots:{react:[Qe],html:[Ge],default:[Ke]},$$scope:{ctx:w}}}),{c(){Y(e.$$.fragment),m=E(),p=d("p"),n=I("Drawer sidebar can be visible by default on large screens or it can be toggleable on both large and small screens."),s=E(),f=d("p"),r=I("Drawer tags structure:"),t=E(),$=d("pre"),h=E(),_=d("p"),L=I("You can check/uncheck the checkbox using JavaScript or using "),D=d("code"),P=I("<label>"),N=I(" tag."),y=E(),Y(A.$$.fragment),S=E(),Y(b.$$.fragment),M=E(),Y(j.$$.fragment),T=E(),Y(g.$$.fragment),this.h()},l(o){K(e.$$.fragment,o),m=x(o),p=c(o,"P",{});var v=u(p);n=k(v,"Drawer sidebar can be visible by default on large screens or it can be toggleable on both large and small screens."),v.forEach(l),s=x(o),f=c(o,"P",{});var B=u(f);r=k(B,"Drawer tags structure:"),B.forEach(l),t=x(o),$=c(o,"PRE",{class:!0});var z=u($);z.forEach(l),h=x(o),_=c(o,"P",{});var F=u(_);L=k(F,"You can check/uncheck the checkbox using JavaScript or using "),D=c(F,"CODE",{});var R=u(D);P=k(R,"<label>"),R.forEach(l),N=k(F," tag."),F.forEach(l),y=x(o),K(A.$$.fragment,o),S=x(o),K(b.$$.fragment,o),M=x(o),K(j.$$.fragment,o),T=x(o),K(g.$$.fragment,o),this.h()},h(){i($,"class","language-js")},m(o,v){G(e,o,v),V(o,m,v),V(o,p,v),a(p,n),V(o,s,v),V(o,f,v),a(f,r),V(o,t,v),V(o,$,v),$.innerHTML=O,V(o,h,v),V(o,_,v),a(_,L),a(_,D),a(D,P),a(_,N),V(o,y,v),G(A,o,v),V(o,S,v),G(b,o,v),V(o,M,v),G(j,o,v),V(o,T,v),G(g,o,v),C=!0},p(o,v){const B={};v&5&&(B.$$scope={dirty:v,ctx:o}),A.$set(B);const z={};v&5&&(z.$$scope={dirty:v,ctx:o}),b.$set(z);const F={};v&5&&(F.$$scope={dirty:v,ctx:o}),j.$set(F);const R={};v&5&&(R.$$scope={dirty:v,ctx:o}),g.$set(R)},i(o){C||(Q(e.$$.fragment,o),Q(A.$$.fragment,o),Q(b.$$.fragment,o),Q(j.$$.fragment,o),Q(g.$$.fragment,o),C=!0)},o(o){X(e.$$.fragment,o),X(A.$$.fragment,o),X(b.$$.fragment,o),X(j.$$.fragment,o),X(g.$$.fragment,o),C=!1},d(o){Z(e,o),o&&l(m),o&&l(p),o&&l(s),o&&l(f),o&&l(t),o&&l($),o&&l(h),o&&l(_),o&&l(y),Z(A,o),o&&l(S),Z(b,o),o&&l(M),Z(j,o),o&&l(T),Z(g,o)}}}function Ze(w){let e,m;const p=[w[1],Pe];let n={$$slots:{default:[Xe]},$$scope:{ctx:w}};for(let s=0;s<p.length;s+=1)n=me(n,p[s]);return e=new Me({props:n}),{c(){Y(e.$$.fragment)},l(s){K(e.$$.fragment,s)},m(s,f){G(e,s,f),m=!0},p(s,[f]){const r=f&2?je(p,[f&2&&Ne(s[1]),f&0&&Ne(Pe)]):{};f&5&&(r.$$scope={dirty:f,ctx:s}),e.$set(r)},i(s){m||(Q(e.$$.fragment,s),m=!0)},o(s){X(e.$$.fragment,s),m=!1},d(s){Z(e,s)}}}const Pe={title:"Drawer",desc:"Drawer is a grid layout that can show/hide a sidebar on the left or right side of the page.",published:!0};function ea(w,e,m){let p;return Be(w,Oe,n=>m(0,p=n)),w.$$set=n=>{m(1,e=me(me({},e),Se(n)))},e=Se(e),[p,e]}class ca extends Ae{constructor(e){super();Ve(this,e,ea,Ze,Te,{})}}export{ca as default,Pe as metadata};
