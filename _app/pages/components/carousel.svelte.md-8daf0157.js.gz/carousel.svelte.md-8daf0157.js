import{S as xe,i as Ae,s as Ge,w as Z,k as $,x as ee,m as I,y as se,g as L,q as ae,o as te,B as le,d as c,e as t,c as l,a as h,O as S,b as e,H as a,t as Q,h as U,L as ie}from"../../chunks/vendor-bfed1aed.js";import{C as Me,a as re}from"../../chunks/ClassTable-225b3e1d.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/stores-7e0df911.js";function ze(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2")||e(m,"src",v),e(m,"alt","Burger"),e(o,"class","carousel-item"),S(p.src,j="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB")||e(p,"src",j),e(p,"alt","Burger"),e(_,"class","carousel-item"),S(g.src,R="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6")||e(g,"src",R),e(g,"alt","Burger"),e(D,"class","carousel-item"),S(w.src,q="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693")||e(w,"src",q),e(w,"alt","Burger"),e(E,"class","carousel-item"),S(f.src,P="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7")||e(f,"src",P),e(f,"alt","Burger"),e(n,"class","carousel-item"),S(b.src,k="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094")||e(b,"src",k),e(b,"alt","Burger"),e(u,"class","carousel-item"),S(C.src,z="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A")||e(C,"src",z),e(C,"alt","Burger"),e(B,"class","carousel-item"),e(s,"class","carousel rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function Te(O){let s,o=`<div class="carousel rounded-box">
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=8B7BCDC2" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=500B67FB" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=A89D0DE6" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=225E6693" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=9D9539E7" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=BDC01094" alt="Burger">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/burger?w=400&h=300&hash=7F5AE56A" alt="Burger">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function ke(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2")||e(m,"src",v),e(m,"alt","Pizza"),e(o,"class","carousel-item"),S(p.src,j="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB")||e(p,"src",j),e(p,"alt","Pizza"),e(_,"class","carousel-item"),S(g.src,R="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6")||e(g,"src",R),e(g,"alt","Pizza"),e(D,"class","carousel-item"),S(w.src,q="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693")||e(w,"src",q),e(w,"alt","Pizza"),e(E,"class","carousel-item"),S(f.src,P="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7")||e(f,"src",P),e(f,"alt","Pizza"),e(n,"class","carousel-item"),S(b.src,k="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094")||e(b,"src",k),e(b,"alt","Pizza"),e(u,"class","carousel-item"),S(C.src,z="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A")||e(C,"src",z),e(C,"alt","Pizza"),e(B,"class","carousel-item"),e(s,"class","carousel carousel-center rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function Fe(O){let s,o=`<div class="carousel carousel-center rounded-box">
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=8B7BCDC2" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=500B67FB" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=A89D0DE6" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=225E6693" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=9D9539E7" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=BDC01094" alt="Pizza">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/pizza?w=400&h=300&hash=7F5AE56A" alt="Pizza">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Pe(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2")||e(m,"src",v),e(m,"alt","Drink"),e(o,"class","carousel-item"),S(p.src,j="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB")||e(p,"src",j),e(p,"alt","Drink"),e(_,"class","carousel-item"),S(g.src,R="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6")||e(g,"src",R),e(g,"alt","Drink"),e(D,"class","carousel-item"),S(w.src,q="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693")||e(w,"src",q),e(w,"alt","Drink"),e(E,"class","carousel-item"),S(f.src,P="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7")||e(f,"src",P),e(f,"alt","Drink"),e(n,"class","carousel-item"),S(b.src,k="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094")||e(b,"src",k),e(b,"alt","Drink"),e(u,"class","carousel-item"),S(C.src,z="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A")||e(C,"src",z),e(C,"alt","Drink"),e(B,"class","carousel-item"),e(s,"class","carousel carousel-end rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function ye(O){let s,o=`<div class="carousel carousel-end rounded-box">
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=8B7BCDC2" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=500B67FB" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=A89D0DE6" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=225E6693" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=9D9539E7" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=BDC01094" alt="Drink">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/drink?w=400&h=300&hash=7F5AE56A" alt="Drink">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function je(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,class:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,class:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||e(m,"src",v),e(m,"class","w-full"),e(m,"alt","Tailwind CSS carousel component"),e(o,"class","w-full carousel-item"),S(p.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||e(p,"src",j),e(p,"class","w-full"),e(p,"alt","Tailwind CSS carousel component"),e(_,"class","w-full carousel-item"),S(g.src,R="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||e(g,"src",R),e(g,"class","w-full"),e(g,"alt","Tailwind CSS carousel component"),e(D,"class","w-full carousel-item"),S(w.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||e(w,"src",q),e(w,"class","w-full"),e(w,"alt","Tailwind CSS carousel component"),e(E,"class","w-full carousel-item"),S(f.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||e(f,"src",P),e(f,"class","w-full"),e(f,"alt","Tailwind CSS carousel component"),e(n,"class","w-full carousel-item"),S(b.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||e(b,"src",k),e(b,"class","w-full"),e(b,"alt","Tailwind CSS carousel component"),e(u,"class","w-full carousel-item"),S(C.src,z="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||e(C,"src",z),e(C,"class","w-full"),e(C,"alt","Tailwind CSS carousel component"),e(B,"class","w-full carousel-item"),e(s,"class","w-64 carousel rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function Re(O){let s,o=`<div class="w-64 carousel rounded-box">
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full" alt="Tailwind CSS Carousel component">
  </div> 
  <div class="w-full carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full" alt="Tailwind CSS Carousel component">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function qe(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||e(m,"src",v),e(m,"alt","Tailwind Image slider"),e(o,"class","carousel-item h-full"),S(p.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||e(p,"src",j),e(p,"alt","Tailwind Image slider"),e(_,"class","carousel-item h-full"),S(g.src,R="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||e(g,"src",R),e(g,"alt","Tailwind Image slider"),e(D,"class","carousel-item h-full"),S(w.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||e(w,"src",q),e(w,"alt","Tailwind Image slider"),e(E,"class","carousel-item h-full"),S(f.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||e(f,"src",P),e(f,"alt","Tailwind Image slider"),e(n,"class","carousel-item h-full"),S(b.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||e(b,"src",k),e(b,"alt","Tailwind Image slider"),e(u,"class","carousel-item h-full"),S(C.src,z="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||e(C,"src",z),e(C,"alt","Tailwind Image slider"),e(B,"class","carousel-item h-full"),e(s,"class","h-96 carousel carousel-vertical rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function He(O){let s,o=`<div class="h-96 carousel carousel-vertical rounded-box">
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094">
  </div> 
  <div class="carousel-item h-full">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Le(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,class:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,class:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2")||e(m,"src",v),e(m,"class","w-full"),e(m,"alt","Tailwind CSS Image slider"),e(o,"class","w-1/2 carousel-item"),S(p.src,j="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB")||e(p,"src",j),e(p,"class","w-full"),e(p,"alt","Tailwind CSS Image slider"),e(_,"class","w-1/2 carousel-item"),S(g.src,R="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6")||e(g,"src",R),e(g,"class","w-full"),e(g,"alt","Tailwind CSS Image slider"),e(D,"class","w-1/2 carousel-item"),S(w.src,q="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693")||e(w,"src",q),e(w,"class","w-full"),e(w,"alt","Tailwind CSS Image slider"),e(E,"class","w-1/2 carousel-item"),S(f.src,P="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7")||e(f,"src",P),e(f,"class","w-full"),e(f,"alt","Tailwind CSS Image slider"),e(n,"class","w-1/2 carousel-item"),S(b.src,k="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094")||e(b,"src",k),e(b,"class","w-full"),e(b,"alt","Tailwind CSS Image slider"),e(u,"class","w-1/2 carousel-item"),S(C.src,z="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A")||e(C,"src",z),e(C,"class","w-full"),e(C,"alt","Tailwind CSS Image slider"),e(B,"class","w-1/2 carousel-item"),e(s,"class","w-96 carousel rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function Oe(O){let s,o=`<div class="w-96 carousel rounded-box">
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=8B7BCDC2" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=500B67FB" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=A89D0DE6" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=225E6693" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=9D9539E7" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=BDC01094" class="w-full">
  </div> 
  <div class="w-1/2 carousel-item">
    <img src="https://api.lorem.space/image/game?w=256&h=400&hash=7F5AE56A" class="w-full">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Je(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("img"),i=$(),u=t("div"),b=t("img"),G=$(),B=t("div"),C=t("img"),this.h()},l(V){s=l(V,"DIV",{class:!0});var r=h(s);o=l(r,"DIV",{class:!0});var T=h(o);m=l(T,"IMG",{src:!0,class:!0,alt:!0}),T.forEach(c),d=I(r),_=l(r,"DIV",{class:!0});var H=h(_);p=l(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(c),M=I(r),D=l(r,"DIV",{class:!0});var J=h(D);g=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(c),x=I(r),E=l(r,"DIV",{class:!0});var K=h(E);w=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var y=h(n);f=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(c),i=I(r),u=l(r,"DIV",{class:!0});var F=h(u);b=l(F,"IMG",{src:!0,class:!0,alt:!0}),F.forEach(c),G=I(r),B=l(r,"DIV",{class:!0});var N=h(B);C=l(N,"IMG",{src:!0,class:!0,alt:!0}),N.forEach(c),r.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2")||e(m,"src",v),e(m,"class","rounded-box"),e(m,"alt","Tailwind CSS component"),e(o,"class","carousel-item"),S(p.src,j="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB")||e(p,"src",j),e(p,"class","rounded-box"),e(p,"alt","Tailwind CSS component"),e(_,"class","carousel-item"),S(g.src,R="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6")||e(g,"src",R),e(g,"class","rounded-box"),e(g,"alt","Tailwind CSS component"),e(D,"class","carousel-item"),S(w.src,q="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693")||e(w,"src",q),e(w,"class","rounded-box"),e(w,"alt","Tailwind CSS component"),e(E,"class","carousel-item"),S(f.src,P="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7")||e(f,"src",P),e(f,"class","rounded-box"),e(f,"alt","Tailwind CSS component"),e(n,"class","carousel-item"),S(b.src,k="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094")||e(b,"src",k),e(b,"class","rounded-box"),e(b,"alt","Tailwind CSS component"),e(u,"class","carousel-item"),S(C.src,z="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A")||e(C,"src",z),e(C,"class","rounded-box"),e(C,"alt","Tailwind CSS component"),e(B,"class","carousel-item"),e(s,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(V,r){L(V,s,r),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),a(s,A),a(s,n),a(n,f),a(s,i),a(s,u),a(u,b),a(s,G),a(s,B),a(B,C)},d(V){V&&c(s)}}}function Ke(O){let s,o=`<div class="max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box">
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=8B7BCDC2" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=500B67FB" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=A89D0DE6" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=225E6693" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=9D9539E7" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=BDC01094" class="rounded-box">
  </div> 
  <div class="carousel-item">
    <img src="https://api.lorem.space/image/furniture?w=250&h=180&hash=7F5AE56A" class="rounded-box">
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Ne(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z,V;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("img"),M=$(),D=t("div"),g=t("img"),x=$(),E=t("div"),w=t("img"),A=$(),n=t("div"),f=t("a"),P=Q("1"),i=$(),u=t("a"),b=Q("2"),k=$(),G=t("a"),B=Q("3"),C=$(),z=t("a"),V=Q("4"),this.h()},l(r){s=l(r,"DIV",{class:!0});var T=h(s);o=l(T,"DIV",{id:!0,class:!0});var H=h(o);m=l(H,"IMG",{src:!0,class:!0,alt:!0}),H.forEach(c),d=I(T),_=l(T,"DIV",{id:!0,class:!0});var J=h(_);p=l(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(c),M=I(T),D=l(T,"DIV",{id:!0,class:!0});var K=h(D);g=l(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(c),x=I(T),E=l(T,"DIV",{id:!0,class:!0});var y=h(E);w=l(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(c),T.forEach(c),A=I(r),n=l(r,"DIV",{class:!0});var F=h(n);f=l(F,"A",{href:!0,class:!0});var N=h(f);P=U(N,"1"),N.forEach(c),i=I(F),u=l(F,"A",{href:!0,class:!0});var me=h(u);b=U(me,"2"),me.forEach(c),k=I(F),G=l(F,"A",{href:!0,class:!0});var W=h(G);B=U(W,"3"),W.forEach(c),C=I(F),z=l(F,"A",{href:!0,class:!0});var X=h(z);V=U(X,"4"),X.forEach(c),F.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||e(m,"src",v),e(m,"class","w-full"),e(m,"alt","Tailwind CSS image gallery"),e(o,"id","item1"),e(o,"class","w-full carousel-item"),S(p.src,j="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||e(p,"src",j),e(p,"class","w-full"),e(p,"alt","Tailwind CSS image gallery"),e(_,"id","item2"),e(_,"class","w-full carousel-item"),S(g.src,R="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||e(g,"src",R),e(g,"class","w-full"),e(g,"alt","Tailwind CSS image gallery"),e(D,"id","item3"),e(D,"class","w-full carousel-item"),S(w.src,q="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||e(w,"src",q),e(w,"class","w-full"),e(w,"alt","Tailwind CSS image gallery"),e(E,"id","item4"),e(E,"class","w-full carousel-item"),e(s,"class","w-full carousel"),e(f,"href","#item1"),e(f,"class","btn btn-xs"),e(u,"href","#item2"),e(u,"class","btn btn-xs"),e(G,"href","#item3"),e(G,"class","btn btn-xs"),e(z,"href","#item4"),e(z,"class","btn btn-xs"),e(n,"class","flex justify-center w-full py-2 gap-2")},m(r,T){L(r,s,T),a(s,o),a(o,m),a(s,d),a(s,_),a(_,p),a(s,M),a(s,D),a(D,g),a(s,x),a(s,E),a(E,w),L(r,A,T),L(r,n,T),a(n,f),a(f,P),a(n,i),a(n,u),a(u,b),a(n,k),a(n,G),a(G,B),a(n,C),a(n,z),a(z,V)},d(r){r&&c(s),r&&c(A),r&&c(n)}}}function Qe(O){let s,o=`<div class="w-full carousel">
  <div id="item1" class="w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full">
  </div> 
  <div id="item2" class="w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full">
  </div> 
  <div id="item3" class="w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full">
  </div> 
  <div id="item4" class="w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full">
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="btn btn-xs">1</a> 
  <a href="#item2" class="btn btn-xs">2</a> 
  <a href="#item3" class="btn btn-xs">3</a> 
  <a href="#item4" class="btn btn-xs">4</a>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Ue(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P,i,u,b,k,G,B,C,z,V,r,T,H,J,K,y,F,N,me,W,X,we,_e,ce,De;return{c(){s=t("div"),o=t("div"),m=t("img"),d=$(),_=t("div"),p=t("a"),j=Q("\u276E"),M=$(),D=t("a"),g=Q("\u276F"),R=$(),x=t("div"),E=t("img"),q=$(),A=t("div"),n=t("a"),f=Q("\u276E"),P=$(),i=t("a"),u=Q("\u276F"),b=$(),k=t("div"),G=t("img"),C=$(),z=t("div"),V=t("a"),r=Q("\u276E"),T=$(),H=t("a"),J=Q("\u276F"),K=$(),y=t("div"),F=t("img"),me=$(),W=t("div"),X=t("a"),we=Q("\u276E"),_e=$(),ce=t("a"),De=Q("\u276F"),this.h()},l(ue){s=l(ue,"DIV",{class:!0});var Y=h(s);o=l(Y,"DIV",{id:!0,class:!0});var oe=h(o);m=l(oe,"IMG",{src:!0,class:!0,alt:!0}),d=I(oe),_=l(oe,"DIV",{class:!0});var he=h(_);p=l(he,"A",{href:!0,class:!0});var Ee=h(p);j=U(Ee,"\u276E"),Ee.forEach(c),M=I(he),D=l(he,"A",{href:!0,class:!0});var $e=h(D);g=U($e,"\u276F"),$e.forEach(c),he.forEach(c),oe.forEach(c),R=I(Y),x=l(Y,"DIV",{id:!0,class:!0});var de=h(x);E=l(de,"IMG",{src:!0,class:!0,alt:!0}),q=I(de),A=l(de,"DIV",{class:!0});var ve=h(A);n=l(ve,"A",{href:!0,class:!0});var Ie=h(n);f=U(Ie,"\u276E"),Ie.forEach(c),P=I(ve),i=l(ve,"A",{href:!0,class:!0});var be=h(i);u=U(be,"\u276F"),be.forEach(c),ve.forEach(c),de.forEach(c),b=I(Y),k=l(Y,"DIV",{id:!0,class:!0});var pe=h(k);G=l(pe,"IMG",{src:!0,class:!0,alt:!0}),C=I(pe),z=l(pe,"DIV",{class:!0});var ne=h(z);V=l(ne,"A",{href:!0,class:!0});var Ce=h(V);r=U(Ce,"\u276E"),Ce.forEach(c),T=I(ne),H=l(ne,"A",{href:!0,class:!0});var Be=h(H);J=U(Be,"\u276F"),Be.forEach(c),ne.forEach(c),pe.forEach(c),K=I(Y),y=l(Y,"DIV",{id:!0,class:!0});var ge=h(y);F=l(ge,"IMG",{src:!0,class:!0,alt:!0}),me=I(ge),W=l(ge,"DIV",{class:!0});var fe=h(W);X=l(fe,"A",{href:!0,class:!0});var Se=h(X);we=U(Se,"\u276E"),Se.forEach(c),_e=I(fe),ce=l(fe,"A",{href:!0,class:!0});var Ve=h(ce);De=U(Ve,"\u276F"),Ve.forEach(c),fe.forEach(c),ge.forEach(c),Y.forEach(c),this.h()},h(){S(m.src,v="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2")||e(m,"src",v),e(m,"class","w-full"),e(m,"alt","Tailwind CSS image slide"),e(p,"href","#slide4"),e(p,"class","btn btn-circle"),e(D,"href","#slide2"),e(D,"class","btn btn-circle"),e(_,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),e(o,"id","slide1"),e(o,"class","relative w-full carousel-item"),S(E.src,w="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB")||e(E,"src",w),e(E,"class","w-full"),e(E,"alt","Tailwind CSS image slide"),e(n,"href","#slide1"),e(n,"class","btn btn-circle"),e(i,"href","#slide3"),e(i,"class","btn btn-circle"),e(A,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),e(x,"id","slide2"),e(x,"class","relative w-full carousel-item"),S(G.src,B="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6")||e(G,"src",B),e(G,"class","w-full"),e(G,"alt","Tailwind CSS image slide"),e(V,"href","#slide2"),e(V,"class","btn btn-circle"),e(H,"href","#slide4"),e(H,"class","btn btn-circle"),e(z,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),e(k,"id","slide3"),e(k,"class","relative w-full carousel-item"),S(F.src,N="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693")||e(F,"src",N),e(F,"class","w-full"),e(F,"alt","Tailwind CSS image slide"),e(X,"href","#slide3"),e(X,"class","btn btn-circle"),e(ce,"href","#slide1"),e(ce,"class","btn btn-circle"),e(W,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),e(y,"id","slide4"),e(y,"class","relative w-full carousel-item"),e(s,"class","w-full carousel")},m(ue,Y){L(ue,s,Y),a(s,o),a(o,m),a(o,d),a(o,_),a(_,p),a(p,j),a(_,M),a(_,D),a(D,g),a(s,R),a(s,x),a(x,E),a(x,q),a(x,A),a(A,n),a(n,f),a(A,P),a(A,i),a(i,u),a(s,b),a(s,k),a(k,G),a(k,C),a(k,z),a(z,V),a(V,r),a(z,T),a(z,H),a(H,J),a(s,K),a(s,y),a(y,F),a(y,me),a(y,W),a(W,X),a(X,we),a(W,_e),a(W,ce),a(ce,De)},d(ue){ue&&c(s)}}}function We(O){let s,o=`<div class="w-full carousel">
  <div id="slide1" class="relative w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=8B7BCDC2" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">\u276E</a> 
      <a href="#slide2" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide2" class="relative w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=500B67FB" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">\u276E</a> 
      <a href="#slide3" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide3" class="relative w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=A89D0DE6" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">\u276E</a> 
      <a href="#slide4" class="btn btn-circle">\u276F</a>
    </div>
  </div> 
  <div id="slide4" class="relative w-full carousel-item">
    <img src="https://api.lorem.space/image/car?w=800&h=200&hash=225E6693" class="w-full"> 
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">\u276E</a> 
      <a href="#slide1" class="btn btn-circle">\u276F</a>
    </div>
  </div>
</div>`,m;return{c(){s=t("pre"),m=Q(o),this.h()},l(v){s=l(v,"PRE",{slot:!0});var d=h(s);m=U(d,o),d.forEach(c),this.h()},h(){e(s,"slot","html")},m(v,d){L(v,s,d),a(s,m)},p:ie,d(v){v&&c(s)}}}function Xe(O){let s,o,m,v,d,_,p,j,M,D,g,R,x,E,w,q,A,n,f,P;return s=new Me({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),m=new re({props:{title:"Snap to start (default)",$$slots:{html:[Te],default:[ze]},$$scope:{ctx:O}}}),d=new re({props:{title:"Snap to center",$$slots:{html:[Fe],default:[ke]},$$scope:{ctx:O}}}),p=new re({props:{title:"Snap to end",$$slots:{html:[ye],default:[Pe]},$$scope:{ctx:O}}}),M=new re({props:{title:"Carousel with full width items",$$slots:{html:[Re],default:[je]},$$scope:{ctx:O}}}),g=new re({props:{title:"Vertical carousel",$$slots:{html:[He],default:[qe]},$$scope:{ctx:O}}}),x=new re({props:{title:"Carousel with half width items",$$slots:{html:[Oe],default:[Le]},$$scope:{ctx:O}}}),w=new re({props:{title:"Full-bleed carousel",$$slots:{html:[Ke],default:[Je]},$$scope:{ctx:O}}}),A=new re({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[Qe],default:[Ne]},$$scope:{ctx:O}}}),f=new re({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will vertically to the image when you click buttons.",$$slots:{html:[We],default:[Ue]},$$scope:{ctx:O}}}),{c(){Z(s.$$.fragment),o=$(),Z(m.$$.fragment),v=$(),Z(d.$$.fragment),_=$(),Z(p.$$.fragment),j=$(),Z(M.$$.fragment),D=$(),Z(g.$$.fragment),R=$(),Z(x.$$.fragment),E=$(),Z(w.$$.fragment),q=$(),Z(A.$$.fragment),n=$(),Z(f.$$.fragment)},l(i){ee(s.$$.fragment,i),o=I(i),ee(m.$$.fragment,i),v=I(i),ee(d.$$.fragment,i),_=I(i),ee(p.$$.fragment,i),j=I(i),ee(M.$$.fragment,i),D=I(i),ee(g.$$.fragment,i),R=I(i),ee(x.$$.fragment,i),E=I(i),ee(w.$$.fragment,i),q=I(i),ee(A.$$.fragment,i),n=I(i),ee(f.$$.fragment,i)},m(i,u){se(s,i,u),L(i,o,u),se(m,i,u),L(i,v,u),se(d,i,u),L(i,_,u),se(p,i,u),L(i,j,u),se(M,i,u),L(i,D,u),se(g,i,u),L(i,R,u),se(x,i,u),L(i,E,u),se(w,i,u),L(i,q,u),se(A,i,u),L(i,n,u),se(f,i,u),P=!0},p(i,[u]){const b={};u&1&&(b.$$scope={dirty:u,ctx:i}),m.$set(b);const k={};u&1&&(k.$$scope={dirty:u,ctx:i}),d.$set(k);const G={};u&1&&(G.$$scope={dirty:u,ctx:i}),p.$set(G);const B={};u&1&&(B.$$scope={dirty:u,ctx:i}),M.$set(B);const C={};u&1&&(C.$$scope={dirty:u,ctx:i}),g.$set(C);const z={};u&1&&(z.$$scope={dirty:u,ctx:i}),x.$set(z);const V={};u&1&&(V.$$scope={dirty:u,ctx:i}),w.$set(V);const r={};u&1&&(r.$$scope={dirty:u,ctx:i}),A.$set(r);const T={};u&1&&(T.$$scope={dirty:u,ctx:i}),f.$set(T)},i(i){P||(ae(s.$$.fragment,i),ae(m.$$.fragment,i),ae(d.$$.fragment,i),ae(p.$$.fragment,i),ae(M.$$.fragment,i),ae(g.$$.fragment,i),ae(x.$$.fragment,i),ae(w.$$.fragment,i),ae(A.$$.fragment,i),ae(f.$$.fragment,i),P=!0)},o(i){te(s.$$.fragment,i),te(m.$$.fragment,i),te(d.$$.fragment,i),te(p.$$.fragment,i),te(M.$$.fragment,i),te(g.$$.fragment,i),te(x.$$.fragment,i),te(w.$$.fragment,i),te(A.$$.fragment,i),te(f.$$.fragment,i),P=!1},d(i){le(s,i),i&&c(o),le(m,i),i&&c(v),le(d,i),i&&c(_),le(p,i),i&&c(j),le(M,i),i&&c(D),le(g,i),i&&c(R),le(x,i),i&&c(E),le(w,i),i&&c(q),le(A,i),i&&c(n),le(f,i)}}}const as={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};class ts extends xe{constructor(s){super();Ae(this,s,null,Xe,Ge,{})}}export{ts as default,as as metadata};
