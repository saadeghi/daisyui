import{S as He,i as Me,s as ze,C as ke,w as j,x as H,y as M,z as Oe,A as Ue,q as z,o as O,B as q,K as qe,ag as ye,k as B,e as $,H as $e,t as w,m as P,c as m,a as u,I as me,d as r,h as x,b as p,g as L,F as n,a9 as V,Q as U}from"../../chunks/vendor-3400f70d.js";import{M as Se}from"../../chunks/_markdown-d3b608a8.js";import{p as Ye,C as Fe,a as W,r as y}from"../../chunks/actions-fa801718.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-d48cc1de.js";import"../../chunks/index-8d10d321.js";import"../../chunks/SEO-29dfc4ea.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-124099b0.js";function We(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function Ke(h){let e,s=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Qe(h){let e,s=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Te(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-end mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function Ge(h){let e,s=`<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Je(h){let e,s=`<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Xe(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-top mt-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function Ze(h){let e,s=`<div class="$$dropdown $$dropdown-top">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function et(h){let e,s=`<div className="$$dropdown $$dropdown-top">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function tt(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-top dropdown-end mt-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function lt(h){let e,s=`<div class="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function at(h){let e,s=`<div className="$$dropdown $$dropdown-top $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ot(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-bottom mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function st(h){let e,s=`<div class="$$dropdown $$dropdown-bottom">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function nt(h){let e,s=`<div className="$$dropdown $$dropdown-bottom">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function rt(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-bottom dropdown-end mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function dt(h){let e,s=`<div class="$$dropdown $$dropdown-bottom $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function it(h){let e,s=`<div className="$$dropdown $$dropdown-bottom $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ct(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-left mb-16")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function ut(h){let e,s=`<div class="$$dropdown $$dropdown-left">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function pt(h){let e,s=`<div className="$$dropdown $$dropdown-left">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function $t(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-left dropdown-end mt-16")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function mt(h){let e,s=`<div class="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ft(h){let e,s=`<div className="$$dropdown $$dropdown-left $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function ht(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-right mb-16")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function bt(h){let e,s=`<div class="$$dropdown $$dropdown-right">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function vt(h){let e,s=`<div className="$$dropdown $$dropdown-right">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function _t(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Click"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-right dropdown-end mt-16")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function wt(h){let e,s=`<div class="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function xt(h){let e,s=`<div className="$$dropdown $$dropdown-right $$dropdown-end">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Et(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Hover"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Hover"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-hover mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function It(h){let e,s=`<div class="$$dropdown $$dropdown-hover">
  <label tabindex="0" class="$$btn m-1">Hover</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function gt(h){let e,s=`<div className="$$dropdown $$dropdown-hover">
  <label tabIndex={0} className="$$btn m-1">Hover</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function kt(h){let e,s,i,o,l,d,t,a,k,_,v,I;return{c(){e=$("div"),s=$("label"),i=w("Button"),o=B(),l=$("ul"),d=$("li"),t=$("a"),a=w("Item 1"),k=B(),_=$("li"),v=$("a"),I=w("Item 2"),this.h()},l(b){e=m(b,"DIV",{class:!0});var f=u(e);s=m(f,"LABEL",{tabindex:!0,class:!0});var C=u(s);i=x(C,"Button"),C.forEach(r),o=P(f),l=m(f,"UL",{tabindex:!0,class:!0});var E=u(l);d=m(E,"LI",{});var N=u(d);t=m(N,"A",{});var A=u(t);a=x(A,"Item 1"),A.forEach(r),N.forEach(r),k=P(E),_=m(E,"LI",{});var R=u(_);v=m(R,"A",{});var D=u(v);I=x(D,"Item 2"),D.forEach(r),R.forEach(r),E.forEach(r),f.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(l,"tabindex","0"),p(l,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52"),p(e,"class","dropdown dropdown-open mb-32")},m(b,f){L(b,e,f),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(l,k),n(l,_),n(_,v),n(v,I)},d(b){b&&r(e)}}}function Lt(h){let e,s=`<div class="$$dropdown $$dropdown-open">
  <label tabindex="0" class="$$btn m-1">Button</label>
  <ul tabindex="0" class="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Ct(h){let e,s=`<div className="$$dropdown $$dropdown-open">
  <label tabIndex={0} className="$$btn m-1">Button</label>
  <ul tabIndex={0} className="$$dropdown-content $$menu p-2 shadow bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Nt(h){let e,s,i,o,l,d,t,a,k,_,v;return{c(){e=$("div"),s=$("label"),i=w("Click"),o=B(),l=$("div"),d=$("div"),t=$("h3"),a=w("Card title!"),k=B(),_=$("p"),v=w("you can use any element as a dropdown."),this.h()},l(I){e=m(I,"DIV",{class:!0});var b=u(e);s=m(b,"LABEL",{tabindex:!0,class:!0});var f=u(s);i=x(f,"Click"),f.forEach(r),o=P(b),l=m(b,"DIV",{tabindex:!0,class:!0});var C=u(l);d=m(C,"DIV",{class:!0});var E=u(d);t=m(E,"H3",{class:!0});var N=u(t);a=x(N,"Card title!"),N.forEach(r),k=P(E),_=m(E,"P",{});var A=u(_);v=x(A,"you can use any element as a dropdown."),A.forEach(r),E.forEach(r),C.forEach(r),b.forEach(r),this.h()},h(){p(s,"tabindex","0"),p(s,"class","m-1 btn"),p(t,"class","card-title"),p(d,"class","card-body"),p(l,"tabindex","0"),p(l,"class","w-64 p-2 shadow card card-compact dropdown-content bg-primary text-primary-content"),p(e,"class","dropdown mb-32")},m(I,b){L(I,e,b),n(e,s),n(s,i),n(e,o),n(e,l),n(l,d),n(d,t),n(t,a),n(d,k),n(d,_),n(_,v)},d(I){I&&r(e)}}}function At(h){let e,s=`<div class="$$dropdown">
  <label tabindex="0" class="$$btn m-1">Click</label>
  <div tabindex="0" class="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div class="$$card-body">
      <h3 class="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Dt(h){let e,s=`<div className="$$dropdown">
  <label tabIndex={0} className="$$btn m-1">Click</label>
  <div tabIndex={0} className="$$dropdown-content $$card $$card-compact w-64 p-2 shadow bg-primary text-primary-content">
    <div className="$$card-body">
      <h3 className="$$card-title">Card title!</h3>
      <p>you can use any element as a dropdown.</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Bt(h){let e,s,i,o,l,d,t,a,k,_,v,I,b,f,C,E,N,A,R,D,S,Y;return{c(){e=$("div"),s=$("div"),i=$("a"),o=w("daisyUI"),l=B(),d=$("div"),t=$("div"),a=$("a"),k=w("Button"),_=B(),v=$("div"),I=$("label"),b=w("Dropdown"),f=B(),C=$("ul"),E=$("li"),N=$("a"),A=w("Item 1"),R=B(),D=$("li"),S=$("a"),Y=w("Item 2"),this.h()},l(K){e=m(K,"DIV",{class:!0});var F=u(e);s=m(F,"DIV",{class:!0});var ne=u(s);i=m(ne,"A",{class:!0});var J=u(i);o=x(J,"daisyUI"),J.forEach(r),ne.forEach(r),l=P(F),d=m(F,"DIV",{class:!0});var re=u(d);t=m(re,"DIV",{class:!0});var Q=u(t);a=m(Q,"A",{class:!0});var de=u(a);k=x(de,"Button"),de.forEach(r),_=P(Q),v=m(Q,"DIV",{class:!0});var T=u(v);I=m(T,"LABEL",{tabindex:!0,class:!0});var ie=u(I);b=x(ie,"Dropdown"),ie.forEach(r),f=P(T),C=m(T,"UL",{tabindex:!0,class:!0});var G=u(C);E=m(G,"LI",{});var ce=u(E);N=m(ce,"A",{});var X=u(N);A=x(X,"Item 1"),X.forEach(r),ce.forEach(r),R=P(G),D=m(G,"LI",{});var ue=u(D);S=m(ue,"A",{});var Z=u(S);Y=x(Z,"Item 2"),Z.forEach(r),ue.forEach(r),G.forEach(r),T.forEach(r),Q.forEach(r),re.forEach(r),F.forEach(r),this.h()},h(){p(i,"class","text-lg font-bold"),p(s,"class","flex-1 px-2 lg:flex-none"),p(a,"class","btn btn-ghost rounded-btn"),p(I,"tabindex","0"),p(I,"class","btn btn-ghost rounded-btn"),p(C,"tabindex","0"),p(C,"class","p-2 shadow menu dropdown-content bg-base-100 rounded-box w-52 mt-4"),p(v,"class","dropdown dropdown-end"),p(t,"class","flex items-stretch"),p(d,"class","flex justify-end flex-1 px-2"),p(e,"class","navbar mb-40 bg-base-300 rounded-box w-full")},m(K,F){L(K,e,F),n(e,s),n(s,i),n(i,o),n(e,l),n(e,d),n(d,t),n(t,a),n(a,k),n(t,_),n(t,v),n(v,I),n(I,b),n(v,f),n(v,C),n(C,E),n(E,N),n(N,A),n(C,R),n(C,D),n(D,S),n(S,Y)},d(K){K&&r(e)}}}function Pt(h){let e,s=`<div class="$$navbar bg-base-300 rounded-box">
  <div class="flex-1 px-2 lg:flex-none">
    <a class="text-lg font-bold">daisyUI</a>
  </div> 
  <div class="flex justify-end flex-1 px-2">
    <div class="flex items-stretch">
      <a class="$$btn $$btn-ghost rounded-btn">Button</a>
      <div class="$$dropdown $$dropdown-end">
        <label tabindex="0" class="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabindex="0" class="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Rt(h){let e,s=`<div className="$$navbar bg-base-300 rounded-box">
  <div className="flex-1 px-2 lg:flex-none">
    <a className="text-lg font-bold">daisyUI</a>
  </div> 
  <div className="flex justify-end flex-1 px-2">
    <div className="flex items-stretch">
      <a className="$$btn $$btn-ghost rounded-btn">Button</a>
      <div className="$$dropdown $$dropdown-end">
        <label tabIndex={0} className="$$btn $$btn-ghost rounded-btn">Dropdown</label>
        <ul tabIndex={0} className="$$menu $$dropdown-content p-2 shadow bg-base-100 rounded-box w-52 mt-4">
          <li><a>Item 1</a></li> 
          <li><a>Item 2</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function Vt(h){let e,s,i,o,l,d,t,a,k,_,v,I,b,f;return{c(){e=$("div"),s=w(`A normal text and a helper dropdown
  `),i=$("div"),o=$("label"),l=$e("svg"),d=$e("path"),t=B(),a=$("div"),k=$("div"),_=$("h2"),v=w("You needed more info?"),I=B(),b=$("p"),f=w("Here is a description!"),this.h()},l(C){e=m(C,"DIV",{class:!0});var E=u(e);s=x(E,`A normal text and a helper dropdown
  `),i=m(E,"DIV",{class:!0});var N=u(i);o=m(N,"LABEL",{tabindex:!0,class:!0});var A=u(o);l=me(A,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var R=u(l);d=me(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),R.forEach(r),A.forEach(r),t=P(N),a=m(N,"DIV",{tabindex:!0,class:!0});var D=u(a);k=m(D,"DIV",{class:!0});var S=u(k);_=m(S,"H2",{class:!0});var Y=u(_);v=x(Y,"You needed more info?"),Y.forEach(r),I=P(S),b=m(S,"P",{});var K=u(b);f=x(K,"Here is a description!"),K.forEach(r),S.forEach(r),D.forEach(r),N.forEach(r),E.forEach(r),this.h()},h(){p(d,"stroke-linecap","round"),p(d,"stroke-linejoin","round"),p(d,"stroke-width","2"),p(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(l,"xmlns","http://www.w3.org/2000/svg"),p(l,"fill","none"),p(l,"viewBox","0 0 24 24"),p(l,"class","w-4 h-4 stroke-current"),p(o,"tabindex","0"),p(o,"class","btn btn-circle btn-ghost btn-xs text-info"),p(_,"class","card-title"),p(k,"class","card-body"),p(a,"tabindex","0"),p(a,"class","shadow card compact dropdown-content bg-base-100 rounded-box w-64"),p(i,"class","dropdown dropdown-end"),p(e,"class","mb-28 mt-6 flex gap-1 items-center")},m(C,E){L(C,e,E),n(e,s),n(e,i),n(i,o),n(o,l),n(l,d),n(i,t),n(i,a),n(a,k),n(k,_),n(_,v),n(k,I),n(k,b),n(b,f)},d(C){C&&r(e)}}}function Ut(h){let e,s=`A normal text and a helper dropdown
<div class="$$dropdown $$dropdown-end">
  <label tabindex="0" class="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="w-4 h-4 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabindex="0" class="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div class="$$card-body">
      <h2 class="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","html")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function yt(h){let e,s=`A normal text and a helper dropdown
<div className="$$dropdown $$dropdown-end">
  <label tabIndex={0} className="$$btn $$btn-circle $$btn-ghost $$btn-xs text-info">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="w-4 h-4 stroke-current"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
  </label>
  <div tabIndex={0} className="$$card $$compact $$dropdown-content shadow bg-base-100 rounded-box w-64">
    <div className="$$card-body">
      <h2 className="$$card-title">You needed more info?</h2> 
      <p>Here is a description!</p>
    </div>
  </div>
</div>`,i,o,l,d;return{c(){e=$("pre"),i=w(s),this.h()},l(t){e=m(t,"PRE",{slot:!0});var a=u(e);i=x(a,s),a.forEach(r),this.h()},h(){p(e,"slot","react")},m(t,a){L(t,e,a),n(e,i),l||(d=V(o=y.call(null,e,{to:h[0]})),l=!0)},p(t,a){o&&U(o.update)&&a&1&&o.update.call(null,{to:t[0]})},d(t){t&&r(e),l=!1,d()}}}function jt(h){let e,s,i,o,l,d,t,a,k,_,v,I,b,f,C,E,N,A,R,D,S,Y,K,F,ne,J,re,Q,de,T,ie,G,ce,X,ue,Z,_e,ee,we,te,xe,le,Ee,ae,Ie,oe,ge;return e=new Fe({props:{data:[{type:"component",class:"dropdown",desc:"Container element"},{type:"component",class:"dropdown-content",desc:"Container for content"},{type:"modifier",class:"dropdown-end",desc:"Aligns to end"},{type:"modifier",class:"dropdown-top",desc:"Open from top"},{type:"modifier",class:"dropdown-bottom",desc:"Open from bottom"},{type:"modifier",class:"dropdown-left",desc:"Open from left"},{type:"modifier",class:"dropdown-right",desc:"Open from right"},{type:"modifier",class:"dropdown-hover",desc:"Opens on hover too"},{type:"modifier",class:"dropdown-open",desc:"Force open"}]}}),A=new W({props:{title:"Dropdown menu",$$slots:{react:[Qe],html:[Ke],default:[We]},$$scope:{ctx:h}}}),D=new W({props:{title:"Dropdown / aligns to end",$$slots:{react:[Je],html:[Ge],default:[Te]},$$scope:{ctx:h}}}),Y=new W({props:{title:"Dropdown top",$$slots:{react:[et],html:[Ze],default:[Xe]},$$scope:{ctx:h}}}),F=new W({props:{title:"Dropdown top / aligns to end",$$slots:{react:[at],html:[lt],default:[tt]},$$scope:{ctx:h}}}),J=new W({props:{title:"Dropdown bottom",$$slots:{react:[nt],html:[st],default:[ot]},$$scope:{ctx:h}}}),Q=new W({props:{title:"Dropdown bottom / aligns to end",$$slots:{react:[it],html:[dt],default:[rt]},$$scope:{ctx:h}}}),T=new W({props:{title:"Dropdown left",$$slots:{react:[pt],html:[ut],default:[ct]},$$scope:{ctx:h}}}),G=new W({props:{title:"Dropdown left / aligns to end",$$slots:{react:[ft],html:[mt],default:[$t]},$$scope:{ctx:h}}}),X=new W({props:{title:"Dropdown right",$$slots:{react:[vt],html:[bt],default:[ht]},$$scope:{ctx:h}}}),Z=new W({props:{title:"Dropdown right / aligns to end",$$slots:{react:[xt],html:[wt],default:[_t]},$$scope:{ctx:h}}}),ee=new W({props:{title:"Dropdown on hover",$$slots:{react:[gt],html:[It],default:[Et]},$$scope:{ctx:h}}}),te=new W({props:{title:"Force open",$$slots:{react:[Ct],html:[Lt],default:[kt]},$$scope:{ctx:h}}}),le=new W({props:{title:"Card as dropdown",$$slots:{react:[Dt],html:[At],default:[Nt]},$$scope:{ctx:h}}}),ae=new W({props:{title:"Dropdown in navbar",$$slots:{react:[Rt],html:[Pt],default:[Bt]},$$scope:{ctx:h}}}),oe=new W({props:{title:"Helper dropdown",$$slots:{react:[yt],html:[Ut],default:[Vt]},$$scope:{ctx:h}}}),{c(){j(e.$$.fragment),s=B(),i=$("div"),o=$("div"),l=$e("svg"),d=$e("path"),t=w(`
    We use a <label tabindex="0"> instead of a <button> because Safari has `),a=$("a"),k=w("a bug"),_=w(" that prevents the button from being focused."),v=B(),I=$("div"),b=$("div"),f=$e("svg"),C=$e("path"),E=w(`
    Using tabindex="0" is required so the dropdown can be focused.`),N=B(),j(A.$$.fragment),R=B(),j(D.$$.fragment),S=B(),j(Y.$$.fragment),K=B(),j(F.$$.fragment),ne=B(),j(J.$$.fragment),re=B(),j(Q.$$.fragment),de=B(),j(T.$$.fragment),ie=B(),j(G.$$.fragment),ce=B(),j(X.$$.fragment),ue=B(),j(Z.$$.fragment),_e=B(),j(ee.$$.fragment),we=B(),j(te.$$.fragment),xe=B(),j(le.$$.fragment),Ee=B(),j(ae.$$.fragment),Ie=B(),j(oe.$$.fragment),this.h()},l(c){H(e.$$.fragment,c),s=P(c),i=m(c,"DIV",{class:!0});var g=u(i);o=m(g,"DIV",{});var se=u(o);l=me(se,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var fe=u(l);d=me(fe,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(d).forEach(r),fe.forEach(r),t=x(se,`
    We use a <label tabindex="0"> instead of a <button> because Safari has `),a=m(se,"A",{rel:!0,target:!0,href:!0});var he=u(a);k=x(he,"a bug"),he.forEach(r),_=x(se," that prevents the button from being focused."),se.forEach(r),g.forEach(r),v=P(c),I=m(c,"DIV",{class:!0});var be=u(I);b=m(be,"DIV",{});var pe=u(b);f=me(pe,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var ve=u(f);C=me(ve,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(C).forEach(r),ve.forEach(r),E=x(pe,`
    Using tabindex="0" is required so the dropdown can be focused.`),pe.forEach(r),be.forEach(r),N=P(c),H(A.$$.fragment,c),R=P(c),H(D.$$.fragment,c),S=P(c),H(Y.$$.fragment,c),K=P(c),H(F.$$.fragment,c),ne=P(c),H(J.$$.fragment,c),re=P(c),H(Q.$$.fragment,c),de=P(c),H(T.$$.fragment,c),ie=P(c),H(G.$$.fragment,c),ce=P(c),H(X.$$.fragment,c),ue=P(c),H(Z.$$.fragment,c),_e=P(c),H(ee.$$.fragment,c),we=P(c),H(te.$$.fragment,c),xe=P(c),H(le.$$.fragment,c),Ee=P(c),H(ae.$$.fragment,c),Ie=P(c),H(oe.$$.fragment,c),this.h()},h(){p(d,"stroke-linecap","round"),p(d,"stroke-linejoin","round"),p(d,"stroke-width","2"),p(d,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(l,"xmlns","http://www.w3.org/2000/svg"),p(l,"fill","none"),p(l,"viewBox","0 0 24 24"),p(l,"class","stroke-info-content flex-shrink-0 w-6 h-6"),p(a,"rel","noopener noreferrer"),p(a,"target","_blank"),p(a,"href","https://bugs.webkit.org/show_bug.cgi?id=22261"),p(i,"class","alert alert-info text-sm mb-2"),p(C,"stroke-linecap","round"),p(C,"stroke-linejoin","round"),p(C,"stroke-width","2"),p(C,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(f,"xmlns","http://www.w3.org/2000/svg"),p(f,"fill","none"),p(f,"viewBox","0 0 24 24"),p(f,"class","stroke-info-content flex-shrink-0 w-6 h-6"),p(I,"class","alert alert-info text-sm")},m(c,g){M(e,c,g),L(c,s,g),L(c,i,g),n(i,o),n(o,l),n(l,d),n(o,t),n(o,a),n(a,k),n(o,_),L(c,v,g),L(c,I,g),n(I,b),n(b,f),n(f,C),n(b,E),L(c,N,g),M(A,c,g),L(c,R,g),M(D,c,g),L(c,S,g),M(Y,c,g),L(c,K,g),M(F,c,g),L(c,ne,g),M(J,c,g),L(c,re,g),M(Q,c,g),L(c,de,g),M(T,c,g),L(c,ie,g),M(G,c,g),L(c,ce,g),M(X,c,g),L(c,ue,g),M(Z,c,g),L(c,_e,g),M(ee,c,g),L(c,we,g),M(te,c,g),L(c,xe,g),M(le,c,g),L(c,Ee,g),M(ae,c,g),L(c,Ie,g),M(oe,c,g),ge=!0},p(c,g){const se={};g&5&&(se.$$scope={dirty:g,ctx:c}),A.$set(se);const fe={};g&5&&(fe.$$scope={dirty:g,ctx:c}),D.$set(fe);const he={};g&5&&(he.$$scope={dirty:g,ctx:c}),Y.$set(he);const be={};g&5&&(be.$$scope={dirty:g,ctx:c}),F.$set(be);const pe={};g&5&&(pe.$$scope={dirty:g,ctx:c}),J.$set(pe);const ve={};g&5&&(ve.$$scope={dirty:g,ctx:c}),Q.$set(ve);const Le={};g&5&&(Le.$$scope={dirty:g,ctx:c}),T.$set(Le);const Ce={};g&5&&(Ce.$$scope={dirty:g,ctx:c}),G.$set(Ce);const Ne={};g&5&&(Ne.$$scope={dirty:g,ctx:c}),X.$set(Ne);const Ae={};g&5&&(Ae.$$scope={dirty:g,ctx:c}),Z.$set(Ae);const De={};g&5&&(De.$$scope={dirty:g,ctx:c}),ee.$set(De);const Be={};g&5&&(Be.$$scope={dirty:g,ctx:c}),te.$set(Be);const Pe={};g&5&&(Pe.$$scope={dirty:g,ctx:c}),le.$set(Pe);const Re={};g&5&&(Re.$$scope={dirty:g,ctx:c}),ae.$set(Re);const Ve={};g&5&&(Ve.$$scope={dirty:g,ctx:c}),oe.$set(Ve)},i(c){ge||(z(e.$$.fragment,c),z(A.$$.fragment,c),z(D.$$.fragment,c),z(Y.$$.fragment,c),z(F.$$.fragment,c),z(J.$$.fragment,c),z(Q.$$.fragment,c),z(T.$$.fragment,c),z(G.$$.fragment,c),z(X.$$.fragment,c),z(Z.$$.fragment,c),z(ee.$$.fragment,c),z(te.$$.fragment,c),z(le.$$.fragment,c),z(ae.$$.fragment,c),z(oe.$$.fragment,c),ge=!0)},o(c){O(e.$$.fragment,c),O(A.$$.fragment,c),O(D.$$.fragment,c),O(Y.$$.fragment,c),O(F.$$.fragment,c),O(J.$$.fragment,c),O(Q.$$.fragment,c),O(T.$$.fragment,c),O(G.$$.fragment,c),O(X.$$.fragment,c),O(Z.$$.fragment,c),O(ee.$$.fragment,c),O(te.$$.fragment,c),O(le.$$.fragment,c),O(ae.$$.fragment,c),O(oe.$$.fragment,c),ge=!1},d(c){q(e,c),c&&r(s),c&&r(i),c&&r(v),c&&r(I),c&&r(N),q(A,c),c&&r(R),q(D,c),c&&r(S),q(Y,c),c&&r(K),q(F,c),c&&r(ne),q(J,c),c&&r(re),q(Q,c),c&&r(de),q(T,c),c&&r(ie),q(G,c),c&&r(ce),q(X,c),c&&r(ue),q(Z,c),c&&r(_e),q(ee,c),c&&r(we),q(te,c),c&&r(xe),q(le,c),c&&r(Ee),q(ae,c),c&&r(Ie),q(oe,c)}}}function Ht(h){let e,s;const i=[h[1],je];let o={$$slots:{default:[jt]},$$scope:{ctx:h}};for(let l=0;l<i.length;l+=1)o=ke(o,i[l]);return e=new Se({props:o}),{c(){j(e.$$.fragment)},l(l){H(e.$$.fragment,l)},m(l,d){M(e,l,d),s=!0},p(l,[d]){const t=d&2?Oe(i,[d&2&&Ue(l[1]),d&0&&Ue(je)]):{};d&5&&(t.$$scope={dirty:d,ctx:l}),e.$set(t)},i(l){s||(z(e.$$.fragment,l),s=!0)},o(l){O(e.$$.fragment,l),s=!1},d(l){q(e,l)}}}const je={title:"Dropdown",desc:"Dropdown can open a menu or any other element when the button is clicked.",published:!0};function Mt(h,e,s){let i;return qe(h,Ye,o=>s(0,i=o)),h.$$set=o=>{s(1,e=ke(ke({},e),ye(o)))},e=ye(e),[i,e]}class Tt extends He{constructor(e){super();Me(this,e,Mt,Ht,ze,{})}}export{Tt as default,je as metadata};
