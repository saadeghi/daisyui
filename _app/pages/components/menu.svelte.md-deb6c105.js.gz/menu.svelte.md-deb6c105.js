import{S as Te,i as Fe,s as Ke,C as Le,w as y,x as ee,y as te,z as Qe,A as De,q as le,o as ae,B as se,K as Xe,ag as qe,k as S,m as N,g as M,d as s,e as h,t as E,c as m,a as u,h as g,b as p,F as a,a9 as q,Q as O,H as oe,I as re}from"../../chunks/vendor-3400f70d.js";import{M as Ge}from"../../chunks/_markdown-97893592.js";import{p as Je,C as Ye,a as he,r as T}from"../../chunks/actions-296e1868.js";import"../../chunks/stores-a971fa48.js";import"../../chunks/Ads-c1aa5061.js";import"../../chunks/index-a7daade6.js";import"../../chunks/SEO-9c2c7857.js";import"../../chunks/preload-helper-ec9aa979.js";import"../../chunks/Translate-20d2573a.js";function Ze($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 w-56 shadow-xl")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function ye($){let e,i=`<ul class="$$menu bg-base-100 w-56">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function et($){let e,i=`<ul className="$$menu bg-base-100 w-56">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function tt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{class:!0});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(t,"class","active"),p(e,"class","menu bg-base-100 w-56 shadow-xl")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function lt($){let e,i=`<ul class="$$menu bg-base-100 w-56">
  <li><a>Item 1</a></li>
  <li><a class="$$active">Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function at($){let e,i=`<ul className="$$menu bg-base-100 w-56">
  <li><a>Item 1</a></li>
  <li><a className="$$active">Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function st($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 w-56 shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function ot($){let e,i=`<ul class="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function rt($){let e,i=`<ul className="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function nt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 w-56 shadow-xl p-2 rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function it($){let e,i=`<ul class="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function ut($){let e,i=`<ul className="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function ct($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V;return{c(){e=h("ul"),i=h("li"),r=h("span"),o=E("Category"),n=S(),c=h("li"),t=h("a"),l=E("Item 1"),b=S(),_=h("li"),v=h("a"),k=E("Item 2"),w=S(),f=h("li"),x=h("span"),L=E("Category"),I=S(),C=h("li"),z=h("a"),P=E("Item 1"),B=S(),H=h("li"),U=h("a"),V=E("Item 2"),this.h()},l(j){e=m(j,"UL",{class:!0});var R=u(e);i=m(R,"LI",{class:!0});var W=u(i);r=m(W,"SPAN",{});var K=u(r);o=g(K,"Category"),K.forEach(s),W.forEach(s),n=N(R),c=m(R,"LI",{});var D=u(c);t=m(D,"A",{});var ne=u(t);l=g(ne,"Item 1"),ne.forEach(s),D.forEach(s),b=N(R),_=m(R,"LI",{});var X=u(_);v=m(X,"A",{});var Q=u(v);k=g(Q,"Item 2"),Q.forEach(s),X.forEach(s),w=N(R),f=m(R,"LI",{class:!0});var G=u(f);x=m(G,"SPAN",{});var F=u(x);L=g(F,"Category"),F.forEach(s),G.forEach(s),I=N(R),C=m(R,"LI",{});var J=u(C);z=m(J,"A",{});var Z=u(z);P=g(Z,"Item 1"),Z.forEach(s),J.forEach(s),B=N(R),H=m(R,"LI",{});var Y=u(H);U=m(Y,"A",{});var ce=u(U);V=g(ce,"Item 2"),ce.forEach(s),Y.forEach(s),R.forEach(s),this.h()},h(){p(i,"class","menu-title"),p(f,"class","menu-title"),p(e,"class","menu bg-base-100 w-56 shadow-xl p-2 rounded-box")},m(j,R){M(j,e,R),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k),a(e,w),a(e,f),a(f,x),a(x,L),a(e,I),a(e,C),a(C,z),a(z,P),a(e,B),a(e,H),a(H,U),a(U,V)},d(j){j&&s(e)}}}function ht($){let e,i=`<ul class="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li class="$$menu-title">
    <span>Category</span>
  </li>
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li class="$$menu-title">
    <span>Category</span>
  </li>
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function mt($){let e,i=`<ul className="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li className="$$menu-title">
    <span>Category</span>
  </li>
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li className="$$menu-title">
    <span>Category</span>
  </li>
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function dt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("I have border"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{class:!0});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"I have border"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(c,"class","bordered"),p(e,"class","menu bg-base-100 w-56 shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function pt($){let e,i=`<ul class="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li class="$$bordered"><a>I have border</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function ft($){let e,i=`<ul className="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li className="$$bordered"><a>I have border</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function vt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Hover me"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{class:!0});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Hover me"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(c,"class","hover-bordered"),p(e,"class","menu bg-base-100 w-56 shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function _t($){let e,i=`<ul class="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li class="$$hover-bordered"><a>Hover me</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function $t($){let e,i=`<ul className="$$menu bg-base-100 w-56 rounded-box">
  <li><a>Item 1</a></li>
  <li className="$$hover-bordered"><a>Hover me</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function wt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{class:!0});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{class:!0});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{class:!0});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(i,"class","disabled"),p(c,"class","disabled"),p(_,"class","disabled"),p(e,"class","menu bg-base-100 w-56 shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function bt($){let e,i=`<ul class="$$menu bg-base-100 w-56 rounded-box">
  <li class="$$disabled"><a>Item 1</a></li>
  <li class="$$disabled"><a>Item 2</a></li>
  <li class="$$disabled"><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Et($){let e,i=`<ul className="$$menu bg-base-100 w-56 rounded-box">
  <li className="$$disabled"><a>Item 1</a></li>
  <li className="$$disabled"><a>Item 2</a></li>
  <li className="$$disabled"><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function gt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 menu-compact w-56 shadow-xl p-2 rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function It($){let e,i=`<ul class="$$menu $$menu-compact bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function kt($){let e,i=`<ul className="$$menu $$menu-compact bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function xt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 menu-compact lg:menu-normal w-56 shadow-xl p-2 rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function Lt($){let e,i=`<ul class="$$menu $$menu-compact lg:$$menu-normal bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function At($){let e,i=`<ul className="$$menu $$menu-compact lg:$$menu-normal bg-base-100 w-56 p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Pt($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 menu-horizontal shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function Mt($){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-100 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function zt($){let e,i=`<ul className="$$menu $$menu-horizontal bg-base-100 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function St($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu bg-base-100 menu-vertical lg:menu-horizontal shadow-xl rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function Nt($){let e,i=`<ul class="$$menu $$menu-vertical lg:$$menu-horizontal bg-base-100 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Ct($){let e,i=`<ul className="$$menu $$menu-vertical lg:$$menu-horizontal bg-base-100 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function jt($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=oe("svg"),n=oe("path"),c=E(`
    Item 2`),t=S(),l=h("li"),b=h("a"),_=oe("svg"),v=oe("path"),k=E(`
      Item 1`),w=S(),f=h("li"),x=h("a"),L=oe("svg"),I=oe("path"),C=E(`
      Item 3`),this.h()},l(z){e=m(z,"UL",{class:!0});var P=u(e);i=m(P,"LI",{});var B=u(i);r=m(B,"A",{});var H=u(r);o=re(H,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var U=u(o);n=re(U,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(n).forEach(s),U.forEach(s),c=g(H,`
    Item 2`),H.forEach(s),B.forEach(s),t=N(P),l=m(P,"LI",{});var V=u(l);b=m(V,"A",{});var j=u(b);_=re(j,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var R=u(_);v=re(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(v).forEach(s),R.forEach(s),k=g(j,`
      Item 1`),j.forEach(s),V.forEach(s),w=N(P),f=m(P,"LI",{});var W=u(f);x=m(W,"A",{});var K=u(x);L=re(K,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var D=u(L);I=re(D,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(I).forEach(s),D.forEach(s),C=g(K,`
      Item 3`),K.forEach(s),W.forEach(s),P.forEach(s),this.h()},h(){p(n,"stroke-linecap","round"),p(n,"stroke-linejoin","round"),p(n,"stroke-width","2"),p(n,"d","M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"),p(o,"xmlns","http://www.w3.org/2000/svg"),p(o,"class","h-5 w-5"),p(o,"fill","none"),p(o,"viewBox","0 0 24 24"),p(o,"stroke","currentColor"),p(v,"stroke-linecap","round"),p(v,"stroke-linejoin","round"),p(v,"stroke-width","2"),p(v,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(_,"xmlns","http://www.w3.org/2000/svg"),p(_,"class","h-5 w-5"),p(_,"fill","none"),p(_,"viewBox","0 0 24 24"),p(_,"stroke","currentColor"),p(I,"stroke-linecap","round"),p(I,"stroke-linejoin","round"),p(I,"stroke-width","2"),p(I,"d","M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"),p(L,"xmlns","http://www.w3.org/2000/svg"),p(L,"class","h-5 w-5"),p(L,"fill","none"),p(L,"viewBox","0 0 24 24"),p(L,"stroke","currentColor"),p(e,"class","menu bg-base-100 w-56 shadow-xl p-2 rounded-box")},m(z,P){M(z,e,P),a(e,i),a(i,r),a(r,o),a(o,n),a(r,c),a(e,t),a(e,l),a(l,b),a(b,_),a(_,v),a(b,k),a(e,w),a(e,f),a(f,x),a(x,L),a(L,I),a(x,C)},d(z){z&&s(e)}}}function Bt($){let e,i=`<ul class="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    Item 2
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      Item 1
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
      Item 3
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Rt($){let e,i=`<ul className="$$menu bg-base-100 w-56 p-2 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    Item 2
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      Item 1
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
      Item 3
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Ut($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=oe("svg"),n=oe("path"),c=S(),t=h("li"),l=h("a"),b=oe("svg"),_=oe("path"),v=S(),k=h("li"),w=h("a"),f=oe("svg"),x=oe("path"),this.h()},l(L){e=m(L,"UL",{class:!0});var I=u(e);i=m(I,"LI",{});var C=u(i);r=m(C,"A",{});var z=u(r);o=re(z,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var P=u(o);n=re(P,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(n).forEach(s),P.forEach(s),z.forEach(s),C.forEach(s),c=N(I),t=m(I,"LI",{});var B=u(t);l=m(B,"A",{});var H=u(l);b=re(H,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var U=u(b);_=re(U,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(_).forEach(s),U.forEach(s),H.forEach(s),B.forEach(s),v=N(I),k=m(I,"LI",{});var V=u(k);w=m(V,"A",{});var j=u(w);f=re(j,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var R=u(f);x=re(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(x).forEach(s),R.forEach(s),j.forEach(s),V.forEach(s),I.forEach(s),this.h()},h(){p(n,"stroke-linecap","round"),p(n,"stroke-linejoin","round"),p(n,"stroke-width","2"),p(n,"d","M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"),p(o,"xmlns","http://www.w3.org/2000/svg"),p(o,"class","h-5 w-5"),p(o,"fill","none"),p(o,"viewBox","0 0 24 24"),p(o,"stroke","currentColor"),p(_,"stroke-linecap","round"),p(_,"stroke-linejoin","round"),p(_,"stroke-width","2"),p(_,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(b,"xmlns","http://www.w3.org/2000/svg"),p(b,"class","h-5 w-5"),p(b,"fill","none"),p(b,"viewBox","0 0 24 24"),p(b,"stroke","currentColor"),p(x,"stroke-linecap","round"),p(x,"stroke-linejoin","round"),p(x,"stroke-width","2"),p(x,"d","M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"),p(f,"xmlns","http://www.w3.org/2000/svg"),p(f,"class","h-5 w-5"),p(f,"fill","none"),p(f,"viewBox","0 0 24 24"),p(f,"stroke","currentColor"),p(e,"class","menu bg-base-100 shadow-xl rounded-box")},m(L,I){M(L,e,I),a(e,i),a(i,r),a(r,o),a(o,n),a(e,c),a(e,t),a(t,l),a(l,b),a(b,_),a(e,v),a(e,k),a(k,w),a(w,f),a(f,x)},d(L){L&&s(e)}}}function Vt($){let e,i=`<ul class="$$menu bg-base-100 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Ht($){let e,i=`<ul className="$$menu bg-base-100 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Wt($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=oe("svg"),n=oe("path"),c=S(),t=h("li"),l=h("a"),b=oe("svg"),_=oe("path"),v=S(),k=h("li"),w=h("a"),f=oe("svg"),x=oe("path"),this.h()},l(L){e=m(L,"UL",{class:!0});var I=u(e);i=m(I,"LI",{});var C=u(i);r=m(C,"A",{});var z=u(r);o=re(z,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var P=u(o);n=re(P,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(n).forEach(s),P.forEach(s),z.forEach(s),C.forEach(s),c=N(I),t=m(I,"LI",{});var B=u(t);l=m(B,"A",{});var H=u(l);b=re(H,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var U=u(b);_=re(U,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(_).forEach(s),U.forEach(s),H.forEach(s),B.forEach(s),v=N(I),k=m(I,"LI",{});var V=u(k);w=m(V,"A",{});var j=u(w);f=re(j,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var R=u(f);x=re(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(x).forEach(s),R.forEach(s),j.forEach(s),V.forEach(s),I.forEach(s),this.h()},h(){p(n,"stroke-linecap","round"),p(n,"stroke-linejoin","round"),p(n,"stroke-width","2"),p(n,"d","M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"),p(o,"xmlns","http://www.w3.org/2000/svg"),p(o,"class","h-5 w-5"),p(o,"fill","none"),p(o,"viewBox","0 0 24 24"),p(o,"stroke","currentColor"),p(_,"stroke-linecap","round"),p(_,"stroke-linejoin","round"),p(_,"stroke-width","2"),p(_,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(b,"xmlns","http://www.w3.org/2000/svg"),p(b,"class","h-5 w-5"),p(b,"fill","none"),p(b,"viewBox","0 0 24 24"),p(b,"stroke","currentColor"),p(x,"stroke-linecap","round"),p(x,"stroke-linejoin","round"),p(x,"stroke-width","2"),p(x,"d","M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"),p(f,"xmlns","http://www.w3.org/2000/svg"),p(f,"class","h-5 w-5"),p(f,"fill","none"),p(f,"viewBox","0 0 24 24"),p(f,"stroke","currentColor"),p(e,"class","menu bg-base-100 menu-horizontal shadow-xl rounded-box")},m(L,I){M(L,e,I),a(e,i),a(i,r),a(r,o),a(o,n),a(e,c),a(e,t),a(t,l),a(l,b),a(b,_),a(e,v),a(e,k),a(k,w),a(w,f),a(f,x)},d(L){L&&s(e)}}}function Dt($){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-100 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function qt($){let e,i=`<ul className="$$menu $$menu-horizontal bg-base-100 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Ot($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=oe("svg"),n=oe("path"),c=S(),t=h("li"),l=h("a"),b=oe("svg"),_=oe("path"),v=S(),k=h("li"),w=h("a"),f=oe("svg"),x=oe("path"),this.h()},l(L){e=m(L,"UL",{class:!0});var I=u(e);i=m(I,"LI",{});var C=u(i);r=m(C,"A",{});var z=u(r);o=re(z,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var P=u(o);n=re(P,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(n).forEach(s),P.forEach(s),z.forEach(s),C.forEach(s),c=N(I),t=m(I,"LI",{});var B=u(t);l=m(B,"A",{});var H=u(l);b=re(H,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var U=u(b);_=re(U,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(_).forEach(s),U.forEach(s),H.forEach(s),B.forEach(s),v=N(I),k=m(I,"LI",{});var V=u(k);w=m(V,"A",{});var j=u(w);f=re(j,"svg",{xmlns:!0,class:!0,fill:!0,viewBox:!0,stroke:!0});var R=u(f);x=re(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),u(x).forEach(s),R.forEach(s),j.forEach(s),V.forEach(s),I.forEach(s),this.h()},h(){p(n,"stroke-linecap","round"),p(n,"stroke-linejoin","round"),p(n,"stroke-width","2"),p(n,"d","M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"),p(o,"xmlns","http://www.w3.org/2000/svg"),p(o,"class","h-5 w-5"),p(o,"fill","none"),p(o,"viewBox","0 0 24 24"),p(o,"stroke","currentColor"),p(_,"stroke-linecap","round"),p(_,"stroke-linejoin","round"),p(_,"stroke-width","2"),p(_,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),p(b,"xmlns","http://www.w3.org/2000/svg"),p(b,"class","h-5 w-5"),p(b,"fill","none"),p(b,"viewBox","0 0 24 24"),p(b,"stroke","currentColor"),p(x,"stroke-linecap","round"),p(x,"stroke-linejoin","round"),p(x,"stroke-width","2"),p(x,"d","M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"),p(f,"xmlns","http://www.w3.org/2000/svg"),p(f,"class","h-5 w-5"),p(f,"fill","none"),p(f,"viewBox","0 0 24 24"),p(f,"stroke","currentColor"),p(e,"class","menu bg-base-100 shadow-xl p-2 rounded-box")},m(L,I){M(L,e,I),a(e,i),a(i,r),a(r,o),a(o,n),a(e,c),a(e,t),a(t,l),a(l,b),a(b,_),a(e,v),a(e,k),a(k,w),a(w,f),a(f,x)},d(L){L&&s(e)}}}function Tt($){let e,i=`<ul class="$$menu bg-base-100 p-2 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Ft($){let e,i=`<ul className="$$menu bg-base-100 p-2 rounded-box">
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
    </a>
  </li>
  <li>
    <a>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
    </a>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Kt($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R;return{c(){e=h("div"),i=h("ul"),r=h("li"),o=h("a"),n=E("Item 1"),c=S(),t=h("li"),l=h("span"),b=E("Parent"),_=S(),v=h("ul"),k=h("li"),w=h("a"),f=E("Submenu 1"),x=S(),L=h("li"),I=h("a"),C=E("Submenu 2"),z=S(),P=h("li"),B=h("a"),H=E("Submenu 3"),U=S(),V=h("li"),j=h("a"),R=E("Item 3"),this.h()},l(W){e=m(W,"DIV",{class:!0});var K=u(e);i=m(K,"UL",{class:!0});var D=u(i);r=m(D,"LI",{});var ne=u(r);o=m(ne,"A",{});var X=u(o);n=g(X,"Item 1"),X.forEach(s),ne.forEach(s),c=N(D),t=m(D,"LI",{tabindex:!0});var Q=u(t);l=m(Q,"SPAN",{});var G=u(l);b=g(G,"Parent"),G.forEach(s),_=N(Q),v=m(Q,"UL",{class:!0});var F=u(v);k=m(F,"LI",{});var J=u(k);w=m(J,"A",{});var Z=u(w);f=g(Z,"Submenu 1"),Z.forEach(s),J.forEach(s),x=N(F),L=m(F,"LI",{});var Y=u(L);I=m(Y,"A",{});var ce=u(I);C=g(ce,"Submenu 2"),ce.forEach(s),Y.forEach(s),z=N(F),P=m(F,"LI",{});var ie=u(P);B=m(ie,"A",{});var me=u(B);H=g(me,"Submenu 3"),me.forEach(s),ie.forEach(s),F.forEach(s),Q.forEach(s),U=N(D),V=m(D,"LI",{});var ue=u(V);j=m(ue,"A",{});var de=u(j);R=g(de,"Item 3"),de.forEach(s),ue.forEach(s),D.forEach(s),K.forEach(s),this.h()},h(){p(v,"class","bg-base-100"),p(t,"tabindex","0"),p(i,"class","menu bg-base-100 menu-horizontal"),p(e,"class","mb-40")},m(W,K){M(W,e,K),a(e,i),a(i,r),a(r,o),a(o,n),a(i,c),a(i,t),a(t,l),a(l,b),a(t,_),a(t,v),a(v,k),a(k,w),a(w,f),a(v,x),a(v,L),a(L,I),a(I,C),a(v,z),a(v,P),a(P,B),a(B,H),a(i,U),a(i,V),a(V,j),a(j,R)},d(W){W&&s(e)}}}function Qt($){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-100">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabindex="0">
    <span>Parent</span>
    <ul class="bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Xt($){let e,i=`<ul className="$$menu $$menu-horizontal bg-base-100">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabIndex={0}>
    <span>Parent</span>
    <ul className="bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Gt($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R;return{c(){e=h("div"),i=h("ul"),r=h("li"),o=h("a"),n=E("Item 1"),c=S(),t=h("li"),l=h("span"),b=E("Parent"),_=S(),v=h("ul"),k=h("li"),w=h("a"),f=E("Submenu 1"),x=S(),L=h("li"),I=h("a"),C=E("Submenu 2"),z=S(),P=h("li"),B=h("a"),H=E("Submenu 3"),U=S(),V=h("li"),j=h("a"),R=E("Item 3"),this.h()},l(W){e=m(W,"DIV",{class:!0});var K=u(e);i=m(K,"UL",{class:!0});var D=u(i);r=m(D,"LI",{});var ne=u(r);o=m(ne,"A",{});var X=u(o);n=g(X,"Item 1"),X.forEach(s),ne.forEach(s),c=N(D),t=m(D,"LI",{tabindex:!0});var Q=u(t);l=m(Q,"SPAN",{});var G=u(l);b=g(G,"Parent"),G.forEach(s),_=N(Q),v=m(Q,"UL",{class:!0});var F=u(v);k=m(F,"LI",{});var J=u(k);w=m(J,"A",{});var Z=u(w);f=g(Z,"Submenu 1"),Z.forEach(s),J.forEach(s),x=N(F),L=m(F,"LI",{});var Y=u(L);I=m(Y,"A",{});var ce=u(I);C=g(ce,"Submenu 2"),ce.forEach(s),Y.forEach(s),z=N(F),P=m(F,"LI",{});var ie=u(P);B=m(ie,"A",{});var me=u(B);H=g(me,"Submenu 3"),me.forEach(s),ie.forEach(s),F.forEach(s),Q.forEach(s),U=N(D),V=m(D,"LI",{});var ue=u(V);j=m(ue,"A",{});var de=u(j);R=g(de,"Item 3"),de.forEach(s),ue.forEach(s),D.forEach(s),K.forEach(s),this.h()},h(){p(v,"class","rounded-box bg-base-100 p-2 shadow-xl"),p(t,"tabindex","0"),p(i,"class","menu bg-base-100 menu-horizontal shadow-xl rounded-box p-2"),p(e,"class","mb-40")},m(W,K){M(W,e,K),a(e,i),a(i,r),a(r,o),a(o,n),a(i,c),a(i,t),a(t,l),a(l,b),a(t,_),a(t,v),a(v,k),a(k,w),a(w,f),a(v,x),a(v,L),a(L,I),a(I,C),a(v,z),a(v,P),a(P,B),a(B,H),a(i,U),a(i,V),a(V,j),a(j,R)},d(W){W&&s(e)}}}function Jt($){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-100 rounded-box p-2">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabindex="0">
    <span>Parent</span>
    <ul class="rounded-box bg-base-100 p-2">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Yt($){let e,i=`<ul className="$$menu $$menu-horizontal bg-base-100 rounded-box p-2">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabIndex={0}>
    <span>Parent</span>
    <ul className="rounded-box bg-base-100 p-2">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function Zt($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R;return{c(){e=h("div"),i=h("ul"),r=h("li"),o=h("a"),n=E("Item 1"),c=S(),t=h("li"),l=h("span"),b=E("Parent"),_=S(),v=h("ul"),k=h("li"),w=h("a"),f=E("Submenu 1"),x=S(),L=h("li"),I=h("a"),C=E("Submenu 2"),z=S(),P=h("li"),B=h("a"),H=E("Submenu 3"),U=S(),V=h("li"),j=h("a"),R=E("Item 3"),this.h()},l(W){e=m(W,"DIV",{class:!0});var K=u(e);i=m(K,"UL",{class:!0});var D=u(i);r=m(D,"LI",{});var ne=u(r);o=m(ne,"A",{});var X=u(o);n=g(X,"Item 1"),X.forEach(s),ne.forEach(s),c=N(D),t=m(D,"LI",{tabindex:!0});var Q=u(t);l=m(Q,"SPAN",{});var G=u(l);b=g(G,"Parent"),G.forEach(s),_=N(Q),v=m(Q,"UL",{class:!0});var F=u(v);k=m(F,"LI",{});var J=u(k);w=m(J,"A",{});var Z=u(w);f=g(Z,"Submenu 1"),Z.forEach(s),J.forEach(s),x=N(F),L=m(F,"LI",{});var Y=u(L);I=m(Y,"A",{});var ce=u(I);C=g(ce,"Submenu 2"),ce.forEach(s),Y.forEach(s),z=N(F),P=m(F,"LI",{});var ie=u(P);B=m(ie,"A",{});var me=u(B);H=g(me,"Submenu 3"),me.forEach(s),ie.forEach(s),F.forEach(s),Q.forEach(s),U=N(D),V=m(D,"LI",{});var ue=u(V);j=m(ue,"A",{});var de=u(j);R=g(de,"Item 3"),de.forEach(s),ue.forEach(s),D.forEach(s),K.forEach(s),this.h()},h(){p(v,"class","bg-base-100"),p(t,"tabindex","0"),p(i,"class","menu bg-base-100"),p(e,"class","mb-20 mr-20")},m(W,K){M(W,e,K),a(e,i),a(i,r),a(r,o),a(o,n),a(i,c),a(i,t),a(t,l),a(l,b),a(t,_),a(t,v),a(v,k),a(k,w),a(w,f),a(v,x),a(v,L),a(L,I),a(I,C),a(v,z),a(v,P),a(P,B),a(B,H),a(i,U),a(i,V),a(V,j),a(j,R)},d(W){W&&s(e)}}}function yt($){let e,i=`<ul class="$$menu bg-base-100">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabindex="0">
    <span>Parent</span>
    <ul class="bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function el($){let e,i=`<ul className="$$menu bg-base-100">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabIndex={0}>
    <span>Parent</span>
    <ul className="bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function tl($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R;return{c(){e=h("div"),i=h("ul"),r=h("li"),o=h("a"),n=E("Item 1"),c=S(),t=h("li"),l=h("span"),b=E("Parent"),_=S(),v=h("ul"),k=h("li"),w=h("a"),f=E("Submenu 1"),x=S(),L=h("li"),I=h("a"),C=E("Submenu 2"),z=S(),P=h("li"),B=h("a"),H=E("Submenu 3"),U=S(),V=h("li"),j=h("a"),R=E("Item 3"),this.h()},l(W){e=m(W,"DIV",{class:!0});var K=u(e);i=m(K,"UL",{class:!0});var D=u(i);r=m(D,"LI",{});var ne=u(r);o=m(ne,"A",{});var X=u(o);n=g(X,"Item 1"),X.forEach(s),ne.forEach(s),c=N(D),t=m(D,"LI",{tabindex:!0});var Q=u(t);l=m(Q,"SPAN",{});var G=u(l);b=g(G,"Parent"),G.forEach(s),_=N(Q),v=m(Q,"UL",{class:!0});var F=u(v);k=m(F,"LI",{});var J=u(k);w=m(J,"A",{});var Z=u(w);f=g(Z,"Submenu 1"),Z.forEach(s),J.forEach(s),x=N(F),L=m(F,"LI",{});var Y=u(L);I=m(Y,"A",{});var ce=u(I);C=g(ce,"Submenu 2"),ce.forEach(s),Y.forEach(s),z=N(F),P=m(F,"LI",{});var ie=u(P);B=m(ie,"A",{});var me=u(B);H=g(me,"Submenu 3"),me.forEach(s),ie.forEach(s),F.forEach(s),Q.forEach(s),U=N(D),V=m(D,"LI",{});var ue=u(V);j=m(ue,"A",{});var de=u(j);R=g(de,"Item 3"),de.forEach(s),ue.forEach(s),D.forEach(s),K.forEach(s),this.h()},h(){p(v,"class","rounded-box p-2 bg-base-100 shadow-xl"),p(t,"tabindex","0"),p(i,"class","menu bg-base-100 shadow-xl rounded-box p-2"),p(e,"class","mb-20 mr-20")},m(W,K){M(W,e,K),a(e,i),a(i,r),a(r,o),a(o,n),a(i,c),a(i,t),a(t,l),a(l,b),a(t,_),a(t,v),a(v,k),a(k,w),a(w,f),a(v,x),a(v,L),a(L,I),a(I,C),a(v,z),a(v,P),a(P,B),a(B,H),a(i,U),a(i,V),a(V,j),a(j,R)},d(W){W&&s(e)}}}function ll($){let e,i=`<ul class="$$menu bg-base-100 rounded-box p-2">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabindex="0">
    <span>Parent</span>
    <ul class="rounded-box p-2 bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function al($){let e,i=`<ul className="$$menu bg-base-100 rounded-box p-2">
  <li><a>Item 1</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabIndex={0}>
    <span>Parent</span>
    <ul className="rounded-box p-2 bg-base-100">
      <li><a>Submenu 1</a></li>
      <li><a>Submenu 2</a></li>
      <li><a>Submenu 3</a></li>
    </ul>
  </li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function sl($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R,W,K,D,ne,X,Q,G,F;return{c(){e=h("div"),i=h("ul"),r=h("li"),o=h("a"),n=E("Item"),c=S(),t=h("li"),l=h("span"),b=E("Level 1"),_=S(),v=h("ul"),k=h("li"),w=h("span"),f=E("Level 2"),x=S(),L=h("ul"),I=h("li"),C=h("span"),z=E("Level 3"),P=S(),B=h("ul"),H=h("li"),U=h("span"),V=E("Level 4"),j=S(),R=h("ul"),W=h("li"),K=h("span"),D=E("Level 5"),ne=S(),X=h("ul"),Q=h("li"),G=h("a"),F=E("Level 6"),this.h()},l(J){e=m(J,"DIV",{class:!0});var Z=u(e);i=m(Z,"UL",{class:!0});var Y=u(i);r=m(Y,"LI",{});var ce=u(r);o=m(ce,"A",{});var ie=u(o);n=g(ie,"Item"),ie.forEach(s),ce.forEach(s),c=N(Y),t=m(Y,"LI",{tabindex:!0});var me=u(t);l=m(me,"SPAN",{});var ue=u(l);b=g(ue,"Level 1"),ue.forEach(s),_=N(me),v=m(me,"UL",{class:!0});var de=u(v);k=m(de,"LI",{});var pe=u(k);w=m(pe,"SPAN",{});var _e=u(w);f=g(_e,"Level 2"),_e.forEach(s),x=N(pe),L=m(pe,"UL",{});var fe=u(L);I=m(fe,"LI",{});var ve=u(I);C=m(ve,"SPAN",{});var d=u(C);z=g(d,"Level 3"),d.forEach(s),P=N(ve),B=m(ve,"UL",{});var A=u(B);H=m(A,"LI",{});var $e=u(H);U=m($e,"SPAN",{});var be=u(U);V=g(be,"Level 4"),be.forEach(s),j=N($e),R=m($e,"UL",{});var Ee=u(R);W=m(Ee,"LI",{});var we=u(W);K=m(we,"SPAN",{});var ge=u(K);D=g(ge,"Level 5"),ge.forEach(s),ne=N(we),X=m(we,"UL",{});var Ie=u(X);Q=m(Ie,"LI",{});var ke=u(Q);G=m(ke,"A",{});var xe=u(G);F=g(xe,"Level 6"),xe.forEach(s),ke.forEach(s),Ie.forEach(s),we.forEach(s),Ee.forEach(s),$e.forEach(s),A.forEach(s),ve.forEach(s),fe.forEach(s),pe.forEach(s),de.forEach(s),me.forEach(s),Y.forEach(s),Z.forEach(s),this.h()},h(){p(v,"class","rounded-box bg-base-100 shadow-xl p-2"),p(t,"tabindex","0"),p(i,"class","menu bg-base-100 menu-horizontal shadow-xl rounded-box p-2"),p(e,"class","mb-80")},m(J,Z){M(J,e,Z),a(e,i),a(i,r),a(r,o),a(o,n),a(i,c),a(i,t),a(t,l),a(l,b),a(t,_),a(t,v),a(v,k),a(k,w),a(w,f),a(k,x),a(k,L),a(L,I),a(I,C),a(C,z),a(I,P),a(I,B),a(B,H),a(H,U),a(U,V),a(H,j),a(H,R),a(R,W),a(W,K),a(K,D),a(W,ne),a(W,X),a(X,Q),a(Q,G),a(G,F)},d(J){J&&s(e)}}}function ol($){let e,i=`<ul class="$$menu $$menu-horizontal bg-base-100 rounded-box p-2">
  <li><a>Item</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabindex="0">
    <span>Level 1</span>
    <ul class="rounded-box bg-base-100 p-2">
      <li>
        <span>Level 2</span>
        <ul>
          <li>
            <span>Level 3</span>
            <ul>
              <li>
                <span>Level 4</span>
                <ul>
                  <li>
                    <span>Level 5</span>
                    <ul>
                      <li><a>Level 6</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function rl($){let e,i=`<ul className="$$menu $$menu-horizontal bg-base-100 rounded-box p-2">
  <li><a>Item</a></li>
  <!-- tabindex will make the parent menu focusable to keep the submenu open if it's focused -->
  <li tabIndex={0}>
    <span>Level 1</span>
    <ul className="rounded-box bg-base-100 p-2">
      <li>
        <span>Level 2</span>
        <ul>
          <li>
            <span>Level 3</span>
            <ul>
              <li>
                <span>Level 4</span>
                <ul>
                  <li>
                    <span>Level 5</span>
                    <ul>
                      <li><a>Level 6</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function nl($){let e,i,r,o,n,c,t,l,b,_,v,k;return{c(){e=h("ul"),i=h("li"),r=h("a"),o=E("Item 1"),n=S(),c=h("li"),t=h("a"),l=E("Item 2"),b=S(),_=h("li"),v=h("a"),k=E("Item 3"),this.h()},l(w){e=m(w,"UL",{class:!0});var f=u(e);i=m(f,"LI",{});var x=u(i);r=m(x,"A",{});var L=u(r);o=g(L,"Item 1"),L.forEach(s),x.forEach(s),n=N(f),c=m(f,"LI",{});var I=u(c);t=m(I,"A",{});var C=u(t);l=g(C,"Item 2"),C.forEach(s),I.forEach(s),b=N(f),_=m(f,"LI",{});var z=u(_);v=m(z,"A",{});var P=u(v);k=g(P,"Item 3"),P.forEach(s),z.forEach(s),f.forEach(s),this.h()},h(){p(e,"class","menu w-56 bg-secondary text-secondary-content p-2 rounded-box")},m(w,f){M(w,e,f),a(e,i),a(i,r),a(r,o),a(e,n),a(e,c),a(c,t),a(t,l),a(e,b),a(e,_),a(_,v),a(v,k)},d(w){w&&s(e)}}}function il($){let e,i=`<ul class="$$menu w-56 bg-secondary text-secondary-content p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","html")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function ul($){let e,i=`<ul className="$$menu w-56 bg-secondary text-secondary-content p-2 rounded-box">
  <li><a>Item 1</a></li>
  <li><a>Item 2</a></li>
  <li><a>Item 3</a></li>
</ul>`,r,o,n,c;return{c(){e=h("pre"),r=E(i),this.h()},l(t){e=m(t,"PRE",{slot:!0});var l=u(e);r=g(l,i),l.forEach(s),this.h()},h(){p(e,"slot","react")},m(t,l){M(t,e,l),a(e,r),n||(c=q(o=T.call(null,e,{to:$[0]})),n=!0)},p(t,l){o&&O(o.update)&&l&1&&o.update.call(null,{to:t[0]})},d(t){t&&s(e),n=!1,c()}}}function cl($){let e,i,r,o,n,c,t,l,b,_,v,k,w,f,x,L,I,C,z,P,B,H,U,V,j,R,W,K,D,ne,X,Q,G,F,J,Z,Y,ce,ie,me,ue,de,pe,_e,fe,ve;return e=new Ye({props:{data:[{type:"component",class:"menu",desc:"Container <ul> element"},{type:"component",class:"menu-title",desc:"Identify <li> as the title of menu"},{type:"modifier",class:"disabled",desc:"Sets <li> as disabled"},{type:"modifier",class:"active",desc:"highlights the element inside <li> as active"},{type:"modifier",class:"bordered",desc:"adds a border to the <li>"},{type:"modifier",class:"hover-bordered",desc:"adds a border to the <li> when hovered"},{type:"responsive",class:"menu-normal",desc:"Normal text size and normal spacing (default)"},{type:"responsive",class:"menu-compact",desc:"Smaller text size and compact spacing"},{type:"responsive",class:"menu-vertical",desc:"Vertical menu (default)"},{type:"responsive",class:"menu-horizontal",desc:"Horizontal menu"}]}}),r=new he({props:{title:"Menu",$$slots:{react:[et],html:[ye],default:[Ze]},$$scope:{ctx:$}}}),n=new he({props:{title:"Menu with active item",$$slots:{react:[at],html:[lt],default:[tt]},$$scope:{ctx:$}}}),t=new he({props:{title:"Menu with rounded corner",$$slots:{react:[rt],html:[ot],default:[st]},$$scope:{ctx:$}}}),b=new he({props:{title:"Menu with padding",$$slots:{react:[ut],html:[it],default:[nt]},$$scope:{ctx:$}}}),v=new he({props:{title:"Menu with title",$$slots:{react:[mt],html:[ht],default:[ct]},$$scope:{ctx:$}}}),w=new he({props:{title:"Item with border",$$slots:{react:[ft],html:[pt],default:[dt]},$$scope:{ctx:$}}}),x=new he({props:{title:"Item with border (on hover)",$$slots:{react:[$t],html:[_t],default:[vt]},$$scope:{ctx:$}}}),I=new he({props:{title:"Disabled items",$$slots:{react:[Et],html:[bt],default:[wt]},$$scope:{ctx:$}}}),z=new he({props:{title:"Compact",$$slots:{react:[kt],html:[It],default:[gt]},$$scope:{ctx:$}}}),B=new he({props:{title:"Responsive (compact by default, normal on large screen)",$$slots:{react:[At],html:[Lt],default:[xt]},$$scope:{ctx:$}}}),U=new he({props:{title:"Horizontal",$$slots:{react:[zt],html:[Mt],default:[Pt]},$$scope:{ctx:$}}}),j=new he({props:{title:"Responsive (vertical by default, horizontal on large screen)",$$slots:{react:[Ct],html:[Nt],default:[St]},$$scope:{ctx:$}}}),W=new he({props:{title:"With icons",$$slots:{react:[Rt],html:[Bt],default:[jt]},$$scope:{ctx:$}}}),D=new he({props:{title:"Only icons",$$slots:{react:[Ht],html:[Vt],default:[Ut]},$$scope:{ctx:$}}}),X=new he({props:{title:"Only icons (horizontal)",$$slots:{react:[qt],html:[Dt],default:[Wt]},$$scope:{ctx:$}}}),G=new he({props:{title:"Icons with padding",$$slots:{react:[Ft],html:[Tt],default:[Ot]},$$scope:{ctx:$}}}),J=new he({props:{title:"Horizontal with submenu",$$slots:{react:[Xt],html:[Qt],default:[Kt]},$$scope:{ctx:$}}}),Y=new he({props:{title:"Horizontal with submenu and padding and border radius",$$slots:{react:[Yt],html:[Jt],default:[Gt]},$$scope:{ctx:$}}}),ie=new he({props:{title:"Vertical with submenu",$$slots:{react:[el],html:[yt],default:[Zt]},$$scope:{ctx:$}}}),ue=new he({props:{title:"Vertical with submenu and padding and border radius",$$slots:{react:[al],html:[ll],default:[tl]},$$scope:{ctx:$}}}),pe=new he({props:{title:"A lot of submenus",desc:"The second level will be a dropdown and after that, to avoid a bad UX all levels will be visible with a padding.",$$slots:{react:[rl],html:[ol],default:[sl]},$$scope:{ctx:$}}}),fe=new he({props:{title:"With custom color",$$slots:{react:[ul],html:[il],default:[nl]},$$scope:{ctx:$}}}),{c(){y(e.$$.fragment),i=S(),y(r.$$.fragment),o=S(),y(n.$$.fragment),c=S(),y(t.$$.fragment),l=S(),y(b.$$.fragment),_=S(),y(v.$$.fragment),k=S(),y(w.$$.fragment),f=S(),y(x.$$.fragment),L=S(),y(I.$$.fragment),C=S(),y(z.$$.fragment),P=S(),y(B.$$.fragment),H=S(),y(U.$$.fragment),V=S(),y(j.$$.fragment),R=S(),y(W.$$.fragment),K=S(),y(D.$$.fragment),ne=S(),y(X.$$.fragment),Q=S(),y(G.$$.fragment),F=S(),y(J.$$.fragment),Z=S(),y(Y.$$.fragment),ce=S(),y(ie.$$.fragment),me=S(),y(ue.$$.fragment),de=S(),y(pe.$$.fragment),_e=S(),y(fe.$$.fragment)},l(d){ee(e.$$.fragment,d),i=N(d),ee(r.$$.fragment,d),o=N(d),ee(n.$$.fragment,d),c=N(d),ee(t.$$.fragment,d),l=N(d),ee(b.$$.fragment,d),_=N(d),ee(v.$$.fragment,d),k=N(d),ee(w.$$.fragment,d),f=N(d),ee(x.$$.fragment,d),L=N(d),ee(I.$$.fragment,d),C=N(d),ee(z.$$.fragment,d),P=N(d),ee(B.$$.fragment,d),H=N(d),ee(U.$$.fragment,d),V=N(d),ee(j.$$.fragment,d),R=N(d),ee(W.$$.fragment,d),K=N(d),ee(D.$$.fragment,d),ne=N(d),ee(X.$$.fragment,d),Q=N(d),ee(G.$$.fragment,d),F=N(d),ee(J.$$.fragment,d),Z=N(d),ee(Y.$$.fragment,d),ce=N(d),ee(ie.$$.fragment,d),me=N(d),ee(ue.$$.fragment,d),de=N(d),ee(pe.$$.fragment,d),_e=N(d),ee(fe.$$.fragment,d)},m(d,A){te(e,d,A),M(d,i,A),te(r,d,A),M(d,o,A),te(n,d,A),M(d,c,A),te(t,d,A),M(d,l,A),te(b,d,A),M(d,_,A),te(v,d,A),M(d,k,A),te(w,d,A),M(d,f,A),te(x,d,A),M(d,L,A),te(I,d,A),M(d,C,A),te(z,d,A),M(d,P,A),te(B,d,A),M(d,H,A),te(U,d,A),M(d,V,A),te(j,d,A),M(d,R,A),te(W,d,A),M(d,K,A),te(D,d,A),M(d,ne,A),te(X,d,A),M(d,Q,A),te(G,d,A),M(d,F,A),te(J,d,A),M(d,Z,A),te(Y,d,A),M(d,ce,A),te(ie,d,A),M(d,me,A),te(ue,d,A),M(d,de,A),te(pe,d,A),M(d,_e,A),te(fe,d,A),ve=!0},p(d,A){const $e={};A&5&&($e.$$scope={dirty:A,ctx:d}),r.$set($e);const be={};A&5&&(be.$$scope={dirty:A,ctx:d}),n.$set(be);const Ee={};A&5&&(Ee.$$scope={dirty:A,ctx:d}),t.$set(Ee);const we={};A&5&&(we.$$scope={dirty:A,ctx:d}),b.$set(we);const ge={};A&5&&(ge.$$scope={dirty:A,ctx:d}),v.$set(ge);const Ie={};A&5&&(Ie.$$scope={dirty:A,ctx:d}),w.$set(Ie);const ke={};A&5&&(ke.$$scope={dirty:A,ctx:d}),x.$set(ke);const xe={};A&5&&(xe.$$scope={dirty:A,ctx:d}),I.$set(xe);const Ae={};A&5&&(Ae.$$scope={dirty:A,ctx:d}),z.$set(Ae);const Pe={};A&5&&(Pe.$$scope={dirty:A,ctx:d}),B.$set(Pe);const Me={};A&5&&(Me.$$scope={dirty:A,ctx:d}),U.$set(Me);const ze={};A&5&&(ze.$$scope={dirty:A,ctx:d}),j.$set(ze);const Se={};A&5&&(Se.$$scope={dirty:A,ctx:d}),W.$set(Se);const Ne={};A&5&&(Ne.$$scope={dirty:A,ctx:d}),D.$set(Ne);const Ce={};A&5&&(Ce.$$scope={dirty:A,ctx:d}),X.$set(Ce);const je={};A&5&&(je.$$scope={dirty:A,ctx:d}),G.$set(je);const Be={};A&5&&(Be.$$scope={dirty:A,ctx:d}),J.$set(Be);const Re={};A&5&&(Re.$$scope={dirty:A,ctx:d}),Y.$set(Re);const Ue={};A&5&&(Ue.$$scope={dirty:A,ctx:d}),ie.$set(Ue);const Ve={};A&5&&(Ve.$$scope={dirty:A,ctx:d}),ue.$set(Ve);const He={};A&5&&(He.$$scope={dirty:A,ctx:d}),pe.$set(He);const We={};A&5&&(We.$$scope={dirty:A,ctx:d}),fe.$set(We)},i(d){ve||(le(e.$$.fragment,d),le(r.$$.fragment,d),le(n.$$.fragment,d),le(t.$$.fragment,d),le(b.$$.fragment,d),le(v.$$.fragment,d),le(w.$$.fragment,d),le(x.$$.fragment,d),le(I.$$.fragment,d),le(z.$$.fragment,d),le(B.$$.fragment,d),le(U.$$.fragment,d),le(j.$$.fragment,d),le(W.$$.fragment,d),le(D.$$.fragment,d),le(X.$$.fragment,d),le(G.$$.fragment,d),le(J.$$.fragment,d),le(Y.$$.fragment,d),le(ie.$$.fragment,d),le(ue.$$.fragment,d),le(pe.$$.fragment,d),le(fe.$$.fragment,d),ve=!0)},o(d){ae(e.$$.fragment,d),ae(r.$$.fragment,d),ae(n.$$.fragment,d),ae(t.$$.fragment,d),ae(b.$$.fragment,d),ae(v.$$.fragment,d),ae(w.$$.fragment,d),ae(x.$$.fragment,d),ae(I.$$.fragment,d),ae(z.$$.fragment,d),ae(B.$$.fragment,d),ae(U.$$.fragment,d),ae(j.$$.fragment,d),ae(W.$$.fragment,d),ae(D.$$.fragment,d),ae(X.$$.fragment,d),ae(G.$$.fragment,d),ae(J.$$.fragment,d),ae(Y.$$.fragment,d),ae(ie.$$.fragment,d),ae(ue.$$.fragment,d),ae(pe.$$.fragment,d),ae(fe.$$.fragment,d),ve=!1},d(d){se(e,d),d&&s(i),se(r,d),d&&s(o),se(n,d),d&&s(c),se(t,d),d&&s(l),se(b,d),d&&s(_),se(v,d),d&&s(k),se(w,d),d&&s(f),se(x,d),d&&s(L),se(I,d),d&&s(C),se(z,d),d&&s(P),se(B,d),d&&s(H),se(U,d),d&&s(V),se(j,d),d&&s(R),se(W,d),d&&s(K),se(D,d),d&&s(ne),se(X,d),d&&s(Q),se(G,d),d&&s(F),se(J,d),d&&s(Z),se(Y,d),d&&s(ce),se(ie,d),d&&s(me),se(ue,d),d&&s(de),se(pe,d),d&&s(_e),se(fe,d)}}}function hl($){let e,i;const r=[$[1],Oe];let o={$$slots:{default:[cl]},$$scope:{ctx:$}};for(let n=0;n<r.length;n+=1)o=Le(o,r[n]);return e=new Ge({props:o}),{c(){y(e.$$.fragment)},l(n){ee(e.$$.fragment,n)},m(n,c){te(e,n,c),i=!0},p(n,[c]){const t=c&2?Qe(r,[c&2&&De(n[1]),c&0&&De(Oe)]):{};c&5&&(t.$$scope={dirty:c,ctx:n}),e.$set(t)},i(n){i||(le(e.$$.fragment,n),i=!0)},o(n){ae(e.$$.fragment,n),i=!1},d(n){se(e,n)}}}const Oe={title:"Menu",desc:"Menu is used to display a list of links vertically or horizontally.",published:!0};function ml($,e,i){let r;return Xe($,Je,o=>i(0,r=o)),$.$$set=o=>{i(1,e=Le(Le({},e),qe(o)))},e=qe(e),[r,e]}class gl extends Te{constructor(e){super();Fe(this,e,ml,hl,Ke,{})}}export{gl as default,Oe as metadata};
