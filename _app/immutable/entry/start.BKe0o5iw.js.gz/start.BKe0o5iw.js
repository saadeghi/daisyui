import{a as t}from"../chunks/entry.B1HtNHG-.js";export{t as start};
