import{a as t}from"../chunks/entry._Y2GNVbf.js";export{t as start};
