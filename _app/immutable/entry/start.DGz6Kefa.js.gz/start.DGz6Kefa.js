import{a as t}from"../chunks/entry.COajjx3P.js";export{t as start};
