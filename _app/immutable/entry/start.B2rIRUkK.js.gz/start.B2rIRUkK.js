import{a as t}from"../chunks/entry.ezzM030k.js";export{t as start};
