import{a as t}from"../chunks/entry.CwvU7qbD.js";export{t as start};
