import{a as t}from"../chunks/entry.CFLDxgLf.js";export{t as start};
