import{a as t}from"../chunks/entry.CPpbjevb.js";export{t as start};
