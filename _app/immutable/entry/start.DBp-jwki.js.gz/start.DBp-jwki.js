import{a as t}from"../chunks/CYkKu5qb.js";export{t as start};
