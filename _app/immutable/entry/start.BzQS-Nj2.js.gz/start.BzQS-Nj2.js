import{a as t}from"../chunks/entry.Bh5qElkz.js";export{t as start};
