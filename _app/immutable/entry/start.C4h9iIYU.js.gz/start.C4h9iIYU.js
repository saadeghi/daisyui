import{a as t}from"../chunks/entry.CHx3eZHe.js";export{t as start};
