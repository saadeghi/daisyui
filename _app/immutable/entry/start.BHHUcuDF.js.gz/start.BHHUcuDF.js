import{a as t}from"../chunks/entry.CvNqOzNW.js";export{t as start};
