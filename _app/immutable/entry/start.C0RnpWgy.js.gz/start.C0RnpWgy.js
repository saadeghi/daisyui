import{a as t}from"../chunks/ByihB70r.js";export{t as start};
