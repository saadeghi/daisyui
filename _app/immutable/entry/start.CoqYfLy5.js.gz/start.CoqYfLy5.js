import{a as t}from"../chunks/entry.w-abjTGG.js";export{t as start};
