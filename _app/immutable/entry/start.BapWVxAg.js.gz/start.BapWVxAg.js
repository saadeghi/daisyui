import{a as t}from"../chunks/entry.DKqd5WkX.js";export{t as start};
