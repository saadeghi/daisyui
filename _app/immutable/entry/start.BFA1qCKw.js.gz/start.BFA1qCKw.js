import{a as t}from"../chunks/entry.Cn5XlGYh.js";export{t as start};
