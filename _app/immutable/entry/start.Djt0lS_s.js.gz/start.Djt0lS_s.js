import{a as t}from"../chunks/entry.ihug3pz9.js";export{t as start};
