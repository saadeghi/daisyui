import{a as t}from"../chunks/entry.BCWWbhIM.js";export{t as start};
