import{a as t}from"../chunks/entry.DbFOXxv5.js";export{t as start};
