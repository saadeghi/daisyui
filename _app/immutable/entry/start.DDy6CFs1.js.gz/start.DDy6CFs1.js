import{a as t}from"../chunks/entry.ZUwL_95K.js";export{t as start};
