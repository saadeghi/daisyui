import{a as t}from"../chunks/entry.xjhFI0ka.js";export{t as start};
