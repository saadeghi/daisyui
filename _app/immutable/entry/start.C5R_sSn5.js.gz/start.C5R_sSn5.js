import{a as t}from"../chunks/entry.DMG2UGtd.js";export{t as start};
