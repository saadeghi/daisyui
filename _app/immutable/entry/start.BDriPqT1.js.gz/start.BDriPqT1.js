import{a as t}from"../chunks/entry.C_ZqiWef.js";export{t as start};
