import{a as t}from"../chunks/entry.DmNGkwez.js";export{t as start};
