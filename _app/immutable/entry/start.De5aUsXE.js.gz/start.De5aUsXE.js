import{a as t}from"../chunks/entry.Cp6yHe66.js";export{t as start};
