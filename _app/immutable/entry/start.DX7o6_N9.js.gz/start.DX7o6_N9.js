import{a as t}from"../chunks/entry.BgTpdH36.js";export{t as start};
