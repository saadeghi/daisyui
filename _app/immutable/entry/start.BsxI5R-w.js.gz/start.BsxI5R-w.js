import{a as t}from"../chunks/entry.4UFqE8wa.js";export{t as start};
