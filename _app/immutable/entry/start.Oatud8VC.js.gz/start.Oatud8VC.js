import{a as t}from"../chunks/entry.vF8xyX6n.js";export{t as start};
