import{a as t}from"../chunks/entry.i1BXSR2u.js";export{t as start};
