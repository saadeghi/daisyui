import{a as t}from"../chunks/entry.mzdkRZ3h.js";export{t as start};
