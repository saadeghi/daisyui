import{a as t}from"../chunks/entry.C55NN0uU.js";export{t as start};
