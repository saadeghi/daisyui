import{a as t}from"../chunks/entry.CnuNXjXZ.js";export{t as start};
