import{a as t}from"../chunks/entry.CGZb-SL4.js";export{t as start};
