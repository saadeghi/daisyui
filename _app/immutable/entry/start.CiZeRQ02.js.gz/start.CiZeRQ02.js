import{a as t}from"../chunks/entry.quk-4Vlc.js";export{t as start};
