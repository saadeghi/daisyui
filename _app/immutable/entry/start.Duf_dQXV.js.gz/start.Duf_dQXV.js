import{a as t}from"../chunks/entry.y9CIGcuu.js";export{t as start};
