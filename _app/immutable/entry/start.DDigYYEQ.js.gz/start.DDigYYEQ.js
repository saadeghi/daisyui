import{a as t}from"../chunks/entry.B8EZtuDu.js";export{t as start};
