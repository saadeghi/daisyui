import{a as t}from"../chunks/entry.VTEOgMcE.js";export{t as start};
