import{a as t}from"../chunks/entry.p7HXjqZr.js";export{t as start};
