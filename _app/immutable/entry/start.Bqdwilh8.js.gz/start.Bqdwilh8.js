import{a as t}from"../chunks/entry.KAqWR8xk.js";export{t as start};
