import{a as t}from"../chunks/Dovt6Cru.js";export{t as start};
