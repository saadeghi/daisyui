import{a as t}from"../chunks/entry.YXTmcKk9.js";export{t as start};
