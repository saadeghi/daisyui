import{a as t}from"../chunks/entry.CrTfxy4o.js";export{t as start};
