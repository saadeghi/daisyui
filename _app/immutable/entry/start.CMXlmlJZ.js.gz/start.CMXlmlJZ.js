import{a as t}from"../chunks/entry.Dl17QUPD.js";export{t as start};
