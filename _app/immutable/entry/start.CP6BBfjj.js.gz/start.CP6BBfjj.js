import{a as t}from"../chunks/entry.CJv70Hze.js";export{t as start};
