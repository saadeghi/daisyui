import{a as t}from"../chunks/entry.vtkeWrnN.js";export{t as start};
