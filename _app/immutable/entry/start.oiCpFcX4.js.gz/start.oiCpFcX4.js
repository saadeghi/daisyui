import{a as t}from"../chunks/entry.x27qyBoh.js";export{t as start};
