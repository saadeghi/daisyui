import{a as t}from"../chunks/entry.1if2M0Ha.js";export{t as start};
