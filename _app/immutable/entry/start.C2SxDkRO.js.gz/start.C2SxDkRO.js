import{a as t}from"../chunks/entry.JEipwPzN.js";export{t as start};
