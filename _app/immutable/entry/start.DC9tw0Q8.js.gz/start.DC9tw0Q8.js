import{a as t}from"../chunks/entry.C4Af2mbV.js";export{t as start};
