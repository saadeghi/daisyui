import{az as t}from"../chunks/vendor.0c0f6e56.js";export{t as start};
