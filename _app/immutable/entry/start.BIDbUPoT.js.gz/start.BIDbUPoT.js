import{a as t}from"../chunks/entry.DXNgIHi-.js";export{t as start};
