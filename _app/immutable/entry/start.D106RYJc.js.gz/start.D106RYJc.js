import{a as t}from"../chunks/entry.BQGG3hOg.js";export{t as start};
