import{a as t}from"../chunks/entry.BN4GkWE5.js";export{t as start};
