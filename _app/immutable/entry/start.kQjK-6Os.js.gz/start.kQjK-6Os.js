import{a as t}from"../chunks/entry.GR_saq63.js";export{t as start};
