import{a as t}from"../chunks/entry.C5n3U3Me.js";export{t as start};
