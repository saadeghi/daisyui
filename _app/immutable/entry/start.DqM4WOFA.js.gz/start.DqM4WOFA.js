import{a as t}from"../chunks/entry.BPduv9Vw.js";export{t as start};
