import{a as t}from"../chunks/entry.z3h-volo.js";export{t as start};
