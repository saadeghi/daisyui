import{a as t}from"../chunks/entry.BlZ9izVS.js";export{t as start};
