import{a as t}from"../chunks/entry.QvY-hUaa.js";export{t as start};
