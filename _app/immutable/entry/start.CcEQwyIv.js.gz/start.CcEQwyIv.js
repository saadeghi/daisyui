import{a as t}from"../chunks/entry.B4-4ORrg.js";export{t as start};
