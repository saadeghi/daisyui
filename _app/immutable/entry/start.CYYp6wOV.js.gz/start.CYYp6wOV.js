import{a as t}from"../chunks/entry.m-2Yip5z.js";export{t as start};
