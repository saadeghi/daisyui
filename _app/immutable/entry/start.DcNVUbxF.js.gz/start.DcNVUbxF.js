import{a as t}from"../chunks/entry.BslzQWcg.js";export{t as start};
