import{a as t}from"../chunks/entry.BDRpAIgI.js";export{t as start};
