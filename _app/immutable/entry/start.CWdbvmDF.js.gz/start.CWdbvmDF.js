import{a as t}from"../chunks/entry.B0n-XcUp.js";export{t as start};
