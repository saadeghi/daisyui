import{a as t}from"../chunks/entry.CnIg3J9r.js";export{t as start};
