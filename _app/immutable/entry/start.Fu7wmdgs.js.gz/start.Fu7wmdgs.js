import{a as t}from"../chunks/entry.BdIeYxCb.js";export{t as start};
