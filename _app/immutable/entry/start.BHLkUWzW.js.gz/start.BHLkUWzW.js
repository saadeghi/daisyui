import{a as t}from"../chunks/Hbmuet8k.js";export{t as start};
