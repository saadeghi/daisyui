import{a as t}from"../chunks/entry.IxpIU2KE.js";export{t as start};
