import{a as t}from"../chunks/PTazwu7L.js";export{t as start};
