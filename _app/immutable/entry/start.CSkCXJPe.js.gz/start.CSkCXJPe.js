import{a as t}from"../chunks/entry.DorUnAAR.js";export{t as start};
