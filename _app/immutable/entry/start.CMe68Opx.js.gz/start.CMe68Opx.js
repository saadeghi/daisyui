import{a as t}from"../chunks/entry.Bw41_mB1.js";export{t as start};
