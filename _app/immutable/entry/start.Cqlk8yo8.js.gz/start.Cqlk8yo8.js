import{a as t}from"../chunks/entry.Vif8P-De.js";export{t as start};
