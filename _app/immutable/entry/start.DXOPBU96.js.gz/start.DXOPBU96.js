import{a as t}from"../chunks/entry.B2lD_fFF.js";export{t as start};
