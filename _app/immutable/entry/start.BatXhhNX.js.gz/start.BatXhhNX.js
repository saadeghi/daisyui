import{a as t}from"../chunks/entry.nFnr0t_Q.js";export{t as start};
