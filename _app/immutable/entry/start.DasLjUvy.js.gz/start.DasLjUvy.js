import{a as t}from"../chunks/entry.C5Ce0L2S.js";export{t as start};
