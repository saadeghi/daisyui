import{a as t}from"../chunks/entry.CsHxfWFS.js";export{t as start};
