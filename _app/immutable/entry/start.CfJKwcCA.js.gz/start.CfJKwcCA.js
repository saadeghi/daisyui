import{a as t}from"../chunks/entry.ssRTJYMq.js";export{t as start};
