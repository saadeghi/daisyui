import{a as t}from"../chunks/entry.CsnIj4-k.js";export{t as start};
