import{a as t}from"../chunks/entry.CGw8VLjj.js";export{t as start};
