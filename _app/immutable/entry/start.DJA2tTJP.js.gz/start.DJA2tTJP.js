import{a as t}from"../chunks/entry.Ch-C5SjT.js";export{t as start};
