import{a as t}from"../chunks/entry.DZAeo7BD.js";export{t as start};
