import{a as t}from"../chunks/entry.ix408t_5.js";export{t as start};
