import{a as t}from"../chunks/entry.DEXNoejG.js";export{t as start};
