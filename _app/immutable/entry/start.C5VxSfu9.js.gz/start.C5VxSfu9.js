import{a as t}from"../chunks/BAcMr-rf.js";export{t as start};
