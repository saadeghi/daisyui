import{a as t}from"../chunks/entry.DJclIgKD.js";export{t as start};
