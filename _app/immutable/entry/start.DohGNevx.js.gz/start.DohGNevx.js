import{a as t}from"../chunks/entry.Bhb4PgUs.js";export{t as start};
