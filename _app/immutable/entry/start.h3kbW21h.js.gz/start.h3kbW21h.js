import{a as t}from"../chunks/entry.WSvH_GRa.js";export{t as start};
