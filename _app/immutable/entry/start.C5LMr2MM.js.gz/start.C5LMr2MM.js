import{a as t}from"../chunks/BMJsbbQJ.js";export{t as start};
