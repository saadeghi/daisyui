import{a as t}from"../chunks/entry.h2GBwEWD.js";export{t as start};
