import{a as t}from"../chunks/CzU6wgqm.js";export{t as start};
