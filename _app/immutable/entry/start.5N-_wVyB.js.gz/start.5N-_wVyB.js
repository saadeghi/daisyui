import{a as t}from"../chunks/entry.Bp8TbUuF.js";export{t as start};
