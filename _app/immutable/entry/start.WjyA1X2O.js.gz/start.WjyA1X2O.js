import{a as t}from"../chunks/entry.BcQzd_Ly.js";export{t as start};
