import{a as t}from"../chunks/entry.t8gyXPry.js";export{t as start};
