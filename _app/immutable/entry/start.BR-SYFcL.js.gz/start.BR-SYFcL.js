import{a as t}from"../chunks/entry.C-rZ9d3Q.js";export{t as start};
