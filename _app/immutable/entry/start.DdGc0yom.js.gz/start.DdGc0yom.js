import{a as t}from"../chunks/entry.Dg5qoZiB.js";export{t as start};
