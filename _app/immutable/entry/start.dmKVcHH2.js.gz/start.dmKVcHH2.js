import{a as t}from"../chunks/entry.DSAuU_EC.js";export{t as start};
