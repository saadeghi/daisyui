import{a as t}from"../chunks/entry.BRDz4cRy.js";export{t as start};
