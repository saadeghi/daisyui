import{a as t}from"../chunks/entry.CNdcP9Yh.js";export{t as start};
