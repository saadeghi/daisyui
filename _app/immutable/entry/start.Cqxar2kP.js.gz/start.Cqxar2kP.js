import{a as t}from"../chunks/BvhjWhgf.js";export{t as start};
