import{a as t}from"../chunks/entry.CBV0MJCt.js";export{t as start};
