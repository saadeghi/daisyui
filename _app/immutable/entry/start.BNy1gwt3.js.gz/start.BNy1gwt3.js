import{a as t}from"../chunks/entry.DIxtb7Q3.js";export{t as start};
