import{a as t}from"../chunks/entry.DJzCxYgN.js";export{t as start};
