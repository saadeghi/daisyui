import{a as t}from"../chunks/entry.Dvmv5gcm.js";export{t as start};
