import{a as t}from"../chunks/entry.B3MevqWg.js";export{t as start};
