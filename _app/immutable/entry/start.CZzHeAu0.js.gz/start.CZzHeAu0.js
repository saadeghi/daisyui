import{a as t}from"../chunks/entry.DZ0Q6ZDy.js";export{t as start};
