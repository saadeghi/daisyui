import{a as t}from"../chunks/entry.BCAebLN9.js";export{t as start};
