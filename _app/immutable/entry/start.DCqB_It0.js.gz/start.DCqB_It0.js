import{a as t}from"../chunks/entry.C0PkACnR.js";export{t as start};
