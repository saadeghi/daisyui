import{a as t}from"../chunks/MsZsc4Ra.js";export{t as start};
