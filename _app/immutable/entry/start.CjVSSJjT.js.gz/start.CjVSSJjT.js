import{a as t}from"../chunks/entry.yUeNl6Vl.js";export{t as start};
