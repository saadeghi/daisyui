import{a as t}from"../chunks/entry.DXTeSIgX.js";export{t as start};
