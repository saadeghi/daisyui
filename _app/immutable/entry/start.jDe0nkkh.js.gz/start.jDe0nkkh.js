import{a as t}from"../chunks/entry.BgjY1gGL.js";export{t as start};
