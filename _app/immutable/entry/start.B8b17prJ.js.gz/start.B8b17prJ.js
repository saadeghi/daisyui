import{a as t}from"../chunks/entry.Bt81sV_V.js";export{t as start};
