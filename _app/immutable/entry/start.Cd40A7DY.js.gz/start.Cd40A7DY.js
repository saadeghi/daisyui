import{a as t}from"../chunks/entry.B-NYyypX.js";export{t as start};
