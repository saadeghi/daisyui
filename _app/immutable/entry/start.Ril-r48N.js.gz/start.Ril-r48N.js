import{a as t}from"../chunks/BLLqTIQo.js";export{t as start};
