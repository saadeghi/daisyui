import{a as t}from"../chunks/entry.BR_bgoTE.js";export{t as start};
