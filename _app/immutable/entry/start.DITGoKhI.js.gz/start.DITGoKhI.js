import{a as t}from"../chunks/entry.CfRUm4nL.js";export{t as start};
