import{a as t}from"../chunks/entry.B3JjAOOQ.js";export{t as start};
