import{a as t}from"../chunks/entry.DYzmlGSF.js";export{t as start};
