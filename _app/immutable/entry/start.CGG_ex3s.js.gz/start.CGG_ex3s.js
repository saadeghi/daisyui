import{a as t}from"../chunks/entry.CN2zv12I.js";export{t as start};
