import{a as t}from"../chunks/entry.DkKa5PkL.js";export{t as start};
