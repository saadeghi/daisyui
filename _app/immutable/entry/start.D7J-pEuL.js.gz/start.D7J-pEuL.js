import{a as t}from"../chunks/entry.BYS69-RL.js";export{t as start};
