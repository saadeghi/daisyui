import{a as t}from"../chunks/entry.JZZOS5Km.js";export{t as start};
