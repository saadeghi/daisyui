import{a as t}from"../chunks/entry.FSdpX92m.js";export{t as start};
