import{a as t}from"../chunks/entry.ryo9Jkm4.js";export{t as start};
