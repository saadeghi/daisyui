import{a as t}from"../chunks/entry.B-8DSsy5.js";export{t as start};
