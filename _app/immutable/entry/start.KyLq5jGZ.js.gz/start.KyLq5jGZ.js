import{a as t}from"../chunks/entry.Bev3RkNW.js";export{t as start};
