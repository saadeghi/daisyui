import{a as t}from"../chunks/entry.ZzZ7Jbkg.js";export{t as start};
