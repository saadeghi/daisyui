import{a as t}from"../chunks/entry.CGyLjzem.js";export{t as start};
