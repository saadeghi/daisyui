import{a as t}from"../chunks/entry.BX1jDyKb.js";export{t as start};
