import{a as t}from"../chunks/entry.CYOyub71.js";export{t as start};
