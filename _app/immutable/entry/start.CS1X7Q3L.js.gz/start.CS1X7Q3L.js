import{a as t}from"../chunks/kBF1hu8p.js";export{t as start};
