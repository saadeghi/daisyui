import{a as t}from"../chunks/CH1fGGo7.js";export{t as start};
