import{a as t}from"../chunks/entry.BEryBIlv.js";export{t as start};
