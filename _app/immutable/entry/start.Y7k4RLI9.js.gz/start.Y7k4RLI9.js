import{a as t}from"../chunks/entry.Dbl_fY4N.js";export{t as start};
