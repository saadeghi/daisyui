import{a as t}from"../chunks/entry.BmDoCCSZ.js";export{t as start};
