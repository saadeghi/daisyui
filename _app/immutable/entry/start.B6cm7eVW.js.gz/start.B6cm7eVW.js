import{a as t}from"../chunks/entry.Db_F6hFW.js";export{t as start};
