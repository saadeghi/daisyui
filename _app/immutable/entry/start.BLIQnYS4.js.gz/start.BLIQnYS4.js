import{a as t}from"../chunks/entry.CHt8qy8L.js";export{t as start};
