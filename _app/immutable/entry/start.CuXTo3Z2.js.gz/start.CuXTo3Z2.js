import{a as t}from"../chunks/entry.CAWGaBUP.js";export{t as start};
