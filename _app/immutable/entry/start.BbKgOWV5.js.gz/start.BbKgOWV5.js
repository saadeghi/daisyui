import{a as t}from"../chunks/entry.DYfg2Rsa.js";export{t as start};
