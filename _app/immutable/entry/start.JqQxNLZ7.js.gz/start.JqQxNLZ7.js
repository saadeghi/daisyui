import{a as t}from"../chunks/entry.Da9OxA5P.js";export{t as start};
