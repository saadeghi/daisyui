import{a as t}from"../chunks/entry.DDT989W9.js";export{t as start};
