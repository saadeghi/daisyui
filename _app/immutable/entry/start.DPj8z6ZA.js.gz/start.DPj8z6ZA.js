import{a as t}from"../chunks/entry.N6cr83Hf.js";export{t as start};
