import{a as t}from"../chunks/entry.BxMK8Yu4.js";export{t as start};
