import{a as t}from"../chunks/CUrAfvxw.js";export{t as start};
