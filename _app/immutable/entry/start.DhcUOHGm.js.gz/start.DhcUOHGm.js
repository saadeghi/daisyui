import{a as t}from"../chunks/entry.D1Xg236P.js";export{t as start};
