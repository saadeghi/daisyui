import{a as t}from"../chunks/entry.BtQw-h73.js";export{t as start};
