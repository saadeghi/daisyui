import{a as t}from"../chunks/entry.DcR-kcTU.js";export{t as start};
