import{a as t}from"../chunks/entry.Bn_w5X0C.js";export{t as start};
