import{a as t}from"../chunks/entry.BL6RnLGI.js";export{t as start};
