import{a as t}from"../chunks/entry.B45EZfes.js";export{t as start};
