import{a as t}from"../chunks/entry.r8sSrXAj.js";export{t as start};
