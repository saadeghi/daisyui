import{a as t}from"../chunks/entry.BYv6_d-O.js";export{t as start};
