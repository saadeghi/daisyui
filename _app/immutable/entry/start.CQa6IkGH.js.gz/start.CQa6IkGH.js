import{a as t}from"../chunks/entry.DBYDVajP.js";export{t as start};
