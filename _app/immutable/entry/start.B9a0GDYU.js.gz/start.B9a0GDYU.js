import{a as t}from"../chunks/entry.Bkc0qTXW.js";export{t as start};
