import{a as t}from"../chunks/entry.Bpg-EK0e.js";export{t as start};
