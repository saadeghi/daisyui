import{a as t}from"../chunks/entry.B6tb5tq3.js";export{t as start};
