import{a as t}from"../chunks/entry.jurhzB1v.js";export{t as start};
