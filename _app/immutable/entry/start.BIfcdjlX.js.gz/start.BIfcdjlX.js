import{a as t}from"../chunks/entry.7Hdi37jl.js";export{t as start};
