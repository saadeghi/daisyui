import{a as t}from"../chunks/entry.6MqfJL2n.js";export{t as start};
