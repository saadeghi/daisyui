import{a as t}from"../chunks/entry.DRT4rHQj.js";export{t as start};
