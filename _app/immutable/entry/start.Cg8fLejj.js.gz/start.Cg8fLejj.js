import{a as t}from"../chunks/entry.BxlHlUIa.js";export{t as start};
