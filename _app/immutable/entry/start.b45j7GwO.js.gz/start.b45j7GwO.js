import{a as t}from"../chunks/entry.Bv7_atKu.js";export{t as start};
