import{a as t}from"../chunks/entry.CGftIPwe.js";export{t as start};
