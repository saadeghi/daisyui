import{a as t}from"../chunks/entry.9Oqo3wDW.js";export{t as start};
