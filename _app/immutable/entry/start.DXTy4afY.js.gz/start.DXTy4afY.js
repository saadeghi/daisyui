import{a as t}from"../chunks/entry.DNs3rfH8.js";export{t as start};
