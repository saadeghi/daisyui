import{a as t}from"../chunks/entry.Bw2uYb0x.js";export{t as start};
