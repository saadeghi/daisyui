import{a as t}from"../chunks/entry.Cct2kmZ9.js";export{t as start};
