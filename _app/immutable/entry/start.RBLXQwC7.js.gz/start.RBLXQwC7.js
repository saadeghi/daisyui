import{a as t}from"../chunks/entry.BPIKB7JM.js";export{t as start};
