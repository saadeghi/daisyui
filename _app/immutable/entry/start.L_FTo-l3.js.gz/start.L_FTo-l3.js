import{a as t}from"../chunks/entry.DE9H-eeK.js";export{t as start};
