import{a as t}from"../chunks/entry.DiajxMVf.js";export{t as start};
