import{a as t}from"../chunks/entry.phLwnhIt.js";export{t as start};
