import{L as e,_ as n}from"../chunks/0.aI-ziA9I.js";export{e as component,n as universal};
