import{L as e,_ as n}from"../chunks/0.h0xGljXE.js";export{e as component,n as universal};
