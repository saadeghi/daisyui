import{L as e,_ as n}from"../chunks/0.bqNZ0jYf.js";export{e as component,n as universal};
