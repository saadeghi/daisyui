import{L as e,_ as n}from"../chunks/0.75b98ca0.js";export{e as component,n as universal};
