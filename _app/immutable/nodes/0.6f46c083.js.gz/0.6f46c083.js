import{L as e,_ as n}from"../chunks/0.4725612b.js";export{e as component,n as universal};
