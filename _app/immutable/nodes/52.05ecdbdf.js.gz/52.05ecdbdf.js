import{S as $i,i as Si,s as gi,M as X1,y as Ch,z as wh,A as Ah,U as Ri,$ as mi,g as kh,d as Ih,B as Bh,H as Ci,Y as yi,a as l,c as o,b as Re,h as e,k as a,q as n,l as d,m as r,r as h,n as y,E as t,F as fs,a9 as vs,a4 as Ts,K as j1}from"../chunks/index.b33eaa49.js";import{M as wi}from"../chunks/mdsvex.fc60cf6a.js";import{p as Ai,C as ki,a as is,r as _s}from"../chunks/ClassTable.0ccc276f.js";function Ii(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("th"),T=n("Name"),J=l(),G=a("th"),rt=n("Job"),ct=l(),A=a("th"),it=n("Favorite Color"),X=l(),g=a("tbody"),D=a("tr"),V=a("th"),v=n("1"),b=l(),k=a("td"),tt=n("Cy Ganderton"),Et=l(),q=a("td"),p=n("Quality Control Specialist"),P=l(),u=a("td"),I=n("Blue"),ft=l(),H=a("tr"),lt=a("th"),At=n("2"),Tt=l(),L=a("td"),Dt=n("Hart Hagerty"),bt=l(),et=a("td"),kt=n("Desktop Support Technician"),mt=l(),W=a("td"),It=n("Purple"),Bt=l(),S=a("tr"),z=a("th"),Pt=n("3"),Wt=l(),N=a("td"),F=n("Brice Swyre"),Lt=l(),Z=a("td"),ut=n("Tax Accountant"),yt=l(),R=a("td"),Q=n("Red"),this.h()},l(Y){c=d(Y,"DIV",{class:!0});var st=r(c);s=d(st,"TABLE",{class:!0});var dt=r(s);E=d(dt,"THEAD",{});var qt=r(E);i=d(qt,"TR",{});var B=r(i);_=d(B,"TH",{}),r(_).forEach(e),$=o(B),f=d(B,"TH",{});var at=r(f);T=h(at,"Name"),at.forEach(e),J=o(B),G=d(B,"TH",{});var $t=r(G);rt=h($t,"Job"),$t.forEach(e),ct=o(B),A=d(B,"TH",{});var Mt=r(A);it=h(Mt,"Favorite Color"),Mt.forEach(e),B.forEach(e),qt.forEach(e),X=o(dt),g=d(dt,"TBODY",{});var M=r(g);D=d(M,"TR",{});var x=r(D);V=d(x,"TH",{});var Ut=r(V);v=h(Ut,"1"),Ut.forEach(e),b=o(x),k=d(x,"TD",{});var Ht=r(k);tt=h(Ht,"Cy Ganderton"),Ht.forEach(e),Et=o(x),q=d(x,"TD",{});var Vt=r(q);p=h(Vt,"Quality Control Specialist"),Vt.forEach(e),P=o(x),u=d(x,"TD",{});var re=r(u);I=h(re,"Blue"),re.forEach(e),x.forEach(e),ft=o(M),H=d(M,"TR",{});var C=r(H);lt=d(C,"TH",{});var O=r(lt);At=h(O,"2"),O.forEach(e),Tt=o(C),L=d(C,"TD",{});var Zt=r(L);Dt=h(Zt,"Hart Hagerty"),Zt.forEach(e),bt=o(C),et=d(C,"TD",{});var Qt=r(et);kt=h(Qt,"Desktop Support Technician"),Qt.forEach(e),mt=o(C),W=d(C,"TD",{});var St=r(W);It=h(St,"Purple"),St.forEach(e),C.forEach(e),Bt=o(M),S=d(M,"TR",{});var w=r(S);z=d(w,"TH",{});var jt=r(z);Pt=h(jt,"3"),jt.forEach(e),Wt=o(w),N=d(w,"TD",{});var le=r(N);F=h(le,"Brice Swyre"),le.forEach(e),Lt=o(w),Z=d(w,"TD",{});var gt=r(Z);ut=h(gt,"Tax Accountant"),gt.forEach(e),yt=o(w),R=d(w,"TD",{});var K=r(R);Q=h(K,"Red"),K.forEach(e),w.forEach(e),M.forEach(e),dt.forEach(e),st.forEach(e),this.h()},h(){y(s,"class","table"),y(c,"class","overflow-x-auto")},m(Y,st){Re(Y,c,st),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(s,X),t(s,g),t(g,D),t(D,V),t(V,v),t(D,b),t(D,k),t(k,tt),t(D,Et),t(D,q),t(q,p),t(D,P),t(D,u),t(u,I),t(g,ft),t(g,H),t(H,lt),t(lt,At),t(H,Tt),t(H,L),t(L,Dt),t(H,bt),t(H,et),t(et,kt),t(H,mt),t(H,W),t(W,It),t(g,Bt),t(g,S),t(S,z),t(z,Pt),t(S,Wt),t(S,N),t(N,F),t(S,Lt),t(S,Z),t(Z,ut),t(S,yt),t(S,R),t(R,Q)},p:fs,d(Y){Y&&e(c)}}}function Bi(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function Pi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("th"),T=n("Name"),J=l(),G=a("th"),rt=n("Job"),ct=l(),A=a("th"),it=n("Favorite Color"),X=l(),g=a("tbody"),D=a("tr"),V=a("th"),v=n("1"),b=l(),k=a("td"),tt=n("Cy Ganderton"),Et=l(),q=a("td"),p=n("Quality Control Specialist"),P=l(),u=a("td"),I=n("Blue"),ft=l(),H=a("tr"),lt=a("th"),At=n("2"),Tt=l(),L=a("td"),Dt=n("Hart Hagerty"),bt=l(),et=a("td"),kt=n("Desktop Support Technician"),mt=l(),W=a("td"),It=n("Purple"),Bt=l(),S=a("tr"),z=a("th"),Pt=n("3"),Wt=l(),N=a("td"),F=n("Brice Swyre"),Lt=l(),Z=a("td"),ut=n("Tax Accountant"),yt=l(),R=a("td"),Q=n("Red"),this.h()},l(Y){c=d(Y,"DIV",{class:!0});var st=r(c);s=d(st,"TABLE",{class:!0});var dt=r(s);E=d(dt,"THEAD",{});var qt=r(E);i=d(qt,"TR",{});var B=r(i);_=d(B,"TH",{}),r(_).forEach(e),$=o(B),f=d(B,"TH",{});var at=r(f);T=h(at,"Name"),at.forEach(e),J=o(B),G=d(B,"TH",{});var $t=r(G);rt=h($t,"Job"),$t.forEach(e),ct=o(B),A=d(B,"TH",{});var Mt=r(A);it=h(Mt,"Favorite Color"),Mt.forEach(e),B.forEach(e),qt.forEach(e),X=o(dt),g=d(dt,"TBODY",{});var M=r(g);D=d(M,"TR",{class:!0});var x=r(D);V=d(x,"TH",{});var Ut=r(V);v=h(Ut,"1"),Ut.forEach(e),b=o(x),k=d(x,"TD",{});var Ht=r(k);tt=h(Ht,"Cy Ganderton"),Ht.forEach(e),Et=o(x),q=d(x,"TD",{});var Vt=r(q);p=h(Vt,"Quality Control Specialist"),Vt.forEach(e),P=o(x),u=d(x,"TD",{});var re=r(u);I=h(re,"Blue"),re.forEach(e),x.forEach(e),ft=o(M),H=d(M,"TR",{});var C=r(H);lt=d(C,"TH",{});var O=r(lt);At=h(O,"2"),O.forEach(e),Tt=o(C),L=d(C,"TD",{});var Zt=r(L);Dt=h(Zt,"Hart Hagerty"),Zt.forEach(e),bt=o(C),et=d(C,"TD",{});var Qt=r(et);kt=h(Qt,"Desktop Support Technician"),Qt.forEach(e),mt=o(C),W=d(C,"TD",{});var St=r(W);It=h(St,"Purple"),St.forEach(e),C.forEach(e),Bt=o(M),S=d(M,"TR",{});var w=r(S);z=d(w,"TH",{});var jt=r(z);Pt=h(jt,"3"),jt.forEach(e),Wt=o(w),N=d(w,"TD",{});var le=r(N);F=h(le,"Brice Swyre"),le.forEach(e),Lt=o(w),Z=d(w,"TD",{});var gt=r(Z);ut=h(gt,"Tax Accountant"),gt.forEach(e),yt=o(w),R=d(w,"TD",{});var K=r(R);Q=h(K,"Red"),K.forEach(e),w.forEach(e),M.forEach(e),dt.forEach(e),st.forEach(e),this.h()},h(){y(D,"class","bg-base-200"),y(s,"class","table"),y(c,"class","overflow-x-auto")},m(Y,st){Re(Y,c,st),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(s,X),t(s,g),t(g,D),t(D,V),t(V,v),t(D,b),t(D,k),t(k,tt),t(D,Et),t(D,q),t(q,p),t(D,P),t(D,u),t(u,I),t(g,ft),t(g,H),t(H,lt),t(lt,At),t(H,Tt),t(H,L),t(L,Dt),t(H,bt),t(H,et),t(et,kt),t(H,mt),t(H,W),t(W,It),t(g,Bt),t(g,S),t(S,z),t(z,Pt),t(S,Wt),t(S,N),t(N,F),t(S,Lt),t(S,Z),t(Z,ut),t(S,yt),t(S,R),t(R,Q)},p:fs,d(Y){Y&&e(c)}}}function Li(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr class="bg-base-200">
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function xi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("th"),T=n("Name"),J=l(),G=a("th"),rt=n("Job"),ct=l(),A=a("th"),it=n("Favorite Color"),X=l(),g=a("tbody"),D=a("tr"),V=a("th"),v=n("1"),b=l(),k=a("td"),tt=n("Cy Ganderton"),Et=l(),q=a("td"),p=n("Quality Control Specialist"),P=l(),u=a("td"),I=n("Blue"),ft=l(),H=a("tr"),lt=a("th"),At=n("2"),Tt=l(),L=a("td"),Dt=n("Hart Hagerty"),bt=l(),et=a("td"),kt=n("Desktop Support Technician"),mt=l(),W=a("td"),It=n("Purple"),Bt=l(),S=a("tr"),z=a("th"),Pt=n("3"),Wt=l(),N=a("td"),F=n("Brice Swyre"),Lt=l(),Z=a("td"),ut=n("Tax Accountant"),yt=l(),R=a("td"),Q=n("Red"),this.h()},l(Y){c=d(Y,"DIV",{class:!0});var st=r(c);s=d(st,"TABLE",{class:!0});var dt=r(s);E=d(dt,"THEAD",{});var qt=r(E);i=d(qt,"TR",{});var B=r(i);_=d(B,"TH",{}),r(_).forEach(e),$=o(B),f=d(B,"TH",{});var at=r(f);T=h(at,"Name"),at.forEach(e),J=o(B),G=d(B,"TH",{});var $t=r(G);rt=h($t,"Job"),$t.forEach(e),ct=o(B),A=d(B,"TH",{});var Mt=r(A);it=h(Mt,"Favorite Color"),Mt.forEach(e),B.forEach(e),qt.forEach(e),X=o(dt),g=d(dt,"TBODY",{});var M=r(g);D=d(M,"TR",{});var x=r(D);V=d(x,"TH",{});var Ut=r(V);v=h(Ut,"1"),Ut.forEach(e),b=o(x),k=d(x,"TD",{});var Ht=r(k);tt=h(Ht,"Cy Ganderton"),Ht.forEach(e),Et=o(x),q=d(x,"TD",{});var Vt=r(q);p=h(Vt,"Quality Control Specialist"),Vt.forEach(e),P=o(x),u=d(x,"TD",{});var re=r(u);I=h(re,"Blue"),re.forEach(e),x.forEach(e),ft=o(M),H=d(M,"TR",{class:!0});var C=r(H);lt=d(C,"TH",{});var O=r(lt);At=h(O,"2"),O.forEach(e),Tt=o(C),L=d(C,"TD",{});var Zt=r(L);Dt=h(Zt,"Hart Hagerty"),Zt.forEach(e),bt=o(C),et=d(C,"TD",{});var Qt=r(et);kt=h(Qt,"Desktop Support Technician"),Qt.forEach(e),mt=o(C),W=d(C,"TD",{});var St=r(W);It=h(St,"Purple"),St.forEach(e),C.forEach(e),Bt=o(M),S=d(M,"TR",{});var w=r(S);z=d(w,"TH",{});var jt=r(z);Pt=h(jt,"3"),jt.forEach(e),Wt=o(w),N=d(w,"TD",{});var le=r(N);F=h(le,"Brice Swyre"),le.forEach(e),Lt=o(w),Z=d(w,"TD",{});var gt=r(Z);ut=h(gt,"Tax Accountant"),gt.forEach(e),yt=o(w),R=d(w,"TD",{});var K=r(R);Q=h(K,"Red"),K.forEach(e),w.forEach(e),M.forEach(e),dt.forEach(e),st.forEach(e),this.h()},h(){y(H,"class","hover:bg-base-300"),y(s,"class","table"),y(c,"class","overflow-x-auto")},m(Y,st){Re(Y,c,st),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(s,X),t(s,g),t(g,D),t(D,V),t(V,v),t(D,b),t(D,k),t(k,tt),t(D,Et),t(D,q),t(q,p),t(D,P),t(D,u),t(u,I),t(g,ft),t(g,H),t(H,lt),t(lt,At),t(H,Tt),t(H,L),t(L,Dt),t(H,bt),t(H,et),t(et,kt),t(H,mt),t(H,W),t(W,It),t(g,Bt),t(g,S),t(S,z),t(z,Pt),t(S,Wt),t(S,N),t(N,F),t(S,Lt),t(S,Z),t(Z,ut),t(S,yt),t(S,R),t(R,Q)},p:fs,d(Y){Y&&e(c)}}}function Gi(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr class="$$hover">
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function Mi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("th"),T=n("Name"),J=l(),G=a("th"),rt=n("Job"),ct=l(),A=a("th"),it=n("Favorite Color"),X=l(),g=a("tbody"),D=a("tr"),V=a("th"),v=n("1"),b=l(),k=a("td"),tt=n("Cy Ganderton"),Et=l(),q=a("td"),p=n("Quality Control Specialist"),P=l(),u=a("td"),I=n("Blue"),ft=l(),H=a("tr"),lt=a("th"),At=n("2"),Tt=l(),L=a("td"),Dt=n("Hart Hagerty"),bt=l(),et=a("td"),kt=n("Desktop Support Technician"),mt=l(),W=a("td"),It=n("Purple"),Bt=l(),S=a("tr"),z=a("th"),Pt=n("3"),Wt=l(),N=a("td"),F=n("Brice Swyre"),Lt=l(),Z=a("td"),ut=n("Tax Accountant"),yt=l(),R=a("td"),Q=n("Red"),this.h()},l(Y){c=d(Y,"DIV",{class:!0});var st=r(c);s=d(st,"TABLE",{class:!0});var dt=r(s);E=d(dt,"THEAD",{});var qt=r(E);i=d(qt,"TR",{});var B=r(i);_=d(B,"TH",{}),r(_).forEach(e),$=o(B),f=d(B,"TH",{});var at=r(f);T=h(at,"Name"),at.forEach(e),J=o(B),G=d(B,"TH",{});var $t=r(G);rt=h($t,"Job"),$t.forEach(e),ct=o(B),A=d(B,"TH",{});var Mt=r(A);it=h(Mt,"Favorite Color"),Mt.forEach(e),B.forEach(e),qt.forEach(e),X=o(dt),g=d(dt,"TBODY",{});var M=r(g);D=d(M,"TR",{});var x=r(D);V=d(x,"TH",{});var Ut=r(V);v=h(Ut,"1"),Ut.forEach(e),b=o(x),k=d(x,"TD",{});var Ht=r(k);tt=h(Ht,"Cy Ganderton"),Ht.forEach(e),Et=o(x),q=d(x,"TD",{});var Vt=r(q);p=h(Vt,"Quality Control Specialist"),Vt.forEach(e),P=o(x),u=d(x,"TD",{});var re=r(u);I=h(re,"Blue"),re.forEach(e),x.forEach(e),ft=o(M),H=d(M,"TR",{});var C=r(H);lt=d(C,"TH",{});var O=r(lt);At=h(O,"2"),O.forEach(e),Tt=o(C),L=d(C,"TD",{});var Zt=r(L);Dt=h(Zt,"Hart Hagerty"),Zt.forEach(e),bt=o(C),et=d(C,"TD",{});var Qt=r(et);kt=h(Qt,"Desktop Support Technician"),Qt.forEach(e),mt=o(C),W=d(C,"TD",{});var St=r(W);It=h(St,"Purple"),St.forEach(e),C.forEach(e),Bt=o(M),S=d(M,"TR",{});var w=r(S);z=d(w,"TH",{});var jt=r(z);Pt=h(jt,"3"),jt.forEach(e),Wt=o(w),N=d(w,"TD",{});var le=r(N);F=h(le,"Brice Swyre"),le.forEach(e),Lt=o(w),Z=d(w,"TD",{});var gt=r(Z);ut=h(gt,"Tax Accountant"),gt.forEach(e),yt=o(w),R=d(w,"TD",{});var K=r(R);Q=h(K,"Red"),K.forEach(e),w.forEach(e),M.forEach(e),dt.forEach(e),st.forEach(e),this.h()},h(){y(s,"class","table table-zebra"),y(c,"class","overflow-x-auto")},m(Y,st){Re(Y,c,st),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(s,X),t(s,g),t(g,D),t(D,V),t(V,v),t(D,b),t(D,k),t(k,tt),t(D,Et),t(D,q),t(q,p),t(D,P),t(D,u),t(u,I),t(g,ft),t(g,H),t(H,lt),t(lt,At),t(H,Tt),t(H,L),t(L,Dt),t(H,bt),t(H,et),t(et,kt),t(H,mt),t(H,W),t(W,It),t(g,Bt),t(g,S),t(S,z),t(z,Pt),t(S,Wt),t(S,N),t(N,F),t(S,Lt),t(S,Z),t(Z,ut),t(S,yt),t(S,R),t(R,Q)},p:fs,d(Y){Y&&e(c)}}}function Vi(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table $$table-zebra">
    <!-- head -->
    <thead>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>1</th>
        <td>Cy Ganderton</td>
        <td>Quality Control Specialist</td>
        <td>Blue</td>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>2</th>
        <td>Hart Hagerty</td>
        <td>Desktop Support Technician</td>
        <td>Purple</td>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>3</th>
        <td>Brice Swyre</td>
        <td>Tax Accountant</td>
        <td>Red</td>
      </tr>
    </tbody>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function Fi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q,Y,st,dt,qt,B,at,$t,Mt,M,x,Ut,Ht,Vt,re,C,O,Zt,Qt,St,w,jt,le,gt,K,Da,ba,Kr,Te,Je,ea,Rd,Cd,oe,qe,ma,wd,ya,xt,Be,aa,da,Pe,hr,Jr,Ce,Le,Ad,kd,Rt,Ha,$a,xe,Id,Bd,Pd,Ge,Sa,qr,ga,zt,Ra,Ue,Xa,Ld,Ca,ne,Ze,wa,xd,_e,Qe,Me,ra,Ct,Ve,td,Ur,je,Fe,Gd,Md,Ft,Aa,ka,la,Vd,Ia,Fd,We,Wd,Zr,Ee,Ba,zd,Pa,oa,Od,La,Gt,he,na,Nd,xa,Xt,Ga,Xe,Yd,Kd,Ma,Va,Fa,ha;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=a("label"),f=a("input"),T=l(),J=a("th"),G=n("Name"),rt=l(),ct=a("th"),A=n("Job"),it=l(),X=a("th"),g=n("Favorite Color"),D=l(),V=a("th"),v=l(),b=a("tbody"),k=a("tr"),tt=a("th"),Et=a("label"),q=a("input"),p=l(),P=a("td"),u=a("div"),I=a("div"),ft=a("div"),H=a("img"),At=l(),Tt=a("div"),L=a("div"),Dt=n("Hart Hagerty"),bt=l(),et=a("div"),kt=n("United States"),mt=l(),W=a("td"),It=n(`Zemlak, Daniel and Leannon
          `),Bt=a("br"),S=l(),z=a("span"),Pt=n("Desktop Support Technician"),Wt=l(),N=a("td"),F=n("Purple"),Lt=l(),Z=a("th"),ut=a("button"),yt=n("details"),R=l(),Q=a("tr"),Y=a("th"),st=a("label"),dt=a("input"),qt=l(),B=a("td"),at=a("div"),$t=a("div"),Mt=a("div"),M=a("img"),Ut=l(),Ht=a("div"),Vt=a("div"),re=n("Brice Swyre"),C=l(),O=a("div"),Zt=n("China"),Qt=l(),St=a("td"),w=n(`Carroll Group
          `),jt=a("br"),le=l(),gt=a("span"),K=n("Tax Accountant"),Da=l(),ba=a("td"),Kr=n("Red"),Te=l(),Je=a("th"),ea=a("button"),Rd=n("details"),Cd=l(),oe=a("tr"),qe=a("th"),ma=a("label"),wd=a("input"),ya=l(),xt=a("td"),Be=a("div"),aa=a("div"),da=a("div"),Pe=a("img"),Jr=l(),Ce=a("div"),Le=a("div"),Ad=n("Marjy Ferencz"),kd=l(),Rt=a("div"),Ha=n("Russia"),$a=l(),xe=a("td"),Id=n(`Rowe-Schoen
          `),Bd=a("br"),Pd=l(),Ge=a("span"),Sa=n("Office Assistant I"),qr=l(),ga=a("td"),zt=n("Crimson"),Ra=l(),Ue=a("th"),Xa=a("button"),Ld=n("details"),Ca=l(),ne=a("tr"),Ze=a("th"),wa=a("label"),xd=a("input"),_e=l(),Qe=a("td"),Me=a("div"),ra=a("div"),Ct=a("div"),Ve=a("img"),Ur=l(),je=a("div"),Fe=a("div"),Gd=n("Yancy Tear"),Md=l(),Ft=a("div"),Aa=n("Brazil"),ka=l(),la=a("td"),Vd=n(`Wyman-Ledner
          `),Ia=a("br"),Fd=l(),We=a("span"),Wd=n("Community Outreach Specialist"),Zr=l(),Ee=a("td"),Ba=n("Indigo"),zd=l(),Pa=a("th"),oa=a("button"),Od=n("details"),La=l(),Gt=a("tfoot"),he=a("tr"),na=a("th"),Nd=l(),xa=a("th"),Xt=n("Name"),Ga=l(),Xe=a("th"),Yd=n("Job"),Kd=l(),Ma=a("th"),Va=n("Favorite Color"),Fa=l(),ha=a("th"),this.h()},l(Jd){c=d(Jd,"DIV",{class:!0});var ed=r(c);s=d(ed,"TABLE",{class:!0});var ze=r(s);E=d(ze,"THEAD",{});var sr=r(E);i=d(sr,"TR",{});var De=r(i);_=d(De,"TH",{});var cr=r(_);$=d(cr,"LABEL",{});var ir=r($);f=d(ir,"INPUT",{type:!0,class:!0}),ir.forEach(e),cr.forEach(e),T=o(De),J=d(De,"TH",{});var ad=r(J);G=h(ad,"Name"),ad.forEach(e),rt=o(De),ct=d(De,"TH",{});var dd=r(ct);A=h(dd,"Job"),dd.forEach(e),it=o(De),X=d(De,"TH",{});var sl=r(X);g=h(sl,"Favorite Color"),sl.forEach(e),D=o(De),V=d(De,"TH",{}),r(V).forEach(e),De.forEach(e),sr.forEach(e),v=o(ze),b=d(ze,"TBODY",{});var Oe=r(b);k=d(Oe,"TR",{});var ot=r(k);tt=d(ot,"TH",{});var rd=r(tt);Et=d(rd,"LABEL",{});var Kt=r(Et);q=d(Kt,"INPUT",{type:!0,class:!0}),Kt.forEach(e),rd.forEach(e),p=o(ot),P=d(ot,"TD",{});var fr=r(P);u=d(fr,"DIV",{class:!0});var ld=r(u);I=d(ld,"DIV",{class:!0});var vr=r(I);ft=d(vr,"DIV",{class:!0});var od=r(ft);H=d(od,"IMG",{src:!0,alt:!0}),od.forEach(e),vr.forEach(e),At=o(ld),Tt=d(ld,"DIV",{});var sa=r(Tt);L=d(sa,"DIV",{class:!0});var cl=r(L);Dt=h(cl,"Hart Hagerty"),cl.forEach(e),bt=o(sa),et=d(sa,"DIV",{class:!0});var Tr=r(et);kt=h(Tr,"United States"),Tr.forEach(e),sa.forEach(e),ld.forEach(e),fr.forEach(e),mt=o(ot),W=d(ot,"TD",{});var we=r(W);It=h(we,`Zemlak, Daniel and Leannon
          `),Bt=d(we,"BR",{}),S=o(we),z=d(we,"SPAN",{class:!0});var _r=r(z);Pt=h(_r,"Desktop Support Technician"),_r.forEach(e),we.forEach(e),Wt=o(ot),N=d(ot,"TD",{});var nd=r(N);F=h(nd,"Purple"),nd.forEach(e),Lt=o(ot),Z=d(ot,"TH",{});var Er=r(Z);ut=d(Er,"BUTTON",{class:!0});var il=r(ut);yt=h(il,"details"),il.forEach(e),Er.forEach(e),ot.forEach(e),R=o(Oe),Q=d(Oe,"TR",{});var se=r(Q);Y=d(se,"TH",{});var hd=r(Y);st=d(hd,"LABEL",{});var fl=r(st);dt=d(fl,"INPUT",{type:!0,class:!0}),fl.forEach(e),hd.forEach(e),qt=o(se),B=d(se,"TD",{});var ur=r(B);at=d(ur,"DIV",{class:!0});var ca=r(at);$t=d(ca,"DIV",{class:!0});var pr=r($t);Mt=d(pr,"DIV",{class:!0});var sd=r(Mt);M=d(sd,"IMG",{src:!0,alt:!0}),sd.forEach(e),pr.forEach(e),Ut=o(ca),Ht=d(ca,"DIV",{});var cd=r(Ht);Vt=d(cd,"DIV",{class:!0});var vl=r(Vt);re=h(vl,"Brice Swyre"),vl.forEach(e),C=o(cd),O=d(cd,"DIV",{class:!0});var vt=r(O);Zt=h(vt,"China"),vt.forEach(e),cd.forEach(e),ca.forEach(e),ur.forEach(e),Qt=o(se),St=d(se,"TD",{});var _t=r(St);w=h(_t,`Carroll Group
          `),jt=d(_t,"BR",{}),le=o(_t),gt=d(_t,"SPAN",{class:!0});var id=r(gt);K=h(id,"Tax Accountant"),id.forEach(e),_t.forEach(e),Da=o(se),ba=d(se,"TD",{});var Tl=r(ba);Kr=h(Tl,"Red"),Tl.forEach(e),Te=o(se),Je=d(se,"TH",{});var Dr=r(Je);ea=d(Dr,"BUTTON",{class:!0});var fd=r(ea);Rd=h(fd,"details"),fd.forEach(e),Dr.forEach(e),se.forEach(e),Cd=o(Oe),oe=d(Oe,"TR",{});var be=r(oe);qe=d(be,"TH",{});var br=r(qe);ma=d(br,"LABEL",{});var mr=r(ma);wd=d(mr,"INPUT",{type:!0,class:!0}),mr.forEach(e),br.forEach(e),ya=o(be),xt=d(be,"TD",{});var yr=r(xt);Be=d(yr,"DIV",{class:!0});var ia=r(Be);aa=d(ia,"DIV",{class:!0});var Hr=r(aa);da=d(Hr,"DIV",{class:!0});var _l=r(da);Pe=d(_l,"IMG",{src:!0,alt:!0}),_l.forEach(e),Hr.forEach(e),Jr=o(ia),Ce=d(ia,"DIV",{});var fa=r(Ce);Le=d(fa,"DIV",{class:!0});var vd=r(Le);Ad=h(vd,"Marjy Ferencz"),vd.forEach(e),kd=o(fa),Rt=d(fa,"DIV",{class:!0});var El=r(Rt);Ha=h(El,"Russia"),El.forEach(e),fa.forEach(e),ia.forEach(e),yr.forEach(e),$a=o(be),xe=d(be,"TD",{});var Wa=r(xe);Id=h(Wa,`Rowe-Schoen
          `),Bd=d(Wa,"BR",{}),Pd=o(Wa),Ge=d(Wa,"SPAN",{class:!0});var Td=r(Ge);Sa=h(Td,"Office Assistant I"),Td.forEach(e),Wa.forEach(e),qr=o(be),ga=d(be,"TD",{});var $r=r(ga);zt=h($r,"Crimson"),$r.forEach(e),Ra=o(be),Ue=d(be,"TH",{});var Sr=r(Ue);Xa=d(Sr,"BUTTON",{class:!0});var gr=r(Xa);Ld=h(gr,"details"),gr.forEach(e),Sr.forEach(e),be.forEach(e),Ca=o(Oe),ne=d(Oe,"TR",{});var me=r(ne);Ze=d(me,"TH",{});var Jt=r(Ze);wa=d(Jt,"LABEL",{});var va=r(wa);xd=d(va,"INPUT",{type:!0,class:!0}),va.forEach(e),Jt.forEach(e),_e=o(me),Qe=d(me,"TD",{});var ul=r(Qe);Me=d(ul,"DIV",{class:!0});var Rr=r(Me);ra=d(Rr,"DIV",{class:!0});var pt=r(ra);Ct=d(pt,"DIV",{class:!0});var _d=r(Ct);Ve=d(_d,"IMG",{src:!0,alt:!0}),_d.forEach(e),pt.forEach(e),Ur=o(Rr),je=d(Rr,"DIV",{});var Ed=r(je);Fe=d(Ed,"DIV",{class:!0});var Cr=r(Fe);Gd=h(Cr,"Yancy Tear"),Cr.forEach(e),Md=o(Ed),Ft=d(Ed,"DIV",{class:!0});var wr=r(Ft);Aa=h(wr,"Brazil"),wr.forEach(e),Ed.forEach(e),Rr.forEach(e),ul.forEach(e),ka=o(me),la=d(me,"TD",{});var za=r(la);Vd=h(za,`Wyman-Ledner
          `),Ia=d(za,"BR",{}),Fd=o(za),We=d(za,"SPAN",{class:!0});var ud=r(We);Wd=h(ud,"Community Outreach Specialist"),ud.forEach(e),za.forEach(e),Zr=o(me),Ee=d(me,"TD",{});var Ar=r(Ee);Ba=h(Ar,"Indigo"),Ar.forEach(e),zd=o(me),Pa=d(me,"TH",{});var pl=r(Pa);oa=d(pl,"BUTTON",{class:!0});var pd=r(oa);Od=h(pd,"details"),pd.forEach(e),pl.forEach(e),me.forEach(e),Oe.forEach(e),La=o(ze),Gt=d(ze,"TFOOT",{});var Dd=r(Gt);he=d(Dd,"TR",{});var ye=r(he);na=d(ye,"TH",{}),r(na).forEach(e),Nd=o(ye),xa=d(ye,"TH",{});var kr=r(xa);Xt=h(kr,"Name"),kr.forEach(e),Ga=o(ye),Xe=d(ye,"TH",{});var Ir=r(Xe);Yd=h(Ir,"Job"),Ir.forEach(e),Kd=o(ye),Ma=d(ye,"TH",{});var Ne=r(Ma);Va=h(Ne,"Favorite Color"),Ne.forEach(e),Fa=o(ye),ha=d(ye,"TH",{}),r(ha).forEach(e),ye.forEach(e),Dd.forEach(e),ze.forEach(e),ed.forEach(e),this.h()},h(){y(f,"type","checkbox"),y(f,"class","checkbox"),y(q,"type","checkbox"),y(q,"class","checkbox"),j1(H.src,lt="/tailwind-css-component-profile-2@56w.png")||y(H,"src",lt),y(H,"alt","Avatar Tailwind CSS Component"),y(ft,"class","w-12 h-12 mask mask-squircle"),y(I,"class","avatar"),y(L,"class","font-bold"),y(et,"class","text-sm opacity-50"),y(u,"class","flex items-center space-x-3"),y(z,"class","badge badge-ghost badge-sm"),y(ut,"class","btn btn-ghost btn-xs"),y(dt,"type","checkbox"),y(dt,"class","checkbox"),j1(M.src,x="/tailwind-css-component-profile-3@56w.png")||y(M,"src",x),y(M,"alt","Avatar Tailwind CSS Component"),y(Mt,"class","w-12 h-12 mask mask-squircle"),y($t,"class","avatar"),y(Vt,"class","font-bold"),y(O,"class","text-sm opacity-50"),y(at,"class","flex items-center space-x-3"),y(gt,"class","badge badge-ghost badge-sm"),y(ea,"class","btn btn-ghost btn-xs"),y(wd,"type","checkbox"),y(wd,"class","checkbox"),j1(Pe.src,hr="/tailwind-css-component-profile-4@56w.png")||y(Pe,"src",hr),y(Pe,"alt","Avatar Tailwind CSS Component"),y(da,"class","w-12 h-12 mask mask-squircle"),y(aa,"class","avatar"),y(Le,"class","font-bold"),y(Rt,"class","text-sm opacity-50"),y(Be,"class","flex items-center space-x-3"),y(Ge,"class","badge badge-ghost badge-sm"),y(Xa,"class","btn btn-ghost btn-xs"),y(xd,"type","checkbox"),y(xd,"class","checkbox"),j1(Ve.src,td="/tailwind-css-component-profile-5@56w.png")||y(Ve,"src",td),y(Ve,"alt","Avatar Tailwind CSS Component"),y(Ct,"class","w-12 h-12 mask mask-squircle"),y(ra,"class","avatar"),y(Fe,"class","font-bold"),y(Ft,"class","text-sm opacity-50"),y(Me,"class","flex items-center space-x-3"),y(We,"class","badge badge-ghost badge-sm"),y(oa,"class","btn btn-ghost btn-xs"),y(s,"class","table"),y(c,"class","overflow-x-auto")},m(Jd,ed){Re(Jd,c,ed),t(c,s),t(s,E),t(E,i),t(i,_),t(_,$),t($,f),t(i,T),t(i,J),t(J,G),t(i,rt),t(i,ct),t(ct,A),t(i,it),t(i,X),t(X,g),t(i,D),t(i,V),t(s,v),t(s,b),t(b,k),t(k,tt),t(tt,Et),t(Et,q),t(k,p),t(k,P),t(P,u),t(u,I),t(I,ft),t(ft,H),t(u,At),t(u,Tt),t(Tt,L),t(L,Dt),t(Tt,bt),t(Tt,et),t(et,kt),t(k,mt),t(k,W),t(W,It),t(W,Bt),t(W,S),t(W,z),t(z,Pt),t(k,Wt),t(k,N),t(N,F),t(k,Lt),t(k,Z),t(Z,ut),t(ut,yt),t(b,R),t(b,Q),t(Q,Y),t(Y,st),t(st,dt),t(Q,qt),t(Q,B),t(B,at),t(at,$t),t($t,Mt),t(Mt,M),t(at,Ut),t(at,Ht),t(Ht,Vt),t(Vt,re),t(Ht,C),t(Ht,O),t(O,Zt),t(Q,Qt),t(Q,St),t(St,w),t(St,jt),t(St,le),t(St,gt),t(gt,K),t(Q,Da),t(Q,ba),t(ba,Kr),t(Q,Te),t(Q,Je),t(Je,ea),t(ea,Rd),t(b,Cd),t(b,oe),t(oe,qe),t(qe,ma),t(ma,wd),t(oe,ya),t(oe,xt),t(xt,Be),t(Be,aa),t(aa,da),t(da,Pe),t(Be,Jr),t(Be,Ce),t(Ce,Le),t(Le,Ad),t(Ce,kd),t(Ce,Rt),t(Rt,Ha),t(oe,$a),t(oe,xe),t(xe,Id),t(xe,Bd),t(xe,Pd),t(xe,Ge),t(Ge,Sa),t(oe,qr),t(oe,ga),t(ga,zt),t(oe,Ra),t(oe,Ue),t(Ue,Xa),t(Xa,Ld),t(b,Ca),t(b,ne),t(ne,Ze),t(Ze,wa),t(wa,xd),t(ne,_e),t(ne,Qe),t(Qe,Me),t(Me,ra),t(ra,Ct),t(Ct,Ve),t(Me,Ur),t(Me,je),t(je,Fe),t(Fe,Gd),t(je,Md),t(je,Ft),t(Ft,Aa),t(ne,ka),t(ne,la),t(la,Vd),t(la,Ia),t(la,Fd),t(la,We),t(We,Wd),t(ne,Zr),t(ne,Ee),t(Ee,Ba),t(ne,zd),t(ne,Pa),t(Pa,oa),t(oa,Od),t(s,La),t(s,Gt),t(Gt,he),t(he,na),t(he,Nd),t(he,xa),t(xa,Xt),t(he,Ga),t(he,Xe),t(Xe,Yd),t(he,Kd),t(he,Ma),t(Ma,Va),t(he,Fa),t(he,ha)},p:fs,d(Jd){Jd&&e(c)}}}function Wi(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table">
    <!-- head -->
    <thead>
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <!-- row 1 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-2@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Hart Hagerty</div>
              <div class="text-sm opacity-50">United States</div>
            </div>
          </div>
        </td>
        <td>
          Zemlak, Daniel and Leannon
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Desktop Support Technician</span>
        </td>
        <td>Purple</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 2 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-3@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Brice Swyre</div>
              <div class="text-sm opacity-50">China</div>
            </div>
          </div>
        </td>
        <td>
          Carroll Group
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Tax Accountant</span>
        </td>
        <td>Red</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 3 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-4@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Marjy Ferencz</div>
              <div class="text-sm opacity-50">Russia</div>
            </div>
          </div>
        </td>
        <td>
          Rowe-Schoen
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Office Assistant I</span>
        </td>
        <td>Crimson</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
      <!-- row 4 -->
      <tr>
        <th>
          <label>
            <input type="checkbox" class="$$checkbox" />
          </label>
        </th>
        <td>
          <div class="flex items-center space-x-3">
            <div class="$$avatar">
              <div class="$$mask $$mask-squircle w-12 h-12">
                <img src="/tailwind-css-component-profile-5@56w.png" alt="Avatar Tailwind CSS Component" />
              </div>
            </div>
            <div>
              <div class="font-bold">Yancy Tear</div>
              <div class="text-sm opacity-50">Brazil</div>
            </div>
          </div>
        </td>
        <td>
          Wyman-Ledner
          <br/>
          <span class="$$badge $$badge-ghost $$badge-sm">Community Outreach Specialist</span>
        </td>
        <td>Indigo</td>
        <th>
          <button class="$$btn $$btn-ghost $$btn-xs">details</button>
        </th>
      </tr>
    </tbody>
    <!-- foot -->
    <tfoot>
      <tr>
        <th></th>
        <th>Name</th>
        <th>Job</th>
        <th>Favorite Color</th>
        <th></th>
      </tr>
    </tfoot>
    
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function zi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q,Y,st,dt,qt,B,at,$t,Mt,M,x,Ut,Ht,Vt,re,C,O,Zt,Qt,St,w,jt,le,gt,K,Da,ba,Kr,Te,Je,ea,Rd,Cd,oe,qe,ma,wd,ya,xt,Be,aa,da,Pe,hr,Jr,Ce,Le,Ad,kd,Rt,Ha,$a,xe,Id,Bd,Pd,Ge,Sa,qr,ga,zt,Ra,Ue,Xa,Ld,Ca,ne,Ze,wa,xd,_e,Qe,Me,ra,Ct,Ve,td,Ur,je,Fe,Gd,Md,Ft,Aa,ka,la,Vd,Ia,Fd,We,Wd,Zr,Ee,Ba,zd,Pa,oa,Od,La,Gt,he,na,Nd,xa,Xt,Ga,Xe,Yd,Kd,Ma,Va,Fa,ha,Jd,ed,ze,sr,De,cr,ir,ad,dd,sl,Oe,ot,rd,Kt,fr,ld,vr,od,sa,cl,Tr,we,_r,nd,Er,il,se,hd,fl,ur,ca,pr,sd,cd,vl,vt,_t,id,Tl,Dr,fd,be,br,mr,yr,ia,Hr,_l,fa,vd,El,Wa,Td,$r,Sr,gr,me,Jt,va,ul,Rr,pt,_d,Ed,Cr,wr,za,ud,Ar,pl,pd,Dd,ye,kr,Ir,Ne,Qr,jr,xo,ue,qd,ao,Go,Xr,ro,lo,te,oo,no,tl,ho,Mo,el,al,so,co,io,fo,dl,rl,Vo,pe,Ud,vo,To,ll,Fo,ol,Zd,_o,Wo,ee,nl,Eo,uo,hl,po,m,Do,Qo,bo,Ta,jo,He,Dl,Xo,tn,bl,en,an,ml,dn,rn,yl,ln,bd,ae,mo,on,yo,Ho,nn,$o,So,hn,$e,Hl,sn,cn,_a,fn,vn,$l,Tn,_n,Sl,En,un,gl,pn,Dn,wt,go,bn,Ro,Co,mn,Se,Rl,yn,Hn,Cl,$n,Sn,wl,gn,Rn,Al,Cn,wn,kl,An,kn,Il,In,Br,de,wo,Bn,ge,Bl,Pn,Ln,Pl,xn,Gn,Ll,xl,Mn,Gl,Vn,Fn,Ml,Wn,zn,Vl,On,Ao,Fl,Nn,Yn,nt,Wl,Kn,Jn,zl,qn,Un,Ol,Zn,Qn,Pr,jn,Xn,Nl,th,eh,Yl,ah,md,Kl,dh,rh,ce,ko,lh,ie,Jl,oh,nh,ql,hh,sh,Lr,ch,ih,Ul,fh,vh,Zl,Th,xr,Ql,_h,Eh,fe,Io,uh,Bo,Po,ph,ve,jl,Dh,bh,Xl,mh,yh,to,Lo,Hh,eo,$h,Sh,zo,Es,us,Ae,Ph,ps,Lh,xh,Ds,Gh,Mh,bs,ke,Oo,ms,ys,No,Hs,$s,Yo,Ss,gs,Ko,Rs,Cs,Jo,ta,Jh,Vh,Fh,ws,Wh,zh,As,Oh,Nh,ks,Ie,qo,Is,Bs,Uo,Ps,Ls,Zo,xs;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("th"),T=n("Name"),J=l(),G=a("th"),rt=n("Job"),ct=l(),A=a("th"),it=n("company"),X=l(),g=a("th"),D=n("location"),V=l(),v=a("th"),b=n("Last Login"),k=l(),tt=a("th"),Et=n("Favorite Color"),q=l(),p=a("tbody"),P=a("tr"),u=a("th"),I=n("1"),ft=l(),H=a("td"),lt=n("Cy Ganderton"),At=l(),Tt=a("td"),L=n("Quality Control Specialist"),Dt=l(),bt=a("td"),et=n("Littel, Schaden and Vandervort"),kt=l(),mt=a("td"),W=n("Canada"),It=l(),Bt=a("td"),S=n("12/16/2020"),z=l(),Pt=a("td"),Wt=n("Blue"),N=l(),F=a("tr"),Lt=a("th"),Z=n("2"),ut=l(),yt=a("td"),R=n("Hart Hagerty"),Q=l(),Y=a("td"),st=n("Desktop Support Technician"),dt=l(),qt=a("td"),B=n("Zemlak, Daniel and Leannon"),at=l(),$t=a("td"),Mt=n("United States"),M=l(),x=a("td"),Ut=n("12/5/2020"),Ht=l(),Vt=a("td"),re=n("Purple"),C=l(),O=a("tr"),Zt=a("th"),Qt=n("3"),St=l(),w=a("td"),jt=n("Brice Swyre"),le=l(),gt=a("td"),K=n("Tax Accountant"),Da=l(),ba=a("td"),Kr=n("Carroll Group"),Te=l(),Je=a("td"),ea=n("China"),Rd=l(),Cd=a("td"),oe=n("8/15/2020"),qe=l(),ma=a("td"),wd=n("Red"),ya=l(),xt=a("tr"),Be=a("th"),aa=n("4"),da=l(),Pe=a("td"),hr=n("Marjy Ferencz"),Jr=l(),Ce=a("td"),Le=n("Office Assistant I"),Ad=l(),kd=a("td"),Rt=n("Rowe-Schoen"),Ha=l(),$a=a("td"),xe=n("Russia"),Id=l(),Bd=a("td"),Pd=n("3/25/2021"),Ge=l(),Sa=a("td"),qr=n("Crimson"),ga=l(),zt=a("tr"),Ra=a("th"),Ue=n("5"),Xa=l(),Ld=a("td"),Ca=n("Yancy Tear"),ne=l(),Ze=a("td"),wa=n("Community Outreach Specialist"),xd=l(),_e=a("td"),Qe=n("Wyman-Ledner"),Me=l(),ra=a("td"),Ct=n("Brazil"),Ve=l(),td=a("td"),Ur=n("5/22/2020"),je=l(),Fe=a("td"),Gd=n("Indigo"),Md=l(),Ft=a("tr"),Aa=a("th"),ka=n("6"),la=l(),Vd=a("td"),Ia=n("Irma Vasilik"),Fd=l(),We=a("td"),Wd=n("Editor"),Zr=l(),Ee=a("td"),Ba=n("Wiza, Bins and Emard"),zd=l(),Pa=a("td"),oa=n("Venezuela"),Od=l(),La=a("td"),Gt=n("12/8/2020"),he=l(),na=a("td"),Nd=n("Purple"),xa=l(),Xt=a("tr"),Ga=a("th"),Xe=n("7"),Yd=l(),Kd=a("td"),Ma=n("Meghann Durtnal"),Va=l(),Fa=a("td"),ha=n("Staff Accountant IV"),Jd=l(),ed=a("td"),ze=n("Schuster-Schimmel"),sr=l(),De=a("td"),cr=n("Philippines"),ir=l(),ad=a("td"),dd=n("2/17/2021"),sl=l(),Oe=a("td"),ot=n("Yellow"),rd=l(),Kt=a("tr"),fr=a("th"),ld=n("8"),vr=l(),od=a("td"),sa=n("Sammy Seston"),cl=l(),Tr=a("td"),we=n("Accountant I"),_r=l(),nd=a("td"),Er=n("O'Hara, Welch and Keebler"),il=l(),se=a("td"),hd=n("Indonesia"),fl=l(),ur=a("td"),ca=n("5/23/2020"),pr=l(),sd=a("td"),cd=n("Crimson"),vl=l(),vt=a("tr"),_t=a("th"),id=n("9"),Tl=l(),Dr=a("td"),fd=n("Lesya Tinham"),be=l(),br=a("td"),mr=n("Safety Technician IV"),yr=l(),ia=a("td"),Hr=n("Turner-Kuhlman"),_l=l(),fa=a("td"),vd=n("Philippines"),El=l(),Wa=a("td"),Td=n("2/21/2021"),$r=l(),Sr=a("td"),gr=n("Maroon"),me=l(),Jt=a("tr"),va=a("th"),ul=n("10"),Rr=l(),pt=a("td"),_d=n("Zaneta Tewkesbury"),Ed=l(),Cr=a("td"),wr=n("VP Marketing"),za=l(),ud=a("td"),Ar=n("Sauer LLC"),pl=l(),pd=a("td"),Dd=n("Chad"),ye=l(),kr=a("td"),Ir=n("6/23/2020"),Ne=l(),Qr=a("td"),jr=n("Green"),xo=l(),ue=a("tr"),qd=a("th"),ao=n("11"),Go=l(),Xr=a("td"),ro=n("Andy Tipple"),lo=l(),te=a("td"),oo=n("Librarian"),no=l(),tl=a("td"),ho=n("Hilpert Group"),Mo=l(),el=a("td"),al=n("Poland"),so=l(),co=a("td"),io=n("7/9/2020"),fo=l(),dl=a("td"),rl=n("Indigo"),Vo=l(),pe=a("tr"),Ud=a("th"),vo=n("12"),To=l(),ll=a("td"),Fo=n("Sophi Biles"),ol=l(),Zd=a("td"),_o=n("Recruiting Manager"),Wo=l(),ee=a("td"),nl=n("Gutmann Inc"),Eo=l(),uo=a("td"),hl=n("Indonesia"),po=l(),m=a("td"),Do=n("2/12/2021"),Qo=l(),bo=a("td"),Ta=n("Maroon"),jo=l(),He=a("tr"),Dl=a("th"),Xo=n("13"),tn=l(),bl=a("td"),en=n("Florida Garces"),an=l(),ml=a("td"),dn=n("Web Developer IV"),rn=l(),yl=a("td"),ln=n("Gaylord, Pacocha and Baumbach"),bd=l(),ae=a("td"),mo=n("Poland"),on=l(),yo=a("td"),Ho=n("5/31/2020"),nn=l(),$o=a("td"),So=n("Purple"),hn=l(),$e=a("tr"),Hl=a("th"),sn=n("14"),cn=l(),_a=a("td"),fn=n("Maribeth Popping"),vn=l(),$l=a("td"),Tn=n("Analyst Programmer"),_n=l(),Sl=a("td"),En=n("Deckow-Pouros"),un=l(),gl=a("td"),pn=n("Portugal"),Dn=l(),wt=a("td"),go=n("4/27/2021"),bn=l(),Ro=a("td"),Co=n("Aquamarine"),mn=l(),Se=a("tr"),Rl=a("th"),yn=n("15"),Hn=l(),Cl=a("td"),$n=n("Moritz Dryburgh"),Sn=l(),wl=a("td"),gn=n("Dental Hygienist"),Rn=l(),Al=a("td"),Cn=n("Schiller, Cole and Hackett"),wn=l(),kl=a("td"),An=n("Sri Lanka"),kn=l(),Il=a("td"),In=n("8/8/2020"),Br=l(),de=a("td"),wo=n("Crimson"),Bn=l(),ge=a("tr"),Bl=a("th"),Pn=n("16"),Ln=l(),Pl=a("td"),xn=n("Reid Semiras"),Gn=l(),Ll=a("td"),xl=n("Teacher"),Mn=l(),Gl=a("td"),Vn=n("Sporer, Sipes and Rogahn"),Fn=l(),Ml=a("td"),Wn=n("Poland"),zn=l(),Vl=a("td"),On=n("7/30/2020"),Ao=l(),Fl=a("td"),Nn=n("Green"),Yn=l(),nt=a("tr"),Wl=a("th"),Kn=n("17"),Jn=l(),zl=a("td"),qn=n("Alec Lethby"),Un=l(),Ol=a("td"),Zn=n("Teacher"),Qn=l(),Pr=a("td"),jn=n("Reichel, Glover and Hamill"),Xn=l(),Nl=a("td"),th=n("China"),eh=l(),Yl=a("td"),ah=n("2/28/2021"),md=l(),Kl=a("td"),dh=n("Khaki"),rh=l(),ce=a("tr"),ko=a("th"),lh=n("18"),ie=l(),Jl=a("td"),oh=n("Aland Wilber"),nh=l(),ql=a("td"),hh=n("Quality Control Specialist"),sh=l(),Lr=a("td"),ch=n("Kshlerin, Rogahn and Swaniawski"),ih=l(),Ul=a("td"),fh=n("Czech Republic"),vh=l(),Zl=a("td"),Th=n("9/29/2020"),xr=l(),Ql=a("td"),_h=n("Purple"),Eh=l(),fe=a("tr"),Io=a("th"),uh=n("19"),Bo=l(),Po=a("td"),ph=n("Teddie Duerden"),ve=l(),jl=a("td"),Dh=n("Staff Accountant III"),bh=l(),Xl=a("td"),mh=n("Pouros, Ullrich and Windler"),yh=l(),to=a("td"),Lo=n("France"),Hh=l(),eo=a("td"),$h=n("10/27/2020"),Sh=l(),zo=a("td"),Es=n("Aquamarine"),us=l(),Ae=a("tr"),Ph=a("th"),ps=n("20"),Lh=l(),xh=a("td"),Ds=n("Lorelei Blackstone"),Gh=l(),Mh=a("td"),bs=n("Data Coordinator"),ke=l(),Oo=a("td"),ms=n("Witting, Kutch and Greenfelder"),ys=l(),No=a("td"),Hs=n("Kazakhstan"),$s=l(),Yo=a("td"),Ss=n("6/3/2020"),gs=l(),Ko=a("td"),Rs=n("Red"),Cs=l(),Jo=a("tfoot"),ta=a("tr"),Jh=a("th"),Vh=l(),Fh=a("th"),ws=n("Name"),Wh=l(),zh=a("th"),As=n("Job"),Oh=l(),Nh=a("th"),ks=n("company"),Ie=l(),qo=a("th"),Is=n("location"),Bs=l(),Uo=a("th"),Ps=n("Last Login"),Ls=l(),Zo=a("th"),xs=n("Favorite Color"),this.h()},l(Yh){c=d(Yh,"DIV",{class:!0});var gh=r(c);s=d(gh,"TABLE",{class:!0});var Rh=r(s);E=d(Rh,"THEAD",{});var Fs=r(E);i=d(Fs,"TR",{});var Ea=r(i);_=d(Ea,"TH",{}),r(_).forEach(e),$=o(Ea),f=d(Ea,"TH",{});var Ws=r(f);T=h(Ws,"Name"),Ws.forEach(e),J=o(Ea),G=d(Ea,"TH",{});var zs=r(G);rt=h(zs,"Job"),zs.forEach(e),ct=o(Ea),A=d(Ea,"TH",{});var qh=r(A);it=h(qh,"company"),qh.forEach(e),X=o(Ea),g=d(Ea,"TH",{});var Os=r(g);D=h(Os,"location"),Os.forEach(e),V=o(Ea),v=d(Ea,"TH",{});var Ns=r(v);b=h(Ns,"Last Login"),Ns.forEach(e),k=o(Ea),tt=d(Ea,"TH",{});var Uh=r(tt);Et=h(Uh,"Favorite Color"),Uh.forEach(e),Ea.forEach(e),Fs.forEach(e),q=o(Rh),p=d(Rh,"TBODY",{});var U=r(p);P=d(U,"TR",{});var yd=r(P);u=d(yd,"TH",{});var Zh=r(u);I=h(Zh,"1"),Zh.forEach(e),ft=o(yd),H=d(yd,"TD",{});var Ys=r(H);lt=h(Ys,"Cy Ganderton"),Ys.forEach(e),At=o(yd),Tt=d(yd,"TD",{});var Ks=r(Tt);L=h(Ks,"Quality Control Specialist"),Ks.forEach(e),Dt=o(yd),bt=d(yd,"TD",{});var Ye=r(bt);et=h(Ye,"Littel, Schaden and Vandervort"),Ye.forEach(e),kt=o(yd),mt=d(yd,"TD",{});var Qh=r(mt);W=h(Qh,"Canada"),Qh.forEach(e),It=o(yd),Bt=d(yd,"TD",{});var Js=r(Bt);S=h(Js,"12/16/2020"),Js.forEach(e),z=o(yd),Pt=d(yd,"TD",{});var qs=r(Pt);Wt=h(qs,"Blue"),qs.forEach(e),yd.forEach(e),N=o(U),F=d(U,"TR",{});var ua=r(F);Lt=d(ua,"TH",{});var Us=r(Lt);Z=h(Us,"2"),Us.forEach(e),ut=o(ua),yt=d(ua,"TD",{});var Zs=r(yt);R=h(Zs,"Hart Hagerty"),Zs.forEach(e),Q=o(ua),Y=d(ua,"TD",{});var jh=r(Y);st=h(jh,"Desktop Support Technician"),jh.forEach(e),dt=o(ua),qt=d(ua,"TD",{});var Qs=r(qt);B=h(Qs,"Zemlak, Daniel and Leannon"),Qs.forEach(e),at=o(ua),$t=d(ua,"TD",{});var js=r($t);Mt=h(js,"United States"),js.forEach(e),M=o(ua),x=d(ua,"TD",{});var Xh=r(x);Ut=h(Xh,"12/5/2020"),Xh.forEach(e),Ht=o(ua),Vt=d(ua,"TD",{});var Xs=r(Vt);re=h(Xs,"Purple"),Xs.forEach(e),ua.forEach(e),C=o(U),O=d(U,"TR",{});var Hd=r(O);Zt=d(Hd,"TH",{});var ts=r(Zt);Qt=h(ts,"3"),ts.forEach(e),St=o(Hd),w=d(Hd,"TD",{});var tc=r(w);jt=h(tc,"Brice Swyre"),tc.forEach(e),le=o(Hd),gt=d(Hd,"TD",{});var ec=r(gt);K=h(ec,"Tax Accountant"),ec.forEach(e),Da=o(Hd),ba=d(Hd,"TD",{});var es=r(ba);Kr=h(es,"Carroll Group"),es.forEach(e),Te=o(Hd),Je=d(Hd,"TD",{});var ac=r(Je);ea=h(ac,"China"),ac.forEach(e),Rd=o(Hd),Cd=d(Hd,"TD",{});var dc=r(Cd);oe=h(dc,"8/15/2020"),dc.forEach(e),qe=o(Hd),ma=d(Hd,"TD",{});var as=r(ma);wd=h(as,"Red"),as.forEach(e),Hd.forEach(e),ya=o(U),xt=d(U,"TR",{});var $d=r(xt);Be=d($d,"TH",{});var rc=r(Be);aa=h(rc,"4"),rc.forEach(e),da=o($d),Pe=d($d,"TD",{});var ds=r(Pe);hr=h(ds,"Marjy Ferencz"),ds.forEach(e),Jr=o($d),Ce=d($d,"TD",{});var lc=r(Ce);Le=h(lc,"Office Assistant I"),lc.forEach(e),Ad=o($d),kd=d($d,"TD",{});var oc=r(kd);Rt=h(oc,"Rowe-Schoen"),oc.forEach(e),Ha=o($d),$a=d($d,"TD",{});var rs=r($a);xe=h(rs,"Russia"),rs.forEach(e),Id=o($d),Bd=d($d,"TD",{});var Ke=r(Bd);Pd=h(Ke,"3/25/2021"),Ke.forEach(e),Ge=o($d),Sa=d($d,"TD",{});var Gs=r(Sa);qr=h(Gs,"Crimson"),Gs.forEach(e),$d.forEach(e),ga=o(U),zt=d(U,"TR",{});var Sd=r(zt);Ra=d(Sd,"TH",{});var ls=r(Ra);Ue=h(ls,"5"),ls.forEach(e),Xa=o(Sd),Ld=d(Sd,"TD",{});var nc=r(Ld);Ca=h(nc,"Yancy Tear"),nc.forEach(e),ne=o(Sd),Ze=d(Sd,"TD",{});var hc=r(Ze);wa=h(hc,"Community Outreach Specialist"),hc.forEach(e),xd=o(Sd),_e=d(Sd,"TD",{});var os=r(_e);Qe=h(os,"Wyman-Ledner"),os.forEach(e),Me=o(Sd),ra=d(Sd,"TD",{});var sc=r(ra);Ct=h(sc,"Brazil"),sc.forEach(e),Ve=o(Sd),td=d(Sd,"TD",{});var cc=r(td);Ur=h(cc,"5/22/2020"),cc.forEach(e),je=o(Sd),Fe=d(Sd,"TD",{});var ns=r(Fe);Gd=h(ns,"Indigo"),ns.forEach(e),Sd.forEach(e),Md=o(U),Ft=d(U,"TR",{});var gd=r(Ft);Aa=d(gd,"TH",{});var ic=r(Aa);ka=h(ic,"6"),ic.forEach(e),la=o(gd),Vd=d(gd,"TD",{});var hs=r(Vd);Ia=h(hs,"Irma Vasilik"),hs.forEach(e),Fd=o(gd),We=d(gd,"TD",{});var fc=r(We);Wd=h(fc,"Editor"),fc.forEach(e),Zr=o(gd),Ee=d(gd,"TD",{});var vc=r(Ee);Ba=h(vc,"Wiza, Bins and Emard"),vc.forEach(e),zd=o(gd),Pa=d(gd,"TD",{});var ss=r(Pa);oa=h(ss,"Venezuela"),ss.forEach(e),Od=o(gd),La=d(gd,"TD",{});var Tc=r(La);Gt=h(Tc,"12/8/2020"),Tc.forEach(e),he=o(gd),na=d(gd,"TD",{});var _c=r(na);Nd=h(_c,"Purple"),_c.forEach(e),gd.forEach(e),xa=o(U),Xt=d(U,"TR",{});var pa=r(Xt);Ga=d(pa,"TH",{});var Ec=r(Ga);Xe=h(Ec,"7"),Ec.forEach(e),Yd=o(pa),Kd=d(pa,"TD",{});var uc=r(Kd);Ma=h(uc,"Meghann Durtnal"),uc.forEach(e),Va=o(pa),Fa=d(pa,"TD",{});var Ms=r(Fa);ha=h(Ms,"Staff Accountant IV"),Ms.forEach(e),Jd=o(pa),ed=d(pa,"TD",{});var cs=r(ed);ze=h(cs,"Schuster-Schimmel"),cs.forEach(e),sr=o(pa),De=d(pa,"TD",{});var Vs=r(De);cr=h(Vs,"Philippines"),Vs.forEach(e),ir=o(pa),ad=d(pa,"TD",{});var Kh=r(ad);dd=h(Kh,"2/17/2021"),Kh.forEach(e),sl=o(pa),Oe=d(pa,"TD",{});var pc=r(Oe);ot=h(pc,"Yellow"),pc.forEach(e),pa.forEach(e),rd=o(U),Kt=d(U,"TR",{});var Ot=r(Kt);fr=d(Ot,"TH",{});var Dc=r(fr);ld=h(Dc,"8"),Dc.forEach(e),vr=o(Ot),od=d(Ot,"TD",{});var bc=r(od);sa=h(bc,"Sammy Seston"),bc.forEach(e),cl=o(Ot),Tr=d(Ot,"TD",{});var mc=r(Tr);we=h(mc,"Accountant I"),mc.forEach(e),_r=o(Ot),nd=d(Ot,"TD",{});var yc=r(nd);Er=h(yc,"O'Hara, Welch and Keebler"),yc.forEach(e),il=o(Ot),se=d(Ot,"TD",{});var Hc=r(se);hd=h(Hc,"Indonesia"),Hc.forEach(e),fl=o(Ot),ur=d(Ot,"TD",{});var $c=r(ur);ca=h($c,"5/23/2020"),$c.forEach(e),pr=o(Ot),sd=d(Ot,"TD",{});var j=r(sd);cd=h(j,"Crimson"),j.forEach(e),Ot.forEach(e),vl=o(U),vt=d(U,"TR",{});var Nt=r(vt);_t=d(Nt,"TH",{});var Sc=r(_t);id=h(Sc,"9"),Sc.forEach(e),Tl=o(Nt),Dr=d(Nt,"TD",{});var gc=r(Dr);fd=h(gc,"Lesya Tinham"),gc.forEach(e),be=o(Nt),br=d(Nt,"TD",{});var Rc=r(br);mr=h(Rc,"Safety Technician IV"),Rc.forEach(e),yr=o(Nt),ia=d(Nt,"TD",{});var Cc=r(ia);Hr=h(Cc,"Turner-Kuhlman"),Cc.forEach(e),_l=o(Nt),fa=d(Nt,"TD",{});var wc=r(fa);vd=h(wc,"Philippines"),wc.forEach(e),El=o(Nt),Wa=d(Nt,"TD",{});var Ac=r(Wa);Td=h(Ac,"2/21/2021"),Ac.forEach(e),$r=o(Nt),Sr=d(Nt,"TD",{});var kc=r(Sr);gr=h(kc,"Maroon"),kc.forEach(e),Nt.forEach(e),me=o(U),Jt=d(U,"TR",{});var Qd=r(Jt);va=d(Qd,"TH",{});var Oa=r(va);ul=h(Oa,"10"),Oa.forEach(e),Rr=o(Qd),pt=d(Qd,"TD",{});var Ic=r(pt);_d=h(Ic,"Zaneta Tewkesbury"),Ic.forEach(e),Ed=o(Qd),Cr=d(Qd,"TD",{});var Bc=r(Cr);wr=h(Bc,"VP Marketing"),Bc.forEach(e),za=o(Qd),ud=d(Qd,"TD",{});var Pc=r(ud);Ar=h(Pc,"Sauer LLC"),Pc.forEach(e),pl=o(Qd),pd=d(Qd,"TD",{});var Lc=r(pd);Dd=h(Lc,"Chad"),Lc.forEach(e),ye=o(Qd),kr=d(Qd,"TD",{});var xc=r(kr);Ir=h(xc,"6/23/2020"),xc.forEach(e),Ne=o(Qd),Qr=d(Qd,"TD",{});var Gc=r(Qr);jr=h(Gc,"Green"),Gc.forEach(e),Qd.forEach(e),xo=o(U),ue=d(U,"TR",{});var jd=r(ue);qd=d(jd,"TH",{});var Mc=r(qd);ao=h(Mc,"11"),Mc.forEach(e),Go=o(jd),Xr=d(jd,"TD",{});var Na=r(Xr);ro=h(Na,"Andy Tipple"),Na.forEach(e),lo=o(jd),te=d(jd,"TD",{});var Vc=r(te);oo=h(Vc,"Librarian"),Vc.forEach(e),no=o(jd),tl=d(jd,"TD",{});var Fc=r(tl);ho=h(Fc,"Hilpert Group"),Fc.forEach(e),Mo=o(jd),el=d(jd,"TD",{});var Wc=r(el);al=h(Wc,"Poland"),Wc.forEach(e),so=o(jd),co=d(jd,"TD",{});var zc=r(co);io=h(zc,"7/9/2020"),zc.forEach(e),fo=o(jd),dl=d(jd,"TD",{});var Oc=r(dl);rl=h(Oc,"Indigo"),Oc.forEach(e),jd.forEach(e),Vo=o(U),pe=d(U,"TR",{});var Xd=r(pe);Ud=d(Xd,"TH",{});var Nc=r(Ud);vo=h(Nc,"12"),Nc.forEach(e),To=o(Xd),ll=d(Xd,"TD",{});var Yc=r(ll);Fo=h(Yc,"Sophi Biles"),Yc.forEach(e),ol=o(Xd),Zd=d(Xd,"TD",{});var Ya=r(Zd);_o=h(Ya,"Recruiting Manager"),Ya.forEach(e),Wo=o(Xd),ee=d(Xd,"TD",{});var Kc=r(ee);nl=h(Kc,"Gutmann Inc"),Kc.forEach(e),Eo=o(Xd),uo=d(Xd,"TD",{});var Jc=r(uo);hl=h(Jc,"Indonesia"),Jc.forEach(e),po=o(Xd),m=d(Xd,"TD",{});var qc=r(m);Do=h(qc,"2/12/2021"),qc.forEach(e),Qo=o(Xd),bo=d(Xd,"TD",{});var Uc=r(bo);Ta=h(Uc,"Maroon"),Uc.forEach(e),Xd.forEach(e),jo=o(U),He=d(U,"TR",{});var tr=r(He);Dl=d(tr,"TH",{});var Zc=r(Dl);Xo=h(Zc,"13"),Zc.forEach(e),tn=o(tr),bl=d(tr,"TD",{});var Qc=r(bl);en=h(Qc,"Florida Garces"),Qc.forEach(e),an=o(tr),ml=d(tr,"TD",{});var jc=r(ml);dn=h(jc,"Web Developer IV"),jc.forEach(e),rn=o(tr),yl=d(tr,"TD",{});var Ka=r(yl);ln=h(Ka,"Gaylord, Pacocha and Baumbach"),Ka.forEach(e),bd=o(tr),ae=d(tr,"TD",{});var Xc=r(ae);mo=h(Xc,"Poland"),Xc.forEach(e),on=o(tr),yo=d(tr,"TD",{});var t1=r(yo);Ho=h(t1,"5/31/2020"),t1.forEach(e),nn=o(tr),$o=d(tr,"TD",{});var e1=r($o);So=h(e1,"Purple"),e1.forEach(e),tr.forEach(e),hn=o(U),$e=d(U,"TR",{});var er=r($e);Hl=d(er,"TH",{});var a1=r(Hl);sn=h(a1,"14"),a1.forEach(e),cn=o(er),_a=d(er,"TD",{});var d1=r(_a);fn=h(d1,"Maribeth Popping"),d1.forEach(e),vn=o(er),$l=d(er,"TD",{});var r1=r($l);Tn=h(r1,"Analyst Programmer"),r1.forEach(e),_n=o(er),Sl=d(er,"TD",{});var l1=r(Sl);En=h(l1,"Deckow-Pouros"),l1.forEach(e),un=o(er),gl=d(er,"TD",{});var Ja=r(gl);pn=h(Ja,"Portugal"),Ja.forEach(e),Dn=o(er),wt=d(er,"TD",{});var o1=r(wt);go=h(o1,"4/27/2021"),o1.forEach(e),bn=o(er),Ro=d(er,"TD",{});var n1=r(Ro);Co=h(n1,"Aquamarine"),n1.forEach(e),er.forEach(e),mn=o(U),Se=d(U,"TR",{});var ar=r(Se);Rl=d(ar,"TH",{});var h1=r(Rl);yn=h(h1,"15"),h1.forEach(e),Hn=o(ar),Cl=d(ar,"TD",{});var s1=r(Cl);$n=h(s1,"Moritz Dryburgh"),s1.forEach(e),Sn=o(ar),wl=d(ar,"TD",{});var c1=r(wl);gn=h(c1,"Dental Hygienist"),c1.forEach(e),Rn=o(ar),Al=d(ar,"TD",{});var i1=r(Al);Cn=h(i1,"Schiller, Cole and Hackett"),i1.forEach(e),wn=o(ar),kl=d(ar,"TD",{});var f1=r(kl);An=h(f1,"Sri Lanka"),f1.forEach(e),kn=o(ar),Il=d(ar,"TD",{});var qa=r(Il);In=h(qa,"8/8/2020"),qa.forEach(e),Br=o(ar),de=d(ar,"TD",{});var v1=r(de);wo=h(v1,"Crimson"),v1.forEach(e),ar.forEach(e),Bn=o(U),ge=d(U,"TR",{});var dr=r(ge);Bl=d(dr,"TH",{});var T1=r(Bl);Pn=h(T1,"16"),T1.forEach(e),Ln=o(dr),Pl=d(dr,"TD",{});var _1=r(Pl);xn=h(_1,"Reid Semiras"),_1.forEach(e),Gn=o(dr),Ll=d(dr,"TD",{});var E1=r(Ll);xl=h(E1,"Teacher"),E1.forEach(e),Mn=o(dr),Gl=d(dr,"TD",{});var u1=r(Gl);Vn=h(u1,"Sporer, Sipes and Rogahn"),u1.forEach(e),Fn=o(dr),Ml=d(dr,"TD",{});var p1=r(Ml);Wn=h(p1,"Poland"),p1.forEach(e),zn=o(dr),Vl=d(dr,"TD",{});var D1=r(Vl);On=h(D1,"7/30/2020"),D1.forEach(e),Ao=o(dr),Fl=d(dr,"TD",{});var Ua=r(Fl);Nn=h(Ua,"Green"),Ua.forEach(e),dr.forEach(e),Yn=o(U),nt=d(U,"TR",{});var rr=r(nt);Wl=d(rr,"TH",{});var b1=r(Wl);Kn=h(b1,"17"),b1.forEach(e),Jn=o(rr),zl=d(rr,"TD",{});var m1=r(zl);qn=h(m1,"Alec Lethby"),m1.forEach(e),Un=o(rr),Ol=d(rr,"TD",{});var y1=r(Ol);Zn=h(y1,"Teacher"),y1.forEach(e),Qn=o(rr),Pr=d(rr,"TD",{});var H1=r(Pr);jn=h(H1,"Reichel, Glover and Hamill"),H1.forEach(e),Xn=o(rr),Nl=d(rr,"TD",{});var $1=r(Nl);th=h($1,"China"),$1.forEach(e),eh=o(rr),Yl=d(rr,"TD",{});var S1=r(Yl);ah=h(S1,"2/28/2021"),S1.forEach(e),md=o(rr),Kl=d(rr,"TD",{});var g1=r(Kl);dh=h(g1,"Khaki"),g1.forEach(e),rr.forEach(e),rh=o(U),ce=d(U,"TR",{});var Yt=r(ce);ko=d(Yt,"TH",{});var R1=r(ko);lh=h(R1,"18"),R1.forEach(e),ie=o(Yt),Jl=d(Yt,"TD",{});var C1=r(Jl);oh=h(C1,"Aland Wilber"),C1.forEach(e),nh=o(Yt),ql=d(Yt,"TD",{});var w1=r(ql);hh=h(w1,"Quality Control Specialist"),w1.forEach(e),sh=o(Yt),Lr=d(Yt,"TD",{});var A1=r(Lr);ch=h(A1,"Kshlerin, Rogahn and Swaniawski"),A1.forEach(e),ih=o(Yt),Ul=d(Yt,"TD",{});var k1=r(Ul);fh=h(k1,"Czech Republic"),k1.forEach(e),vh=o(Yt),Zl=d(Yt,"TD",{});var I1=r(Zl);Th=h(I1,"9/29/2020"),I1.forEach(e),xr=o(Yt),Ql=d(Yt,"TD",{});var B1=r(Ql);_h=h(B1,"Purple"),B1.forEach(e),Yt.forEach(e),Eh=o(U),fe=d(U,"TR",{});var lr=r(fe);Io=d(lr,"TH",{});var Za=r(Io);uh=h(Za,"19"),Za.forEach(e),Bo=o(lr),Po=d(lr,"TD",{});var P1=r(Po);ph=h(P1,"Teddie Duerden"),P1.forEach(e),ve=o(lr),jl=d(lr,"TD",{});var L1=r(jl);Dh=h(L1,"Staff Accountant III"),L1.forEach(e),bh=o(lr),Xl=d(lr,"TD",{});var x1=r(Xl);mh=h(x1,"Pouros, Ullrich and Windler"),x1.forEach(e),yh=o(lr),to=d(lr,"TD",{});var G1=r(to);Lo=h(G1,"France"),G1.forEach(e),Hh=o(lr),eo=d(lr,"TD",{});var M1=r(eo);$h=h(M1,"10/27/2020"),M1.forEach(e),Sh=o(lr),zo=d(lr,"TD",{});var V1=r(zo);Es=h(V1,"Aquamarine"),V1.forEach(e),lr.forEach(e),us=o(U),Ae=d(U,"TR",{});var or=r(Ae);Ph=d(or,"TH",{});var F1=r(Ph);ps=h(F1,"20"),F1.forEach(e),Lh=o(or),xh=d(or,"TD",{});var Qa=r(xh);Ds=h(Qa,"Lorelei Blackstone"),Qa.forEach(e),Gh=o(or),Mh=d(or,"TD",{});var W1=r(Mh);bs=h(W1,"Data Coordinator"),W1.forEach(e),ke=o(or),Oo=d(or,"TD",{});var z1=r(Oo);ms=h(z1,"Witting, Kutch and Greenfelder"),z1.forEach(e),ys=o(or),No=d(or,"TD",{});var O1=r(No);Hs=h(O1,"Kazakhstan"),O1.forEach(e),$s=o(or),Yo=d(or,"TD",{});var N1=r(Yo);Ss=h(N1,"6/3/2020"),N1.forEach(e),gs=o(or),Ko=d(or,"TD",{});var Y1=r(Ko);Rs=h(Y1,"Red"),Y1.forEach(e),or.forEach(e),U.forEach(e),Cs=o(Rh),Jo=d(Rh,"TFOOT",{});var K1=r(Jo);ta=d(K1,"TR",{});var nr=r(ta);Jh=d(nr,"TH",{}),r(Jh).forEach(e),Vh=o(nr),Fh=d(nr,"TH",{});var J1=r(Fh);ws=h(J1,"Name"),J1.forEach(e),Wh=o(nr),zh=d(nr,"TH",{});var ja=r(zh);As=h(ja,"Job"),ja.forEach(e),Oh=o(nr),Nh=d(nr,"TH",{});var q1=r(Nh);ks=h(q1,"company"),q1.forEach(e),Ie=o(nr),qo=d(nr,"TH",{});var U1=r(qo);Is=h(U1,"location"),U1.forEach(e),Bs=o(nr),Uo=d(nr,"TH",{});var Z1=r(Uo);Ps=h(Z1,"Last Login"),Z1.forEach(e),Ls=o(nr),Zo=d(nr,"TH",{});var Q1=r(Zo);xs=h(Q1,"Favorite Color"),Q1.forEach(e),nr.forEach(e),K1.forEach(e),Rh.forEach(e),gh.forEach(e),this.h()},h(){y(s,"class","table table-xs"),y(c,"class","overflow-x-auto")},m(Yh,gh){Re(Yh,c,gh),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(i,X),t(i,g),t(g,D),t(i,V),t(i,v),t(v,b),t(i,k),t(i,tt),t(tt,Et),t(s,q),t(s,p),t(p,P),t(P,u),t(u,I),t(P,ft),t(P,H),t(H,lt),t(P,At),t(P,Tt),t(Tt,L),t(P,Dt),t(P,bt),t(bt,et),t(P,kt),t(P,mt),t(mt,W),t(P,It),t(P,Bt),t(Bt,S),t(P,z),t(P,Pt),t(Pt,Wt),t(p,N),t(p,F),t(F,Lt),t(Lt,Z),t(F,ut),t(F,yt),t(yt,R),t(F,Q),t(F,Y),t(Y,st),t(F,dt),t(F,qt),t(qt,B),t(F,at),t(F,$t),t($t,Mt),t(F,M),t(F,x),t(x,Ut),t(F,Ht),t(F,Vt),t(Vt,re),t(p,C),t(p,O),t(O,Zt),t(Zt,Qt),t(O,St),t(O,w),t(w,jt),t(O,le),t(O,gt),t(gt,K),t(O,Da),t(O,ba),t(ba,Kr),t(O,Te),t(O,Je),t(Je,ea),t(O,Rd),t(O,Cd),t(Cd,oe),t(O,qe),t(O,ma),t(ma,wd),t(p,ya),t(p,xt),t(xt,Be),t(Be,aa),t(xt,da),t(xt,Pe),t(Pe,hr),t(xt,Jr),t(xt,Ce),t(Ce,Le),t(xt,Ad),t(xt,kd),t(kd,Rt),t(xt,Ha),t(xt,$a),t($a,xe),t(xt,Id),t(xt,Bd),t(Bd,Pd),t(xt,Ge),t(xt,Sa),t(Sa,qr),t(p,ga),t(p,zt),t(zt,Ra),t(Ra,Ue),t(zt,Xa),t(zt,Ld),t(Ld,Ca),t(zt,ne),t(zt,Ze),t(Ze,wa),t(zt,xd),t(zt,_e),t(_e,Qe),t(zt,Me),t(zt,ra),t(ra,Ct),t(zt,Ve),t(zt,td),t(td,Ur),t(zt,je),t(zt,Fe),t(Fe,Gd),t(p,Md),t(p,Ft),t(Ft,Aa),t(Aa,ka),t(Ft,la),t(Ft,Vd),t(Vd,Ia),t(Ft,Fd),t(Ft,We),t(We,Wd),t(Ft,Zr),t(Ft,Ee),t(Ee,Ba),t(Ft,zd),t(Ft,Pa),t(Pa,oa),t(Ft,Od),t(Ft,La),t(La,Gt),t(Ft,he),t(Ft,na),t(na,Nd),t(p,xa),t(p,Xt),t(Xt,Ga),t(Ga,Xe),t(Xt,Yd),t(Xt,Kd),t(Kd,Ma),t(Xt,Va),t(Xt,Fa),t(Fa,ha),t(Xt,Jd),t(Xt,ed),t(ed,ze),t(Xt,sr),t(Xt,De),t(De,cr),t(Xt,ir),t(Xt,ad),t(ad,dd),t(Xt,sl),t(Xt,Oe),t(Oe,ot),t(p,rd),t(p,Kt),t(Kt,fr),t(fr,ld),t(Kt,vr),t(Kt,od),t(od,sa),t(Kt,cl),t(Kt,Tr),t(Tr,we),t(Kt,_r),t(Kt,nd),t(nd,Er),t(Kt,il),t(Kt,se),t(se,hd),t(Kt,fl),t(Kt,ur),t(ur,ca),t(Kt,pr),t(Kt,sd),t(sd,cd),t(p,vl),t(p,vt),t(vt,_t),t(_t,id),t(vt,Tl),t(vt,Dr),t(Dr,fd),t(vt,be),t(vt,br),t(br,mr),t(vt,yr),t(vt,ia),t(ia,Hr),t(vt,_l),t(vt,fa),t(fa,vd),t(vt,El),t(vt,Wa),t(Wa,Td),t(vt,$r),t(vt,Sr),t(Sr,gr),t(p,me),t(p,Jt),t(Jt,va),t(va,ul),t(Jt,Rr),t(Jt,pt),t(pt,_d),t(Jt,Ed),t(Jt,Cr),t(Cr,wr),t(Jt,za),t(Jt,ud),t(ud,Ar),t(Jt,pl),t(Jt,pd),t(pd,Dd),t(Jt,ye),t(Jt,kr),t(kr,Ir),t(Jt,Ne),t(Jt,Qr),t(Qr,jr),t(p,xo),t(p,ue),t(ue,qd),t(qd,ao),t(ue,Go),t(ue,Xr),t(Xr,ro),t(ue,lo),t(ue,te),t(te,oo),t(ue,no),t(ue,tl),t(tl,ho),t(ue,Mo),t(ue,el),t(el,al),t(ue,so),t(ue,co),t(co,io),t(ue,fo),t(ue,dl),t(dl,rl),t(p,Vo),t(p,pe),t(pe,Ud),t(Ud,vo),t(pe,To),t(pe,ll),t(ll,Fo),t(pe,ol),t(pe,Zd),t(Zd,_o),t(pe,Wo),t(pe,ee),t(ee,nl),t(pe,Eo),t(pe,uo),t(uo,hl),t(pe,po),t(pe,m),t(m,Do),t(pe,Qo),t(pe,bo),t(bo,Ta),t(p,jo),t(p,He),t(He,Dl),t(Dl,Xo),t(He,tn),t(He,bl),t(bl,en),t(He,an),t(He,ml),t(ml,dn),t(He,rn),t(He,yl),t(yl,ln),t(He,bd),t(He,ae),t(ae,mo),t(He,on),t(He,yo),t(yo,Ho),t(He,nn),t(He,$o),t($o,So),t(p,hn),t(p,$e),t($e,Hl),t(Hl,sn),t($e,cn),t($e,_a),t(_a,fn),t($e,vn),t($e,$l),t($l,Tn),t($e,_n),t($e,Sl),t(Sl,En),t($e,un),t($e,gl),t(gl,pn),t($e,Dn),t($e,wt),t(wt,go),t($e,bn),t($e,Ro),t(Ro,Co),t(p,mn),t(p,Se),t(Se,Rl),t(Rl,yn),t(Se,Hn),t(Se,Cl),t(Cl,$n),t(Se,Sn),t(Se,wl),t(wl,gn),t(Se,Rn),t(Se,Al),t(Al,Cn),t(Se,wn),t(Se,kl),t(kl,An),t(Se,kn),t(Se,Il),t(Il,In),t(Se,Br),t(Se,de),t(de,wo),t(p,Bn),t(p,ge),t(ge,Bl),t(Bl,Pn),t(ge,Ln),t(ge,Pl),t(Pl,xn),t(ge,Gn),t(ge,Ll),t(Ll,xl),t(ge,Mn),t(ge,Gl),t(Gl,Vn),t(ge,Fn),t(ge,Ml),t(Ml,Wn),t(ge,zn),t(ge,Vl),t(Vl,On),t(ge,Ao),t(ge,Fl),t(Fl,Nn),t(p,Yn),t(p,nt),t(nt,Wl),t(Wl,Kn),t(nt,Jn),t(nt,zl),t(zl,qn),t(nt,Un),t(nt,Ol),t(Ol,Zn),t(nt,Qn),t(nt,Pr),t(Pr,jn),t(nt,Xn),t(nt,Nl),t(Nl,th),t(nt,eh),t(nt,Yl),t(Yl,ah),t(nt,md),t(nt,Kl),t(Kl,dh),t(p,rh),t(p,ce),t(ce,ko),t(ko,lh),t(ce,ie),t(ce,Jl),t(Jl,oh),t(ce,nh),t(ce,ql),t(ql,hh),t(ce,sh),t(ce,Lr),t(Lr,ch),t(ce,ih),t(ce,Ul),t(Ul,fh),t(ce,vh),t(ce,Zl),t(Zl,Th),t(ce,xr),t(ce,Ql),t(Ql,_h),t(p,Eh),t(p,fe),t(fe,Io),t(Io,uh),t(fe,Bo),t(fe,Po),t(Po,ph),t(fe,ve),t(fe,jl),t(jl,Dh),t(fe,bh),t(fe,Xl),t(Xl,mh),t(fe,yh),t(fe,to),t(to,Lo),t(fe,Hh),t(fe,eo),t(eo,$h),t(fe,Sh),t(fe,zo),t(zo,Es),t(p,us),t(p,Ae),t(Ae,Ph),t(Ph,ps),t(Ae,Lh),t(Ae,xh),t(xh,Ds),t(Ae,Gh),t(Ae,Mh),t(Mh,bs),t(Ae,ke),t(Ae,Oo),t(Oo,ms),t(Ae,ys),t(Ae,No),t(No,Hs),t(Ae,$s),t(Ae,Yo),t(Yo,Ss),t(Ae,gs),t(Ae,Ko),t(Ko,Rs),t(s,Cs),t(s,Jo),t(Jo,ta),t(ta,Jh),t(ta,Vh),t(ta,Fh),t(Fh,ws),t(ta,Wh),t(ta,zh),t(zh,As),t(ta,Oh),t(ta,Nh),t(Nh,ks),t(ta,Ie),t(ta,qo),t(qo,Is),t(ta,Bs),t(ta,Uo),t(Uo,Ps),t(ta,Ls),t(ta,Zo),t(Zo,xs)},p:fs,d(Yh){Yh&&e(c)}}}function Oi(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table $$table-xs">
    <thead>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordiator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <th>Name</th> 
        <th>Job</th> 
        <th>company</th> 
        <th>location</th> 
        <th>Last Login</th> 
        <th>Favorite Color</th>
      </tr>
    </tfoot>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function Ni(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q,Y,st,dt,qt,B,at,$t,Mt,M,x,Ut,Ht,Vt,re,C,O,Zt,Qt,St,w,jt,le,gt,K,Da,ba,Kr,Te,Je,ea,Rd,Cd,oe,qe,ma,wd,ya,xt,Be,aa,da,Pe,hr,Jr,Ce,Le,Ad,kd,Rt,Ha,$a,xe,Id,Bd,Pd,Ge,Sa,qr,ga,zt,Ra,Ue,Xa,Ld,Ca,ne,Ze,wa,xd,_e,Qe,Me,ra,Ct,Ve,td,Ur,je,Fe,Gd,Md,Ft,Aa,ka,la,Vd,Ia,Fd,We,Wd,Zr,Ee,Ba,zd,Pa,oa,Od,La,Gt,he,na,Nd,xa,Xt,Ga,Xe,Yd,Kd,Ma,Va,Fa,ha,Jd,ed,ze,sr,De,cr,ir,ad,dd,sl,Oe,ot,rd,Kt,fr,ld,vr,od,sa,cl,Tr,we,_r,nd,Er,il,se,hd,fl,ur,ca,pr,sd,cd,vl,vt,_t,id,Tl,Dr,fd,be,br,mr,yr,ia,Hr,_l,fa,vd,El,Wa,Td,$r,Sr,gr,me,Jt,va,ul,Rr,pt,_d,Ed,Cr,wr,za,ud,Ar,pl,pd,Dd,ye,kr,Ir,Ne,Qr,jr,xo,ue,qd,ao,Go,Xr,ro,lo,te,oo,no,tl,ho,Mo,el,al,so,co,io,fo,dl,rl,Vo,pe,Ud,vo,To,ll,Fo,ol,Zd,_o,Wo,ee,nl,Eo,uo;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=n("A"),f=l(),T=a("tbody"),J=a("tr"),G=a("td"),rt=n("Ant-Man"),ct=l(),A=a("tr"),it=a("td"),X=n("Aquaman"),g=l(),D=a("tr"),V=a("td"),v=n("Asterix"),b=l(),k=a("tr"),tt=a("td"),Et=n("The Atom"),q=l(),p=a("tr"),P=a("td"),u=n("The Avengers"),I=l(),ft=a("thead"),H=a("tr"),lt=a("th"),At=n("B"),Tt=l(),L=a("tbody"),Dt=a("tr"),bt=a("td"),et=n("Batgirl"),kt=l(),mt=a("tr"),W=a("td"),It=n("Batman"),Bt=l(),S=a("tr"),z=a("td"),Pt=n("Batwoman"),Wt=l(),N=a("tr"),F=a("td"),Lt=n("Black Canary"),Z=l(),ut=a("tr"),yt=a("td"),R=n("Black Panther"),Q=l(),Y=a("thead"),st=a("tr"),dt=a("th"),qt=n("C"),B=l(),at=a("tbody"),$t=a("tr"),Mt=a("td"),M=n("Captain America"),x=l(),Ut=a("tr"),Ht=a("td"),Vt=n("Captain Marvel"),re=l(),C=a("tr"),O=a("td"),Zt=n("Catwoman"),Qt=l(),St=a("tr"),w=a("td"),jt=n("Conan the Barbarian"),le=l(),gt=a("thead"),K=a("tr"),Da=a("th"),ba=n("D"),Kr=l(),Te=a("tbody"),Je=a("tr"),ea=a("td"),Rd=n("Daredevil"),Cd=l(),oe=a("tr"),qe=a("td"),ma=n("The Defenders"),wd=l(),ya=a("tr"),xt=a("td"),Be=n("Doc Savage"),aa=l(),da=a("tr"),Pe=a("td"),hr=n("Doctor Strange"),Jr=l(),Ce=a("thead"),Le=a("tr"),Ad=a("th"),kd=n("E"),Rt=l(),Ha=a("tbody"),$a=a("tr"),xe=a("td"),Id=n("Elektra"),Bd=l(),Pd=a("thead"),Ge=a("tr"),Sa=a("th"),qr=n("F"),ga=l(),zt=a("tbody"),Ra=a("tr"),Ue=a("td"),Xa=n("Fantastic Four"),Ld=l(),Ca=a("thead"),ne=a("tr"),Ze=a("th"),wa=n("G"),xd=l(),_e=a("tbody"),Qe=a("tr"),Me=a("td"),ra=n("Ghost Rider"),Ct=l(),Ve=a("tr"),td=a("td"),Ur=n("Green Arrow"),je=l(),Fe=a("tr"),Gd=a("td"),Md=n("Green Lantern"),Ft=l(),Aa=a("tr"),ka=a("td"),la=n("Guardians of the Galaxy"),Vd=l(),Ia=a("thead"),Fd=a("tr"),We=a("th"),Wd=n("H"),Zr=l(),Ee=a("tbody"),Ba=a("tr"),zd=a("td"),Pa=n("Hawkeye"),oa=l(),Od=a("tr"),La=a("td"),Gt=n("Hellboy"),he=l(),na=a("tr"),Nd=a("td"),xa=n("Incredible Hulk"),Xt=l(),Ga=a("thead"),Xe=a("tr"),Yd=a("th"),Kd=n("I"),Ma=l(),Va=a("tbody"),Fa=a("tr"),ha=a("td"),Jd=n("Iron Fist"),ed=l(),ze=a("tr"),sr=a("td"),De=n("Iron Man"),cr=l(),ir=a("thead"),ad=a("tr"),dd=a("th"),sl=n("M"),Oe=l(),ot=a("tbody"),rd=a("tr"),Kt=a("td"),fr=n("Marvelman"),ld=l(),vr=a("thead"),od=a("tr"),sa=a("th"),cl=n("R"),Tr=l(),we=a("tbody"),_r=a("tr"),nd=a("td"),Er=n("Robin"),il=l(),se=a("tr"),hd=a("td"),fl=n("The Rocketeer"),ur=l(),ca=a("thead"),pr=a("tr"),sd=a("th"),cd=n("S"),vl=l(),vt=a("tbody"),_t=a("tr"),id=a("td"),Tl=n("The Shadow"),Dr=l(),fd=a("tr"),be=a("td"),br=n("Spider-Man"),mr=l(),yr=a("tr"),ia=a("td"),Hr=n("Sub-Mariner"),_l=l(),fa=a("tr"),vd=a("td"),El=n("Supergirl"),Wa=l(),Td=a("tr"),$r=a("td"),Sr=n("Superman"),gr=l(),me=a("thead"),Jt=a("tr"),va=a("th"),ul=n("T"),Rr=l(),pt=a("tbody"),_d=a("tr"),Ed=a("td"),Cr=n("Teenage Mutant Ninja Turtles"),wr=l(),za=a("tr"),ud=a("td"),Ar=n("Thor"),pl=l(),pd=a("thead"),Dd=a("tr"),ye=a("th"),kr=n("W"),Ir=l(),Ne=a("tbody"),Qr=a("tr"),jr=a("td"),xo=n("The Wasp"),ue=l(),qd=a("tr"),ao=a("td"),Go=n("Watchmen"),Xr=l(),ro=a("tr"),lo=a("td"),te=n("Wolverine"),oo=l(),no=a("tr"),tl=a("td"),ho=n("Wonder Woman"),Mo=l(),el=a("thead"),al=a("tr"),so=a("th"),co=n("X"),io=l(),fo=a("tbody"),dl=a("tr"),rl=a("td"),Vo=n("X-Men"),pe=l(),Ud=a("thead"),vo=a("tr"),To=a("th"),ll=n("Z"),Fo=l(),ol=a("tbody"),Zd=a("tr"),_o=a("td"),Wo=n("Zatanna"),ee=l(),nl=a("tr"),Eo=a("td"),uo=n("Zatara"),this.h()},l(hl){c=d(hl,"DIV",{class:!0});var po=r(c);s=d(po,"TABLE",{class:!0});var m=r(s);E=d(m,"THEAD",{});var Do=r(E);i=d(Do,"TR",{});var Qo=r(i);_=d(Qo,"TH",{});var bo=r(_);$=h(bo,"A"),bo.forEach(e),Qo.forEach(e),Do.forEach(e),f=o(m),T=d(m,"TBODY",{});var Ta=r(T);J=d(Ta,"TR",{});var jo=r(J);G=d(jo,"TD",{});var He=r(G);rt=h(He,"Ant-Man"),He.forEach(e),jo.forEach(e),ct=o(Ta),A=d(Ta,"TR",{});var Dl=r(A);it=d(Dl,"TD",{});var Xo=r(it);X=h(Xo,"Aquaman"),Xo.forEach(e),Dl.forEach(e),g=o(Ta),D=d(Ta,"TR",{});var tn=r(D);V=d(tn,"TD",{});var bl=r(V);v=h(bl,"Asterix"),bl.forEach(e),tn.forEach(e),b=o(Ta),k=d(Ta,"TR",{});var en=r(k);tt=d(en,"TD",{});var an=r(tt);Et=h(an,"The Atom"),an.forEach(e),en.forEach(e),q=o(Ta),p=d(Ta,"TR",{});var ml=r(p);P=d(ml,"TD",{});var dn=r(P);u=h(dn,"The Avengers"),dn.forEach(e),ml.forEach(e),Ta.forEach(e),I=o(m),ft=d(m,"THEAD",{});var rn=r(ft);H=d(rn,"TR",{});var yl=r(H);lt=d(yl,"TH",{});var ln=r(lt);At=h(ln,"B"),ln.forEach(e),yl.forEach(e),rn.forEach(e),Tt=o(m),L=d(m,"TBODY",{});var bd=r(L);Dt=d(bd,"TR",{});var ae=r(Dt);bt=d(ae,"TD",{});var mo=r(bt);et=h(mo,"Batgirl"),mo.forEach(e),ae.forEach(e),kt=o(bd),mt=d(bd,"TR",{});var on=r(mt);W=d(on,"TD",{});var yo=r(W);It=h(yo,"Batman"),yo.forEach(e),on.forEach(e),Bt=o(bd),S=d(bd,"TR",{});var Ho=r(S);z=d(Ho,"TD",{});var nn=r(z);Pt=h(nn,"Batwoman"),nn.forEach(e),Ho.forEach(e),Wt=o(bd),N=d(bd,"TR",{});var $o=r(N);F=d($o,"TD",{});var So=r(F);Lt=h(So,"Black Canary"),So.forEach(e),$o.forEach(e),Z=o(bd),ut=d(bd,"TR",{});var hn=r(ut);yt=d(hn,"TD",{});var $e=r(yt);R=h($e,"Black Panther"),$e.forEach(e),hn.forEach(e),bd.forEach(e),Q=o(m),Y=d(m,"THEAD",{});var Hl=r(Y);st=d(Hl,"TR",{});var sn=r(st);dt=d(sn,"TH",{});var cn=r(dt);qt=h(cn,"C"),cn.forEach(e),sn.forEach(e),Hl.forEach(e),B=o(m),at=d(m,"TBODY",{});var _a=r(at);$t=d(_a,"TR",{});var fn=r($t);Mt=d(fn,"TD",{});var vn=r(Mt);M=h(vn,"Captain America"),vn.forEach(e),fn.forEach(e),x=o(_a),Ut=d(_a,"TR",{});var $l=r(Ut);Ht=d($l,"TD",{});var Tn=r(Ht);Vt=h(Tn,"Captain Marvel"),Tn.forEach(e),$l.forEach(e),re=o(_a),C=d(_a,"TR",{});var _n=r(C);O=d(_n,"TD",{});var Sl=r(O);Zt=h(Sl,"Catwoman"),Sl.forEach(e),_n.forEach(e),Qt=o(_a),St=d(_a,"TR",{});var En=r(St);w=d(En,"TD",{});var un=r(w);jt=h(un,"Conan the Barbarian"),un.forEach(e),En.forEach(e),_a.forEach(e),le=o(m),gt=d(m,"THEAD",{});var gl=r(gt);K=d(gl,"TR",{});var pn=r(K);Da=d(pn,"TH",{});var Dn=r(Da);ba=h(Dn,"D"),Dn.forEach(e),pn.forEach(e),gl.forEach(e),Kr=o(m),Te=d(m,"TBODY",{});var wt=r(Te);Je=d(wt,"TR",{});var go=r(Je);ea=d(go,"TD",{});var bn=r(ea);Rd=h(bn,"Daredevil"),bn.forEach(e),go.forEach(e),Cd=o(wt),oe=d(wt,"TR",{});var Ro=r(oe);qe=d(Ro,"TD",{});var Co=r(qe);ma=h(Co,"The Defenders"),Co.forEach(e),Ro.forEach(e),wd=o(wt),ya=d(wt,"TR",{});var mn=r(ya);xt=d(mn,"TD",{});var Se=r(xt);Be=h(Se,"Doc Savage"),Se.forEach(e),mn.forEach(e),aa=o(wt),da=d(wt,"TR",{});var Rl=r(da);Pe=d(Rl,"TD",{});var yn=r(Pe);hr=h(yn,"Doctor Strange"),yn.forEach(e),Rl.forEach(e),wt.forEach(e),Jr=o(m),Ce=d(m,"THEAD",{});var Hn=r(Ce);Le=d(Hn,"TR",{});var Cl=r(Le);Ad=d(Cl,"TH",{});var $n=r(Ad);kd=h($n,"E"),$n.forEach(e),Cl.forEach(e),Hn.forEach(e),Rt=o(m),Ha=d(m,"TBODY",{});var Sn=r(Ha);$a=d(Sn,"TR",{});var wl=r($a);xe=d(wl,"TD",{});var gn=r(xe);Id=h(gn,"Elektra"),gn.forEach(e),wl.forEach(e),Sn.forEach(e),Bd=o(m),Pd=d(m,"THEAD",{});var Rn=r(Pd);Ge=d(Rn,"TR",{});var Al=r(Ge);Sa=d(Al,"TH",{});var Cn=r(Sa);qr=h(Cn,"F"),Cn.forEach(e),Al.forEach(e),Rn.forEach(e),ga=o(m),zt=d(m,"TBODY",{});var wn=r(zt);Ra=d(wn,"TR",{});var kl=r(Ra);Ue=d(kl,"TD",{});var An=r(Ue);Xa=h(An,"Fantastic Four"),An.forEach(e),kl.forEach(e),wn.forEach(e),Ld=o(m),Ca=d(m,"THEAD",{});var kn=r(Ca);ne=d(kn,"TR",{});var Il=r(ne);Ze=d(Il,"TH",{});var In=r(Ze);wa=h(In,"G"),In.forEach(e),Il.forEach(e),kn.forEach(e),xd=o(m),_e=d(m,"TBODY",{});var Br=r(_e);Qe=d(Br,"TR",{});var de=r(Qe);Me=d(de,"TD",{});var wo=r(Me);ra=h(wo,"Ghost Rider"),wo.forEach(e),de.forEach(e),Ct=o(Br),Ve=d(Br,"TR",{});var Bn=r(Ve);td=d(Bn,"TD",{});var ge=r(td);Ur=h(ge,"Green Arrow"),ge.forEach(e),Bn.forEach(e),je=o(Br),Fe=d(Br,"TR",{});var Bl=r(Fe);Gd=d(Bl,"TD",{});var Pn=r(Gd);Md=h(Pn,"Green Lantern"),Pn.forEach(e),Bl.forEach(e),Ft=o(Br),Aa=d(Br,"TR",{});var Ln=r(Aa);ka=d(Ln,"TD",{});var Pl=r(ka);la=h(Pl,"Guardians of the Galaxy"),Pl.forEach(e),Ln.forEach(e),Br.forEach(e),Vd=o(m),Ia=d(m,"THEAD",{});var xn=r(Ia);Fd=d(xn,"TR",{});var Gn=r(Fd);We=d(Gn,"TH",{});var Ll=r(We);Wd=h(Ll,"H"),Ll.forEach(e),Gn.forEach(e),xn.forEach(e),Zr=o(m),Ee=d(m,"TBODY",{});var xl=r(Ee);Ba=d(xl,"TR",{});var Mn=r(Ba);zd=d(Mn,"TD",{});var Gl=r(zd);Pa=h(Gl,"Hawkeye"),Gl.forEach(e),Mn.forEach(e),oa=o(xl),Od=d(xl,"TR",{});var Vn=r(Od);La=d(Vn,"TD",{});var Fn=r(La);Gt=h(Fn,"Hellboy"),Fn.forEach(e),Vn.forEach(e),he=o(xl),na=d(xl,"TR",{});var Ml=r(na);Nd=d(Ml,"TD",{});var Wn=r(Nd);xa=h(Wn,"Incredible Hulk"),Wn.forEach(e),Ml.forEach(e),xl.forEach(e),Xt=o(m),Ga=d(m,"THEAD",{});var zn=r(Ga);Xe=d(zn,"TR",{});var Vl=r(Xe);Yd=d(Vl,"TH",{});var On=r(Yd);Kd=h(On,"I"),On.forEach(e),Vl.forEach(e),zn.forEach(e),Ma=o(m),Va=d(m,"TBODY",{});var Ao=r(Va);Fa=d(Ao,"TR",{});var Fl=r(Fa);ha=d(Fl,"TD",{});var Nn=r(ha);Jd=h(Nn,"Iron Fist"),Nn.forEach(e),Fl.forEach(e),ed=o(Ao),ze=d(Ao,"TR",{});var Yn=r(ze);sr=d(Yn,"TD",{});var nt=r(sr);De=h(nt,"Iron Man"),nt.forEach(e),Yn.forEach(e),Ao.forEach(e),cr=o(m),ir=d(m,"THEAD",{});var Wl=r(ir);ad=d(Wl,"TR",{});var Kn=r(ad);dd=d(Kn,"TH",{});var Jn=r(dd);sl=h(Jn,"M"),Jn.forEach(e),Kn.forEach(e),Wl.forEach(e),Oe=o(m),ot=d(m,"TBODY",{});var zl=r(ot);rd=d(zl,"TR",{});var qn=r(rd);Kt=d(qn,"TD",{});var Un=r(Kt);fr=h(Un,"Marvelman"),Un.forEach(e),qn.forEach(e),zl.forEach(e),ld=o(m),vr=d(m,"THEAD",{});var Ol=r(vr);od=d(Ol,"TR",{});var Zn=r(od);sa=d(Zn,"TH",{});var Qn=r(sa);cl=h(Qn,"R"),Qn.forEach(e),Zn.forEach(e),Ol.forEach(e),Tr=o(m),we=d(m,"TBODY",{});var Pr=r(we);_r=d(Pr,"TR",{});var jn=r(_r);nd=d(jn,"TD",{});var Xn=r(nd);Er=h(Xn,"Robin"),Xn.forEach(e),jn.forEach(e),il=o(Pr),se=d(Pr,"TR",{});var Nl=r(se);hd=d(Nl,"TD",{});var th=r(hd);fl=h(th,"The Rocketeer"),th.forEach(e),Nl.forEach(e),Pr.forEach(e),ur=o(m),ca=d(m,"THEAD",{});var eh=r(ca);pr=d(eh,"TR",{});var Yl=r(pr);sd=d(Yl,"TH",{});var ah=r(sd);cd=h(ah,"S"),ah.forEach(e),Yl.forEach(e),eh.forEach(e),vl=o(m),vt=d(m,"TBODY",{});var md=r(vt);_t=d(md,"TR",{});var Kl=r(_t);id=d(Kl,"TD",{});var dh=r(id);Tl=h(dh,"The Shadow"),dh.forEach(e),Kl.forEach(e),Dr=o(md),fd=d(md,"TR",{});var rh=r(fd);be=d(rh,"TD",{});var ce=r(be);br=h(ce,"Spider-Man"),ce.forEach(e),rh.forEach(e),mr=o(md),yr=d(md,"TR",{});var ko=r(yr);ia=d(ko,"TD",{});var lh=r(ia);Hr=h(lh,"Sub-Mariner"),lh.forEach(e),ko.forEach(e),_l=o(md),fa=d(md,"TR",{});var ie=r(fa);vd=d(ie,"TD",{});var Jl=r(vd);El=h(Jl,"Supergirl"),Jl.forEach(e),ie.forEach(e),Wa=o(md),Td=d(md,"TR",{});var oh=r(Td);$r=d(oh,"TD",{});var nh=r($r);Sr=h(nh,"Superman"),nh.forEach(e),oh.forEach(e),md.forEach(e),gr=o(m),me=d(m,"THEAD",{});var ql=r(me);Jt=d(ql,"TR",{});var hh=r(Jt);va=d(hh,"TH",{});var sh=r(va);ul=h(sh,"T"),sh.forEach(e),hh.forEach(e),ql.forEach(e),Rr=o(m),pt=d(m,"TBODY",{});var Lr=r(pt);_d=d(Lr,"TR",{});var ch=r(_d);Ed=d(ch,"TD",{});var ih=r(Ed);Cr=h(ih,"Teenage Mutant Ninja Turtles"),ih.forEach(e),ch.forEach(e),wr=o(Lr),za=d(Lr,"TR",{});var Ul=r(za);ud=d(Ul,"TD",{});var fh=r(ud);Ar=h(fh,"Thor"),fh.forEach(e),Ul.forEach(e),Lr.forEach(e),pl=o(m),pd=d(m,"THEAD",{});var vh=r(pd);Dd=d(vh,"TR",{});var Zl=r(Dd);ye=d(Zl,"TH",{});var Th=r(ye);kr=h(Th,"W"),Th.forEach(e),Zl.forEach(e),vh.forEach(e),Ir=o(m),Ne=d(m,"TBODY",{});var xr=r(Ne);Qr=d(xr,"TR",{});var Ql=r(Qr);jr=d(Ql,"TD",{});var _h=r(jr);xo=h(_h,"The Wasp"),_h.forEach(e),Ql.forEach(e),ue=o(xr),qd=d(xr,"TR",{});var Eh=r(qd);ao=d(Eh,"TD",{});var fe=r(ao);Go=h(fe,"Watchmen"),fe.forEach(e),Eh.forEach(e),Xr=o(xr),ro=d(xr,"TR",{});var Io=r(ro);lo=d(Io,"TD",{});var uh=r(lo);te=h(uh,"Wolverine"),uh.forEach(e),Io.forEach(e),oo=o(xr),no=d(xr,"TR",{});var Bo=r(no);tl=d(Bo,"TD",{});var Po=r(tl);ho=h(Po,"Wonder Woman"),Po.forEach(e),Bo.forEach(e),xr.forEach(e),Mo=o(m),el=d(m,"THEAD",{});var ph=r(el);al=d(ph,"TR",{});var ve=r(al);so=d(ve,"TH",{});var jl=r(so);co=h(jl,"X"),jl.forEach(e),ve.forEach(e),ph.forEach(e),io=o(m),fo=d(m,"TBODY",{});var Dh=r(fo);dl=d(Dh,"TR",{});var bh=r(dl);rl=d(bh,"TD",{});var Xl=r(rl);Vo=h(Xl,"X-Men"),Xl.forEach(e),bh.forEach(e),Dh.forEach(e),pe=o(m),Ud=d(m,"THEAD",{});var mh=r(Ud);vo=d(mh,"TR",{});var yh=r(vo);To=d(yh,"TH",{});var to=r(To);ll=h(to,"Z"),to.forEach(e),yh.forEach(e),mh.forEach(e),Fo=o(m),ol=d(m,"TBODY",{});var Lo=r(ol);Zd=d(Lo,"TR",{});var Hh=r(Zd);_o=d(Hh,"TD",{});var eo=r(_o);Wo=h(eo,"Zatanna"),eo.forEach(e),Hh.forEach(e),ee=o(Lo),nl=d(Lo,"TR",{});var $h=r(nl);Eo=d($h,"TD",{});var Sh=r(Eo);uo=h(Sh,"Zatara"),Sh.forEach(e),$h.forEach(e),Lo.forEach(e),m.forEach(e),po.forEach(e),this.h()},h(){y(s,"class","table table-pin-rows"),y(c,"class","overflow-x-auto h-96")},m(hl,po){Re(hl,c,po),t(c,s),t(s,E),t(E,i),t(i,_),t(_,$),t(s,f),t(s,T),t(T,J),t(J,G),t(G,rt),t(T,ct),t(T,A),t(A,it),t(it,X),t(T,g),t(T,D),t(D,V),t(V,v),t(T,b),t(T,k),t(k,tt),t(tt,Et),t(T,q),t(T,p),t(p,P),t(P,u),t(s,I),t(s,ft),t(ft,H),t(H,lt),t(lt,At),t(s,Tt),t(s,L),t(L,Dt),t(Dt,bt),t(bt,et),t(L,kt),t(L,mt),t(mt,W),t(W,It),t(L,Bt),t(L,S),t(S,z),t(z,Pt),t(L,Wt),t(L,N),t(N,F),t(F,Lt),t(L,Z),t(L,ut),t(ut,yt),t(yt,R),t(s,Q),t(s,Y),t(Y,st),t(st,dt),t(dt,qt),t(s,B),t(s,at),t(at,$t),t($t,Mt),t(Mt,M),t(at,x),t(at,Ut),t(Ut,Ht),t(Ht,Vt),t(at,re),t(at,C),t(C,O),t(O,Zt),t(at,Qt),t(at,St),t(St,w),t(w,jt),t(s,le),t(s,gt),t(gt,K),t(K,Da),t(Da,ba),t(s,Kr),t(s,Te),t(Te,Je),t(Je,ea),t(ea,Rd),t(Te,Cd),t(Te,oe),t(oe,qe),t(qe,ma),t(Te,wd),t(Te,ya),t(ya,xt),t(xt,Be),t(Te,aa),t(Te,da),t(da,Pe),t(Pe,hr),t(s,Jr),t(s,Ce),t(Ce,Le),t(Le,Ad),t(Ad,kd),t(s,Rt),t(s,Ha),t(Ha,$a),t($a,xe),t(xe,Id),t(s,Bd),t(s,Pd),t(Pd,Ge),t(Ge,Sa),t(Sa,qr),t(s,ga),t(s,zt),t(zt,Ra),t(Ra,Ue),t(Ue,Xa),t(s,Ld),t(s,Ca),t(Ca,ne),t(ne,Ze),t(Ze,wa),t(s,xd),t(s,_e),t(_e,Qe),t(Qe,Me),t(Me,ra),t(_e,Ct),t(_e,Ve),t(Ve,td),t(td,Ur),t(_e,je),t(_e,Fe),t(Fe,Gd),t(Gd,Md),t(_e,Ft),t(_e,Aa),t(Aa,ka),t(ka,la),t(s,Vd),t(s,Ia),t(Ia,Fd),t(Fd,We),t(We,Wd),t(s,Zr),t(s,Ee),t(Ee,Ba),t(Ba,zd),t(zd,Pa),t(Ee,oa),t(Ee,Od),t(Od,La),t(La,Gt),t(Ee,he),t(Ee,na),t(na,Nd),t(Nd,xa),t(s,Xt),t(s,Ga),t(Ga,Xe),t(Xe,Yd),t(Yd,Kd),t(s,Ma),t(s,Va),t(Va,Fa),t(Fa,ha),t(ha,Jd),t(Va,ed),t(Va,ze),t(ze,sr),t(sr,De),t(s,cr),t(s,ir),t(ir,ad),t(ad,dd),t(dd,sl),t(s,Oe),t(s,ot),t(ot,rd),t(rd,Kt),t(Kt,fr),t(s,ld),t(s,vr),t(vr,od),t(od,sa),t(sa,cl),t(s,Tr),t(s,we),t(we,_r),t(_r,nd),t(nd,Er),t(we,il),t(we,se),t(se,hd),t(hd,fl),t(s,ur),t(s,ca),t(ca,pr),t(pr,sd),t(sd,cd),t(s,vl),t(s,vt),t(vt,_t),t(_t,id),t(id,Tl),t(vt,Dr),t(vt,fd),t(fd,be),t(be,br),t(vt,mr),t(vt,yr),t(yr,ia),t(ia,Hr),t(vt,_l),t(vt,fa),t(fa,vd),t(vd,El),t(vt,Wa),t(vt,Td),t(Td,$r),t($r,Sr),t(s,gr),t(s,me),t(me,Jt),t(Jt,va),t(va,ul),t(s,Rr),t(s,pt),t(pt,_d),t(_d,Ed),t(Ed,Cr),t(pt,wr),t(pt,za),t(za,ud),t(ud,Ar),t(s,pl),t(s,pd),t(pd,Dd),t(Dd,ye),t(ye,kr),t(s,Ir),t(s,Ne),t(Ne,Qr),t(Qr,jr),t(jr,xo),t(Ne,ue),t(Ne,qd),t(qd,ao),t(ao,Go),t(Ne,Xr),t(Ne,ro),t(ro,lo),t(lo,te),t(Ne,oo),t(Ne,no),t(no,tl),t(tl,ho),t(s,Mo),t(s,el),t(el,al),t(al,so),t(so,co),t(s,io),t(s,fo),t(fo,dl),t(dl,rl),t(rl,Vo),t(s,pe),t(s,Ud),t(Ud,vo),t(vo,To),t(To,ll),t(s,Fo),t(s,ol),t(ol,Zd),t(Zd,_o),t(_o,Wo),t(ol,ee),t(ol,nl),t(nl,Eo),t(Eo,uo)},p:fs,d(hl){hl&&e(c)}}}function Yi(ht){let c,s=`<div class="overflow-x-auto h-96">
  <table class="$$table $$table-pin-rows">
  <thead>
    <tr>
      <th>A</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Ant-Man</td></tr>
    <tr><td>Aquaman</td></tr>
    <tr><td>Asterix</td></tr>
    <tr><td>The Atom</td></tr>
    <tr><td>The Avengers</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>B</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Batgirl</td></tr>
    <tr><td>Batman</td></tr>
    <tr><td>Batwoman</td></tr>
    <tr><td>Black Canary</td></tr>
    <tr><td>Black Panther</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>C</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Captain America</td></tr>
    <tr><td>Captain Marvel</td></tr>
    <tr><td>Catwoman</td></tr>
    <tr><td>Conan the Barbarian</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Daredevil</td></tr>
    <tr><td>The Defenders</td></tr>
    <tr><td>Doc Savage</td></tr>
    <tr><td>Doctor Strange</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Elektra</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Fantastic Four</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>G</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Ghost Rider</td></tr>
    <tr><td>Green Arrow</td></tr>
    <tr><td>Green Lantern</td></tr>
    <tr><td>Guardians of the Galaxy</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>H</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Hawkeye</td></tr>
    <tr><td>Hellboy</td></tr>
    <tr><td>Incredible Hulk</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>I</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Iron Fist</td></tr>
    <tr><td>Iron Man</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>M</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Marvelman</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>R</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Robin</td></tr>
    <tr><td>The Rocketeer</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>S</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>The Shadow</td></tr>
    <tr><td>Spider-Man</td></tr>
    <tr><td>Sub-Mariner</td></tr>
    <tr><td>Supergirl</td></tr>
    <tr><td>Superman</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>T</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Teenage Mutant Ninja Turtles</td></tr>
    <tr><td>Thor</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>W</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>The Wasp</td></tr>
    <tr><td>Watchmen</td></tr>
    <tr><td>Wolverine</td></tr>
    <tr><td>Wonder Woman</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>X</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>X-Men</td></tr>
  </tbody>
  <thead>
    <tr>
      <th>Z</th>
    </tr>
  </thead>
  <tbody>
    <tr><td>Zatanna</td></tr>
    <tr><td>Zatara</td></tr>
  </tbody>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function Ki(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V,v,b,k,tt,Et,q,p,P,u,I,ft,H,lt,At,Tt,L,Dt,bt,et,kt,mt,W,It,Bt,S,z,Pt,Wt,N,F,Lt,Z,ut,yt,R,Q,Y,st,dt,qt,B,at,$t,Mt,M,x,Ut,Ht,Vt,re,C,O,Zt,Qt,St,w,jt,le,gt,K,Da,ba,Kr,Te,Je,ea,Rd,Cd,oe,qe,ma,wd,ya,xt,Be,aa,da,Pe,hr,Jr,Ce,Le,Ad,kd,Rt,Ha,$a,xe,Id,Bd,Pd,Ge,Sa,qr,ga,zt,Ra,Ue,Xa,Ld,Ca,ne,Ze,wa,xd,_e,Qe,Me,ra,Ct,Ve,td,Ur,je,Fe,Gd,Md,Ft,Aa,ka,la,Vd,Ia,Fd,We,Wd,Zr,Ee,Ba,zd,Pa,oa,Od,La,Gt,he,na,Nd,xa,Xt,Ga,Xe,Yd,Kd,Ma,Va,Fa,ha,Jd,ed,ze,sr,De,cr,ir,ad,dd,sl,Oe,ot,rd,Kt,fr,ld,vr,od,sa,cl,Tr,we,_r,nd,Er,il,se,hd,fl,ur,ca,pr,sd,cd,vl,vt,_t,id,Tl,Dr,fd,be,br,mr,yr,ia,Hr,_l,fa,vd,El,Wa,Td,$r,Sr,gr,me,Jt,va,ul,Rr,pt,_d,Ed,Cr,wr,za,ud,Ar,pl,pd,Dd,ye,kr,Ir,Ne,Qr,jr,xo,ue,qd,ao,Go,Xr,ro,lo,te,oo,no,tl,ho,Mo,el,al,so,co,io,fo,dl,rl,Vo,pe,Ud,vo,To,ll,Fo,ol,Zd,_o,Wo,ee,nl,Eo,uo,hl,po,m,Do,Qo,bo,Ta,jo,He,Dl,Xo,tn,bl,en,an,ml,dn,rn,yl,ln,bd,ae,mo,on,yo,Ho,nn,$o,So,hn,$e,Hl,sn,cn,_a,fn,vn,$l,Tn,_n,Sl,En,un,gl,pn,Dn,wt,go,bn,Ro,Co,mn,Se,Rl,yn,Hn,Cl,$n,Sn,wl,gn,Rn,Al,Cn,wn,kl,An,kn,Il,In,Br,de,wo,Bn,ge,Bl,Pn,Ln,Pl,xn,Gn,Ll,xl,Mn,Gl,Vn,Fn,Ml,Wn,zn,Vl,On,Ao,Fl,Nn,Yn,nt,Wl,Kn,Jn,zl,qn,Un,Ol,Zn,Qn,Pr,jn,Xn,Nl,th,eh,Yl,ah,md,Kl,dh,rh,ce,ko,lh,ie,Jl,oh,nh,ql,hh,sh,Lr,ch,ih,Ul,fh,vh,Zl,Th,xr,Ql,_h,Eh,fe,Io,uh,Bo,Po,ph,ve,jl,Dh,bh,Xl,mh,yh,to,Lo,Hh,eo,$h,Sh,zo,Es,us,Ae,Ph,ps,Lh,xh,Ds,Gh,Mh,bs,ke,Oo,ms,ys,No,Hs,$s,Yo,Ss,gs,Ko,Rs,Cs,Jo,ta,Jh,Vh,Fh,ws,Wh,zh,As,Oh,Nh,ks,Ie,qo,Is,Bs,Uo,Ps,Ls,Zo,xs,Yh,gh,Rh,Fs,Ea,Ws,zs,qh,Os,Ns,Uh,U,yd,Zh,Ys,Ks,Ye,Qh,Js,qs,ua,Us,Zs,jh,Qs,js,Xh,Xs,Hd,ts,tc,ec,es,ac,dc,as,$d,rc,ds,lc,oc,rs,Ke,Gs,Sd,ls,nc,hc,os,sc,cc,ns,gd,ic,hs,fc,vc,ss,Tc,_c,pa,Ec,uc,Ms;return{c(){c=a("div"),s=a("table"),E=a("thead"),i=a("tr"),_=a("th"),$=l(),f=a("td"),T=n("Name"),J=l(),G=a("td"),rt=n("Job"),ct=l(),A=a("td"),it=n("company"),X=l(),g=a("td"),D=n("location"),V=l(),v=a("td"),b=n("Last Login"),k=l(),tt=a("td"),Et=n("Favorite Color"),q=l(),p=a("th"),P=l(),u=a("tbody"),I=a("tr"),ft=a("th"),H=n("1"),lt=l(),At=a("td"),Tt=n("Cy Ganderton"),L=l(),Dt=a("td"),bt=n("Quality Control Specialist"),et=l(),kt=a("td"),mt=n("Littel, Schaden and Vandervort"),W=l(),It=a("td"),Bt=n("Canada"),S=l(),z=a("td"),Pt=n("12/16/2020"),Wt=l(),N=a("td"),F=n("Blue"),Lt=l(),Z=a("th"),ut=n("1"),yt=l(),R=a("tr"),Q=a("th"),Y=n("2"),st=l(),dt=a("td"),qt=n("Hart Hagerty"),B=l(),at=a("td"),$t=n("Desktop Support Technician"),Mt=l(),M=a("td"),x=n("Zemlak, Daniel and Leannon"),Ut=l(),Ht=a("td"),Vt=n("United States"),re=l(),C=a("td"),O=n("12/5/2020"),Zt=l(),Qt=a("td"),St=n("Purple"),w=l(),jt=a("th"),le=n("2"),gt=l(),K=a("tr"),Da=a("th"),ba=n("3"),Kr=l(),Te=a("td"),Je=n("Brice Swyre"),ea=l(),Rd=a("td"),Cd=n("Tax Accountant"),oe=l(),qe=a("td"),ma=n("Carroll Group"),wd=l(),ya=a("td"),xt=n("China"),Be=l(),aa=a("td"),da=n("8/15/2020"),Pe=l(),hr=a("td"),Jr=n("Red"),Ce=l(),Le=a("th"),Ad=n("3"),kd=l(),Rt=a("tr"),Ha=a("th"),$a=n("4"),xe=l(),Id=a("td"),Bd=n("Marjy Ferencz"),Pd=l(),Ge=a("td"),Sa=n("Office Assistant I"),qr=l(),ga=a("td"),zt=n("Rowe-Schoen"),Ra=l(),Ue=a("td"),Xa=n("Russia"),Ld=l(),Ca=a("td"),ne=n("3/25/2021"),Ze=l(),wa=a("td"),xd=n("Crimson"),_e=l(),Qe=a("th"),Me=n("4"),ra=l(),Ct=a("tr"),Ve=a("th"),td=n("5"),Ur=l(),je=a("td"),Fe=n("Yancy Tear"),Gd=l(),Md=a("td"),Ft=n("Community Outreach Specialist"),Aa=l(),ka=a("td"),la=n("Wyman-Ledner"),Vd=l(),Ia=a("td"),Fd=n("Brazil"),We=l(),Wd=a("td"),Zr=n("5/22/2020"),Ee=l(),Ba=a("td"),zd=n("Indigo"),Pa=l(),oa=a("th"),Od=n("5"),La=l(),Gt=a("tr"),he=a("th"),na=n("6"),Nd=l(),xa=a("td"),Xt=n("Irma Vasilik"),Ga=l(),Xe=a("td"),Yd=n("Editor"),Kd=l(),Ma=a("td"),Va=n("Wiza, Bins and Emard"),Fa=l(),ha=a("td"),Jd=n("Venezuela"),ed=l(),ze=a("td"),sr=n("12/8/2020"),De=l(),cr=a("td"),ir=n("Purple"),ad=l(),dd=a("th"),sl=n("6"),Oe=l(),ot=a("tr"),rd=a("th"),Kt=n("7"),fr=l(),ld=a("td"),vr=n("Meghann Durtnal"),od=l(),sa=a("td"),cl=n("Staff Accountant IV"),Tr=l(),we=a("td"),_r=n("Schuster-Schimmel"),nd=l(),Er=a("td"),il=n("Philippines"),se=l(),hd=a("td"),fl=n("2/17/2021"),ur=l(),ca=a("td"),pr=n("Yellow"),sd=l(),cd=a("th"),vl=n("7"),vt=l(),_t=a("tr"),id=a("th"),Tl=n("8"),Dr=l(),fd=a("td"),be=n("Sammy Seston"),br=l(),mr=a("td"),yr=n("Accountant I"),ia=l(),Hr=a("td"),_l=n("O'Hara, Welch and Keebler"),fa=l(),vd=a("td"),El=n("Indonesia"),Wa=l(),Td=a("td"),$r=n("5/23/2020"),Sr=l(),gr=a("td"),me=n("Crimson"),Jt=l(),va=a("th"),ul=n("8"),Rr=l(),pt=a("tr"),_d=a("th"),Ed=n("9"),Cr=l(),wr=a("td"),za=n("Lesya Tinham"),ud=l(),Ar=a("td"),pl=n("Safety Technician IV"),pd=l(),Dd=a("td"),ye=n("Turner-Kuhlman"),kr=l(),Ir=a("td"),Ne=n("Philippines"),Qr=l(),jr=a("td"),xo=n("2/21/2021"),ue=l(),qd=a("td"),ao=n("Maroon"),Go=l(),Xr=a("th"),ro=n("9"),lo=l(),te=a("tr"),oo=a("th"),no=n("10"),tl=l(),ho=a("td"),Mo=n("Zaneta Tewkesbury"),el=l(),al=a("td"),so=n("VP Marketing"),co=l(),io=a("td"),fo=n("Sauer LLC"),dl=l(),rl=a("td"),Vo=n("Chad"),pe=l(),Ud=a("td"),vo=n("6/23/2020"),To=l(),ll=a("td"),Fo=n("Green"),ol=l(),Zd=a("th"),_o=n("10"),Wo=l(),ee=a("tr"),nl=a("th"),Eo=n("11"),uo=l(),hl=a("td"),po=n("Andy Tipple"),m=l(),Do=a("td"),Qo=n("Librarian"),bo=l(),Ta=a("td"),jo=n("Hilpert Group"),He=l(),Dl=a("td"),Xo=n("Poland"),tn=l(),bl=a("td"),en=n("7/9/2020"),an=l(),ml=a("td"),dn=n("Indigo"),rn=l(),yl=a("th"),ln=n("11"),bd=l(),ae=a("tr"),mo=a("th"),on=n("12"),yo=l(),Ho=a("td"),nn=n("Sophi Biles"),$o=l(),So=a("td"),hn=n("Recruiting Manager"),$e=l(),Hl=a("td"),sn=n("Gutmann Inc"),cn=l(),_a=a("td"),fn=n("Indonesia"),vn=l(),$l=a("td"),Tn=n("2/12/2021"),_n=l(),Sl=a("td"),En=n("Maroon"),un=l(),gl=a("th"),pn=n("12"),Dn=l(),wt=a("tr"),go=a("th"),bn=n("13"),Ro=l(),Co=a("td"),mn=n("Florida Garces"),Se=l(),Rl=a("td"),yn=n("Web Developer IV"),Hn=l(),Cl=a("td"),$n=n("Gaylord, Pacocha and Baumbach"),Sn=l(),wl=a("td"),gn=n("Poland"),Rn=l(),Al=a("td"),Cn=n("5/31/2020"),wn=l(),kl=a("td"),An=n("Purple"),kn=l(),Il=a("th"),In=n("13"),Br=l(),de=a("tr"),wo=a("th"),Bn=n("14"),ge=l(),Bl=a("td"),Pn=n("Maribeth Popping"),Ln=l(),Pl=a("td"),xn=n("Analyst Programmer"),Gn=l(),Ll=a("td"),xl=n("Deckow-Pouros"),Mn=l(),Gl=a("td"),Vn=n("Portugal"),Fn=l(),Ml=a("td"),Wn=n("4/27/2021"),zn=l(),Vl=a("td"),On=n("Aquamarine"),Ao=l(),Fl=a("th"),Nn=n("14"),Yn=l(),nt=a("tr"),Wl=a("th"),Kn=n("15"),Jn=l(),zl=a("td"),qn=n("Moritz Dryburgh"),Un=l(),Ol=a("td"),Zn=n("Dental Hygienist"),Qn=l(),Pr=a("td"),jn=n("Schiller, Cole and Hackett"),Xn=l(),Nl=a("td"),th=n("Sri Lanka"),eh=l(),Yl=a("td"),ah=n("8/8/2020"),md=l(),Kl=a("td"),dh=n("Crimson"),rh=l(),ce=a("th"),ko=n("15"),lh=l(),ie=a("tr"),Jl=a("th"),oh=n("16"),nh=l(),ql=a("td"),hh=n("Reid Semiras"),sh=l(),Lr=a("td"),ch=n("Teacher"),ih=l(),Ul=a("td"),fh=n("Sporer, Sipes and Rogahn"),vh=l(),Zl=a("td"),Th=n("Poland"),xr=l(),Ql=a("td"),_h=n("7/30/2020"),Eh=l(),fe=a("td"),Io=n("Green"),uh=l(),Bo=a("th"),Po=n("16"),ph=l(),ve=a("tr"),jl=a("th"),Dh=n("17"),bh=l(),Xl=a("td"),mh=n("Alec Lethby"),yh=l(),to=a("td"),Lo=n("Teacher"),Hh=l(),eo=a("td"),$h=n("Reichel, Glover and Hamill"),Sh=l(),zo=a("td"),Es=n("China"),us=l(),Ae=a("td"),Ph=n("2/28/2021"),ps=l(),Lh=a("td"),xh=n("Khaki"),Ds=l(),Gh=a("th"),Mh=n("17"),bs=l(),ke=a("tr"),Oo=a("th"),ms=n("18"),ys=l(),No=a("td"),Hs=n("Aland Wilber"),$s=l(),Yo=a("td"),Ss=n("Quality Control Specialist"),gs=l(),Ko=a("td"),Rs=n("Kshlerin, Rogahn and Swaniawski"),Cs=l(),Jo=a("td"),ta=n("Czech Republic"),Jh=l(),Vh=a("td"),Fh=n("9/29/2020"),ws=l(),Wh=a("td"),zh=n("Purple"),As=l(),Oh=a("th"),Nh=n("18"),ks=l(),Ie=a("tr"),qo=a("th"),Is=n("19"),Bs=l(),Uo=a("td"),Ps=n("Teddie Duerden"),Ls=l(),Zo=a("td"),xs=n("Staff Accountant III"),Yh=l(),gh=a("td"),Rh=n("Pouros, Ullrich and Windler"),Fs=l(),Ea=a("td"),Ws=n("France"),zs=l(),qh=a("td"),Os=n("10/27/2020"),Ns=l(),Uh=a("td"),U=n("Aquamarine"),yd=l(),Zh=a("th"),Ys=n("19"),Ks=l(),Ye=a("tr"),Qh=a("th"),Js=n("20"),qs=l(),ua=a("td"),Us=n("Lorelei Blackstone"),Zs=l(),jh=a("td"),Qs=n("Data Coordinator"),js=l(),Xh=a("td"),Xs=n("Witting, Kutch and Greenfelder"),Hd=l(),ts=a("td"),tc=n("Kazakhstan"),ec=l(),es=a("td"),ac=n("6/3/2020"),dc=l(),as=a("td"),$d=n("Red"),rc=l(),ds=a("th"),lc=n("20"),oc=l(),rs=a("tfoot"),Ke=a("tr"),Gs=a("th"),Sd=l(),ls=a("td"),nc=n("Name"),hc=l(),os=a("td"),sc=n("Job"),cc=l(),ns=a("td"),gd=n("company"),ic=l(),hs=a("td"),fc=n("location"),vc=l(),ss=a("td"),Tc=n("Last Login"),_c=l(),pa=a("td"),Ec=n("Favorite Color"),uc=l(),Ms=a("th"),this.h()},l(cs){c=d(cs,"DIV",{class:!0});var Vs=r(c);s=d(Vs,"TABLE",{class:!0});var Kh=r(s);E=d(Kh,"THEAD",{});var pc=r(E);i=d(pc,"TR",{});var Ot=r(i);_=d(Ot,"TH",{}),r(_).forEach(e),$=o(Ot),f=d(Ot,"TD",{});var Dc=r(f);T=h(Dc,"Name"),Dc.forEach(e),J=o(Ot),G=d(Ot,"TD",{});var bc=r(G);rt=h(bc,"Job"),bc.forEach(e),ct=o(Ot),A=d(Ot,"TD",{});var mc=r(A);it=h(mc,"company"),mc.forEach(e),X=o(Ot),g=d(Ot,"TD",{});var yc=r(g);D=h(yc,"location"),yc.forEach(e),V=o(Ot),v=d(Ot,"TD",{});var Hc=r(v);b=h(Hc,"Last Login"),Hc.forEach(e),k=o(Ot),tt=d(Ot,"TD",{});var $c=r(tt);Et=h($c,"Favorite Color"),$c.forEach(e),q=o(Ot),p=d(Ot,"TH",{}),r(p).forEach(e),Ot.forEach(e),pc.forEach(e),P=o(Kh),u=d(Kh,"TBODY",{});var j=r(u);I=d(j,"TR",{});var Nt=r(I);ft=d(Nt,"TH",{});var Sc=r(ft);H=h(Sc,"1"),Sc.forEach(e),lt=o(Nt),At=d(Nt,"TD",{});var gc=r(At);Tt=h(gc,"Cy Ganderton"),gc.forEach(e),L=o(Nt),Dt=d(Nt,"TD",{});var Rc=r(Dt);bt=h(Rc,"Quality Control Specialist"),Rc.forEach(e),et=o(Nt),kt=d(Nt,"TD",{});var Cc=r(kt);mt=h(Cc,"Littel, Schaden and Vandervort"),Cc.forEach(e),W=o(Nt),It=d(Nt,"TD",{});var wc=r(It);Bt=h(wc,"Canada"),wc.forEach(e),S=o(Nt),z=d(Nt,"TD",{});var Ac=r(z);Pt=h(Ac,"12/16/2020"),Ac.forEach(e),Wt=o(Nt),N=d(Nt,"TD",{});var kc=r(N);F=h(kc,"Blue"),kc.forEach(e),Lt=o(Nt),Z=d(Nt,"TH",{});var Qd=r(Z);ut=h(Qd,"1"),Qd.forEach(e),Nt.forEach(e),yt=o(j),R=d(j,"TR",{});var Oa=r(R);Q=d(Oa,"TH",{});var Ic=r(Q);Y=h(Ic,"2"),Ic.forEach(e),st=o(Oa),dt=d(Oa,"TD",{});var Bc=r(dt);qt=h(Bc,"Hart Hagerty"),Bc.forEach(e),B=o(Oa),at=d(Oa,"TD",{});var Pc=r(at);$t=h(Pc,"Desktop Support Technician"),Pc.forEach(e),Mt=o(Oa),M=d(Oa,"TD",{});var Lc=r(M);x=h(Lc,"Zemlak, Daniel and Leannon"),Lc.forEach(e),Ut=o(Oa),Ht=d(Oa,"TD",{});var xc=r(Ht);Vt=h(xc,"United States"),xc.forEach(e),re=o(Oa),C=d(Oa,"TD",{});var Gc=r(C);O=h(Gc,"12/5/2020"),Gc.forEach(e),Zt=o(Oa),Qt=d(Oa,"TD",{});var jd=r(Qt);St=h(jd,"Purple"),jd.forEach(e),w=o(Oa),jt=d(Oa,"TH",{});var Mc=r(jt);le=h(Mc,"2"),Mc.forEach(e),Oa.forEach(e),gt=o(j),K=d(j,"TR",{});var Na=r(K);Da=d(Na,"TH",{});var Vc=r(Da);ba=h(Vc,"3"),Vc.forEach(e),Kr=o(Na),Te=d(Na,"TD",{});var Fc=r(Te);Je=h(Fc,"Brice Swyre"),Fc.forEach(e),ea=o(Na),Rd=d(Na,"TD",{});var Wc=r(Rd);Cd=h(Wc,"Tax Accountant"),Wc.forEach(e),oe=o(Na),qe=d(Na,"TD",{});var zc=r(qe);ma=h(zc,"Carroll Group"),zc.forEach(e),wd=o(Na),ya=d(Na,"TD",{});var Oc=r(ya);xt=h(Oc,"China"),Oc.forEach(e),Be=o(Na),aa=d(Na,"TD",{});var Xd=r(aa);da=h(Xd,"8/15/2020"),Xd.forEach(e),Pe=o(Na),hr=d(Na,"TD",{});var Nc=r(hr);Jr=h(Nc,"Red"),Nc.forEach(e),Ce=o(Na),Le=d(Na,"TH",{});var Yc=r(Le);Ad=h(Yc,"3"),Yc.forEach(e),Na.forEach(e),kd=o(j),Rt=d(j,"TR",{});var Ya=r(Rt);Ha=d(Ya,"TH",{});var Kc=r(Ha);$a=h(Kc,"4"),Kc.forEach(e),xe=o(Ya),Id=d(Ya,"TD",{});var Jc=r(Id);Bd=h(Jc,"Marjy Ferencz"),Jc.forEach(e),Pd=o(Ya),Ge=d(Ya,"TD",{});var qc=r(Ge);Sa=h(qc,"Office Assistant I"),qc.forEach(e),qr=o(Ya),ga=d(Ya,"TD",{});var Uc=r(ga);zt=h(Uc,"Rowe-Schoen"),Uc.forEach(e),Ra=o(Ya),Ue=d(Ya,"TD",{});var tr=r(Ue);Xa=h(tr,"Russia"),tr.forEach(e),Ld=o(Ya),Ca=d(Ya,"TD",{});var Zc=r(Ca);ne=h(Zc,"3/25/2021"),Zc.forEach(e),Ze=o(Ya),wa=d(Ya,"TD",{});var Qc=r(wa);xd=h(Qc,"Crimson"),Qc.forEach(e),_e=o(Ya),Qe=d(Ya,"TH",{});var jc=r(Qe);Me=h(jc,"4"),jc.forEach(e),Ya.forEach(e),ra=o(j),Ct=d(j,"TR",{});var Ka=r(Ct);Ve=d(Ka,"TH",{});var Xc=r(Ve);td=h(Xc,"5"),Xc.forEach(e),Ur=o(Ka),je=d(Ka,"TD",{});var t1=r(je);Fe=h(t1,"Yancy Tear"),t1.forEach(e),Gd=o(Ka),Md=d(Ka,"TD",{});var e1=r(Md);Ft=h(e1,"Community Outreach Specialist"),e1.forEach(e),Aa=o(Ka),ka=d(Ka,"TD",{});var er=r(ka);la=h(er,"Wyman-Ledner"),er.forEach(e),Vd=o(Ka),Ia=d(Ka,"TD",{});var a1=r(Ia);Fd=h(a1,"Brazil"),a1.forEach(e),We=o(Ka),Wd=d(Ka,"TD",{});var d1=r(Wd);Zr=h(d1,"5/22/2020"),d1.forEach(e),Ee=o(Ka),Ba=d(Ka,"TD",{});var r1=r(Ba);zd=h(r1,"Indigo"),r1.forEach(e),Pa=o(Ka),oa=d(Ka,"TH",{});var l1=r(oa);Od=h(l1,"5"),l1.forEach(e),Ka.forEach(e),La=o(j),Gt=d(j,"TR",{});var Ja=r(Gt);he=d(Ja,"TH",{});var o1=r(he);na=h(o1,"6"),o1.forEach(e),Nd=o(Ja),xa=d(Ja,"TD",{});var n1=r(xa);Xt=h(n1,"Irma Vasilik"),n1.forEach(e),Ga=o(Ja),Xe=d(Ja,"TD",{});var ar=r(Xe);Yd=h(ar,"Editor"),ar.forEach(e),Kd=o(Ja),Ma=d(Ja,"TD",{});var h1=r(Ma);Va=h(h1,"Wiza, Bins and Emard"),h1.forEach(e),Fa=o(Ja),ha=d(Ja,"TD",{});var s1=r(ha);Jd=h(s1,"Venezuela"),s1.forEach(e),ed=o(Ja),ze=d(Ja,"TD",{});var c1=r(ze);sr=h(c1,"12/8/2020"),c1.forEach(e),De=o(Ja),cr=d(Ja,"TD",{});var i1=r(cr);ir=h(i1,"Purple"),i1.forEach(e),ad=o(Ja),dd=d(Ja,"TH",{});var f1=r(dd);sl=h(f1,"6"),f1.forEach(e),Ja.forEach(e),Oe=o(j),ot=d(j,"TR",{});var qa=r(ot);rd=d(qa,"TH",{});var v1=r(rd);Kt=h(v1,"7"),v1.forEach(e),fr=o(qa),ld=d(qa,"TD",{});var dr=r(ld);vr=h(dr,"Meghann Durtnal"),dr.forEach(e),od=o(qa),sa=d(qa,"TD",{});var T1=r(sa);cl=h(T1,"Staff Accountant IV"),T1.forEach(e),Tr=o(qa),we=d(qa,"TD",{});var _1=r(we);_r=h(_1,"Schuster-Schimmel"),_1.forEach(e),nd=o(qa),Er=d(qa,"TD",{});var E1=r(Er);il=h(E1,"Philippines"),E1.forEach(e),se=o(qa),hd=d(qa,"TD",{});var u1=r(hd);fl=h(u1,"2/17/2021"),u1.forEach(e),ur=o(qa),ca=d(qa,"TD",{});var p1=r(ca);pr=h(p1,"Yellow"),p1.forEach(e),sd=o(qa),cd=d(qa,"TH",{});var D1=r(cd);vl=h(D1,"7"),D1.forEach(e),qa.forEach(e),vt=o(j),_t=d(j,"TR",{});var Ua=r(_t);id=d(Ua,"TH",{});var rr=r(id);Tl=h(rr,"8"),rr.forEach(e),Dr=o(Ua),fd=d(Ua,"TD",{});var b1=r(fd);be=h(b1,"Sammy Seston"),b1.forEach(e),br=o(Ua),mr=d(Ua,"TD",{});var m1=r(mr);yr=h(m1,"Accountant I"),m1.forEach(e),ia=o(Ua),Hr=d(Ua,"TD",{});var y1=r(Hr);_l=h(y1,"O'Hara, Welch and Keebler"),y1.forEach(e),fa=o(Ua),vd=d(Ua,"TD",{});var H1=r(vd);El=h(H1,"Indonesia"),H1.forEach(e),Wa=o(Ua),Td=d(Ua,"TD",{});var $1=r(Td);$r=h($1,"5/23/2020"),$1.forEach(e),Sr=o(Ua),gr=d(Ua,"TD",{});var S1=r(gr);me=h(S1,"Crimson"),S1.forEach(e),Jt=o(Ua),va=d(Ua,"TH",{});var g1=r(va);ul=h(g1,"8"),g1.forEach(e),Ua.forEach(e),Rr=o(j),pt=d(j,"TR",{});var Yt=r(pt);_d=d(Yt,"TH",{});var R1=r(_d);Ed=h(R1,"9"),R1.forEach(e),Cr=o(Yt),wr=d(Yt,"TD",{});var C1=r(wr);za=h(C1,"Lesya Tinham"),C1.forEach(e),ud=o(Yt),Ar=d(Yt,"TD",{});var w1=r(Ar);pl=h(w1,"Safety Technician IV"),w1.forEach(e),pd=o(Yt),Dd=d(Yt,"TD",{});var A1=r(Dd);ye=h(A1,"Turner-Kuhlman"),A1.forEach(e),kr=o(Yt),Ir=d(Yt,"TD",{});var k1=r(Ir);Ne=h(k1,"Philippines"),k1.forEach(e),Qr=o(Yt),jr=d(Yt,"TD",{});var I1=r(jr);xo=h(I1,"2/21/2021"),I1.forEach(e),ue=o(Yt),qd=d(Yt,"TD",{});var B1=r(qd);ao=h(B1,"Maroon"),B1.forEach(e),Go=o(Yt),Xr=d(Yt,"TH",{});var lr=r(Xr);ro=h(lr,"9"),lr.forEach(e),Yt.forEach(e),lo=o(j),te=d(j,"TR",{});var Za=r(te);oo=d(Za,"TH",{});var P1=r(oo);no=h(P1,"10"),P1.forEach(e),tl=o(Za),ho=d(Za,"TD",{});var L1=r(ho);Mo=h(L1,"Zaneta Tewkesbury"),L1.forEach(e),el=o(Za),al=d(Za,"TD",{});var x1=r(al);so=h(x1,"VP Marketing"),x1.forEach(e),co=o(Za),io=d(Za,"TD",{});var G1=r(io);fo=h(G1,"Sauer LLC"),G1.forEach(e),dl=o(Za),rl=d(Za,"TD",{});var M1=r(rl);Vo=h(M1,"Chad"),M1.forEach(e),pe=o(Za),Ud=d(Za,"TD",{});var V1=r(Ud);vo=h(V1,"6/23/2020"),V1.forEach(e),To=o(Za),ll=d(Za,"TD",{});var or=r(ll);Fo=h(or,"Green"),or.forEach(e),ol=o(Za),Zd=d(Za,"TH",{});var F1=r(Zd);_o=h(F1,"10"),F1.forEach(e),Za.forEach(e),Wo=o(j),ee=d(j,"TR",{});var Qa=r(ee);nl=d(Qa,"TH",{});var W1=r(nl);Eo=h(W1,"11"),W1.forEach(e),uo=o(Qa),hl=d(Qa,"TD",{});var z1=r(hl);po=h(z1,"Andy Tipple"),z1.forEach(e),m=o(Qa),Do=d(Qa,"TD",{});var O1=r(Do);Qo=h(O1,"Librarian"),O1.forEach(e),bo=o(Qa),Ta=d(Qa,"TD",{});var N1=r(Ta);jo=h(N1,"Hilpert Group"),N1.forEach(e),He=o(Qa),Dl=d(Qa,"TD",{});var Y1=r(Dl);Xo=h(Y1,"Poland"),Y1.forEach(e),tn=o(Qa),bl=d(Qa,"TD",{});var K1=r(bl);en=h(K1,"7/9/2020"),K1.forEach(e),an=o(Qa),ml=d(Qa,"TD",{});var nr=r(ml);dn=h(nr,"Indigo"),nr.forEach(e),rn=o(Qa),yl=d(Qa,"TH",{});var J1=r(yl);ln=h(J1,"11"),J1.forEach(e),Qa.forEach(e),bd=o(j),ae=d(j,"TR",{});var ja=r(ae);mo=d(ja,"TH",{});var q1=r(mo);on=h(q1,"12"),q1.forEach(e),yo=o(ja),Ho=d(ja,"TD",{});var U1=r(Ho);nn=h(U1,"Sophi Biles"),U1.forEach(e),$o=o(ja),So=d(ja,"TD",{});var Z1=r(So);hn=h(Z1,"Recruiting Manager"),Z1.forEach(e),$e=o(ja),Hl=d(ja,"TD",{});var Q1=r(Hl);sn=h(Q1,"Gutmann Inc"),Q1.forEach(e),cn=o(ja),_a=d(ja,"TD",{});var t2=r(_a);fn=h(t2,"Indonesia"),t2.forEach(e),vn=o(ja),$l=d(ja,"TD",{});var e2=r($l);Tn=h(e2,"2/12/2021"),e2.forEach(e),_n=o(ja),Sl=d(ja,"TD",{});var a2=r(Sl);En=h(a2,"Maroon"),a2.forEach(e),un=o(ja),gl=d(ja,"TH",{});var d2=r(gl);pn=h(d2,"12"),d2.forEach(e),ja.forEach(e),Dn=o(j),wt=d(j,"TR",{});var Gr=r(wt);go=d(Gr,"TH",{});var r2=r(go);bn=h(r2,"13"),r2.forEach(e),Ro=o(Gr),Co=d(Gr,"TD",{});var l2=r(Co);mn=h(l2,"Florida Garces"),l2.forEach(e),Se=o(Gr),Rl=d(Gr,"TD",{});var o2=r(Rl);yn=h(o2,"Web Developer IV"),o2.forEach(e),Hn=o(Gr),Cl=d(Gr,"TD",{});var n2=r(Cl);$n=h(n2,"Gaylord, Pacocha and Baumbach"),n2.forEach(e),Sn=o(Gr),wl=d(Gr,"TD",{});var h2=r(wl);gn=h(h2,"Poland"),h2.forEach(e),Rn=o(Gr),Al=d(Gr,"TD",{});var s2=r(Al);Cn=h(s2,"5/31/2020"),s2.forEach(e),wn=o(Gr),kl=d(Gr,"TD",{});var c2=r(kl);An=h(c2,"Purple"),c2.forEach(e),kn=o(Gr),Il=d(Gr,"TH",{});var i2=r(Il);In=h(i2,"13"),i2.forEach(e),Gr.forEach(e),Br=o(j),de=d(j,"TR",{});var Mr=r(de);wo=d(Mr,"TH",{});var f2=r(wo);Bn=h(f2,"14"),f2.forEach(e),ge=o(Mr),Bl=d(Mr,"TD",{});var v2=r(Bl);Pn=h(v2,"Maribeth Popping"),v2.forEach(e),Ln=o(Mr),Pl=d(Mr,"TD",{});var T2=r(Pl);xn=h(T2,"Analyst Programmer"),T2.forEach(e),Gn=o(Mr),Ll=d(Mr,"TD",{});var _2=r(Ll);xl=h(_2,"Deckow-Pouros"),_2.forEach(e),Mn=o(Mr),Gl=d(Mr,"TD",{});var E2=r(Gl);Vn=h(E2,"Portugal"),E2.forEach(e),Fn=o(Mr),Ml=d(Mr,"TD",{});var u2=r(Ml);Wn=h(u2,"4/27/2021"),u2.forEach(e),zn=o(Mr),Vl=d(Mr,"TD",{});var p2=r(Vl);On=h(p2,"Aquamarine"),p2.forEach(e),Ao=o(Mr),Fl=d(Mr,"TH",{});var D2=r(Fl);Nn=h(D2,"14"),D2.forEach(e),Mr.forEach(e),Yn=o(j),nt=d(j,"TR",{});var Vr=r(nt);Wl=d(Vr,"TH",{});var b2=r(Wl);Kn=h(b2,"15"),b2.forEach(e),Jn=o(Vr),zl=d(Vr,"TD",{});var m2=r(zl);qn=h(m2,"Moritz Dryburgh"),m2.forEach(e),Un=o(Vr),Ol=d(Vr,"TD",{});var y2=r(Ol);Zn=h(y2,"Dental Hygienist"),y2.forEach(e),Qn=o(Vr),Pr=d(Vr,"TD",{});var H2=r(Pr);jn=h(H2,"Schiller, Cole and Hackett"),H2.forEach(e),Xn=o(Vr),Nl=d(Vr,"TD",{});var $2=r(Nl);th=h($2,"Sri Lanka"),$2.forEach(e),eh=o(Vr),Yl=d(Vr,"TD",{});var S2=r(Yl);ah=h(S2,"8/8/2020"),S2.forEach(e),md=o(Vr),Kl=d(Vr,"TD",{});var g2=r(Kl);dh=h(g2,"Crimson"),g2.forEach(e),rh=o(Vr),ce=d(Vr,"TH",{});var R2=r(ce);ko=h(R2,"15"),R2.forEach(e),Vr.forEach(e),lh=o(j),ie=d(j,"TR",{});var Fr=r(ie);Jl=d(Fr,"TH",{});var C2=r(Jl);oh=h(C2,"16"),C2.forEach(e),nh=o(Fr),ql=d(Fr,"TD",{});var w2=r(ql);hh=h(w2,"Reid Semiras"),w2.forEach(e),sh=o(Fr),Lr=d(Fr,"TD",{});var A2=r(Lr);ch=h(A2,"Teacher"),A2.forEach(e),ih=o(Fr),Ul=d(Fr,"TD",{});var k2=r(Ul);fh=h(k2,"Sporer, Sipes and Rogahn"),k2.forEach(e),vh=o(Fr),Zl=d(Fr,"TD",{});var I2=r(Zl);Th=h(I2,"Poland"),I2.forEach(e),xr=o(Fr),Ql=d(Fr,"TD",{});var B2=r(Ql);_h=h(B2,"7/30/2020"),B2.forEach(e),Eh=o(Fr),fe=d(Fr,"TD",{});var P2=r(fe);Io=h(P2,"Green"),P2.forEach(e),uh=o(Fr),Bo=d(Fr,"TH",{});var L2=r(Bo);Po=h(L2,"16"),L2.forEach(e),Fr.forEach(e),ph=o(j),ve=d(j,"TR",{});var Wr=r(ve);jl=d(Wr,"TH",{});var x2=r(jl);Dh=h(x2,"17"),x2.forEach(e),bh=o(Wr),Xl=d(Wr,"TD",{});var G2=r(Xl);mh=h(G2,"Alec Lethby"),G2.forEach(e),yh=o(Wr),to=d(Wr,"TD",{});var M2=r(to);Lo=h(M2,"Teacher"),M2.forEach(e),Hh=o(Wr),eo=d(Wr,"TD",{});var V2=r(eo);$h=h(V2,"Reichel, Glover and Hamill"),V2.forEach(e),Sh=o(Wr),zo=d(Wr,"TD",{});var F2=r(zo);Es=h(F2,"China"),F2.forEach(e),us=o(Wr),Ae=d(Wr,"TD",{});var W2=r(Ae);Ph=h(W2,"2/28/2021"),W2.forEach(e),ps=o(Wr),Lh=d(Wr,"TD",{});var z2=r(Lh);xh=h(z2,"Khaki"),z2.forEach(e),Ds=o(Wr),Gh=d(Wr,"TH",{});var O2=r(Gh);Mh=h(O2,"17"),O2.forEach(e),Wr.forEach(e),bs=o(j),ke=d(j,"TR",{});var zr=r(ke);Oo=d(zr,"TH",{});var N2=r(Oo);ms=h(N2,"18"),N2.forEach(e),ys=o(zr),No=d(zr,"TD",{});var Y2=r(No);Hs=h(Y2,"Aland Wilber"),Y2.forEach(e),$s=o(zr),Yo=d(zr,"TD",{});var K2=r(Yo);Ss=h(K2,"Quality Control Specialist"),K2.forEach(e),gs=o(zr),Ko=d(zr,"TD",{});var J2=r(Ko);Rs=h(J2,"Kshlerin, Rogahn and Swaniawski"),J2.forEach(e),Cs=o(zr),Jo=d(zr,"TD",{});var q2=r(Jo);ta=h(q2,"Czech Republic"),q2.forEach(e),Jh=o(zr),Vh=d(zr,"TD",{});var U2=r(Vh);Fh=h(U2,"9/29/2020"),U2.forEach(e),ws=o(zr),Wh=d(zr,"TD",{});var Z2=r(Wh);zh=h(Z2,"Purple"),Z2.forEach(e),As=o(zr),Oh=d(zr,"TH",{});var Q2=r(Oh);Nh=h(Q2,"18"),Q2.forEach(e),zr.forEach(e),ks=o(j),Ie=d(j,"TR",{});var Or=r(Ie);qo=d(Or,"TH",{});var j2=r(qo);Is=h(j2,"19"),j2.forEach(e),Bs=o(Or),Uo=d(Or,"TD",{});var X2=r(Uo);Ps=h(X2,"Teddie Duerden"),X2.forEach(e),Ls=o(Or),Zo=d(Or,"TD",{});var ti=r(Zo);xs=h(ti,"Staff Accountant III"),ti.forEach(e),Yh=o(Or),gh=d(Or,"TD",{});var ei=r(gh);Rh=h(ei,"Pouros, Ullrich and Windler"),ei.forEach(e),Fs=o(Or),Ea=d(Or,"TD",{});var ai=r(Ea);Ws=h(ai,"France"),ai.forEach(e),zs=o(Or),qh=d(Or,"TD",{});var di=r(qh);Os=h(di,"10/27/2020"),di.forEach(e),Ns=o(Or),Uh=d(Or,"TD",{});var ri=r(Uh);U=h(ri,"Aquamarine"),ri.forEach(e),yd=o(Or),Zh=d(Or,"TH",{});var li=r(Zh);Ys=h(li,"19"),li.forEach(e),Or.forEach(e),Ks=o(j),Ye=d(j,"TR",{});var Nr=r(Ye);Qh=d(Nr,"TH",{});var oi=r(Qh);Js=h(oi,"20"),oi.forEach(e),qs=o(Nr),ua=d(Nr,"TD",{});var ni=r(ua);Us=h(ni,"Lorelei Blackstone"),ni.forEach(e),Zs=o(Nr),jh=d(Nr,"TD",{});var hi=r(jh);Qs=h(hi,"Data Coordinator"),hi.forEach(e),js=o(Nr),Xh=d(Nr,"TD",{});var si=r(Xh);Xs=h(si,"Witting, Kutch and Greenfelder"),si.forEach(e),Hd=o(Nr),ts=d(Nr,"TD",{});var ci=r(ts);tc=h(ci,"Kazakhstan"),ci.forEach(e),ec=o(Nr),es=d(Nr,"TD",{});var ii=r(es);ac=h(ii,"6/3/2020"),ii.forEach(e),dc=o(Nr),as=d(Nr,"TD",{});var fi=r(as);$d=h(fi,"Red"),fi.forEach(e),rc=o(Nr),ds=d(Nr,"TH",{});var vi=r(ds);lc=h(vi,"20"),vi.forEach(e),Nr.forEach(e),j.forEach(e),oc=o(Kh),rs=d(Kh,"TFOOT",{});var Ti=r(rs);Ke=d(Ti,"TR",{});var Yr=r(Ke);Gs=d(Yr,"TH",{}),r(Gs).forEach(e),Sd=o(Yr),ls=d(Yr,"TD",{});var _i=r(ls);nc=h(_i,"Name"),_i.forEach(e),hc=o(Yr),os=d(Yr,"TD",{});var Ei=r(os);sc=h(Ei,"Job"),Ei.forEach(e),cc=o(Yr),ns=d(Yr,"TD",{});var ui=r(ns);gd=h(ui,"company"),ui.forEach(e),ic=o(Yr),hs=d(Yr,"TD",{});var pi=r(hs);fc=h(pi,"location"),pi.forEach(e),vc=o(Yr),ss=d(Yr,"TD",{});var Di=r(ss);Tc=h(Di,"Last Login"),Di.forEach(e),_c=o(Yr),pa=d(Yr,"TD",{});var bi=r(pa);Ec=h(bi,"Favorite Color"),bi.forEach(e),uc=o(Yr),Ms=d(Yr,"TH",{}),r(Ms).forEach(e),Yr.forEach(e),Ti.forEach(e),Kh.forEach(e),Vs.forEach(e),this.h()},h(){y(s,"class","table table-xs table-pin-rows table-pin-cols"),y(c,"class","overflow-x-auto h-96 w-96")},m(cs,Vs){Re(cs,c,Vs),t(c,s),t(s,E),t(E,i),t(i,_),t(i,$),t(i,f),t(f,T),t(i,J),t(i,G),t(G,rt),t(i,ct),t(i,A),t(A,it),t(i,X),t(i,g),t(g,D),t(i,V),t(i,v),t(v,b),t(i,k),t(i,tt),t(tt,Et),t(i,q),t(i,p),t(s,P),t(s,u),t(u,I),t(I,ft),t(ft,H),t(I,lt),t(I,At),t(At,Tt),t(I,L),t(I,Dt),t(Dt,bt),t(I,et),t(I,kt),t(kt,mt),t(I,W),t(I,It),t(It,Bt),t(I,S),t(I,z),t(z,Pt),t(I,Wt),t(I,N),t(N,F),t(I,Lt),t(I,Z),t(Z,ut),t(u,yt),t(u,R),t(R,Q),t(Q,Y),t(R,st),t(R,dt),t(dt,qt),t(R,B),t(R,at),t(at,$t),t(R,Mt),t(R,M),t(M,x),t(R,Ut),t(R,Ht),t(Ht,Vt),t(R,re),t(R,C),t(C,O),t(R,Zt),t(R,Qt),t(Qt,St),t(R,w),t(R,jt),t(jt,le),t(u,gt),t(u,K),t(K,Da),t(Da,ba),t(K,Kr),t(K,Te),t(Te,Je),t(K,ea),t(K,Rd),t(Rd,Cd),t(K,oe),t(K,qe),t(qe,ma),t(K,wd),t(K,ya),t(ya,xt),t(K,Be),t(K,aa),t(aa,da),t(K,Pe),t(K,hr),t(hr,Jr),t(K,Ce),t(K,Le),t(Le,Ad),t(u,kd),t(u,Rt),t(Rt,Ha),t(Ha,$a),t(Rt,xe),t(Rt,Id),t(Id,Bd),t(Rt,Pd),t(Rt,Ge),t(Ge,Sa),t(Rt,qr),t(Rt,ga),t(ga,zt),t(Rt,Ra),t(Rt,Ue),t(Ue,Xa),t(Rt,Ld),t(Rt,Ca),t(Ca,ne),t(Rt,Ze),t(Rt,wa),t(wa,xd),t(Rt,_e),t(Rt,Qe),t(Qe,Me),t(u,ra),t(u,Ct),t(Ct,Ve),t(Ve,td),t(Ct,Ur),t(Ct,je),t(je,Fe),t(Ct,Gd),t(Ct,Md),t(Md,Ft),t(Ct,Aa),t(Ct,ka),t(ka,la),t(Ct,Vd),t(Ct,Ia),t(Ia,Fd),t(Ct,We),t(Ct,Wd),t(Wd,Zr),t(Ct,Ee),t(Ct,Ba),t(Ba,zd),t(Ct,Pa),t(Ct,oa),t(oa,Od),t(u,La),t(u,Gt),t(Gt,he),t(he,na),t(Gt,Nd),t(Gt,xa),t(xa,Xt),t(Gt,Ga),t(Gt,Xe),t(Xe,Yd),t(Gt,Kd),t(Gt,Ma),t(Ma,Va),t(Gt,Fa),t(Gt,ha),t(ha,Jd),t(Gt,ed),t(Gt,ze),t(ze,sr),t(Gt,De),t(Gt,cr),t(cr,ir),t(Gt,ad),t(Gt,dd),t(dd,sl),t(u,Oe),t(u,ot),t(ot,rd),t(rd,Kt),t(ot,fr),t(ot,ld),t(ld,vr),t(ot,od),t(ot,sa),t(sa,cl),t(ot,Tr),t(ot,we),t(we,_r),t(ot,nd),t(ot,Er),t(Er,il),t(ot,se),t(ot,hd),t(hd,fl),t(ot,ur),t(ot,ca),t(ca,pr),t(ot,sd),t(ot,cd),t(cd,vl),t(u,vt),t(u,_t),t(_t,id),t(id,Tl),t(_t,Dr),t(_t,fd),t(fd,be),t(_t,br),t(_t,mr),t(mr,yr),t(_t,ia),t(_t,Hr),t(Hr,_l),t(_t,fa),t(_t,vd),t(vd,El),t(_t,Wa),t(_t,Td),t(Td,$r),t(_t,Sr),t(_t,gr),t(gr,me),t(_t,Jt),t(_t,va),t(va,ul),t(u,Rr),t(u,pt),t(pt,_d),t(_d,Ed),t(pt,Cr),t(pt,wr),t(wr,za),t(pt,ud),t(pt,Ar),t(Ar,pl),t(pt,pd),t(pt,Dd),t(Dd,ye),t(pt,kr),t(pt,Ir),t(Ir,Ne),t(pt,Qr),t(pt,jr),t(jr,xo),t(pt,ue),t(pt,qd),t(qd,ao),t(pt,Go),t(pt,Xr),t(Xr,ro),t(u,lo),t(u,te),t(te,oo),t(oo,no),t(te,tl),t(te,ho),t(ho,Mo),t(te,el),t(te,al),t(al,so),t(te,co),t(te,io),t(io,fo),t(te,dl),t(te,rl),t(rl,Vo),t(te,pe),t(te,Ud),t(Ud,vo),t(te,To),t(te,ll),t(ll,Fo),t(te,ol),t(te,Zd),t(Zd,_o),t(u,Wo),t(u,ee),t(ee,nl),t(nl,Eo),t(ee,uo),t(ee,hl),t(hl,po),t(ee,m),t(ee,Do),t(Do,Qo),t(ee,bo),t(ee,Ta),t(Ta,jo),t(ee,He),t(ee,Dl),t(Dl,Xo),t(ee,tn),t(ee,bl),t(bl,en),t(ee,an),t(ee,ml),t(ml,dn),t(ee,rn),t(ee,yl),t(yl,ln),t(u,bd),t(u,ae),t(ae,mo),t(mo,on),t(ae,yo),t(ae,Ho),t(Ho,nn),t(ae,$o),t(ae,So),t(So,hn),t(ae,$e),t(ae,Hl),t(Hl,sn),t(ae,cn),t(ae,_a),t(_a,fn),t(ae,vn),t(ae,$l),t($l,Tn),t(ae,_n),t(ae,Sl),t(Sl,En),t(ae,un),t(ae,gl),t(gl,pn),t(u,Dn),t(u,wt),t(wt,go),t(go,bn),t(wt,Ro),t(wt,Co),t(Co,mn),t(wt,Se),t(wt,Rl),t(Rl,yn),t(wt,Hn),t(wt,Cl),t(Cl,$n),t(wt,Sn),t(wt,wl),t(wl,gn),t(wt,Rn),t(wt,Al),t(Al,Cn),t(wt,wn),t(wt,kl),t(kl,An),t(wt,kn),t(wt,Il),t(Il,In),t(u,Br),t(u,de),t(de,wo),t(wo,Bn),t(de,ge),t(de,Bl),t(Bl,Pn),t(de,Ln),t(de,Pl),t(Pl,xn),t(de,Gn),t(de,Ll),t(Ll,xl),t(de,Mn),t(de,Gl),t(Gl,Vn),t(de,Fn),t(de,Ml),t(Ml,Wn),t(de,zn),t(de,Vl),t(Vl,On),t(de,Ao),t(de,Fl),t(Fl,Nn),t(u,Yn),t(u,nt),t(nt,Wl),t(Wl,Kn),t(nt,Jn),t(nt,zl),t(zl,qn),t(nt,Un),t(nt,Ol),t(Ol,Zn),t(nt,Qn),t(nt,Pr),t(Pr,jn),t(nt,Xn),t(nt,Nl),t(Nl,th),t(nt,eh),t(nt,Yl),t(Yl,ah),t(nt,md),t(nt,Kl),t(Kl,dh),t(nt,rh),t(nt,ce),t(ce,ko),t(u,lh),t(u,ie),t(ie,Jl),t(Jl,oh),t(ie,nh),t(ie,ql),t(ql,hh),t(ie,sh),t(ie,Lr),t(Lr,ch),t(ie,ih),t(ie,Ul),t(Ul,fh),t(ie,vh),t(ie,Zl),t(Zl,Th),t(ie,xr),t(ie,Ql),t(Ql,_h),t(ie,Eh),t(ie,fe),t(fe,Io),t(ie,uh),t(ie,Bo),t(Bo,Po),t(u,ph),t(u,ve),t(ve,jl),t(jl,Dh),t(ve,bh),t(ve,Xl),t(Xl,mh),t(ve,yh),t(ve,to),t(to,Lo),t(ve,Hh),t(ve,eo),t(eo,$h),t(ve,Sh),t(ve,zo),t(zo,Es),t(ve,us),t(ve,Ae),t(Ae,Ph),t(ve,ps),t(ve,Lh),t(Lh,xh),t(ve,Ds),t(ve,Gh),t(Gh,Mh),t(u,bs),t(u,ke),t(ke,Oo),t(Oo,ms),t(ke,ys),t(ke,No),t(No,Hs),t(ke,$s),t(ke,Yo),t(Yo,Ss),t(ke,gs),t(ke,Ko),t(Ko,Rs),t(ke,Cs),t(ke,Jo),t(Jo,ta),t(ke,Jh),t(ke,Vh),t(Vh,Fh),t(ke,ws),t(ke,Wh),t(Wh,zh),t(ke,As),t(ke,Oh),t(Oh,Nh),t(u,ks),t(u,Ie),t(Ie,qo),t(qo,Is),t(Ie,Bs),t(Ie,Uo),t(Uo,Ps),t(Ie,Ls),t(Ie,Zo),t(Zo,xs),t(Ie,Yh),t(Ie,gh),t(gh,Rh),t(Ie,Fs),t(Ie,Ea),t(Ea,Ws),t(Ie,zs),t(Ie,qh),t(qh,Os),t(Ie,Ns),t(Ie,Uh),t(Uh,U),t(Ie,yd),t(Ie,Zh),t(Zh,Ys),t(u,Ks),t(u,Ye),t(Ye,Qh),t(Qh,Js),t(Ye,qs),t(Ye,ua),t(ua,Us),t(Ye,Zs),t(Ye,jh),t(jh,Qs),t(Ye,js),t(Ye,Xh),t(Xh,Xs),t(Ye,Hd),t(Ye,ts),t(ts,tc),t(Ye,ec),t(Ye,es),t(es,ac),t(Ye,dc),t(Ye,as),t(as,$d),t(Ye,rc),t(Ye,ds),t(ds,lc),t(s,oc),t(s,rs),t(rs,Ke),t(Ke,Gs),t(Ke,Sd),t(Ke,ls),t(ls,nc),t(Ke,hc),t(Ke,os),t(os,sc),t(Ke,cc),t(Ke,ns),t(ns,gd),t(Ke,ic),t(Ke,hs),t(hs,fc),t(Ke,vc),t(Ke,ss),t(ss,Tc),t(Ke,_c),t(Ke,pa),t(pa,Ec),t(Ke,uc),t(Ke,Ms)},p:fs,d(cs){cs&&e(c)}}}function Ji(ht){let c,s=`<div class="overflow-x-auto">
  <table class="$$table $$table-xs $$table-pin-rows $$table-pin-cols">
    <thead>
      <tr>
        <th></th> 
        <td>Name</td> 
        <td>Job</td> 
        <td>company</td> 
        <td>location</td> 
        <td>Last Login</td> 
        <td>Favorite Color</td>
        <th></th> 
      </tr>
    </thead> 
    <tbody>
      <tr>
        <th>1</th> 
        <td>Cy Ganderton</td> 
        <td>Quality Control Specialist</td> 
        <td>Littel, Schaden and Vandervort</td> 
        <td>Canada</td> 
        <td>12/16/2020</td> 
        <td>Blue</td>
        <th>1</th> 
      </tr>
      <tr>
        <th>2</th> 
        <td>Hart Hagerty</td> 
        <td>Desktop Support Technician</td> 
        <td>Zemlak, Daniel and Leannon</td> 
        <td>United States</td> 
        <td>12/5/2020</td> 
        <td>Purple</td>
        <th>2</th> 
      </tr>
      <tr>
        <th>3</th> 
        <td>Brice Swyre</td> 
        <td>Tax Accountant</td> 
        <td>Carroll Group</td> 
        <td>China</td> 
        <td>8/15/2020</td> 
        <td>Red</td>
        <th>3</th> 
      </tr>
      <tr>
        <th>4</th> 
        <td>Marjy Ferencz</td> 
        <td>Office Assistant I</td> 
        <td>Rowe-Schoen</td> 
        <td>Russia</td> 
        <td>3/25/2021</td> 
        <td>Crimson</td>
        <th>4</th> 
      </tr>
      <tr>
        <th>5</th> 
        <td>Yancy Tear</td> 
        <td>Community Outreach Specialist</td> 
        <td>Wyman-Ledner</td> 
        <td>Brazil</td> 
        <td>5/22/2020</td> 
        <td>Indigo</td>
        <th>5</th> 
      </tr>
      <tr>
        <th>6</th> 
        <td>Irma Vasilik</td> 
        <td>Editor</td> 
        <td>Wiza, Bins and Emard</td> 
        <td>Venezuela</td> 
        <td>12/8/2020</td> 
        <td>Purple</td>
        <th>6</th> 
      </tr>
      <tr>
        <th>7</th> 
        <td>Meghann Durtnal</td> 
        <td>Staff Accountant IV</td> 
        <td>Schuster-Schimmel</td> 
        <td>Philippines</td> 
        <td>2/17/2021</td> 
        <td>Yellow</td>
        <th>7</th> 
      </tr>
      <tr>
        <th>8</th> 
        <td>Sammy Seston</td> 
        <td>Accountant I</td> 
        <td>O'Hara, Welch and Keebler</td> 
        <td>Indonesia</td> 
        <td>5/23/2020</td> 
        <td>Crimson</td>
        <th>8</th> 
      </tr>
      <tr>
        <th>9</th> 
        <td>Lesya Tinham</td> 
        <td>Safety Technician IV</td> 
        <td>Turner-Kuhlman</td> 
        <td>Philippines</td> 
        <td>2/21/2021</td> 
        <td>Maroon</td>
        <th>9</th> 
      </tr>
      <tr>
        <th>10</th> 
        <td>Zaneta Tewkesbury</td> 
        <td>VP Marketing</td> 
        <td>Sauer LLC</td> 
        <td>Chad</td> 
        <td>6/23/2020</td> 
        <td>Green</td>
        <th>10</th> 
      </tr>
      <tr>
        <th>11</th> 
        <td>Andy Tipple</td> 
        <td>Librarian</td> 
        <td>Hilpert Group</td> 
        <td>Poland</td> 
        <td>7/9/2020</td> 
        <td>Indigo</td>
        <th>11</th> 
      </tr>
      <tr>
        <th>12</th> 
        <td>Sophi Biles</td> 
        <td>Recruiting Manager</td> 
        <td>Gutmann Inc</td> 
        <td>Indonesia</td> 
        <td>2/12/2021</td> 
        <td>Maroon</td>
        <th>12</th> 
      </tr>
      <tr>
        <th>13</th> 
        <td>Florida Garces</td> 
        <td>Web Developer IV</td> 
        <td>Gaylord, Pacocha and Baumbach</td> 
        <td>Poland</td> 
        <td>5/31/2020</td> 
        <td>Purple</td>
        <th>13</th> 
      </tr>
      <tr>
        <th>14</th> 
        <td>Maribeth Popping</td> 
        <td>Analyst Programmer</td> 
        <td>Deckow-Pouros</td> 
        <td>Portugal</td> 
        <td>4/27/2021</td> 
        <td>Aquamarine</td>
        <th>14</th> 
      </tr>
      <tr>
        <th>15</th> 
        <td>Moritz Dryburgh</td> 
        <td>Dental Hygienist</td> 
        <td>Schiller, Cole and Hackett</td> 
        <td>Sri Lanka</td> 
        <td>8/8/2020</td> 
        <td>Crimson</td>
        <th>15</th> 
      </tr>
      <tr>
        <th>16</th> 
        <td>Reid Semiras</td> 
        <td>Teacher</td> 
        <td>Sporer, Sipes and Rogahn</td> 
        <td>Poland</td> 
        <td>7/30/2020</td> 
        <td>Green</td>
        <th>16</th> 
      </tr>
      <tr>
        <th>17</th> 
        <td>Alec Lethby</td> 
        <td>Teacher</td> 
        <td>Reichel, Glover and Hamill</td> 
        <td>China</td> 
        <td>2/28/2021</td> 
        <td>Khaki</td>
        <th>17</th> 
      </tr>
      <tr>
        <th>18</th> 
        <td>Aland Wilber</td> 
        <td>Quality Control Specialist</td> 
        <td>Kshlerin, Rogahn and Swaniawski</td> 
        <td>Czech Republic</td> 
        <td>9/29/2020</td> 
        <td>Purple</td>
        <th>18</th> 
      </tr>
      <tr>
        <th>19</th> 
        <td>Teddie Duerden</td> 
        <td>Staff Accountant III</td> 
        <td>Pouros, Ullrich and Windler</td> 
        <td>France</td> 
        <td>10/27/2020</td> 
        <td>Aquamarine</td>
        <th>19</th> 
      </tr>
      <tr>
        <th>20</th> 
        <td>Lorelei Blackstone</td> 
        <td>Data Coordinator</td> 
        <td>Witting, Kutch and Greenfelder</td> 
        <td>Kazakhstan</td> 
        <td>6/3/2020</td> 
        <td>Red</td>
        <th>20</th> 
      </tr>
    </tbody> 
    <tfoot>
      <tr>
        <th></th> 
        <td>Name</td> 
        <td>Job</td> 
        <td>company</td> 
        <td>location</td> 
        <td>Last Login</td> 
        <td>Favorite Color</td>
        <th></th> 
      </tr>
    </tfoot>
  </table>
</div>`,E,i,_,$;return{c(){c=a("pre"),E=n(s),this.h()},l(f){c=d(f,"PRE",{slot:!0});var T=r(c);E=h(T,s),T.forEach(e),this.h()},h(){y(c,"slot","html")},m(f,T){Re(f,c,T),t(c,E),_||($=vs(i=_s.call(null,c,{to:ht[0]})),_=!0)},p(f,T){i&&Ts(i.update)&&T&1&&i.update.call(null,{to:f[0]})},d(f){f&&e(c),_=!1,$()}}}function qi(ht){let c,s,E,i,_,$,f,T,J,G,rt,ct,A,it,X,g,D,V;return c=new ki({props:{data:[{type:"component",class:"table",desc:"For <table> element"},{type:"modifier",class:"table-zebra",desc:"For <table> to show zebra stripe rows"},{type:"modifier",class:"table-pin-rows",desc:"For <table> to make all the rows inside <thead> and <tfoot> sticky"},{type:"modifier",class:"table-pin-cols",desc:"For <table> to make all the <th> columns sticky"},{type:"responsive",class:"table-xs",desc:"Extra small size"},{type:"responsive",class:"table-sm",desc:"Small size"},{type:"responsive",class:"table-md",desc:"Normal size"},{type:"responsive",class:"table-lg",desc:"Large size"}]}}),E=new is({props:{title:"Table",$$slots:{html:[Bi],default:[Ii]},$$scope:{ctx:ht}}}),_=new is({props:{title:"Table with an active row",$$slots:{html:[Li],default:[Pi]},$$scope:{ctx:ht}}}),f=new is({props:{title:"Table with a row that highlights on hover",$$slots:{html:[Gi],default:[xi]},$$scope:{ctx:ht}}}),J=new is({props:{title:"Zebra",$$slots:{html:[Vi],default:[Mi]},$$scope:{ctx:ht}}}),rt=new is({props:{title:"Table with visual elements",$$slots:{html:[Wi],default:[Fi]},$$scope:{ctx:ht}}}),A=new is({props:{title:"Table xs",$$slots:{html:[Oi],default:[zi]},$$scope:{ctx:ht}}}),X=new is({props:{title:"Table with pinned-rows",$$slots:{html:[Yi],default:[Ni]},$$scope:{ctx:ht}}}),D=new is({props:{title:"Table with pinned-rows and pinned-cols",$$slots:{html:[Ji],default:[Ki]},$$scope:{ctx:ht}}}),{c(){Ch(c.$$.fragment),s=l(),Ch(E.$$.fragment),i=l(),Ch(_.$$.fragment),$=l(),Ch(f.$$.fragment),T=l(),Ch(J.$$.fragment),G=l(),Ch(rt.$$.fragment),ct=l(),Ch(A.$$.fragment),it=l(),Ch(X.$$.fragment),g=l(),Ch(D.$$.fragment)},l(v){wh(c.$$.fragment,v),s=o(v),wh(E.$$.fragment,v),i=o(v),wh(_.$$.fragment,v),$=o(v),wh(f.$$.fragment,v),T=o(v),wh(J.$$.fragment,v),G=o(v),wh(rt.$$.fragment,v),ct=o(v),wh(A.$$.fragment,v),it=o(v),wh(X.$$.fragment,v),g=o(v),wh(D.$$.fragment,v)},m(v,b){Ah(c,v,b),Re(v,s,b),Ah(E,v,b),Re(v,i,b),Ah(_,v,b),Re(v,$,b),Ah(f,v,b),Re(v,T,b),Ah(J,v,b),Re(v,G,b),Ah(rt,v,b),Re(v,ct,b),Ah(A,v,b),Re(v,it,b),Ah(X,v,b),Re(v,g,b),Ah(D,v,b),V=!0},p(v,b){const k={};b&5&&(k.$$scope={dirty:b,ctx:v}),E.$set(k);const tt={};b&5&&(tt.$$scope={dirty:b,ctx:v}),_.$set(tt);const Et={};b&5&&(Et.$$scope={dirty:b,ctx:v}),f.$set(Et);const q={};b&5&&(q.$$scope={dirty:b,ctx:v}),J.$set(q);const p={};b&5&&(p.$$scope={dirty:b,ctx:v}),rt.$set(p);const P={};b&5&&(P.$$scope={dirty:b,ctx:v}),A.$set(P);const u={};b&5&&(u.$$scope={dirty:b,ctx:v}),X.$set(u);const I={};b&5&&(I.$$scope={dirty:b,ctx:v}),D.$set(I)},i(v){V||(kh(c.$$.fragment,v),kh(E.$$.fragment,v),kh(_.$$.fragment,v),kh(f.$$.fragment,v),kh(J.$$.fragment,v),kh(rt.$$.fragment,v),kh(A.$$.fragment,v),kh(X.$$.fragment,v),kh(D.$$.fragment,v),V=!0)},o(v){Ih(c.$$.fragment,v),Ih(E.$$.fragment,v),Ih(_.$$.fragment,v),Ih(f.$$.fragment,v),Ih(J.$$.fragment,v),Ih(rt.$$.fragment,v),Ih(A.$$.fragment,v),Ih(X.$$.fragment,v),Ih(D.$$.fragment,v),V=!1},d(v){Bh(c,v),v&&e(s),Bh(E,v),v&&e(i),Bh(_,v),v&&e($),Bh(f,v),v&&e(T),Bh(J,v),v&&e(G),Bh(rt,v),v&&e(ct),Bh(A,v),v&&e(it),Bh(X,v),v&&e(g),Bh(D,v)}}}function Ui(ht){let c,s;const E=[ht[1],Hi];let i={$$slots:{default:[qi]},$$scope:{ctx:ht}};for(let _=0;_<E.length;_+=1)i=X1(i,E[_]);return c=new wi({props:i}),{c(){Ch(c.$$.fragment)},l(_){wh(c.$$.fragment,_)},m(_,$){Ah(c,_,$),s=!0},p(_,[$]){const f=$&2?Ri(E,[$&2&&mi(_[1]),$&0&&mi(Hi)]):{};$&5&&(f.$$scope={dirty:$,ctx:_}),c.$set(f)},i(_){s||(kh(c.$$.fragment,_),s=!0)},o(_){Ih(c.$$.fragment,_),s=!1},d(_){Bh(c,_)}}}const Hi={title:"Table",desc:"Table can be used to show a list of data in a table format.",published:!0};function Zi(ht,c,s){let E;return Ci(ht,Ai,i=>s(0,E=i)),ht.$$set=i=>{s(1,c=X1(X1({},c),yi(i)))},c=yi(c),[E,c]}class tf extends $i{constructor(c){super(),Si(this,c,Zi,Ui,gi,{})}}export{tf as component};
