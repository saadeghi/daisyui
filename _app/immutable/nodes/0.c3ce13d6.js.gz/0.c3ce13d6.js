import{L as e,_ as n}from"../chunks/0.b6b17acf.js";export{e as component,n as universal};
