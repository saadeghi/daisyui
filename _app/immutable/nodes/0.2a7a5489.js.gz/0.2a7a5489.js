import{L as e,_ as n}from"../chunks/0.f39db29e.js";export{e as component,n as universal};
