import{L as e,_ as n}from"../chunks/0.9859b3c3.js";export{e as component,n as universal};
