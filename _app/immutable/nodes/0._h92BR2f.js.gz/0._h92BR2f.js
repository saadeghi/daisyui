import{L as e,_ as n}from"../chunks/0.EpXSavPg.js";export{e as component,n as universal};
