import{L as e,_ as n}from"../chunks/0.6fad487a.js";export{e as component,n as universal};
