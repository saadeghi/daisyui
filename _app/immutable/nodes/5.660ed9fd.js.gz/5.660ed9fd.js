import{s as Q,E as U,y as W,O as G,a as _,f as h,c as x,g as $,z as b,j as f,i as r,d as p,w as A,l as E,h as P,m as R,v as z,Y as B,U as F}from"../chunks/scheduler.e71eccdd.js";import{S as X,i as Z,b as g,d as C,m as M,a as T,t as H,e as L}from"../chunks/index.445ee094.js";import{g as ee,a as K}from"../chunks/index.18b79e66.js";import{M as te}from"../chunks/mdsvex.3a31e1aa.js";import{p as le,C as se,a as V,r as S}from"../chunks/ClassTable.b8d00d65.js";function oe(m){let e,d='<input type="radio" name="my-accordion-1" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',s,l,a='<input type="radio" name="my-accordion-1"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',n,t,c='<input type="radio" name="my-accordion-1"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=h("div"),e.innerHTML=d,s=_(),l=h("div"),l.innerHTML=a,n=_(),t=h("div"),t.innerHTML=c,this.h()},l(i){e=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(e)!=="svelte-clm1hr"&&(e.innerHTML=d),s=x(i),l=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(l)!=="svelte-h9xsaw"&&(l.innerHTML=a),n=x(i),t=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(t)!=="svelte-h9xsaw"&&(t.innerHTML=c),this.h()},h(){f(e,"class","collapse bg-base-200"),f(l,"class","collapse bg-base-200"),f(t,"class","collapse bg-base-200")},m(i,v){r(i,e,v),r(i,s,v),r(i,l,v),r(i,n,v),r(i,t,v)},p:A,d(i){i&&(p(e),p(s),p(l),p(n),p(t))}}}function ie(m){let e,d=`<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,s,l,a,n;return{c(){e=h("pre"),s=E(d),this.h()},l(t){e=$(t,"PRE",{slot:!0});var c=P(e);s=R(c,d),c.forEach(p),this.h()},h(){f(e,"slot","html")},m(t,c){r(t,e,c),z(e,s),a||(n=B(l=S.call(null,e,{to:m[0]})),a=!0)},p(t,c){l&&F(l.update)&&c&1&&l.update.call(null,{to:t[0]})},d(t){t&&p(e),a=!1,n()}}}function ae(m){let e,d='<input type="radio" name="my-accordion-2" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',s,l,a='<input type="radio" name="my-accordion-2"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',n,t,c='<input type="radio" name="my-accordion-2"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=h("div"),e.innerHTML=d,s=_(),l=h("div"),l.innerHTML=a,n=_(),t=h("div"),t.innerHTML=c,this.h()},l(i){e=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(e)!=="svelte-497nvj"&&(e.innerHTML=d),s=x(i),l=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(l)!=="svelte-mpai6"&&(l.innerHTML=a),n=x(i),t=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(t)!=="svelte-mpai6"&&(t.innerHTML=c),this.h()},h(){f(e,"class","collapse collapse-arrow bg-base-200"),f(l,"class","collapse collapse-arrow bg-base-200"),f(t,"class","collapse collapse-arrow bg-base-200")},m(i,v){r(i,e,v),r(i,s,v),r(i,l,v),r(i,n,v),r(i,t,v)},p:A,d(i){i&&(p(e),p(s),p(l),p(n),p(t))}}}function ne(m){let e,d=`<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,s,l,a,n;return{c(){e=h("pre"),s=E(d),this.h()},l(t){e=$(t,"PRE",{slot:!0});var c=P(e);s=R(c,d),c.forEach(p),this.h()},h(){f(e,"slot","html")},m(t,c){r(t,e,c),z(e,s),a||(n=B(l=S.call(null,e,{to:m[0]})),a=!0)},p(t,c){l&&F(l.update)&&c&1&&l.update.call(null,{to:t[0]})},d(t){t&&p(e),a=!1,n()}}}function ce(m){let e,d='<input type="radio" name="my-accordion-3" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',s,l,a='<input type="radio" name="my-accordion-3"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',n,t,c='<input type="radio" name="my-accordion-3"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=h("div"),e.innerHTML=d,s=_(),l=h("div"),l.innerHTML=a,n=_(),t=h("div"),t.innerHTML=c,this.h()},l(i){e=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(e)!=="svelte-1n8yy1f"&&(e.innerHTML=d),s=x(i),l=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(l)!=="svelte-7maod4"&&(l.innerHTML=a),n=x(i),t=$(i,"DIV",{class:!0,["data-svelte-h"]:!0}),b(t)!=="svelte-7maod4"&&(t.innerHTML=c),this.h()},h(){f(e,"class","collapse collapse-plus bg-base-200"),f(l,"class","collapse collapse-plus bg-base-200"),f(t,"class","collapse collapse-plus bg-base-200")},m(i,v){r(i,e,v),r(i,s,v),r(i,l,v),r(i,n,v),r(i,t,v)},p:A,d(i){i&&(p(e),p(s),p(l),p(n),p(t))}}}function de(m){let e,d=`<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,s,l,a,n;return{c(){e=h("pre"),s=E(d),this.h()},l(t){e=$(t,"PRE",{slot:!0});var c=P(e);s=R(c,d),c.forEach(p),this.h()},h(){f(e,"slot","html")},m(t,c){r(t,e,c),z(e,s),a||(n=B(l=S.call(null,e,{to:m[0]})),a=!0)},p(t,c){l&&F(l.update)&&c&1&&l.update.call(null,{to:t[0]})},d(t){t&&p(e),a=!1,n()}}}function pe(m){let e,d='<div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4" checked="checked"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div> <div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div> <div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div>';return{c(){e=h("div"),e.innerHTML=d,this.h()},l(s){e=$(s,"DIV",{class:!0,["data-svelte-h"]:!0}),b(e)!=="svelte-mwrxrm"&&(e.innerHTML=d),this.h()},h(){f(e,"class","join join-vertical w-full")},m(s,l){r(s,e,l)},p:A,d(s){s&&p(e)}}}function re(m){let e,d=`<div class="$$join $$join-vertical w-full">
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" checked="checked" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
</div>`,s,l,a,n;return{c(){e=h("pre"),s=E(d),this.h()},l(t){e=$(t,"PRE",{slot:!0});var c=P(e);s=R(c,d),c.forEach(p),this.h()},h(){f(e,"slot","html")},m(t,c){r(t,e,c),z(e,s),a||(n=B(l=S.call(null,e,{to:m[0]})),a=!0)},p(t,c){l&&F(l.update)&&c&1&&l.update.call(null,{to:t[0]})},d(t){t&&p(e),a=!1,n()}}}function me(m){let e,d,s,l='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="stroke-current shrink-0 w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> <div>Accordion uses the same style as the <a href="/components/collapse/" class="link">collapse component</a> but it works with radio inputs. You can control which item to be open by checking/unchecking the hidden radio input.</div>',a,n,t='<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="stroke-current shrink-0 w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> <div>All radio inputs with the same name work together and only one of them can be open at a time. If you have more than one set of accordion items on a page, use different names for the radio inputs on each set.</div>',c,i,v,y,j,k,I,w,D;return e=new se({props:{data:[{type:"component",class:"collapse",desc:"Container element"},{type:"component",class:"collapse-title",desc:"Title element"},{type:"component",class:"collapse-content",desc:"Container for content"},{type:"modifier",class:"collapse-arrow",desc:"Adds arrow icon"},{type:"modifier",class:"collapse-plus",desc:"Adds plus/minus icon"},{type:"modifier",class:"collapse-open",desc:"Force open"},{type:"modifier",class:"collapse-close",desc:"Force close"}]}}),i=new V({props:{title:"Accordion using radio inputs",$$slots:{html:[ie],default:[oe]},$$scope:{ctx:m}}}),y=new V({props:{title:"Accordion with arrow icon",$$slots:{html:[ne],default:[ae]},$$scope:{ctx:m}}}),k=new V({props:{title:"Accordion with plus/minus icon",$$slots:{html:[de],default:[ce]},$$scope:{ctx:m}}}),w=new V({props:{title:"Using Accordion and Join together",desc:"to join the items together and handle border radius automatically",$$slots:{html:[re],default:[pe]},$$scope:{ctx:m}}}),{c(){g(e.$$.fragment),d=_(),s=h("div"),s.innerHTML=l,a=_(),n=h("div"),n.innerHTML=t,c=_(),g(i.$$.fragment),v=_(),g(y.$$.fragment),j=_(),g(k.$$.fragment),I=_(),g(w.$$.fragment),this.h()},l(o){C(e.$$.fragment,o),d=x(o),s=$(o,"DIV",{class:!0,["data-svelte-h"]:!0}),b(s)!=="svelte-bw2rlt"&&(s.innerHTML=l),a=x(o),n=$(o,"DIV",{class:!0,["data-svelte-h"]:!0}),b(n)!=="svelte-1yuilu5"&&(n.innerHTML=t),c=x(o),C(i.$$.fragment,o),v=x(o),C(y.$$.fragment,o),j=x(o),C(k.$$.fragment,o),I=x(o),C(w.$$.fragment,o),this.h()},h(){f(s,"class","alert text-sm mt-4"),f(n,"class","alert text-sm mt-4")},m(o,u){M(e,o,u),r(o,d,u),r(o,s,u),r(o,a,u),r(o,n,u),r(o,c,u),M(i,o,u),r(o,v,u),M(y,o,u),r(o,j,u),M(k,o,u),r(o,I,u),M(w,o,u),D=!0},p(o,u){const Y={};u&5&&(Y.$$scope={dirty:u,ctx:o}),i.$set(Y);const q={};u&5&&(q.$$scope={dirty:u,ctx:o}),y.$set(q);const J={};u&5&&(J.$$scope={dirty:u,ctx:o}),k.$set(J);const O={};u&5&&(O.$$scope={dirty:u,ctx:o}),w.$set(O)},i(o){D||(T(e.$$.fragment,o),T(i.$$.fragment,o),T(y.$$.fragment,o),T(k.$$.fragment,o),T(w.$$.fragment,o),D=!0)},o(o){H(e.$$.fragment,o),H(i.$$.fragment,o),H(y.$$.fragment,o),H(k.$$.fragment,o),H(w.$$.fragment,o),D=!1},d(o){o&&(p(d),p(s),p(a),p(n),p(c),p(v),p(j),p(I)),L(e,o),L(i,o),L(y,o),L(k,o),L(w,o)}}}function ve(m){let e,d;const s=[m[1],N];let l={$$slots:{default:[me]},$$scope:{ctx:m}};for(let a=0;a<s.length;a+=1)l=U(l,s[a]);return e=new te({props:l}),{c(){g(e.$$.fragment)},l(a){C(e.$$.fragment,a)},m(a,n){M(e,a,n),d=!0},p(a,[n]){const t=n&2?ee(s,[n&2&&K(a[1]),n&0&&K(N)]):{};n&5&&(t.$$scope={dirty:n,ctx:a}),e.$set(t)},i(a){d||(T(e.$$.fragment,a),d=!0)},o(a){H(e.$$.fragment,a),d=!1},d(a){L(e,a)}}}const N={title:"Accordion",desc:"Accordion is used for showing and hiding content but only one item can stay open at a time.",published:!0};function ue(m,e,d){let s;return W(m,le,l=>d(0,s=l)),m.$$set=l=>{d(1,e=U(U({},e),G(l)))},e=G(e),[s,e]}class be extends X{constructor(e){super(),Z(this,e,ue,ve,Q,{})}}export{be as component};
