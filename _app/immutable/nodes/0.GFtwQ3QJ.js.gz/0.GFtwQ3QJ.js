import{L as e,_ as n}from"../chunks/0.yTgiVf4n.js";export{e as component,n as universal};
