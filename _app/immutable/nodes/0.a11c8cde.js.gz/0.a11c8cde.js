import{L as e,_ as n}from"../chunks/0.8ce2f3bd.js";export{e as component,n as universal};
