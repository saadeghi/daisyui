import{S as ye,i as Be,s as Ae,M as je,y as W,z as X,A as Z,U as Re,$ as Te,g as ee,d as se,B as te,H as qe,Y as ze,a as k,c as j,b as U,h as o,k as a,l as c,m as g,K as V,n as s,E as t,F as ie,q as N,r as O,a9 as re,a4 as oe}from"../chunks/index.b33eaa49.js";import{M as Fe}from"../chunks/mdsvex.566e438d.js";import{p as He,C as Ke,a as ce,r as ue}from"../chunks/ClassTable.ab893818.js";function Ue(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"alt","Burger"),s(d,"class","carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"alt","Burger"),s(m,"class","carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"alt","Burger"),s(w,"class","carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Burger"),s(I,"class","carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"alt","Burger"),s(h,"class","carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Burger"),s(f,"class","carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"alt","Burger"),s(S,"class","carousel-item"),s(e,"class","carousel rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function Ye(z){let e,d=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function Je(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"alt","Pizza"),s(d,"class","carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"alt","Pizza"),s(m,"class","carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"alt","Pizza"),s(w,"class","carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Pizza"),s(I,"class","carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"alt","Pizza"),s(h,"class","carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Pizza"),s(f,"class","carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"alt","Pizza"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-center rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function Le(z){let e,d=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function Ne(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"alt","Drink"),s(d,"class","carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"alt","Drink"),s(m,"class","carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"alt","Drink"),s(w,"class","carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Drink"),s(I,"class","carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"alt","Drink"),s(h,"class","carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Drink"),s(f,"class","carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"alt","Drink"),s(S,"class","carousel-item"),s(e,"class","carousel carousel-end rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function Oe(z){let e,d=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function Qe(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,class:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,class:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"class","w-full"),s(u,"alt","Tailwind CSS carousel component"),s(d,"class","w-full carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"class","w-full"),s(l,"alt","Tailwind CSS carousel component"),s(m,"class","w-full carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"class","w-full"),s(_,"alt","Tailwind CSS carousel component"),s(w,"class","w-full carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS carousel component"),s(I,"class","w-full carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"class","w-full"),s($,"alt","Tailwind CSS carousel component"),s(h,"class","w-full carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","w-full"),s(E,"alt","Tailwind CSS carousel component"),s(f,"class","w-full carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"class","w-full"),s(D,"alt","Tailwind CSS carousel component"),s(S,"class","w-full carousel-item"),s(e,"class","w-64 carousel rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function We(z){let e,d=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function Xe(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"alt","Tailwind Image slider"),s(d,"class","carousel-item h-full"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"alt","Tailwind Image slider"),s(m,"class","carousel-item h-full"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"alt","Tailwind Image slider"),s(w,"class","carousel-item h-full"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"alt","Tailwind Image slider"),s(I,"class","carousel-item h-full"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"alt","Tailwind Image slider"),s(h,"class","carousel-item h-full"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"alt","Tailwind Image slider"),s(f,"class","carousel-item h-full"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"alt","Tailwind Image slider"),s(S,"class","carousel-item h-full"),s(e,"class","h-96 carousel carousel-vertical rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function Ze(z){let e,d=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function es(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,class:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,class:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"class","w-full"),s(u,"alt","Tailwind CSS Image slider"),s(d,"class","w-1/2 carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"class","w-full"),s(l,"alt","Tailwind CSS Image slider"),s(m,"class","w-1/2 carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"class","w-full"),s(_,"alt","Tailwind CSS Image slider"),s(w,"class","w-1/2 carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS Image slider"),s(I,"class","w-1/2 carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"class","w-full"),s($,"alt","Tailwind CSS Image slider"),s(h,"class","w-1/2 carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","w-full"),s(E,"alt","Tailwind CSS Image slider"),s(f,"class","w-1/2 carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"class","w-full"),s(D,"alt","Tailwind CSS Image slider"),s(S,"class","w-1/2 carousel-item"),s(e,"class","w-96 carousel rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function ss(z){let e,d=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function ts(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("img"),r=k(),f=a("div"),E=a("img"),x=k(),S=a("div"),D=a("img"),this.h()},l(M){e=c(M,"DIV",{class:!0});var i=g(e);d=c(i,"DIV",{class:!0});var y=g(d);u=c(y,"IMG",{src:!0,class:!0,alt:!0}),y.forEach(o),n=j(i),m=c(i,"DIV",{class:!0});var K=g(m);l=c(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),T=j(i),w=c(i,"DIV",{class:!0});var Y=g(w);_=c(Y,"IMG",{src:!0,class:!0,alt:!0}),Y.forEach(o),G=j(i),I=c(i,"DIV",{class:!0});var J=g(I);b=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var q=g(h);$=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),r=j(i),f=c(i,"DIV",{class:!0});var A=g(f);E=c(A,"IMG",{src:!0,class:!0,alt:!0}),A.forEach(o),x=j(i),S=c(i,"DIV",{class:!0});var L=g(S);D=c(L,"IMG",{src:!0,class:!0,alt:!0}),L.forEach(o),i.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1559703248-dcaaec9fab78.jpg")||s(u,"src",p),s(u,"class","rounded-box"),s(u,"alt","Tailwind CSS component"),s(d,"class","carousel-item"),V(l.src,v="/images/stock/photo-1565098772267-60af42b81ef2.jpg")||s(l,"src",v),s(l,"class","rounded-box"),s(l,"alt","Tailwind CSS component"),s(m,"class","carousel-item"),V(_.src,F="/images/stock/photo-1572635148818-ef6fd45eb394.jpg")||s(_,"src",F),s(_,"class","rounded-box"),s(_,"alt","Tailwind CSS component"),s(w,"class","carousel-item"),V(b.src,H="/images/stock/photo-1494253109108-2e30c049369b.jpg")||s(b,"src",H),s(b,"class","rounded-box"),s(b,"alt","Tailwind CSS component"),s(I,"class","carousel-item"),V($.src,R="/images/stock/photo-1550258987-190a2d41a8ba.jpg")||s($,"src",R),s($,"class","rounded-box"),s($,"alt","Tailwind CSS component"),s(h,"class","carousel-item"),V(E.src,B="/images/stock/photo-1559181567-c3190ca9959b.jpg")||s(E,"src",B),s(E,"class","rounded-box"),s(E,"alt","Tailwind CSS component"),s(f,"class","carousel-item"),V(D.src,P="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg")||s(D,"src",P),s(D,"class","rounded-box"),s(D,"alt","Tailwind CSS component"),s(S,"class","carousel-item"),s(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(M,i){U(M,e,i),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),t(e,C),t(e,h),t(h,$),t(e,r),t(e,f),t(f,E),t(e,x),t(e,S),t(S,D)},p:ie,d(M){M&&o(e)}}}function ls(z){let e,d=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" />
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function as(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P,M;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("img"),T=k(),w=a("div"),_=a("img"),G=k(),I=a("div"),b=a("img"),C=k(),h=a("div"),$=a("a"),R=N("1"),r=k(),f=a("a"),E=N("2"),B=k(),x=a("a"),S=N("3"),D=k(),P=a("a"),M=N("4"),this.h()},l(i){e=c(i,"DIV",{class:!0});var y=g(e);d=c(y,"DIV",{id:!0,class:!0});var K=g(d);u=c(K,"IMG",{src:!0,class:!0,alt:!0}),K.forEach(o),n=j(y),m=c(y,"DIV",{id:!0,class:!0});var Y=g(m);l=c(Y,"IMG",{src:!0,class:!0,alt:!0}),Y.forEach(o),T=j(y),w=c(y,"DIV",{id:!0,class:!0});var J=g(w);_=c(J,"IMG",{src:!0,class:!0,alt:!0}),J.forEach(o),G=j(y),I=c(y,"DIV",{id:!0,class:!0});var q=g(I);b=c(q,"IMG",{src:!0,class:!0,alt:!0}),q.forEach(o),y.forEach(o),C=j(i),h=c(i,"DIV",{class:!0});var A=g(h);$=c(A,"A",{href:!0,class:!0});var L=g($);R=O(L,"1"),L.forEach(o),r=j(A),f=c(A,"A",{href:!0,class:!0});var me=g(f);E=O(me,"2"),me.forEach(o),B=j(A),x=c(A,"A",{href:!0,class:!0});var Q=g(x);S=O(Q,"3"),Q.forEach(o),D=j(A),P=c(A,"A",{href:!0,class:!0});var le=g(P);M=O(le,"4"),le.forEach(o),A.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg")||s(u,"src",p),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image gallery"),s(d,"id","item1"),s(d,"class","w-full carousel-item"),V(l.src,v="/images/stock/photo-1609621838510-5ad474b7d25d.jpg")||s(l,"src",v),s(l,"class","w-full"),s(l,"alt","Tailwind CSS image gallery"),s(m,"id","item2"),s(m,"class","w-full carousel-item"),V(_.src,F="/images/stock/photo-1414694762283-acccc27bca85.jpg")||s(_,"src",F),s(_,"class","w-full"),s(_,"alt","Tailwind CSS image gallery"),s(w,"id","item3"),s(w,"class","w-full carousel-item"),V(b.src,H="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg")||s(b,"src",H),s(b,"class","w-full"),s(b,"alt","Tailwind CSS image gallery"),s(I,"id","item4"),s(I,"class","w-full carousel-item"),s(e,"class","w-full carousel"),s($,"href","#item1"),s($,"class","btn btn-xs"),s(f,"href","#item2"),s(f,"class","btn btn-xs"),s(x,"href","#item3"),s(x,"class","btn btn-xs"),s(P,"href","#item4"),s(P,"class","btn btn-xs"),s(h,"class","flex justify-center w-full py-2 gap-2")},m(i,y){U(i,e,y),t(e,d),t(d,u),t(e,n),t(e,m),t(m,l),t(e,T),t(e,w),t(w,_),t(e,G),t(e,I),t(I,b),U(i,C,y),U(i,h,y),t(h,$),t($,R),t(h,r),t(h,f),t(f,E),t(h,B),t(h,x),t(x,S),t(h,D),t(h,P),t(P,M)},p:ie,d(i){i&&o(e),i&&o(C),i&&o(h)}}}function cs(z){let e,d=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function is(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R,r,f,E,B,x,S,D,P,M,i,y,K,Y,J,q,A,L,me,Q,le,we,Ie,de,ke;return{c(){e=a("div"),d=a("div"),u=a("img"),n=k(),m=a("div"),l=a("a"),v=N("❮"),T=k(),w=a("a"),_=N("❯"),F=k(),G=a("div"),I=a("img"),H=k(),C=a("div"),h=a("a"),$=N("❮"),R=k(),r=a("a"),f=N("❯"),E=k(),B=a("div"),x=a("img"),D=k(),P=a("div"),M=a("a"),i=N("❮"),y=k(),K=a("a"),Y=N("❯"),J=k(),q=a("div"),A=a("img"),me=k(),Q=a("div"),le=a("a"),we=N("❮"),Ie=k(),de=a("a"),ke=N("❯"),this.h()},l(fe){e=c(fe,"DIV",{class:!0});var ae=g(e);d=c(ae,"DIV",{id:!0,class:!0});var ne=g(d);u=c(ne,"IMG",{src:!0,class:!0,alt:!0}),n=j(ne),m=c(ne,"DIV",{class:!0});var ve=g(m);l=c(ve,"A",{href:!0,class:!0});var Ee=g(l);v=O(Ee,"❮"),Ee.forEach(o),T=j(ve),w=c(ve,"A",{href:!0,class:!0});var De=g(w);_=O(De,"❯"),De.forEach(o),ve.forEach(o),ne.forEach(o),F=j(ae),G=c(ae,"DIV",{id:!0,class:!0});var ge=g(G);I=c(ge,"IMG",{src:!0,class:!0,alt:!0}),H=j(ge),C=c(ge,"DIV",{class:!0});var pe=g(C);h=c(pe,"A",{href:!0,class:!0});var Se=g(h);$=O(Se,"❮"),Se.forEach(o),R=j(pe),r=c(pe,"A",{href:!0,class:!0});var Ve=g(r);f=O(Ve,"❯"),Ve.forEach(o),pe.forEach(o),ge.forEach(o),E=j(ae),B=c(ae,"DIV",{id:!0,class:!0});var he=g(B);x=c(he,"IMG",{src:!0,class:!0,alt:!0}),D=j(he),P=c(he,"DIV",{class:!0});var _e=g(P);M=c(_e,"A",{href:!0,class:!0});var Me=g(M);i=O(Me,"❮"),Me.forEach(o),y=j(_e),K=c(_e,"A",{href:!0,class:!0});var Ge=g(K);Y=O(Ge,"❯"),Ge.forEach(o),_e.forEach(o),he.forEach(o),J=j(ae),q=c(ae,"DIV",{id:!0,class:!0});var $e=g(q);A=c($e,"IMG",{src:!0,class:!0,alt:!0}),me=j($e),Q=c($e,"DIV",{class:!0});var be=g(Q);le=c(be,"A",{href:!0,class:!0});var Ce=g(le);we=O(Ce,"❮"),Ce.forEach(o),Ie=j(be),de=c(be,"A",{href:!0,class:!0});var xe=g(de);ke=O(xe,"❯"),xe.forEach(o),be.forEach(o),$e.forEach(o),ae.forEach(o),this.h()},h(){V(u.src,p="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg")||s(u,"src",p),s(u,"class","w-full"),s(u,"alt","Tailwind CSS image slide"),s(l,"href","#slide4"),s(l,"class","btn btn-circle"),s(w,"href","#slide2"),s(w,"class","btn btn-circle"),s(m,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(d,"id","slide1"),s(d,"class","relative w-full carousel-item"),V(I.src,b="/images/stock/photo-1609621838510-5ad474b7d25d.jpg")||s(I,"src",b),s(I,"class","w-full"),s(I,"alt","Tailwind CSS image slide"),s(h,"href","#slide1"),s(h,"class","btn btn-circle"),s(r,"href","#slide3"),s(r,"class","btn btn-circle"),s(C,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(G,"id","slide2"),s(G,"class","relative w-full carousel-item"),V(x.src,S="/images/stock/photo-1414694762283-acccc27bca85.jpg")||s(x,"src",S),s(x,"class","w-full"),s(x,"alt","Tailwind CSS image slide"),s(M,"href","#slide2"),s(M,"class","btn btn-circle"),s(K,"href","#slide4"),s(K,"class","btn btn-circle"),s(P,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(B,"id","slide3"),s(B,"class","relative w-full carousel-item"),V(A.src,L="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg")||s(A,"src",L),s(A,"class","w-full"),s(A,"alt","Tailwind CSS image slide"),s(le,"href","#slide3"),s(le,"class","btn btn-circle"),s(de,"href","#slide1"),s(de,"class","btn btn-circle"),s(Q,"class","absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"),s(q,"id","slide4"),s(q,"class","relative w-full carousel-item"),s(e,"class","w-full carousel")},m(fe,ae){U(fe,e,ae),t(e,d),t(d,u),t(d,n),t(d,m),t(m,l),t(l,v),t(m,T),t(m,w),t(w,_),t(e,F),t(e,G),t(G,I),t(G,H),t(G,C),t(C,h),t(h,$),t(C,R),t(C,r),t(r,f),t(e,E),t(e,B),t(B,x),t(B,D),t(B,P),t(P,M),t(M,i),t(P,y),t(P,K),t(K,Y),t(e,J),t(e,q),t(q,A),t(q,me),t(q,Q),t(Q,le),t(le,we),t(Q,Ie),t(Q,de),t(de,ke)},p:ie,d(fe){fe&&o(e)}}}function rs(z){let e,d=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">❮</a> 
      <a href="#slide2" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">❮</a> 
      <a href="#slide3" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">❮</a> 
      <a href="#slide4" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">❮</a> 
      <a href="#slide1" class="btn btn-circle">❯</a>
    </div>
  </div>
</div>`,u,p,n,m;return{c(){e=a("pre"),u=N(d),this.h()},l(l){e=c(l,"PRE",{slot:!0});var v=g(e);u=O(v,d),v.forEach(o),this.h()},h(){s(e,"slot","html")},m(l,v){U(l,e,v),t(e,u),n||(m=re(p=ue.call(null,e,{to:z[0]})),n=!0)},p(l,v){p&&oe(p.update)&&v&1&&p.update.call(null,{to:l[0]})},d(l){l&&o(e),n=!1,m()}}}function os(z){let e,d,u,p,n,m,l,v,T,w,_,F,G,I,b,H,C,h,$,R;return e=new Ke({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),u=new ce({props:{title:"Snap to start (default)",$$slots:{html:[Ye],default:[Ue]},$$scope:{ctx:z}}}),n=new ce({props:{title:"Snap to center",$$slots:{html:[Le],default:[Je]},$$scope:{ctx:z}}}),l=new ce({props:{title:"Snap to end",$$slots:{html:[Oe],default:[Ne]},$$scope:{ctx:z}}}),T=new ce({props:{title:"Carousel with full width items",$$slots:{html:[We],default:[Qe]},$$scope:{ctx:z}}}),_=new ce({props:{title:"Vertical carousel",$$slots:{html:[Ze],default:[Xe]},$$scope:{ctx:z}}}),G=new ce({props:{title:"Carousel with half width items",$$slots:{html:[ss],default:[es]},$$scope:{ctx:z}}}),b=new ce({props:{title:"Full-bleed carousel",$$slots:{html:[ls],default:[ts]},$$scope:{ctx:z}}}),C=new ce({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[cs],default:[as]},$$scope:{ctx:z}}}),$=new ce({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[rs],default:[is]},$$scope:{ctx:z}}}),{c(){W(e.$$.fragment),d=k(),W(u.$$.fragment),p=k(),W(n.$$.fragment),m=k(),W(l.$$.fragment),v=k(),W(T.$$.fragment),w=k(),W(_.$$.fragment),F=k(),W(G.$$.fragment),I=k(),W(b.$$.fragment),H=k(),W(C.$$.fragment),h=k(),W($.$$.fragment)},l(r){X(e.$$.fragment,r),d=j(r),X(u.$$.fragment,r),p=j(r),X(n.$$.fragment,r),m=j(r),X(l.$$.fragment,r),v=j(r),X(T.$$.fragment,r),w=j(r),X(_.$$.fragment,r),F=j(r),X(G.$$.fragment,r),I=j(r),X(b.$$.fragment,r),H=j(r),X(C.$$.fragment,r),h=j(r),X($.$$.fragment,r)},m(r,f){Z(e,r,f),U(r,d,f),Z(u,r,f),U(r,p,f),Z(n,r,f),U(r,m,f),Z(l,r,f),U(r,v,f),Z(T,r,f),U(r,w,f),Z(_,r,f),U(r,F,f),Z(G,r,f),U(r,I,f),Z(b,r,f),U(r,H,f),Z(C,r,f),U(r,h,f),Z($,r,f),R=!0},p(r,f){const E={};f&5&&(E.$$scope={dirty:f,ctx:r}),u.$set(E);const B={};f&5&&(B.$$scope={dirty:f,ctx:r}),n.$set(B);const x={};f&5&&(x.$$scope={dirty:f,ctx:r}),l.$set(x);const S={};f&5&&(S.$$scope={dirty:f,ctx:r}),T.$set(S);const D={};f&5&&(D.$$scope={dirty:f,ctx:r}),_.$set(D);const P={};f&5&&(P.$$scope={dirty:f,ctx:r}),G.$set(P);const M={};f&5&&(M.$$scope={dirty:f,ctx:r}),b.$set(M);const i={};f&5&&(i.$$scope={dirty:f,ctx:r}),C.$set(i);const y={};f&5&&(y.$$scope={dirty:f,ctx:r}),$.$set(y)},i(r){R||(ee(e.$$.fragment,r),ee(u.$$.fragment,r),ee(n.$$.fragment,r),ee(l.$$.fragment,r),ee(T.$$.fragment,r),ee(_.$$.fragment,r),ee(G.$$.fragment,r),ee(b.$$.fragment,r),ee(C.$$.fragment,r),ee($.$$.fragment,r),R=!0)},o(r){se(e.$$.fragment,r),se(u.$$.fragment,r),se(n.$$.fragment,r),se(l.$$.fragment,r),se(T.$$.fragment,r),se(_.$$.fragment,r),se(G.$$.fragment,r),se(b.$$.fragment,r),se(C.$$.fragment,r),se($.$$.fragment,r),R=!1},d(r){te(e,r),r&&o(d),te(u,r),r&&o(p),te(n,r),r&&o(m),te(l,r),r&&o(v),te(T,r),r&&o(w),te(_,r),r&&o(F),te(G,r),r&&o(I),te(b,r),r&&o(H),te(C,r),r&&o(h),te($,r)}}}function us(z){let e,d;const u=[z[1],Pe];let p={$$slots:{default:[os]},$$scope:{ctx:z}};for(let n=0;n<u.length;n+=1)p=je(p,u[n]);return e=new Fe({props:p}),{c(){W(e.$$.fragment)},l(n){X(e.$$.fragment,n)},m(n,m){Z(e,n,m),d=!0},p(n,[m]){const l=m&2?Re(u,[m&2&&Te(n[1]),m&0&&Te(Pe)]):{};m&5&&(l.$$scope={dirty:m,ctx:n}),e.$set(l)},i(n){d||(ee(e.$$.fragment,n),d=!0)},o(n){se(e.$$.fragment,n),d=!1},d(n){te(e,n)}}}const Pe={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0};function ds(z,e,d){let u;return qe(z,He,p=>d(0,u=p)),z.$$set=p=>{d(1,e=je(je({},e),ze(p)))},e=ze(e),[u,e]}class vs extends ye{constructor(e){super(),Be(this,e,ds,us,Ae,{})}}export{vs as component};
