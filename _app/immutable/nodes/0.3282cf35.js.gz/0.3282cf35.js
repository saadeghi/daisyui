import{L as e,_ as n}from"../chunks/0.10ed8a6b.js";export{e as component,n as universal};
