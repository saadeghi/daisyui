import{L as e,_ as n}from"../chunks/0._4KFP-i5.js";export{e as component,n as universal};
