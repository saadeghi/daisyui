import{S as ye,i as we,s as Ve,M as fe,y as ee,z as te,A as ae,U as ke,$ as Ie,g as se,d as le,B as ce,H as Ce,Y as Ee,a as y,c as w,b as G,h as s,k as d,q as m,l as n,m as v,r as p,n as h,E as t,F as ne,a9 as he,a4 as ve,K as de}from"../chunks/index.b33eaa49.js";import{M as xe}from"../chunks/mdsvex.c9625843.js";import{p as Me,C as je,a as re,r as ue}from"../chunks/ClassTable.a9940f02.js";function Ae(V){let e,l,i,u,o,f,c,r,_,I;return{c(){e=d("div"),l=d("div"),i=d("div"),u=m("It's over Anakin, "),o=d("br"),f=m("I have the high ground."),c=y(),r=d("div"),_=d("div"),I=m("You underestimate my power!"),this.h()},l($){e=n($,"DIV",{class:!0});var E=v(e);l=n(E,"DIV",{class:!0});var a=v(l);i=n(a,"DIV",{class:!0});var b=v(i);u=p(b,"It's over Anakin, "),o=n(b,"BR",{}),f=p(b,"I have the high ground."),b.forEach(s),a.forEach(s),c=w(E),r=n(E,"DIV",{class:!0});var k=v(r);_=n(k,"DIV",{class:!0});var x=v(_);I=p(x,"You underestimate my power!"),x.forEach(s),k.forEach(s),E.forEach(s),this.h()},h(){h(i,"class","chat-bubble"),h(l,"class","chat chat-start"),h(_,"class","chat-bubble"),h(r,"class","chat chat-end"),h(e,"class","w-full")},m($,E){G($,e,E),t(e,l),t(l,i),t(i,u),t(i,o),t(i,f),t(e,c),t(e,r),t(r,_),t(_,I)},p:ne,d($){$&&s(e)}}}function Oe(V){let e,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble">It's over Anakin, <br/>I have the high ground.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble">You underestimate my power!</div>
</div>`,i,u,o,f;return{c(){e=d("pre"),i=m(l),this.h()},l(c){e=n(c,"PRE",{slot:!0});var r=v(e);i=p(r,l),r.forEach(s),this.h()},h(){h(e,"slot","html")},m(c,r){G(c,e,r),t(e,i),o||(f=he(u=ue.call(null,e,{to:V[0]})),o=!0)},p(c,r){u&&ve(u.update)&&r&1&&u.update.call(null,{to:c[0]})},d(c){c&&s(e),o=!1,f()}}}function Ye(V){let e,l,i,u,o,f,c,r,_,I,$,E,a,b,k,x,M,W,D,C,S,O,Y,B,T,j,A;return{c(){e=d("div"),l=d("div"),i=d("div"),u=d("div"),o=d("img"),c=y(),r=d("div"),_=m("It was said that you would, destroy the Sith, not join them."),I=y(),$=d("div"),E=d("div"),a=d("div"),b=d("img"),x=y(),M=d("div"),W=m("It was you who would bring balance to the Force"),D=y(),C=d("div"),S=d("div"),O=d("div"),Y=d("img"),T=y(),j=d("div"),A=m("Not leave it in Darkness"),this.h()},l(P){e=n(P,"DIV",{class:!0});var K=v(e);l=n(K,"DIV",{class:!0});var g=v(l);i=n(g,"DIV",{class:!0});var H=v(i);u=n(H,"DIV",{class:!0});var F=v(u);o=n(F,"IMG",{src:!0}),F.forEach(s),H.forEach(s),c=w(g),r=n(g,"DIV",{class:!0});var R=v(r);_=p(R,"It was said that you would, destroy the Sith, not join them."),R.forEach(s),g.forEach(s),I=w(K),$=n(K,"DIV",{class:!0});var J=v($);E=n(J,"DIV",{class:!0});var N=v(E);a=n(N,"DIV",{class:!0});var q=v(a);b=n(q,"IMG",{src:!0}),q.forEach(s),N.forEach(s),x=w(J),M=n(J,"DIV",{class:!0});var z=v(M);W=p(z,"It was you who would bring balance to the Force"),z.forEach(s),J.forEach(s),D=w(K),C=n(K,"DIV",{class:!0});var L=v(C);S=n(L,"DIV",{class:!0});var X=v(S);O=n(X,"DIV",{class:!0});var Q=v(O);Y=n(Q,"IMG",{src:!0}),Q.forEach(s),X.forEach(s),T=w(L),j=n(L,"DIV",{class:!0});var Z=v(j);A=p(Z,"Not leave it in Darkness"),Z.forEach(s),L.forEach(s),K.forEach(s),this.h()},h(){de(o.src,f="/images/stock/photo-1534528741775-53994a69daeb.jpg")||h(o,"src",f),h(u,"class","w-10 rounded-full"),h(i,"class","chat-image avatar"),h(r,"class","chat-bubble"),h(l,"class","chat chat-start"),de(b.src,k="/images/stock/photo-1534528741775-53994a69daeb.jpg")||h(b,"src",k),h(a,"class","w-10 rounded-full"),h(E,"class","chat-image avatar"),h(M,"class","chat-bubble"),h($,"class","chat chat-start"),de(Y.src,B="/images/stock/photo-1534528741775-53994a69daeb.jpg")||h(Y,"src",B),h(O,"class","w-10 rounded-full"),h(S,"class","chat-image avatar"),h(j,"class","chat-bubble"),h(C,"class","chat chat-start"),h(e,"class","w-full")},m(P,K){G(P,e,K),t(e,l),t(l,i),t(i,u),t(u,o),t(l,c),t(l,r),t(r,_),t(e,I),t(e,$),t($,E),t(E,a),t(a,b),t($,x),t($,M),t(M,W),t(e,D),t(e,C),t(C,S),t(S,O),t(O,Y),t(C,T),t(C,j),t(j,A)},p:ne,d(P){P&&s(e)}}}function We(V){let e,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was said that you would, destroy the Sith, not join them.</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was you who would bring balance to the Force</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">Not leave it in Darkness</div>
</div>`,i,u,o,f;return{c(){e=d("pre"),i=m(l),this.h()},l(c){e=n(c,"PRE",{slot:!0});var r=v(e);i=p(r,l),r.forEach(s),this.h()},h(){h(e,"slot","html")},m(c,r){G(c,e,r),t(e,i),o||(f=he(u=ue.call(null,e,{to:V[0]})),o=!0)},p(c,r){u&&ve(u.update)&&r&1&&u.update.call(null,{to:c[0]})},d(c){c&&s(e),o=!1,f()}}}function Se(V){let e,l,i,u,o,f,c,r,_,I,$,E,a,b,k,x,M,W,D,C,S,O,Y,B,T,j,A,P,K,g,H,F,R,J;return{c(){e=d("div"),l=d("div"),i=d("div"),u=d("div"),o=d("img"),c=y(),r=d("div"),_=m(`Obi-Wan Kenobi
      `),I=d("time"),$=m("12:45"),E=y(),a=d("div"),b=m("You were the Chosen One!"),k=y(),x=d("div"),M=m("Delivered"),W=y(),D=d("div"),C=d("div"),S=d("div"),O=d("img"),B=y(),T=d("div"),j=m(`Anakin
      `),A=d("time"),P=m("12:46"),K=y(),g=d("div"),H=m("I hate you!"),F=y(),R=d("div"),J=m("Seen at 12:46"),this.h()},l(N){e=n(N,"DIV",{class:!0});var q=v(e);l=n(q,"DIV",{class:!0});var z=v(l);i=n(z,"DIV",{class:!0});var L=v(i);u=n(L,"DIV",{class:!0});var X=v(u);o=n(X,"IMG",{src:!0}),X.forEach(s),L.forEach(s),c=w(z),r=n(z,"DIV",{class:!0});var Q=v(r);_=p(Q,`Obi-Wan Kenobi
      `),I=n(Q,"TIME",{class:!0});var Z=v(I);$=p(Z,"12:45"),Z.forEach(s),Q.forEach(s),E=w(z),a=n(z,"DIV",{class:!0});var ie=v(a);b=p(ie,"You were the Chosen One!"),ie.forEach(s),k=w(z),x=n(z,"DIV",{class:!0});var oe=v(x);M=p(oe,"Delivered"),oe.forEach(s),z.forEach(s),W=w(q),D=n(q,"DIV",{class:!0});var U=v(D);C=n(U,"DIV",{class:!0});var $e=v(C);S=n($e,"DIV",{class:!0});var me=v(S);O=n(me,"IMG",{src:!0}),me.forEach(s),$e.forEach(s),B=w(U),T=n(U,"DIV",{class:!0});var be=v(T);j=p(be,`Anakin
      `),A=n(be,"TIME",{class:!0});var pe=v(A);P=p(pe,"12:46"),pe.forEach(s),be.forEach(s),K=w(U),g=n(U,"DIV",{class:!0});var _e=v(g);H=p(_e,"I hate you!"),_e.forEach(s),F=w(U),R=n(U,"DIV",{class:!0});var ge=v(R);J=p(ge,"Seen at 12:46"),ge.forEach(s),U.forEach(s),q.forEach(s),this.h()},h(){de(o.src,f="/images/stock/photo-1534528741775-53994a69daeb.jpg")||h(o,"src",f),h(u,"class","w-10 rounded-full"),h(i,"class","chat-image avatar"),h(I,"class","text-xs opacity-50"),h(r,"class","chat-header"),h(a,"class","chat-bubble"),h(x,"class","chat-footer opacity-50"),h(l,"class","chat chat-start"),de(O.src,Y="/images/stock/photo-1534528741775-53994a69daeb.jpg")||h(O,"src",Y),h(S,"class","w-10 rounded-full"),h(C,"class","chat-image avatar"),h(A,"class","text-xs opacity-50"),h(T,"class","chat-header"),h(g,"class","chat-bubble"),h(R,"class","chat-footer opacity-50"),h(D,"class","chat chat-end"),h(e,"class","w-full")},m(N,q){G(N,e,q),t(e,l),t(l,i),t(i,u),t(u,o),t(l,c),t(l,r),t(r,_),t(r,I),t(I,$),t(l,E),t(l,a),t(a,b),t(l,k),t(l,x),t(x,M),t(e,W),t(e,D),t(D,C),t(C,S),t(S,O),t(D,B),t(D,T),t(T,j),t(T,A),t(A,P),t(D,K),t(D,g),t(g,H),t(D,F),t(D,R),t(R,J)},p:ne,d(N){N&&s(e)}}}function Te(V){let e,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">12:45</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Anakin
    <time class="text-xs opacity-50">12:46</time>
  </div>
  <div class="$$chat-bubble">I hate you!</div>
  <div class="$$chat-footer opacity-50">
    Seen at 12:46
  </div>
</div>`,i,u,o,f;return{c(){e=d("pre"),i=m(l),this.h()},l(c){e=n(c,"PRE",{slot:!0});var r=v(e);i=p(r,l),r.forEach(s),this.h()},h(){h(e,"slot","html")},m(c,r){G(c,e,r),t(e,i),o||(f=he(u=ue.call(null,e,{to:V[0]})),o=!0)},p(c,r){u&&ve(u.update)&&r&1&&u.update.call(null,{to:c[0]})},d(c){c&&s(e),o=!1,f()}}}function Ke(V){let e,l,i,u,o,f,c,r,_,I,$,E,a,b,k,x,M,W,D,C,S,O,Y,B;return{c(){e=d("div"),l=d("div"),i=d("div"),u=m(`Obi-Wan Kenobi
      `),o=d("time"),f=m("2 hours ago"),c=y(),r=d("div"),_=m("You were my brother, Anakin."),I=y(),$=d("div"),E=m("Seen"),a=y(),b=d("div"),k=d("div"),x=m(`Obi-Wan Kenobi
      `),M=d("time"),W=m("2 hour ago"),D=y(),C=d("div"),S=m("I loved you."),O=y(),Y=d("div"),B=m("Delivered"),this.h()},l(T){e=n(T,"DIV",{class:!0});var j=v(e);l=n(j,"DIV",{class:!0});var A=v(l);i=n(A,"DIV",{class:!0});var P=v(i);u=p(P,`Obi-Wan Kenobi
      `),o=n(P,"TIME",{class:!0});var K=v(o);f=p(K,"2 hours ago"),K.forEach(s),P.forEach(s),c=w(A),r=n(A,"DIV",{class:!0});var g=v(r);_=p(g,"You were my brother, Anakin."),g.forEach(s),I=w(A),$=n(A,"DIV",{class:!0});var H=v($);E=p(H,"Seen"),H.forEach(s),A.forEach(s),a=w(j),b=n(j,"DIV",{class:!0});var F=v(b);k=n(F,"DIV",{class:!0});var R=v(k);x=p(R,`Obi-Wan Kenobi
      `),M=n(R,"TIME",{class:!0});var J=v(M);W=p(J,"2 hour ago"),J.forEach(s),R.forEach(s),D=w(F),C=n(F,"DIV",{class:!0});var N=v(C);S=p(N,"I loved you."),N.forEach(s),O=w(F),Y=n(F,"DIV",{class:!0});var q=v(Y);B=p(q,"Delivered"),q.forEach(s),F.forEach(s),j.forEach(s),this.h()},h(){h(o,"class","text-xs opacity-50"),h(i,"class","chat-header"),h(r,"class","chat-bubble"),h($,"class","chat-footer opacity-50"),h(l,"class","chat chat-start"),h(M,"class","text-xs opacity-50"),h(k,"class","chat-header"),h(C,"class","chat-bubble"),h(Y,"class","chat-footer opacity-50"),h(b,"class","chat chat-start"),h(e,"class","w-full")},m(T,j){G(T,e,j),t(e,l),t(l,i),t(i,u),t(i,o),t(o,f),t(l,c),t(l,r),t(r,_),t(l,I),t(l,$),t($,E),t(e,a),t(e,b),t(b,k),t(k,x),t(k,M),t(M,W),t(b,D),t(b,C),t(C,S),t(b,O),t(b,Y),t(Y,B)},p:ne,d(T){T&&s(e)}}}function Pe(V){let e,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hours ago</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Seen
  </div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hour ago</time>
  </div>
  <div class="$$chat-bubble">I loved you.</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>`,i,u,o,f;return{c(){e=d("pre"),i=m(l),this.h()},l(c){e=n(c,"PRE",{slot:!0});var r=v(e);i=p(r,l),r.forEach(s),this.h()},h(){h(e,"slot","html")},m(c,r){G(c,e,r),t(e,i),o||(f=he(u=ue.call(null,e,{to:V[0]})),o=!0)},p(c,r){u&&ve(u.update)&&r&1&&u.update.call(null,{to:c[0]})},d(c){c&&s(e),o=!1,f()}}}function Fe(V){let e,l,i,u,o,f,c,r,_,I,$,E,a,b,k,x,M,W,D,C,S,O,Y,B,T,j,A,P;return{c(){e=d("div"),l=d("div"),i=d("div"),u=m("What kind of nonsense is this"),o=y(),f=d("div"),c=d("div"),r=m("Put me on the Council and not make me a Master!??"),_=y(),I=d("div"),$=d("div"),E=m("That's never been done in the history of the Jedi. It's insulting!"),a=y(),b=d("div"),k=d("div"),x=m("Calm down, Anakin."),M=y(),W=d("div"),D=d("div"),C=m("You have been given a great honor."),S=y(),O=d("div"),Y=d("div"),B=m("To be on the Council at your age."),T=y(),j=d("div"),A=d("div"),P=m("It's never happened before."),this.h()},l(K){e=n(K,"DIV",{class:!0});var g=v(e);l=n(g,"DIV",{class:!0});var H=v(l);i=n(H,"DIV",{class:!0});var F=v(i);u=p(F,"What kind of nonsense is this"),F.forEach(s),H.forEach(s),o=w(g),f=n(g,"DIV",{class:!0});var R=v(f);c=n(R,"DIV",{class:!0});var J=v(c);r=p(J,"Put me on the Council and not make me a Master!??"),J.forEach(s),R.forEach(s),_=w(g),I=n(g,"DIV",{class:!0});var N=v(I);$=n(N,"DIV",{class:!0});var q=v($);E=p(q,"That's never been done in the history of the Jedi. It's insulting!"),q.forEach(s),N.forEach(s),a=w(g),b=n(g,"DIV",{class:!0});var z=v(b);k=n(z,"DIV",{class:!0});var L=v(k);x=p(L,"Calm down, Anakin."),L.forEach(s),z.forEach(s),M=w(g),W=n(g,"DIV",{class:!0});var X=v(W);D=n(X,"DIV",{class:!0});var Q=v(D);C=p(Q,"You have been given a great honor."),Q.forEach(s),X.forEach(s),S=w(g),O=n(g,"DIV",{class:!0});var Z=v(O);Y=n(Z,"DIV",{class:!0});var ie=v(Y);B=p(ie,"To be on the Council at your age."),ie.forEach(s),Z.forEach(s),T=w(g),j=n(g,"DIV",{class:!0});var oe=v(j);A=n(oe,"DIV",{class:!0});var U=v(A);P=p(U,"It's never happened before."),U.forEach(s),oe.forEach(s),g.forEach(s),this.h()},h(){h(i,"class","chat-bubble chat-bubble-primary"),h(l,"class","chat chat-start"),h(c,"class","chat-bubble chat-bubble-secondary"),h(f,"class","chat chat-start"),h($,"class","chat-bubble chat-bubble-accent"),h(I,"class","chat chat-start"),h(k,"class","chat-bubble chat-bubble-info"),h(b,"class","chat chat-end"),h(D,"class","chat-bubble chat-bubble-success"),h(W,"class","chat chat-end"),h(Y,"class","chat-bubble chat-bubble-warning"),h(O,"class","chat chat-end"),h(A,"class","chat-bubble chat-bubble-error"),h(j,"class","chat chat-end"),h(e,"class","w-full")},m(K,g){G(K,e,g),t(e,l),t(l,i),t(i,u),t(e,o),t(e,f),t(f,c),t(c,r),t(e,_),t(e,I),t(I,$),t($,E),t(e,a),t(e,b),t(b,k),t(k,x),t(e,M),t(e,W),t(W,D),t(D,C),t(e,S),t(e,O),t(O,Y),t(Y,B),t(e,T),t(e,j),t(j,A),t(A,P)},p:ne,d(K){K&&s(e)}}}function Re(V){let e,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-primary">What kind of nonsense is this</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-secondary">Put me on the Council and not make me a Master!??</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-accent">That's never been done in the history of the Jedi. It's insulting!</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-info">Calm down, Anakin.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-success">You have been given a great honor.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-warning">To be on the Council at your age.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-error">It's never happened before.</div>
</div>`,i,u,o,f;return{c(){e=d("pre"),i=m(l),this.h()},l(c){e=n(c,"PRE",{slot:!0});var r=v(e);i=p(r,l),r.forEach(s),this.h()},h(){h(e,"slot","html")},m(c,r){G(c,e,r),t(e,i),o||(f=he(u=ue.call(null,e,{to:V[0]})),o=!0)},p(c,r){u&&ve(u.update)&&r&1&&u.update.call(null,{to:c[0]})},d(c){c&&s(e),o=!1,f()}}}function qe(V){let e,l,i,u,o,f,c,r,_,I,$,E;return e=new je({props:{data:[{type:"component",class:"chat",desc:"Container for one line of conversation and all its data"},{type:"modifier",class:"chat-start",desc:"Aligns `chat` to left (required)"},{type:"modifier",class:"chat-end",desc:"Aligns `chat` to end (required)"},{type:"component",class:"chat-image",desc:"For the author image"},{type:"component",class:"chat-header",desc:"For the line above the chat bubble"},{type:"component",class:"chat-footer",desc:"For the line below the chat bubble"},{type:"component",class:"chat-bubble",desc:"For the content of chat"},{type:"modifier",class:"chat-bubble-primary",desc:"sets `primary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-secondary",desc:"sets `secondary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-accent",desc:"sets `accent` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-info",desc:"sets `info` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-success",desc:"sets `success` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-warning",desc:"sets `warning` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-error",desc:"sets `error` color for the `chat-bubble`"}]}}),i=new re({props:{title:"chat-start and chat-end",$$slots:{html:[Oe],default:[Ae]},$$scope:{ctx:V}}}),o=new re({props:{title:"Chat with image",$$slots:{html:[We],default:[Ye]},$$scope:{ctx:V}}}),c=new re({props:{title:"Chat with image, header and footer",$$slots:{html:[Te],default:[Se]},$$scope:{ctx:V}}}),_=new re({props:{title:"Chat with header and footer",$$slots:{html:[Pe],default:[Ke]},$$scope:{ctx:V}}}),$=new re({props:{title:"Chat Bubble with colors",$$slots:{html:[Re],default:[Fe]},$$scope:{ctx:V}}}),{c(){ee(e.$$.fragment),l=y(),ee(i.$$.fragment),u=y(),ee(o.$$.fragment),f=y(),ee(c.$$.fragment),r=y(),ee(_.$$.fragment),I=y(),ee($.$$.fragment)},l(a){te(e.$$.fragment,a),l=w(a),te(i.$$.fragment,a),u=w(a),te(o.$$.fragment,a),f=w(a),te(c.$$.fragment,a),r=w(a),te(_.$$.fragment,a),I=w(a),te($.$$.fragment,a)},m(a,b){ae(e,a,b),G(a,l,b),ae(i,a,b),G(a,u,b),ae(o,a,b),G(a,f,b),ae(c,a,b),G(a,r,b),ae(_,a,b),G(a,I,b),ae($,a,b),E=!0},p(a,b){const k={};b&5&&(k.$$scope={dirty:b,ctx:a}),i.$set(k);const x={};b&5&&(x.$$scope={dirty:b,ctx:a}),o.$set(x);const M={};b&5&&(M.$$scope={dirty:b,ctx:a}),c.$set(M);const W={};b&5&&(W.$$scope={dirty:b,ctx:a}),_.$set(W);const D={};b&5&&(D.$$scope={dirty:b,ctx:a}),$.$set(D)},i(a){E||(se(e.$$.fragment,a),se(i.$$.fragment,a),se(o.$$.fragment,a),se(c.$$.fragment,a),se(_.$$.fragment,a),se($.$$.fragment,a),E=!0)},o(a){le(e.$$.fragment,a),le(i.$$.fragment,a),le(o.$$.fragment,a),le(c.$$.fragment,a),le(_.$$.fragment,a),le($.$$.fragment,a),E=!1},d(a){ce(e,a),a&&s(l),ce(i,a),a&&s(u),ce(o,a),a&&s(f),ce(c,a),a&&s(r),ce(_,a),a&&s(I),ce($,a)}}}function Ge(V){let e,l;const i=[V[1],De];let u={$$slots:{default:[qe]},$$scope:{ctx:V}};for(let o=0;o<i.length;o+=1)u=fe(u,i[o]);return e=new xe({props:u}),{c(){ee(e.$$.fragment)},l(o){te(e.$$.fragment,o)},m(o,f){ae(e,o,f),l=!0},p(o,[f]){const c=f&2?ke(i,[f&2&&Ie(o[1]),f&0&&Ie(De)]):{};f&5&&(c.$$scope={dirty:f,ctx:o}),e.$set(c)},i(o){l||(se(e.$$.fragment,o),l=!0)},o(o){le(e.$$.fragment,o),l=!1},d(o){ce(e,o)}}}const De={title:"Chat bubble",desc:"Chat bubbles are used to show one line of conversation and all its data, including the author image, author name, time, etc.",published:!0};function Be(V,e,l){let i;return Ce(V,Me,u=>l(0,i=u)),V.$$set=u=>{l(1,e=fe(fe({},e),Ee(u)))},e=Ee(e),[i,e]}class He extends ye{constructor(e){super(),we(this,e,Be,Ge,Ve,{})}}export{He as component};
