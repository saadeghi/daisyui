import{S as Jt,i as Ct,s as Lt,M as jt,y as nt,z as ut,A as $t,U as St,$ as Ut,g as ht,d as ft,B as mt,H as At,Y as Pt,a as w,c as g,b as X,h as a,k as c,q as m,l as o,m as i,r as p,n as e,E as t,F as _t,a9 as wt,a4 as gt,C as ot,D as vt,K as Ot}from"../chunks/index.b33eaa49.js";import{M as Wt}from"../chunks/mdsvex.d34811e6.js";import{p as qt,C as Gt,a as pt,r as Et}from"../chunks/ClassTable.66318024.js";function Ht(R){let s,l,v,u,n,h,r,$,D,y;return{c(){s=c("div"),l=c("div"),v=c("div"),u=m("Total Page Views"),n=w(),h=c("div"),r=m("89,400"),$=w(),D=c("div"),y=m("21% more than last month"),this.h()},l(M){s=o(M,"DIV",{class:!0});var V=i(s);l=o(V,"DIV",{class:!0});var _=i(l);v=o(_,"DIV",{class:!0});var K=i(v);u=p(K,"Total Page Views"),K.forEach(a),n=g(_),h=o(_,"DIV",{class:!0});var B=i(h);r=p(B,"89,400"),B.forEach(a),$=g(_),D=o(_,"DIV",{class:!0});var E=i(D);y=p(E,"21% more than last month"),E.forEach(a),_.forEach(a),V.forEach(a),this.h()},h(){e(v,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(s,"class","shadow stats")},m(M,V){X(M,s,V),t(s,l),t(l,v),t(v,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y)},p:_t,d(M){M&&a(s)}}}function Yt(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Total Page Views</div>
    <div class="$$stat-value">89,400</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function Qt(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A,U,J,O,L,N,P,k,x,q,G,H,z,W,tt,Z,S,st,Y,Q;return{c(){s=c("div"),l=c("div"),v=c("div"),u=ot("svg"),n=ot("path"),h=w(),r=c("div"),$=m("Total Likes"),D=w(),y=c("div"),M=m("25.6K"),V=w(),_=c("div"),K=m("21% more than last month"),B=w(),E=c("div"),d=c("div"),f=ot("svg"),b=ot("path"),C=w(),j=c("div"),I=m("Page Views"),F=w(),T=c("div"),A=m("2.6M"),U=w(),J=c("div"),O=m("21% more than last month"),L=w(),N=c("div"),P=c("div"),k=c("div"),x=c("div"),q=c("img"),H=w(),z=c("div"),W=m("86%"),tt=w(),Z=c("div"),S=m("Tasks done"),st=w(),Y=c("div"),Q=m("31 tasks remaining"),this.h()},l(et){s=o(et,"DIV",{class:!0});var at=i(s);l=o(at,"DIV",{class:!0});var lt=i(l);v=o(lt,"DIV",{class:!0});var Vt=i(v);u=vt(Vt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var Dt=i(u);n=vt(Dt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(n).forEach(a),Dt.forEach(a),Vt.forEach(a),h=g(lt),r=o(lt,"DIV",{class:!0});var It=i(r);$=p(It,"Total Likes"),It.forEach(a),D=g(lt),y=o(lt,"DIV",{class:!0});var it=i(y);M=p(it,"25.6K"),it.forEach(a),V=g(lt),_=o(lt,"DIV",{class:!0});var kt=i(_);K=p(kt,"21% more than last month"),kt.forEach(a),lt.forEach(a),B=g(at),E=o(at,"DIV",{class:!0});var dt=i(E);d=o(dt,"DIV",{class:!0});var bt=i(d);f=vt(bt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var xt=i(f);b=vt(xt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),xt.forEach(a),bt.forEach(a),C=g(dt),j=o(dt,"DIV",{class:!0});var yt=i(j);I=p(yt,"Page Views"),yt.forEach(a),F=g(dt),T=o(dt,"DIV",{class:!0});var rt=i(T);A=p(rt,"2.6M"),rt.forEach(a),U=g(dt),J=o(dt,"DIV",{class:!0});var Nt=i(J);O=p(Nt,"21% more than last month"),Nt.forEach(a),dt.forEach(a),L=g(at),N=o(at,"DIV",{class:!0});var ct=i(N);P=o(ct,"DIV",{class:!0});var Mt=i(P);k=o(Mt,"DIV",{class:!0});var Rt=i(k);x=o(Rt,"DIV",{class:!0});var Bt=i(x);q=o(Bt,"IMG",{src:!0}),Bt.forEach(a),Rt.forEach(a),Mt.forEach(a),H=g(ct),z=o(ct,"DIV",{class:!0});var Ft=i(z);W=p(Ft,"86%"),Ft.forEach(a),tt=g(ct),Z=o(ct,"DIV",{class:!0});var Tt=i(Z);S=p(Tt,"Tasks done"),Tt.forEach(a),st=g(ct),Y=o(ct,"DIV",{class:!0});var Kt=i(Y);Q=p(Kt,"31 tasks remaining"),Kt.forEach(a),ct.forEach(a),at.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(v,"class","stat-figure text-primary"),e(r,"class","stat-title"),e(y,"class","stat-value text-primary"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M13 10V3L4 14h7v7l9-11h-7z"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(j,"class","stat-title"),e(T,"class","stat-value text-secondary"),e(J,"class","stat-desc"),e(E,"class","stat"),Ot(q.src,G="/images/stock/photo-1534528741775-53994a69daeb.jpg")||e(q,"src",G),e(x,"class","w-16 rounded-full"),e(k,"class","avatar online"),e(P,"class","stat-figure text-secondary"),e(z,"class","stat-value"),e(Z,"class","stat-title"),e(Y,"class","stat-desc text-secondary"),e(N,"class","stat"),e(s,"class","shadow stats")},m(et,at){X(et,s,at),t(s,l),t(l,v),t(v,u),t(u,n),t(l,h),t(l,r),t(r,$),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,K),t(s,B),t(s,E),t(E,d),t(d,f),t(f,b),t(E,C),t(E,j),t(j,I),t(E,F),t(E,T),t(T,A),t(E,U),t(E,J),t(J,O),t(s,L),t(s,N),t(N,P),t(P,k),t(k,x),t(x,q),t(N,H),t(N,z),t(z,W),t(N,tt),t(N,Z),t(Z,S),t(N,st),t(N,Y),t(Y,Q)},p:_t,d(et){et&&a(s)}}}function Xt(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="$$stat-title">Total Likes</div>
    <div class="$$stat-value text-primary">25.6K</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="$$stat-title">Page Views</div>
    <div class="$$stat-value text-secondary">2.6M</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <div class="$$avatar $$online">
        <div class="w-16 rounded-full">
          <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
        </div>
      </div>
    </div>
    <div class="$$stat-value">86%</div>
    <div class="$$stat-title">Tasks done</div>
    <div class="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function Zt(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A,U,J,O,L,N,P,k,x,q,G,H,z,W,tt,Z,S,st;return{c(){s=c("div"),l=c("div"),v=c("div"),u=ot("svg"),n=ot("path"),h=w(),r=c("div"),$=m("Downloads"),D=w(),y=c("div"),M=m("31K"),V=w(),_=c("div"),K=m("Jan 1st - Feb 1st"),B=w(),E=c("div"),d=c("div"),f=ot("svg"),b=ot("path"),C=w(),j=c("div"),I=m("New Users"),F=w(),T=c("div"),A=m("4,200"),U=w(),J=c("div"),O=m("↗︎ 400 (22%)"),L=w(),N=c("div"),P=c("div"),k=ot("svg"),x=ot("path"),q=w(),G=c("div"),H=m("New Registers"),z=w(),W=c("div"),tt=m("1,200"),Z=w(),S=c("div"),st=m("↘︎ 90 (14%)"),this.h()},l(Y){s=o(Y,"DIV",{class:!0});var Q=i(s);l=o(Q,"DIV",{class:!0});var et=i(l);v=o(et,"DIV",{class:!0});var at=i(v);u=vt(at,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var lt=i(u);n=vt(lt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(n).forEach(a),lt.forEach(a),at.forEach(a),h=g(et),r=o(et,"DIV",{class:!0});var Vt=i(r);$=p(Vt,"Downloads"),Vt.forEach(a),D=g(et),y=o(et,"DIV",{class:!0});var Dt=i(y);M=p(Dt,"31K"),Dt.forEach(a),V=g(et),_=o(et,"DIV",{class:!0});var It=i(_);K=p(It,"Jan 1st - Feb 1st"),It.forEach(a),et.forEach(a),B=g(Q),E=o(Q,"DIV",{class:!0});var it=i(E);d=o(it,"DIV",{class:!0});var kt=i(d);f=vt(kt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var dt=i(f);b=vt(dt,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(b).forEach(a),dt.forEach(a),kt.forEach(a),C=g(it),j=o(it,"DIV",{class:!0});var bt=i(j);I=p(bt,"New Users"),bt.forEach(a),F=g(it),T=o(it,"DIV",{class:!0});var xt=i(T);A=p(xt,"4,200"),xt.forEach(a),U=g(it),J=o(it,"DIV",{class:!0});var yt=i(J);O=p(yt,"↗︎ 400 (22%)"),yt.forEach(a),it.forEach(a),L=g(Q),N=o(Q,"DIV",{class:!0});var rt=i(N);P=o(rt,"DIV",{class:!0});var Nt=i(P);k=vt(Nt,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var ct=i(k);x=vt(ct,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),i(x).forEach(a),ct.forEach(a),Nt.forEach(a),q=g(rt),G=o(rt,"DIV",{class:!0});var Mt=i(G);H=p(Mt,"New Registers"),Mt.forEach(a),z=g(rt),W=o(rt,"DIV",{class:!0});var Rt=i(W);tt=p(Rt,"1,200"),Rt.forEach(a),Z=g(rt),S=o(rt,"DIV",{class:!0});var Bt=i(S);st=p(Bt,"↘︎ 90 (14%)"),Bt.forEach(a),rt.forEach(a),Q.forEach(a),this.h()},h(){e(n,"stroke-linecap","round"),e(n,"stroke-linejoin","round"),e(n,"stroke-width","2"),e(n,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),e(u,"xmlns","http://www.w3.org/2000/svg"),e(u,"fill","none"),e(u,"viewBox","0 0 24 24"),e(u,"class","inline-block w-8 h-8 stroke-current"),e(v,"class","stat-figure text-secondary"),e(r,"class","stat-title"),e(y,"class","stat-value"),e(_,"class","stat-desc"),e(l,"class","stat"),e(b,"stroke-linecap","round"),e(b,"stroke-linejoin","round"),e(b,"stroke-width","2"),e(b,"d","M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"),e(f,"xmlns","http://www.w3.org/2000/svg"),e(f,"fill","none"),e(f,"viewBox","0 0 24 24"),e(f,"class","inline-block w-8 h-8 stroke-current"),e(d,"class","stat-figure text-secondary"),e(j,"class","stat-title"),e(T,"class","stat-value"),e(J,"class","stat-desc"),e(E,"class","stat"),e(x,"stroke-linecap","round"),e(x,"stroke-linejoin","round"),e(x,"stroke-width","2"),e(x,"d","M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"),e(k,"xmlns","http://www.w3.org/2000/svg"),e(k,"fill","none"),e(k,"viewBox","0 0 24 24"),e(k,"class","inline-block w-8 h-8 stroke-current"),e(P,"class","stat-figure text-secondary"),e(G,"class","stat-title"),e(W,"class","stat-value"),e(S,"class","stat-desc"),e(N,"class","stat"),e(s,"class","shadow stats")},m(Y,Q){X(Y,s,Q),t(s,l),t(l,v),t(v,u),t(u,n),t(l,h),t(l,r),t(r,$),t(l,D),t(l,y),t(y,M),t(l,V),t(l,_),t(_,K),t(s,B),t(s,E),t(E,d),t(d,f),t(f,b),t(E,C),t(E,j),t(j,I),t(E,F),t(E,T),t(T,A),t(E,U),t(E,J),t(J,O),t(s,L),t(s,N),t(N,P),t(P,k),t(k,x),t(N,q),t(N,G),t(G,H),t(N,z),t(N,W),t(W,tt),t(N,Z),t(N,S),t(S,st)},p:_t,d(Y){Y&&a(s)}}}function ts(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function ss(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A,U,J,O,L,N;return{c(){s=c("div"),l=c("div"),v=c("div"),u=m("Downloads"),n=w(),h=c("div"),r=m("31K"),$=w(),D=c("div"),y=m("From January 1st to February 1st"),M=w(),V=c("div"),_=c("div"),K=m("Users"),B=w(),E=c("div"),d=m("4,200"),f=w(),b=c("div"),C=m("↗︎ 40 (2%)"),j=w(),I=c("div"),F=c("div"),T=m("New Registers"),A=w(),U=c("div"),J=m("1,200"),O=w(),L=c("div"),N=m("↘︎ 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);v=o(x,"DIV",{class:!0});var q=i(v);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"From January 1st to February 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"↗︎ 40 (2%)"),Z.forEach(a),z.forEach(a),j=g(k),I=o(k,"DIV",{class:!0});var S=i(I);F=o(S,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=g(S),U=o(S,"DIV",{class:!0});var Y=i(U);J=p(Y,"1,200"),Y.forEach(a),O=g(S),L=o(S,"DIV",{class:!0});var Q=i(L);N=p(Q,"↘︎ 90 (14%)"),Q.forEach(a),S.forEach(a),k.forEach(a),this.h()},h(){e(v,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat place-items-center"),e(_,"class","stat-title"),e(E,"class","stat-value text-secondary"),e(b,"class","stat-desc text-secondary"),e(V,"class","stat place-items-center"),e(F,"class","stat-title"),e(U,"class","stat-value"),e(L,"class","stat-desc"),e(I,"class","stat place-items-center"),e(s,"class","shadow stats")},m(P,k){X(P,s,k),t(s,l),t(l,v),t(v,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,j),t(s,I),t(I,F),t(F,T),t(I,A),t(I,U),t(U,J),t(I,O),t(I,L),t(L,N)},p:_t,d(P){P&&a(s)}}}function es(R){let s,l=`<div class="$$stats shadow">
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Users</div>
    <div class="$$stat-value text-secondary">4,200</div>
    <div class="$$stat-desc text-secondary">↗︎ 40 (2%)</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function as(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A,U,J,O,L,N;return{c(){s=c("div"),l=c("div"),v=c("div"),u=m("Downloads"),n=w(),h=c("div"),r=m("31K"),$=w(),D=c("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=c("div"),_=c("div"),K=m("New Users"),B=w(),E=c("div"),d=m("4,200"),f=w(),b=c("div"),C=m("↗︎ 400 (22%)"),j=w(),I=c("div"),F=c("div"),T=m("New Registers"),A=w(),U=c("div"),J=m("1,200"),O=w(),L=c("div"),N=m("↘︎ 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);v=o(x,"DIV",{class:!0});var q=i(v);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"New Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"↗︎ 400 (22%)"),Z.forEach(a),z.forEach(a),j=g(k),I=o(k,"DIV",{class:!0});var S=i(I);F=o(S,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=g(S),U=o(S,"DIV",{class:!0});var Y=i(U);J=p(Y,"1,200"),Y.forEach(a),O=g(S),L=o(S,"DIV",{class:!0});var Q=i(L);N=p(Q,"↘︎ 90 (14%)"),Q.forEach(a),S.forEach(a),k.forEach(a),this.h()},h(){e(v,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(E,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(F,"class","stat-title"),e(U,"class","stat-value"),e(L,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical")},m(P,k){X(P,s,k),t(s,l),t(l,v),t(v,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,j),t(s,I),t(I,F),t(F,T),t(I,A),t(I,U),t(U,J),t(I,O),t(I,L),t(L,N)},p:_t,d(P){P&&a(s)}}}function ls(R){let s,l=`<div class="$$stats $$stats-vertical shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function is(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A,U,J,O,L,N;return{c(){s=c("div"),l=c("div"),v=c("div"),u=m("Downloads"),n=w(),h=c("div"),r=m("31K"),$=w(),D=c("div"),y=m("Jan 1st - Feb 1st"),M=w(),V=c("div"),_=c("div"),K=m("New Users"),B=w(),E=c("div"),d=m("4,200"),f=w(),b=c("div"),C=m("↗︎ 400 (22%)"),j=w(),I=c("div"),F=c("div"),T=m("New Registers"),A=w(),U=c("div"),J=m("1,200"),O=w(),L=c("div"),N=m("↘︎ 90 (14%)"),this.h()},l(P){s=o(P,"DIV",{class:!0});var k=i(s);l=o(k,"DIV",{class:!0});var x=i(l);v=o(x,"DIV",{class:!0});var q=i(v);u=p(q,"Downloads"),q.forEach(a),n=g(x),h=o(x,"DIV",{class:!0});var G=i(h);r=p(G,"31K"),G.forEach(a),$=g(x),D=o(x,"DIV",{class:!0});var H=i(D);y=p(H,"Jan 1st - Feb 1st"),H.forEach(a),x.forEach(a),M=g(k),V=o(k,"DIV",{class:!0});var z=i(V);_=o(z,"DIV",{class:!0});var W=i(_);K=p(W,"New Users"),W.forEach(a),B=g(z),E=o(z,"DIV",{class:!0});var tt=i(E);d=p(tt,"4,200"),tt.forEach(a),f=g(z),b=o(z,"DIV",{class:!0});var Z=i(b);C=p(Z,"↗︎ 400 (22%)"),Z.forEach(a),z.forEach(a),j=g(k),I=o(k,"DIV",{class:!0});var S=i(I);F=o(S,"DIV",{class:!0});var st=i(F);T=p(st,"New Registers"),st.forEach(a),A=g(S),U=o(S,"DIV",{class:!0});var Y=i(U);J=p(Y,"1,200"),Y.forEach(a),O=g(S),L=o(S,"DIV",{class:!0});var Q=i(L);N=p(Q,"↘︎ 90 (14%)"),Q.forEach(a),S.forEach(a),k.forEach(a),this.h()},h(){e(v,"class","stat-title"),e(h,"class","stat-value"),e(D,"class","stat-desc"),e(l,"class","stat"),e(_,"class","stat-title"),e(E,"class","stat-value"),e(b,"class","stat-desc"),e(V,"class","stat"),e(F,"class","stat-title"),e(U,"class","stat-value"),e(L,"class","stat-desc"),e(I,"class","stat"),e(s,"class","shadow stats stats-vertical lg:stats-horizontal")},m(P,k){X(P,s,k),t(s,l),t(l,v),t(v,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(s,M),t(s,V),t(V,_),t(_,K),t(V,B),t(V,E),t(E,d),t(V,f),t(V,b),t(b,C),t(s,j),t(s,I),t(I,F),t(F,T),t(I,A),t(I,U),t(U,J),t(I,O),t(I,L),t(L,N)},p:_t,d(P){P&&a(s)}}}function ds(R){let s,l=`<div class="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function rs(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E,d,f,b,C,j,I,F,T,A;return{c(){s=c("div"),l=c("div"),v=c("div"),u=m("Account balance"),n=w(),h=c("div"),r=m("$89,400"),$=w(),D=c("div"),y=c("button"),M=m("Add funds"),V=w(),_=c("div"),K=c("div"),B=m("Current balance"),E=w(),d=c("div"),f=m("$89,400"),b=w(),C=c("div"),j=c("button"),I=m("Withdrawal"),F=w(),T=c("button"),A=m("deposit"),this.h()},l(U){s=o(U,"DIV",{class:!0});var J=i(s);l=o(J,"DIV",{class:!0});var O=i(l);v=o(O,"DIV",{class:!0});var L=i(v);u=p(L,"Account balance"),L.forEach(a),n=g(O),h=o(O,"DIV",{class:!0});var N=i(h);r=p(N,"$89,400"),N.forEach(a),$=g(O),D=o(O,"DIV",{class:!0});var P=i(D);y=o(P,"BUTTON",{class:!0});var k=i(y);M=p(k,"Add funds"),k.forEach(a),P.forEach(a),O.forEach(a),V=g(J),_=o(J,"DIV",{class:!0});var x=i(_);K=o(x,"DIV",{class:!0});var q=i(K);B=p(q,"Current balance"),q.forEach(a),E=g(x),d=o(x,"DIV",{class:!0});var G=i(d);f=p(G,"$89,400"),G.forEach(a),b=g(x),C=o(x,"DIV",{class:!0});var H=i(C);j=o(H,"BUTTON",{class:!0});var z=i(j);I=p(z,"Withdrawal"),z.forEach(a),F=g(H),T=o(H,"BUTTON",{class:!0});var W=i(T);A=p(W,"deposit"),W.forEach(a),H.forEach(a),x.forEach(a),J.forEach(a),this.h()},h(){e(v,"class","stat-title"),e(h,"class","stat-value"),e(y,"class","btn btn-sm btn-success"),e(D,"class","stat-actions"),e(l,"class","stat"),e(K,"class","stat-title"),e(d,"class","stat-value"),e(j,"class","btn btn-sm"),e(T,"class","btn btn-sm"),e(C,"class","stat-actions"),e(_,"class","stat"),e(s,"class","stats bg-primary text-primary-content")},m(U,J){X(U,s,J),t(s,l),t(l,v),t(v,u),t(l,n),t(l,h),t(h,r),t(l,$),t(l,D),t(D,y),t(y,M),t(s,V),t(s,_),t(_,K),t(K,B),t(_,E),t(_,d),t(d,f),t(_,b),t(_,C),t(C,j),t(j,I),t(C,F),t(C,T),t(T,A)},p:_t,d(U){U&&a(s)}}}function cs(R){let s,l=`<div class="$$stats bg-primary text-primary-content">
  
  <div class="$$stat">
    <div class="$$stat-title">Account balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">Current balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm">Withdrawal</button> 
      <button class="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,v,u,n,h;return{c(){s=c("pre"),v=m(l),this.h()},l(r){s=o(r,"PRE",{slot:!0});var $=i(s);v=p($,l),$.forEach(a),this.h()},h(){e(s,"slot","html")},m(r,$){X(r,s,$),t(s,v),n||(h=wt(u=Et.call(null,s,{to:R[0]})),n=!0)},p(r,$){u&&gt(u.update)&&$&1&&u.update.call(null,{to:r[0]})},d(r){r&&a(s),n=!1,h()}}}function os(R){let s,l,v,u,n,h,r,$,D,y,M,V,_,K,B,E;return s=new Gt({props:{data:[{type:"component",class:"stats",desc:"Container of multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"component",class:"stat-actions",desc:"For buttons, input, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),v=new pt({props:{title:"Stat",$$slots:{html:[Yt],default:[Ht]},$$scope:{ctx:R}}}),n=new pt({props:{title:"Stat with icons or image",$$slots:{html:[Xt],default:[Qt]},$$scope:{ctx:R}}}),r=new pt({props:{title:"Stat",$$slots:{html:[ts],default:[Zt]},$$scope:{ctx:R}}}),D=new pt({props:{title:"Centered items",$$slots:{html:[es],default:[ss]},$$scope:{ctx:R}}}),M=new pt({props:{title:"Vertical",$$slots:{html:[ls],default:[as]},$$scope:{ctx:R}}}),_=new pt({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{html:[ds],default:[is]},$$scope:{ctx:R}}}),B=new pt({props:{title:"With custom colors and button",$$slots:{html:[cs],default:[rs]},$$scope:{ctx:R}}}),{c(){nt(s.$$.fragment),l=w(),nt(v.$$.fragment),u=w(),nt(n.$$.fragment),h=w(),nt(r.$$.fragment),$=w(),nt(D.$$.fragment),y=w(),nt(M.$$.fragment),V=w(),nt(_.$$.fragment),K=w(),nt(B.$$.fragment)},l(d){ut(s.$$.fragment,d),l=g(d),ut(v.$$.fragment,d),u=g(d),ut(n.$$.fragment,d),h=g(d),ut(r.$$.fragment,d),$=g(d),ut(D.$$.fragment,d),y=g(d),ut(M.$$.fragment,d),V=g(d),ut(_.$$.fragment,d),K=g(d),ut(B.$$.fragment,d)},m(d,f){$t(s,d,f),X(d,l,f),$t(v,d,f),X(d,u,f),$t(n,d,f),X(d,h,f),$t(r,d,f),X(d,$,f),$t(D,d,f),X(d,y,f),$t(M,d,f),X(d,V,f),$t(_,d,f),X(d,K,f),$t(B,d,f),E=!0},p(d,f){const b={};f&5&&(b.$$scope={dirty:f,ctx:d}),v.$set(b);const C={};f&5&&(C.$$scope={dirty:f,ctx:d}),n.$set(C);const j={};f&5&&(j.$$scope={dirty:f,ctx:d}),r.$set(j);const I={};f&5&&(I.$$scope={dirty:f,ctx:d}),D.$set(I);const F={};f&5&&(F.$$scope={dirty:f,ctx:d}),M.$set(F);const T={};f&5&&(T.$$scope={dirty:f,ctx:d}),_.$set(T);const A={};f&5&&(A.$$scope={dirty:f,ctx:d}),B.$set(A)},i(d){E||(ht(s.$$.fragment,d),ht(v.$$.fragment,d),ht(n.$$.fragment,d),ht(r.$$.fragment,d),ht(D.$$.fragment,d),ht(M.$$.fragment,d),ht(_.$$.fragment,d),ht(B.$$.fragment,d),E=!0)},o(d){ft(s.$$.fragment,d),ft(v.$$.fragment,d),ft(n.$$.fragment,d),ft(r.$$.fragment,d),ft(D.$$.fragment,d),ft(M.$$.fragment,d),ft(_.$$.fragment,d),ft(B.$$.fragment,d),E=!1},d(d){mt(s,d),d&&a(l),mt(v,d),d&&a(u),mt(n,d),d&&a(h),mt(r,d),d&&a($),mt(D,d),d&&a(y),mt(M,d),d&&a(V),mt(_,d),d&&a(K),mt(B,d)}}}function vs(R){let s,l;const v=[R[1],zt];let u={$$slots:{default:[os]},$$scope:{ctx:R}};for(let n=0;n<v.length;n+=1)u=jt(u,v[n]);return s=new Wt({props:u}),{c(){nt(s.$$.fragment)},l(n){ut(s.$$.fragment,n)},m(n,h){$t(s,n,h),l=!0},p(n,[h]){const r=h&2?St(v,[h&2&&Ut(n[1]),h&0&&Ut(zt)]):{};h&5&&(r.$$scope={dirty:h,ctx:n}),s.$set(r)},i(n){l||(ht(s.$$.fragment,n),l=!0)},o(n){ft(s.$$.fragment,n),l=!1},d(n){mt(s,n)}}}const zt={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0};function ns(R,s,l){let v;return At(R,qt,u=>l(0,v=u)),R.$$set=u=>{l(1,s=jt(jt({},s),Pt(u)))},s=Pt(s),[v,s]}class fs extends Jt{constructor(s){super(),Ct(this,s,ns,vs,Lt,{})}}export{fs as component};
