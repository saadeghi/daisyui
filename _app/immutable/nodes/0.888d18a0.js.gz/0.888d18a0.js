import{L as e,_ as n}from"../chunks/0.224f8995.js";export{e as component,n as universal};
