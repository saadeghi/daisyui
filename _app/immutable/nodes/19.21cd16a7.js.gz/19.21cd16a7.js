import{S as at,i as ot,s as pt,M as tt,y as F,z as G,A as K,U as ut,$ as st,g as Q,d as W,B as X,H as ct,o as rt,Y as nt,k as f,q as _,a as R,l as i,m as v,r as w,h as p,c as C,b as E,E as c,p as A,n as m,a9 as q,u as J,a4 as z}from"../chunks/index.b33eaa49.js";import{M as dt}from"../chunks/mdsvex.ec1f5532.js";import{p as ft,C as it,a as Z,r as B}from"../chunks/ClassTable.be5ea45a.js";function vt(d){let t,n;return{c(){t=f("span"),n=f("span"),this.h()},l(l){t=i(l,"SPAN",{class:!0});var a=v(t);n=i(a,"SPAN",{style:!0}),v(n).forEach(p),a.forEach(p),this.h()},h(){A(n,"--value",d[0]),m(t,"class","countdown")},m(l,a){E(l,t,a),c(t,n)},p(l,a){a&1&&A(n,"--value",l[0])},d(l){l&&p(t)}}}function xt(d){let t,n=`<span class="$$countdown">
  <span style="--value:${d[0]};"></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown">
  <span style="--value:${e[0]};"></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function $t(d){let t,n=`<span class="$$countdown">
  <span style={{"--value":${d[0]}}}></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown">
  <span style={{"--value":${e[0]}}}></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function mt(d){let t,n;return{c(){t=f("span"),n=f("span"),this.h()},l(l){t=i(l,"SPAN",{class:!0});var a=v(t);n=i(a,"SPAN",{style:!0}),v(n).forEach(p),a.forEach(p),this.h()},h(){A(n,"--value",d[0]),m(t,"class","countdown font-mono text-6xl")},m(l,a){E(l,t,a),c(t,n)},p(l,a){a&1&&A(n,"--value",l[0])},d(l){l&&p(t)}}}function ht(d){let t,n=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${d[0]};"></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${e[0]};"></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function _t(d){let t,n=`<span class="$$countdown font-mono text-6xl">
  <span style={{"--value":${d[0]}}}></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-6xl">
  <span style={{"--value":${e[0]}}}></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function wt(d){let t,n,l,a,o,r,e;return{c(){t=f("span"),n=f("span"),l=_(`h
  `),a=f("span"),o=_(`m
  `),r=f("span"),e=_("s"),this.h()},l(s){t=i(s,"SPAN",{class:!0});var h=v(t);n=i(h,"SPAN",{style:!0}),v(n).forEach(p),l=w(h,`h
  `),a=i(h,"SPAN",{style:!0}),v(a).forEach(p),o=w(h,`m
  `),r=i(h,"SPAN",{style:!0}),v(r).forEach(p),e=w(h,"s"),h.forEach(p),this.h()},h(){A(n,"--value","10"),A(a,"--value","24"),A(r,"--value",d[0]),m(t,"class","font-mono text-2xl countdown")},m(s,h){E(s,t,h),c(t,n),c(t,l),c(t,a),c(t,o),c(t,r),c(t,e)},p(s,h){h&1&&A(r,"--value",s[0])},d(s){s&&p(t)}}}function yt(d){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${d[0]};"></span>s
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${e[0]};"></span>s
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function gt(d){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>h
  <span style={{"--value":24}}></span>m
  <span style={{"--value":${d[0]}}}></span>s
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>h
  <span style={{"--value":24}}></span>m
  <span style={{"--value":${e[0]}}}></span>s
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Et(d){let t,n,l,a,o,r;return{c(){t=f("span"),n=f("span"),l=_(`:
  `),a=f("span"),o=_(`:
  `),r=f("span"),this.h()},l(e){t=i(e,"SPAN",{class:!0});var s=v(t);n=i(s,"SPAN",{style:!0}),v(n).forEach(p),l=w(s,`:
  `),a=i(s,"SPAN",{style:!0}),v(a).forEach(p),o=w(s,`:
  `),r=i(s,"SPAN",{style:!0}),v(r).forEach(p),s.forEach(p),this.h()},h(){A(n,"--value","10"),A(a,"--value","24"),A(r,"--value",d[0]),m(t,"class","font-mono text-2xl countdown")},m(e,s){E(e,t,s),c(t,n),c(t,l),c(t,a),c(t,o),c(t,r)},p(e,s){s&1&&A(r,"--value",e[0])},d(e){e&&p(t)}}}function bt(d){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${d[0]};"></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${e[0]};"></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Pt(d){let t,n=`<span class="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>:
  <span style={{"--value":24}}></span>:
  <span style={{"--value":${d[0]}}}></span>
</span>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<span class="$$countdown font-mono text-2xl">
  <span style={{"--value":10}}></span>:
  <span style={{"--value":24}}></span>:
  <span style={{"--value":${e[0]}}}></span>
</span>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function St(d){let t,n,l,a,o,r,e,s,h,M,V,S,b,j,D,k,g,N,P,L;return{c(){t=f("div"),n=f("div"),l=f("span"),a=f("span"),o=_(`
    days`),r=R(),e=f("div"),s=f("span"),h=f("span"),M=_(`
    hours`),V=R(),S=f("div"),b=f("span"),j=f("span"),D=_(`
    minutes`),k=R(),g=f("div"),N=f("span"),P=f("span"),L=_(`
    sec`),this.h()},l(y){t=i(y,"DIV",{class:!0});var $=v(t);n=i($,"DIV",{});var u=v(n);l=i(u,"SPAN",{class:!0});var x=v(l);a=i(x,"SPAN",{style:!0}),v(a).forEach(p),x.forEach(p),o=w(u,`
    days`),u.forEach(p),r=C($),e=i($,"DIV",{});var I=v(e);s=i(I,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),M=w(I,`
    hours`),I.forEach(p),V=C($),S=i($,"DIV",{});var T=v(S);b=i(T,"SPAN",{class:!0});var O=v(b);j=i(O,"SPAN",{style:!0}),v(j).forEach(p),O.forEach(p),D=w(T,`
    minutes`),T.forEach(p),k=C($),g=i($,"DIV",{});var Y=v(g);N=i(Y,"SPAN",{class:!0});var U=v(N);P=i(U,"SPAN",{style:!0}),v(P).forEach(p),U.forEach(p),L=w(Y,`
    sec`),Y.forEach(p),$.forEach(p),this.h()},h(){A(a,"--value","15"),m(l,"class","font-mono text-4xl countdown"),A(h,"--value","10"),m(s,"class","font-mono text-4xl countdown"),A(j,"--value","24"),m(b,"class","font-mono text-4xl countdown"),A(P,"--value",d[0]),m(N,"class","font-mono text-4xl countdown"),m(t,"class","flex gap-5")},m(y,$){E(y,t,$),c(t,n),c(n,l),c(l,a),c(n,o),c(t,r),c(t,e),c(e,s),c(s,h),c(e,M),c(t,V),c(t,S),c(S,b),c(b,j),c(S,D),c(t,k),c(t,g),c(g,N),c(N,P),c(g,L)},p(y,$){$&1&&A(P,"--value",y[0])},d(y){y&&p(t)}}}function At(d){let t,n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Nt(d){let t,n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
        <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
        <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
        <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
        <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style={{"--value":${e[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function jt(d){let t,n,l,a,o,r,e,s,h,M,V,S,b,j,D,k,g,N,P,L;return{c(){t=f("div"),n=f("div"),l=f("span"),a=f("span"),o=_(`
    days`),r=R(),e=f("div"),s=f("span"),h=f("span"),M=_(`
    hours`),V=R(),S=f("div"),b=f("span"),j=f("span"),D=_(`
    min`),k=R(),g=f("div"),N=f("span"),P=f("span"),L=_(`
    sec`),this.h()},l(y){t=i(y,"DIV",{class:!0});var $=v(t);n=i($,"DIV",{class:!0});var u=v(n);l=i(u,"SPAN",{class:!0});var x=v(l);a=i(x,"SPAN",{style:!0}),v(a).forEach(p),x.forEach(p),o=w(u,`
    days`),u.forEach(p),r=C($),e=i($,"DIV",{class:!0});var I=v(e);s=i(I,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),M=w(I,`
    hours`),I.forEach(p),V=C($),S=i($,"DIV",{class:!0});var T=v(S);b=i(T,"SPAN",{class:!0});var O=v(b);j=i(O,"SPAN",{style:!0}),v(j).forEach(p),O.forEach(p),D=w(T,`
    min`),T.forEach(p),k=C($),g=i($,"DIV",{class:!0});var Y=v(g);N=i(Y,"SPAN",{class:!0});var U=v(N);P=i(U,"SPAN",{style:!0}),v(P).forEach(p),U.forEach(p),L=w(Y,`
    sec`),Y.forEach(p),$.forEach(p),this.h()},h(){A(a,"--value","15"),m(l,"class","font-mono text-5xl countdown"),m(n,"class","flex flex-col"),A(h,"--value","10"),m(s,"class","font-mono text-5xl countdown"),m(e,"class","flex flex-col"),A(j,"--value","24"),m(b,"class","font-mono text-5xl countdown"),m(S,"class","flex flex-col"),A(P,"--value",d[0]),m(N,"class","font-mono text-5xl countdown"),m(g,"class","flex flex-col"),m(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(y,$){E(y,t,$),c(t,n),c(n,l),c(l,a),c(n,o),c(t,r),c(t,e),c(e,s),c(s,h),c(e,M),c(t,V),c(t,S),c(S,b),c(b,j),c(S,D),c(t,k),c(t,g),c(g,N),c(N,P),c(g,L)},p(y,$){$&1&&A(P,"--value",y[0])},d(y){y&&p(t)}}}function Vt(d){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Dt(d){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":${e[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function It(d){let t,n,l,a,o,r,e,s,h,M,V,S,b,j,D,k,g,N,P,L;return{c(){t=f("div"),n=f("div"),l=f("span"),a=f("span"),o=_(`
    days`),r=R(),e=f("div"),s=f("span"),h=f("span"),M=_(`
    hours`),V=R(),S=f("div"),b=f("span"),j=f("span"),D=_(`
    min`),k=R(),g=f("div"),N=f("span"),P=f("span"),L=_(`
    sec`),this.h()},l(y){t=i(y,"DIV",{class:!0});var $=v(t);n=i($,"DIV",{class:!0});var u=v(n);l=i(u,"SPAN",{class:!0});var x=v(l);a=i(x,"SPAN",{style:!0}),v(a).forEach(p),x.forEach(p),o=w(u,`
    days`),u.forEach(p),r=C($),e=i($,"DIV",{class:!0});var I=v(e);s=i(I,"SPAN",{class:!0});var H=v(s);h=i(H,"SPAN",{style:!0}),v(h).forEach(p),H.forEach(p),M=w(I,`
    hours`),I.forEach(p),V=C($),S=i($,"DIV",{class:!0});var T=v(S);b=i(T,"SPAN",{class:!0});var O=v(b);j=i(O,"SPAN",{style:!0}),v(j).forEach(p),O.forEach(p),D=w(T,`
    min`),T.forEach(p),k=C($),g=i($,"DIV",{class:!0});var Y=v(g);N=i(Y,"SPAN",{class:!0});var U=v(N);P=i(U,"SPAN",{style:!0}),v(P).forEach(p),U.forEach(p),L=w(Y,`
    sec`),Y.forEach(p),$.forEach(p),this.h()},h(){A(a,"--value","15"),m(l,"class","font-mono text-5xl countdown"),m(n,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),A(h,"--value","10"),m(s,"class","font-mono text-5xl countdown"),m(e,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),A(j,"--value","24"),m(b,"class","font-mono text-5xl countdown"),m(S,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),A(P,"--value",d[0]),m(N,"class","font-mono text-5xl countdown"),m(g,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),m(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(y,$){E(y,t,$),c(t,n),c(n,l),c(l,a),c(n,o),c(t,r),c(t,e),c(e,s),c(s,h),c(e,M),c(t,V),c(t,S),c(S,b),c(b,j),c(S,D),c(t,k),c(t,g),c(g,N),c(N,P),c(g,L)},p(y,$){$&1&&A(P,"--value",y[0])},d(y){y&&p(t)}}}function Rt(d){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${d[0]};"></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","html")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Ct(d){let t,n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":${d[0]}}}></span>
    </span>
    sec
  </div>
</div>`,l,a,o,r;return{c(){t=f("pre"),l=_(n),this.h()},l(e){t=i(e,"PRE",{slot:!0});var s=v(t);l=w(s,n),s.forEach(p),this.h()},h(){m(t,"slot","jsx")},m(e,s){E(e,t,s),c(t,l),o||(r=q(a=B.call(null,t,{to:d[1]})),o=!0)},p(e,s){s&1&&n!==(n=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style={{"--value":${e[0]}}}></span>
    </span>
    sec
  </div>
</div>`)&&J(l,n),a&&z(a.update)&&s&2&&a.update.call(null,{to:e[1]})},d(e){e&&p(t),o=!1,r()}}}function Mt(d){let t,n,l,a,o,r,e,s,h,M,V,S,b,j,D,k,g,N,P,L,y,$;return e=new it({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),h=new Z({props:{title:"Countdown",$$slots:{jsx:[$t],html:[xt],default:[vt]},$$scope:{ctx:d}}}),V=new Z({props:{title:"Large text",$$slots:{jsx:[_t],html:[ht],default:[mt]},$$scope:{ctx:d}}}),b=new Z({props:{title:"Clock countdown",$$slots:{jsx:[gt],html:[yt],default:[wt]},$$scope:{ctx:d}}}),D=new Z({props:{title:"Clock countdown with colons",$$slots:{jsx:[Pt],html:[bt],default:[Et]},$$scope:{ctx:d}}}),g=new Z({props:{title:"Large text with labels",$$slots:{jsx:[Nt],html:[At],default:[St]},$$scope:{ctx:d}}}),P=new Z({props:{title:"Large text with labels under",$$slots:{jsx:[Dt],html:[Vt],default:[jt]},$$scope:{ctx:d}}}),y=new Z({props:{title:"In boxes",$$slots:{jsx:[Ct],html:[Rt],default:[It]},$$scope:{ctx:d}}}),{c(){t=f("p"),n=_("You need to change to "),l=f("code"),a=_("--value"),o=_(" CSS variable using JS. Value must be a number between 0 and 99."),r=R(),F(e.$$.fragment),s=R(),F(h.$$.fragment),M=R(),F(V.$$.fragment),S=R(),F(b.$$.fragment),j=R(),F(D.$$.fragment),k=R(),F(g.$$.fragment),N=R(),F(P.$$.fragment),L=R(),F(y.$$.fragment)},l(u){t=i(u,"P",{});var x=v(t);n=w(x,"You need to change to "),l=i(x,"CODE",{});var I=v(l);a=w(I,"--value"),I.forEach(p),o=w(x," CSS variable using JS. Value must be a number between 0 and 99."),x.forEach(p),r=C(u),G(e.$$.fragment,u),s=C(u),G(h.$$.fragment,u),M=C(u),G(V.$$.fragment,u),S=C(u),G(b.$$.fragment,u),j=C(u),G(D.$$.fragment,u),k=C(u),G(g.$$.fragment,u),N=C(u),G(P.$$.fragment,u),L=C(u),G(y.$$.fragment,u)},m(u,x){E(u,t,x),c(t,n),c(t,l),c(l,a),c(t,o),E(u,r,x),K(e,u,x),E(u,s,x),K(h,u,x),E(u,M,x),K(V,u,x),E(u,S,x),K(b,u,x),E(u,j,x),K(D,u,x),E(u,k,x),K(g,u,x),E(u,N,x),K(P,u,x),E(u,L,x),K(y,u,x),$=!0},p(u,x){const I={};x&19&&(I.$$scope={dirty:x,ctx:u}),h.$set(I);const H={};x&19&&(H.$$scope={dirty:x,ctx:u}),V.$set(H);const T={};x&19&&(T.$$scope={dirty:x,ctx:u}),b.$set(T);const O={};x&19&&(O.$$scope={dirty:x,ctx:u}),D.$set(O);const Y={};x&19&&(Y.$$scope={dirty:x,ctx:u}),g.$set(Y);const U={};x&19&&(U.$$scope={dirty:x,ctx:u}),P.$set(U);const et={};x&19&&(et.$$scope={dirty:x,ctx:u}),y.$set(et)},i(u){$||(Q(e.$$.fragment,u),Q(h.$$.fragment,u),Q(V.$$.fragment,u),Q(b.$$.fragment,u),Q(D.$$.fragment,u),Q(g.$$.fragment,u),Q(P.$$.fragment,u),Q(y.$$.fragment,u),$=!0)},o(u){W(e.$$.fragment,u),W(h.$$.fragment,u),W(V.$$.fragment,u),W(b.$$.fragment,u),W(D.$$.fragment,u),W(g.$$.fragment,u),W(P.$$.fragment,u),W(y.$$.fragment,u),$=!1},d(u){u&&p(t),u&&p(r),X(e,u),u&&p(s),X(h,u),u&&p(M),X(V,u),u&&p(S),X(b,u),u&&p(j),X(D,u),u&&p(k),X(g,u),u&&p(N),X(P,u),u&&p(L),X(y,u)}}}function kt(d){let t,n;const l=[d[2],lt];let a={$$slots:{default:[Mt]},$$scope:{ctx:d}};for(let o=0;o<l.length;o+=1)a=tt(a,l[o]);return t=new dt({props:a}),{c(){F(t.$$.fragment)},l(o){G(t.$$.fragment,o)},m(o,r){K(t,o,r),n=!0},p(o,[r]){const e=r&4?ut(l,[r&4&&st(o[2]),r&0&&st(lt)]):{};r&19&&(e.$$scope={dirty:r,ctx:o}),t.$set(e)},i(o){n||(Q(t.$$.fragment,o),n=!0)},o(o){W(t.$$.fragment,o),n=!1},d(o){X(t,o)}}}const lt={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers.",published:!0};function Lt(d,t,n){let l;ct(d,ft,r=>n(1,l=r));let a=59;function o(){a>0?(n(0,a--,a),setTimeout(o,1e3)):(n(0,a=59),setTimeout(o,1e3))}return rt(()=>{o()}),d.$$set=r=>{n(2,t=tt(tt({},t),nt(r)))},t=nt(t),[a,l,t]}class Jt extends at{constructor(t){super(),ot(this,t,Lt,kt,pt,{})}}export{Jt as component};
