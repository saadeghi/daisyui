import{L as e,_ as n}from"../chunks/0.fc571a39.js";export{e as component,n as universal};
