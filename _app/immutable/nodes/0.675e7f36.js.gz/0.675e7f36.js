import{L as e,_ as n}from"../chunks/0.89b056f7.js";export{e as component,n as universal};
