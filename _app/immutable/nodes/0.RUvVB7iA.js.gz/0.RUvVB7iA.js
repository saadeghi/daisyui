import{L as e,_ as n}from"../chunks/0.UFK24xC-.js";export{e as component,n as universal};
