import{L as e,_ as n}from"../chunks/0.41066d85.js";export{e as component,n as universal};
