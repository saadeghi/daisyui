import{L as e,_ as n}from"../chunks/0.69616d80.js";export{e as component,n as universal};
