import{L as e,_ as n}from"../chunks/0.EP47Rx_9.js";export{e as component,n as universal};
