import{h as s,$ as c,f as n,s as a,a as m,d as p}from"../chunks/disclose-version.vS8Cq8Jh.js";var l=p(`<meta name="robots" content="noindex"> <link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon"> <script>
const urlParams = new URLSearchParams(window.location.search)
window.lemonSqueezyAffiliateConfig = {
  store: "daisyui",
  onTrack: (e) => {
    window.location.href = \`https://daisyui.lemonsqueezy.com/checkout/buy/\${urlParams.get("product")}?aff_ref=\${e.click}\`
  },
}
<\/script> <script src="https://lmsqueezy.com/affiliate.js" defer=""><\/script>`,1);function h(f){s(t=>{var e=l();c.title="Loading…";var r=n(e),i=a(a(r,!0)),o=a(a(i,!0)),u=a(a(o,!0));m(t,e)})}export{h as component};
