import{s as z,E as S,y as B,O as q,a as C,c as k,i as v,d as r,f as u,g as b,z as j,j as $,w as T,l as M,h as D,m as E,v as H,Y as L,U as O}from"../chunks/scheduler.e5ccafd2.js";import{S as U,i as G,b as f,d as g,m as _,a as y,t as w,e as x}from"../chunks/index.fb4b3a7b.js";import{g as Q,a as J}from"../chunks/index.18b79e66.js";import{M as X}from"../chunks/mdsvex.6a13afe3.js";import{p as Z,C as tt,a as I,r as A}from"../chunks/ClassTable.9d1e82e2.js";function et(d){let t,l='<div class="chat chat-start"><div class="chat-bubble">It&#39;s over Anakin, <br/>I have the high ground.</div></div> <div class="chat chat-end"><div class="chat-bubble">You underestimate my power!</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(e){t=b(e,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-xa4d6j"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){v(e,t,i)},p:T,d(e){e&&r(t)}}}function at(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble">It's over Anakin, <br/>I have the high ground.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble">You underestimate my power!</div>
</div>`,e,i,c,n;return{c(){t=u("pre"),e=M(l),this.h()},l(a){t=b(a,"PRE",{slot:!0});var o=D(t);e=E(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){v(a,t,o),H(t,e),c||(n=L(i=A.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&O(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function st(d){let t,l='<div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">It was said that you would, destroy the Sith, not join them.</div></div> <div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">It was you who would bring balance to the Force</div></div> <div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">Not leave it in Darkness</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(e){t=b(e,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-1o4yj7t"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){v(e,t,i)},p:T,d(e){e&&r(t)}}}function it(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was said that you would, destroy the Sith, not join them.</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was you who would bring balance to the Force</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">Not leave it in Darkness</div>
</div>`,e,i,c,n;return{c(){t=u("pre"),e=M(l),this.h()},l(a){t=b(a,"PRE",{slot:!0});var o=D(t);e=E(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){v(a,t,o),H(t,e),c||(n=L(i=A.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&O(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function ct(d){let t,l=`<div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">12:45</time></div> <div class="chat-bubble">You were the Chosen One!</div> <div class="chat-footer opacity-50">Delivered</div></div> <div class="chat chat-end"><div class="chat-image avatar"><div class="w-10 rounded-full"><img src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-header">Anakin
      <time class="text-xs opacity-50">12:46</time></div> <div class="chat-bubble">I hate you!</div> <div class="chat-footer opacity-50">Seen at 12:46</div></div>`;return{c(){t=u("div"),t.innerHTML=l,this.h()},l(e){t=b(e,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-7c3nnv"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){v(e,t,i)},p:T,d(e){e&&r(t)}}}function lt(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">12:45</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Anakin
    <time class="text-xs opacity-50">12:46</time>
  </div>
  <div class="$$chat-bubble">I hate you!</div>
  <div class="$$chat-footer opacity-50">
    Seen at 12:46
  </div>
</div>`,e,i,c,n;return{c(){t=u("pre"),e=M(l),this.h()},l(a){t=b(a,"PRE",{slot:!0});var o=D(t);e=E(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){v(a,t,o),H(t,e),c||(n=L(i=A.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&O(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function ot(d){let t,l=`<div class="chat chat-start"><div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">2 hours ago</time></div> <div class="chat-bubble">You were my brother, Anakin.</div> <div class="chat-footer opacity-50">Seen</div></div> <div class="chat chat-start"><div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">2 hour ago</time></div> <div class="chat-bubble">I loved you.</div> <div class="chat-footer opacity-50">Delivered</div></div>`;return{c(){t=u("div"),t.innerHTML=l,this.h()},l(e){t=b(e,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-1eihov2"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){v(e,t,i)},p:T,d(e){e&&r(t)}}}function dt(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hours ago</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Seen
  </div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hour ago</time>
  </div>
  <div class="$$chat-bubble">I loved you.</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>`,e,i,c,n;return{c(){t=u("pre"),e=M(l),this.h()},l(a){t=b(a,"PRE",{slot:!0});var o=D(t);e=E(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){v(a,t,o),H(t,e),c||(n=L(i=A.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&O(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function nt(d){let t,l='<div class="chat chat-start"><div class="chat-bubble chat-bubble-primary">What kind of nonsense is this</div></div> <div class="chat chat-start"><div class="chat-bubble chat-bubble-secondary">Put me on the Council and not make me a Master!??</div></div> <div class="chat chat-start"><div class="chat-bubble chat-bubble-accent">That&#39;s never been done in the history of the Jedi. It&#39;s insulting!</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-info">Calm down, Anakin.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-success">You have been given a great honor.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-warning">To be on the Council at your age.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-error">It&#39;s never happened before.</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(e){t=b(e,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-6tnx1"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){v(e,t,i)},p:T,d(e){e&&r(t)}}}function ht(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-primary">What kind of nonsense is this</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-secondary">Put me on the Council and not make me a Master!??</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-accent">That's never been done in the history of the Jedi. It's insulting!</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-info">Calm down, Anakin.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-success">You have been given a great honor.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-warning">To be on the Council at your age.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-error">It's never happened before.</div>
</div>`,e,i,c,n;return{c(){t=u("pre"),e=M(l),this.h()},l(a){t=b(a,"PRE",{slot:!0});var o=D(t);e=E(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){v(a,t,o),H(t,e),c||(n=L(i=A.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&O(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function rt(d){let t,l,e,i,c,n,a,o,m,Y,p,P;return t=new tt({props:{data:[{type:"component",class:"chat",desc:"Container for one line of conversation and all its data"},{type:"modifier",class:"chat-start",desc:"Aligns `chat` to left (required)"},{type:"modifier",class:"chat-end",desc:"Aligns `chat` to end (required)"},{type:"component",class:"chat-image",desc:"For the author image"},{type:"component",class:"chat-header",desc:"For the line above the chat bubble"},{type:"component",class:"chat-footer",desc:"For the line below the chat bubble"},{type:"component",class:"chat-bubble",desc:"For the content of chat"},{type:"modifier",class:"chat-bubble-primary",desc:"sets `primary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-secondary",desc:"sets `secondary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-accent",desc:"sets `accent` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-info",desc:"sets `info` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-success",desc:"sets `success` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-warning",desc:"sets `warning` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-error",desc:"sets `error` color for the `chat-bubble`"}]}}),e=new I({props:{title:"chat-start and chat-end",$$slots:{html:[at],default:[et]},$$scope:{ctx:d}}}),c=new I({props:{title:"Chat with image",$$slots:{html:[it],default:[st]},$$scope:{ctx:d}}}),a=new I({props:{title:"Chat with image, header and footer",$$slots:{html:[lt],default:[ct]},$$scope:{ctx:d}}}),m=new I({props:{title:"Chat with header and footer",$$slots:{html:[dt],default:[ot]},$$scope:{ctx:d}}}),p=new I({props:{title:"Chat Bubble with colors",$$slots:{html:[ht],default:[nt]},$$scope:{ctx:d}}}),{c(){f(t.$$.fragment),l=C(),f(e.$$.fragment),i=C(),f(c.$$.fragment),n=C(),f(a.$$.fragment),o=C(),f(m.$$.fragment),Y=C(),f(p.$$.fragment)},l(s){g(t.$$.fragment,s),l=k(s),g(e.$$.fragment,s),i=k(s),g(c.$$.fragment,s),n=k(s),g(a.$$.fragment,s),o=k(s),g(m.$$.fragment,s),Y=k(s),g(p.$$.fragment,s)},m(s,h){_(t,s,h),v(s,l,h),_(e,s,h),v(s,i,h),_(c,s,h),v(s,n,h),_(a,s,h),v(s,o,h),_(m,s,h),v(s,Y,h),_(p,s,h),P=!0},p(s,h){const W={};h&5&&(W.$$scope={dirty:h,ctx:s}),e.$set(W);const F={};h&5&&(F.$$scope={dirty:h,ctx:s}),c.$set(F);const K={};h&5&&(K.$$scope={dirty:h,ctx:s}),a.$set(K);const R={};h&5&&(R.$$scope={dirty:h,ctx:s}),m.$set(R);const V={};h&5&&(V.$$scope={dirty:h,ctx:s}),p.$set(V)},i(s){P||(y(t.$$.fragment,s),y(e.$$.fragment,s),y(c.$$.fragment,s),y(a.$$.fragment,s),y(m.$$.fragment,s),y(p.$$.fragment,s),P=!0)},o(s){w(t.$$.fragment,s),w(e.$$.fragment,s),w(c.$$.fragment,s),w(a.$$.fragment,s),w(m.$$.fragment,s),w(p.$$.fragment,s),P=!1},d(s){s&&(r(l),r(i),r(n),r(o),r(Y)),x(t,s),x(e,s),x(c,s),x(a,s),x(m,s),x(p,s)}}}function vt(d){let t,l;const e=[d[1],N];let i={$$slots:{default:[rt]},$$scope:{ctx:d}};for(let c=0;c<e.length;c+=1)i=S(i,e[c]);return t=new X({props:i}),{c(){f(t.$$.fragment)},l(c){g(t.$$.fragment,c)},m(c,n){_(t,c,n),l=!0},p(c,[n]){const a=n&2?Q(e,[n&2&&J(c[1]),n&0&&J(N)]):{};n&5&&(a.$$scope={dirty:n,ctx:c}),t.$set(a)},i(c){l||(y(t.$$.fragment,c),l=!0)},o(c){w(t.$$.fragment,c),l=!1},d(c){x(t,c)}}}const N={title:"Chat bubble",desc:"Chat bubbles are used to show one line of conversation and all its data, including the author image, author name, time, etc.",published:!0};function ut(d,t,l){let e;return B(d,Z,i=>l(0,e=i)),d.$$set=i=>{l(1,t=S(S({},t),q(i)))},t=q(t),[e,t]}class gt extends U{constructor(t){super(),G(this,t,ut,vt,z,{})}}export{gt as component};
