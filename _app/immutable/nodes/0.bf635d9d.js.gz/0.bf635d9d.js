import{L as e,_ as n}from"../chunks/0.86421788.js";export{e as component,n as universal};
