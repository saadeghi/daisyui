import{s as st,E as X,y as nt,O as tt,f as d,a as C,g as f,z as w,c as M,j as m,i as $,d as u,w as V,l as j,h as E,m as O,v as h,Y as R,U as q,G as N}from"../chunks/scheduler.e71eccdd.js";import{S as at,i as ot,b as L,d as k,m as P,a as D,t as H,e as I}from"../chunks/index.445ee094.js";import{g as pt,a as et}from"../chunks/index.18b79e66.js";import{M as rt}from"../chunks/mdsvex.ebbe1b00.js";import{p as it,C as ut,a as G,r as B}from"../chunks/ClassTable.4105d84b.js";function ct(i){let t,o='<label class="label"><span class="label-text">Your Email</span></label> <label class="input-group"><span>Email</span> <input type="text" placeholder="info@site.com" class="input input-bordered"/></label>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-9voxl5"&&(t.innerHTML=o),this.h()},h(){m(t,"class","form-control")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function $t(i){let t,o=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Your Email</span>
  </label>
  <label class="$$input-group">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" class="$$input $$input-bordered" />
  </label>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function dt(i){let t,o='<label class="label"><span class="label-text">Enter amount</span></label> <label class="input-group"><input type="text" placeholder="0.01" class="input input-bordered"/> <span>BTC</span></label>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-1qq5eg0"&&(t.innerHTML=o),this.h()},h(){m(t,"class","form-control")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function ft(i){let t,o=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Enter amount</span>
  </label>
  <label class="$$input-group">
    <input type="text" placeholder="0.01" class="$$input $$input-bordered" />
    <span>BTC</span>
  </label>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function mt(i){let t,o='<label class="label"><span class="label-text">Enter amount</span></label> <label class="input-group"><span>Price</span> <input type="text" placeholder="10" class="input input-bordered"/> <span>USD</span></label>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-1l327fh"&&(t.innerHTML=o),this.h()},h(){m(t,"class","form-control")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function ht(i){let t,o=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Enter amount</span>
  </label>
  <label class="$$input-group">
    <span>Price</span>
    <input type="text" placeholder="10" class="$$input $$input-bordered" />
    <span>USD</span>
  </label>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function vt(i){let t,o='<label class="label"><span class="label-text">Your Email</span></label> <label class="input-group input-group-vertical"><span>Email</span> <input type="text" placeholder="info@site.com" class="input input-bordered"/></label>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-impxiu"&&(t.innerHTML=o),this.h()},h(){m(t,"class","form-control")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function _t(i){let t,o=`<div class="$$form-control">
  <label class="$$label">
    <span class="$$label-text">Your Email</span>
  </label>
  <label class="$$input-group $$input-group-vertical">
    <span>Email</span>
    <input type="text" placeholder="info@site.com" class="$$input $$input-bordered" />
  </label>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function bt(i){let t,o='<div class="form-control"><label class="input-group input-group-lg"><span>LG</span> <input type="text" placeholder="Type here" class="input input-bordered input-lg"/></label></div> <div class="form-control"><label class="input-group input-group-md"><span>MD</span> <input type="text" placeholder="Type here" class="input input-bordered input-md"/></label></div> <div class="form-control"><label class="input-group input-group-sm"><span>SM</span> <input type="text" placeholder="Type here" class="input input-bordered input-sm"/></label></div> <div class="form-control"><label class="input-group input-group-xs"><span>XS</span> <input type="text" placeholder="Type here" class="input input-bordered input-xs"/></label></div>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-ycxjp6"&&(t.innerHTML=o),this.h()},h(){m(t,"class","flex flex-col gap-4 items-center")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function gt(i){let t,o=`<div class="$$form-control">
  <label class="$$input-group $$input-group-lg">
    <span>LG</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-lg" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-md">
    <span>MD</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-md" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-sm">
    <span>SM</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-sm" />
  </label>
</div>
<div class="$$form-control">
  <label class="$$input-group $$input-group-xs">
    <span>XS</span>
    <input type="text" placeholder="Type here" class="$$input $$input-bordered $$input-xs" />
  </label>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function xt(i){let t,o='<div class="input-group"><input type="text" placeholder="Search…" class="input input-bordered"/> <button class="btn btn-square"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></button></div>';return{c(){t=d("div"),t.innerHTML=o,this.h()},l(e){t=f(e,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-1caev5e"&&(t.innerHTML=o),this.h()},h(){m(t,"class","form-control")},m(e,l){$(e,t,l)},p:V,d(e){e&&u(t)}}}function wt(i){let t,o=`<div class="$$form-control">
  <div class="$$input-group">
    <input type="text" placeholder="Search…" class="$$input $$input-bordered" />
    <button class="$$btn $$btn-square">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
    </button>
  </div>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function Tt(i){let t,o,e,l,p="Pick category",r,a="T-shirts",n,S="Mugs",b,g,x="Go";return{c(){t=d("div"),o=d("div"),e=d("select"),l=d("option"),l.textContent=p,r=d("option"),r.textContent=a,n=d("option"),n.textContent=S,b=C(),g=d("button"),g.textContent=x,this.h()},l(T){t=f(T,"DIV",{class:!0});var v=E(t);o=f(v,"DIV",{class:!0});var y=E(o);e=f(y,"SELECT",{class:!0});var _=E(e);l=f(_,"OPTION",{"data-svelte-h":!0}),w(l)!=="svelte-1nzoa7o"&&(l.textContent=p),r=f(_,"OPTION",{"data-svelte-h":!0}),w(r)!=="svelte-12hv6fq"&&(r.textContent=a),n=f(_,"OPTION",{"data-svelte-h":!0}),w(n)!=="svelte-1fki2vk"&&(n.textContent=S),_.forEach(u),b=M(y),g=f(y,"BUTTON",{class:!0,"data-svelte-h":!0}),w(g)!=="svelte-157zp5v"&&(g.textContent=x),y.forEach(u),v.forEach(u),this.h()},h(){l.disabled=!0,l.selected=!0,l.__value="Pick category",N(l,l.__value),r.__value="T-shirts",N(r,r.__value),n.__value="Mugs",N(n,n.__value),m(e,"class","select select-bordered"),m(g,"class","btn"),m(o,"class","input-group"),m(t,"class","form-control")},m(T,v){$(T,t,v),h(t,o),h(o,e),h(e,l),h(e,r),h(e,n),h(o,b),h(o,g)},p:V,d(T){T&&u(t)}}}function Et(i){let t,o=`<div class="$$form-control">
  <div class="$$input-group">
    <select class="$$select $$select-bordered">
      <option disabled selected>Pick category</option>
      <option>T-shirts</option>
      <option>Mugs</option>
    </select>
    <button class="$$btn">Go</button>
  </div>
</div>`,e,l,p,r;return{c(){t=d("pre"),e=j(o),this.h()},l(a){t=f(a,"PRE",{slot:!0});var n=E(t);e=O(n,o),n.forEach(u),this.h()},h(){m(t,"slot","html")},m(a,n){$(a,t,n),h(t,e),p||(r=R(l=B.call(null,t,{to:i[0]})),p=!0)},p(a,n){l&&q(l.update)&&n&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(t),p=!1,r()}}}function yt(i){let t,o='<svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg> <div><div class="font-bold">Deprecated</div> <div>This component is deprecated and will be removed in the next major version. Use <a class="link" href="/components/join">Join</a> instead.</div></div>',e,l,p,r,a,n,S,b,g,x,T,v,y,_,U,z,Y;return l=new ut({props:{data:[{type:"component",class:"input-group",desc:"Container for grouping elements"},{type:"modifier",class:"input-group-lg",desc:"Large size for input-group wrapper"},{type:"modifier",class:"input-group-md",desc:"Medium (default) size for input-group wrapper"},{type:"modifier",class:"input-group-sm",desc:"Small size for input-group wrapper"},{type:"modifier",class:"input-group-xs",desc:"Extra small size for input-group wrapper"},{type:"modifier",class:"input-group-vertical",desc:"Vertical direction for input-group items"}]}}),r=new G({props:{title:"Group label and text input horizontally",$$slots:{html:[$t],default:[ct]},$$scope:{ctx:i}}}),n=new G({props:{title:"Group text input and label horizontally",$$slots:{html:[ft],default:[dt]},$$scope:{ctx:i}}}),b=new G({props:{title:"label on both sides",$$slots:{html:[ht],default:[mt]},$$scope:{ctx:i}}}),x=new G({props:{title:"Group label and text input vertically",$$slots:{html:[_t],default:[vt]},$$scope:{ctx:i}}}),v=new G({props:{title:"Sizes",$$slots:{html:[gt],default:[bt]},$$scope:{ctx:i}}}),_=new G({props:{title:"Group text input and button",$$slots:{html:[wt],default:[xt]},$$scope:{ctx:i}}}),z=new G({props:{title:"Group select and button",$$slots:{html:[Et],default:[Tt]},$$scope:{ctx:i}}}),{c(){t=d("div"),t.innerHTML=o,e=C(),L(l.$$.fragment),p=C(),L(r.$$.fragment),a=C(),L(n.$$.fragment),S=C(),L(b.$$.fragment),g=C(),L(x.$$.fragment),T=C(),L(v.$$.fragment),y=C(),L(_.$$.fragment),U=C(),L(z.$$.fragment),this.h()},l(s){t=f(s,"DIV",{class:!0,"data-svelte-h":!0}),w(t)!=="svelte-630dms"&&(t.innerHTML=o),e=M(s),k(l.$$.fragment,s),p=M(s),k(r.$$.fragment,s),a=M(s),k(n.$$.fragment,s),S=M(s),k(b.$$.fragment,s),g=M(s),k(x.$$.fragment,s),T=M(s),k(v.$$.fragment,s),y=M(s),k(_.$$.fragment,s),U=M(s),k(z.$$.fragment,s),this.h()},h(){m(t,"class","alert alert-warning")},m(s,c){$(s,t,c),$(s,e,c),P(l,s,c),$(s,p,c),P(r,s,c),$(s,a,c),P(n,s,c),$(s,S,c),P(b,s,c),$(s,g,c),P(x,s,c),$(s,T,c),P(v,s,c),$(s,y,c),P(_,s,c),$(s,U,c),P(z,s,c),Y=!0},p(s,c){const J={};c&5&&(J.$$scope={dirty:c,ctx:s}),r.$set(J);const A={};c&5&&(A.$$scope={dirty:c,ctx:s}),n.$set(A);const F={};c&5&&(F.$$scope={dirty:c,ctx:s}),b.$set(F);const K={};c&5&&(K.$$scope={dirty:c,ctx:s}),x.$set(K);const Q={};c&5&&(Q.$$scope={dirty:c,ctx:s}),v.$set(Q);const W={};c&5&&(W.$$scope={dirty:c,ctx:s}),_.$set(W);const Z={};c&5&&(Z.$$scope={dirty:c,ctx:s}),z.$set(Z)},i(s){Y||(D(l.$$.fragment,s),D(r.$$.fragment,s),D(n.$$.fragment,s),D(b.$$.fragment,s),D(x.$$.fragment,s),D(v.$$.fragment,s),D(_.$$.fragment,s),D(z.$$.fragment,s),Y=!0)},o(s){H(l.$$.fragment,s),H(r.$$.fragment,s),H(n.$$.fragment,s),H(b.$$.fragment,s),H(x.$$.fragment,s),H(v.$$.fragment,s),H(_.$$.fragment,s),H(z.$$.fragment,s),Y=!1},d(s){s&&(u(t),u(e),u(p),u(a),u(S),u(g),u(T),u(y),u(U)),I(l,s),I(r,s),I(n,s),I(b,s),I(x,s),I(v,s),I(_,s),I(z,s)}}}function Ct(i){let t,o;const e=[i[1],lt];let l={$$slots:{default:[yt]},$$scope:{ctx:i}};for(let p=0;p<e.length;p+=1)l=X(l,e[p]);return t=new rt({props:l}),{c(){L(t.$$.fragment)},l(p){k(t.$$.fragment,p)},m(p,r){P(t,p,r),o=!0},p(p,[r]){const a=r&2?pt(e,[r&2&&et(p[1]),r&0&&et(lt)]):{};r&5&&(a.$$scope={dirty:r,ctx:p}),t.$set(a)},i(p){o||(D(t.$$.fragment,p),o=!0)},o(p){H(t.$$.fragment,p),o=!1},d(p){I(t,p)}}}const lt={title:"Input group",desc:"Input group puts an input next to a text or a button.",published:!0};function Mt(i,t,o){let e;return nt(i,it,l=>o(0,e=l)),i.$$set=l=>{o(1,t=X(X({},t),tt(l)))},t=tt(t),[e,t]}class It extends at{constructor(t){super(),ot(this,t,Mt,Ct,st,{})}}export{It as component};
