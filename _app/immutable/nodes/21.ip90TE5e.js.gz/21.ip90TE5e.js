import{s as gt,z as tt,m as vt,A as $t,a as y,d as x,j as u,h as d,e as p,c as $,g as C,i as f,n as k,t as L,b as M,f as T,k as E,D as I,E as H}from"../chunks/scheduler.CmJ_ZkIC.js";import{S as bt,i as _t,c as m,b as g,m as v,t as b,a as _,d as w}from"../chunks/index.BimWP6M-.js";import{g as wt,a as ft}from"../chunks/spread.CgU5AtxT.js";import{M as yt}from"../chunks/mdsvex-components.CeleeIID.js";import{p as xt,C as jt,a as j,r as S}from"../chunks/ClassTable.D04Cd5SB.js";import"../chunks/entry.7Hdi37jl.js";function Ct(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-1t11mir"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function kt(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Lt(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-m10u7f"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 card-compact shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Mt(n){let t,i=`<div class="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Tt(n){let t,i=`<figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!
      <div class="badge badge-secondary">NEW</div></h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><div class="badge badge-outline">Fashion</div> <div class="badge badge-outline">Products</div></div></div>`;return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-r1vt09"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Et(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">
      Shoes!
      <div class="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <div class="$$badge $$badge-outline">Fashion</div> 
      <div class="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function It(n){let t,i='<div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p></div> <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-bfelfo"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Ht(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function St(n){let t,i='<figure class="px-10 pt-10"><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" class="rounded-xl"/></figure> <div class="card-body items-center text-center"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-6w894i"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Nt(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure class="px-10 pt-10">
    <img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" class="rounded-xl" />
  </figure>
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Dt(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-qozwxu"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl image-full")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Pt(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Bt(n){let t,i='<div class="card-body"><h2 class="card-title">Card title!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-1j6hqpx"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Rt(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Vt(n){let t,i='<div class="card-body"><h2 class="card-title">Card title!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn">Buy Now</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-xb5ud6"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-primary text-primary-content")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function At(n){let t,i=`<div class="$$card w-96 bg-primary text-primary-content">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Wt(n){let t,i='<div class="card-body items-center text-center"><h2 class="card-title">Cookies!</h2> <p>We are using cookies for no reason.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Accept</button> <button class="btn btn-ghost">Deny</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-1i3w544"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-neutral text-neutral-content")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function qt(n){let t,i=`<div class="$$card w-96 bg-neutral text-neutral-content">
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Accept</button>
      <button class="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function zt(n){let t,i='<div class="card-body"><div class="justify-end card-actions"><button class="btn btn-square btn-sm"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button></div> <p>We are using cookies for no reason.</p></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-1jhynqq"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Ft(n){let t,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Jt(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure> <div class="card-body"><h2 class="card-title">Life hack</h2> <p>How to park your car at your garage?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Learn now!</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-kyz4r3"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card w-96 glass")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Gt(n){let t,i=`<div class="$$card w-96 glass">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Kt(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure> <div class="card-body"><h2 class="card-title">New movie is released!</h2> <p>Click the button to watch on Jetflix app.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Watch</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-7d4k2"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card card-side bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Ot(n){let t,i=`<div class="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Qt(n){let t,i='<figure><img src="https://img.daisyui.com/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure> <div class="card-body"><h2 class="card-title">New album is released!</h2> <p>Click the button to listen on Spotiwhy app.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Listen</button></div></div>';return{c(){t=p("div"),t.innerHTML=i,this.h()},l(e){t=$(e,"DIV",{class:!0,"data-svelte-h":!0}),C(t)!=="svelte-1jm8io1"&&(t.innerHTML=i),this.h()},h(){f(t,"class","card lg:card-side bg-base-100 shadow-xl")},m(e,o){u(e,t,o)},p:k,d(e){e&&d(t)}}}function Ut(n){let t,i=`<div class="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="https://img.daisyui.com/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,e,o,c,h;return{c(){t=p("pre"),e=L(i),this.h()},l(s){t=$(s,"PRE",{slot:!0});var l=M(t);e=T(l,i),l.forEach(d),this.h()},h(){f(t,"slot","html")},m(s,l){u(s,t,l),E(t,e),c||(h=I(o=S.call(null,t,{to:n[0]})),c=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(t),c=!1,h()}}}function Xt(n){let t,i,e,o,c,h,s,l,N,F,D,J,P,G,B,K,R,O,V,Q,A,U,W,X,q,Y,z,Z;return t=new jt({props:{data:[{type:"component",class:"card",desc:"Container element"},{type:"component",class:"card-title",desc:"Title of card"},{type:"component",class:"card-body",desc:"Container for content"},{type:"component",class:"card-actions",desc:"Container for buttons"},{type:"modifier",class:"card-bordered",desc:"Adds border to <card>"},{type:"modifier",class:"image-full",desc:"The image in <figure> element will be the background"},{type:"responsive",class:"card-normal",desc:"Applies default paddings"},{type:"responsive",class:"card-compact",desc:"Applies smaller padding"},{type:"responsive",class:"card-side",desc:"The image in <figure> will be on to the side"}]}}),e=new j({props:{title:"Card",$$slots:{html:[kt],default:[Ct]},$$scope:{ctx:n}}}),c=new j({props:{title:"Compact card (less padding for `card-body`)",$$slots:{html:[Mt],default:[Lt]},$$scope:{ctx:n}}}),s=new j({props:{title:"Card with badge",$$slots:{html:[Et],default:[Tt]},$$scope:{ctx:n}}}),N=new j({props:{title:"Card with bottom image",$$slots:{html:[Ht],default:[It]},$$scope:{ctx:n}}}),D=new j({props:{title:"Card with centered content and paddings",$$slots:{html:[Nt],default:[St]},$$scope:{ctx:n}}}),P=new j({props:{title:"Card with image overlay",$$slots:{html:[Pt],default:[Dt]},$$scope:{ctx:n}}}),B=new j({props:{title:"Card with no image",$$slots:{html:[Rt],default:[Bt]},$$scope:{ctx:n}}}),R=new j({props:{title:"Card with custom color",$$slots:{html:[At],default:[Vt]},$$scope:{ctx:n}}}),V=new j({props:{title:"Centered card with neutral color",$$slots:{html:[qt],default:[Wt]},$$scope:{ctx:n}}}),A=new j({props:{title:"Card with action on top",$$slots:{html:[Ft],default:[zt]},$$scope:{ctx:n}}}),W=new j({props:{title:"Card glass",bg:"https://img.daisyui.com/images/stock/photo-1481026469463-66327c86e544.jpg",$$slots:{html:[Gt],default:[Jt]},$$scope:{ctx:n}}}),q=new j({props:{title:"Card with image on side",$$slots:{html:[Ot],default:[Kt]},$$scope:{ctx:n}}}),z=new j({props:{title:"Responsive card (vertical on small screen, horizontal on large screen)",$$slots:{html:[Ut],default:[Qt]},$$scope:{ctx:n}}}),{c(){m(t.$$.fragment),i=y(),m(e.$$.fragment),o=y(),m(c.$$.fragment),h=y(),m(s.$$.fragment),l=y(),m(N.$$.fragment),F=y(),m(D.$$.fragment),J=y(),m(P.$$.fragment),G=y(),m(B.$$.fragment),K=y(),m(R.$$.fragment),O=y(),m(V.$$.fragment),Q=y(),m(A.$$.fragment),U=y(),m(W.$$.fragment),X=y(),m(q.$$.fragment),Y=y(),m(z.$$.fragment)},l(a){g(t.$$.fragment,a),i=x(a),g(e.$$.fragment,a),o=x(a),g(c.$$.fragment,a),h=x(a),g(s.$$.fragment,a),l=x(a),g(N.$$.fragment,a),F=x(a),g(D.$$.fragment,a),J=x(a),g(P.$$.fragment,a),G=x(a),g(B.$$.fragment,a),K=x(a),g(R.$$.fragment,a),O=x(a),g(V.$$.fragment,a),Q=x(a),g(A.$$.fragment,a),U=x(a),g(W.$$.fragment,a),X=x(a),g(q.$$.fragment,a),Y=x(a),g(z.$$.fragment,a)},m(a,r){v(t,a,r),u(a,i,r),v(e,a,r),u(a,o,r),v(c,a,r),u(a,h,r),v(s,a,r),u(a,l,r),v(N,a,r),u(a,F,r),v(D,a,r),u(a,J,r),v(P,a,r),u(a,G,r),v(B,a,r),u(a,K,r),v(R,a,r),u(a,O,r),v(V,a,r),u(a,Q,r),v(A,a,r),u(a,U,r),v(W,a,r),u(a,X,r),v(q,a,r),u(a,Y,r),v(z,a,r),Z=!0},p(a,r){const et={};r&5&&(et.$$scope={dirty:r,ctx:a}),e.$set(et);const st={};r&5&&(st.$$scope={dirty:r,ctx:a}),c.$set(st);const at={};r&5&&(at.$$scope={dirty:r,ctx:a}),s.$set(at);const ot={};r&5&&(ot.$$scope={dirty:r,ctx:a}),N.$set(ot);const lt={};r&5&&(lt.$$scope={dirty:r,ctx:a}),D.$set(lt);const it={};r&5&&(it.$$scope={dirty:r,ctx:a}),P.$set(it);const ct={};r&5&&(ct.$$scope={dirty:r,ctx:a}),B.$set(ct);const nt={};r&5&&(nt.$$scope={dirty:r,ctx:a}),R.$set(nt);const rt={};r&5&&(rt.$$scope={dirty:r,ctx:a}),V.$set(rt);const dt={};r&5&&(dt.$$scope={dirty:r,ctx:a}),A.$set(dt);const ht={};r&5&&(ht.$$scope={dirty:r,ctx:a}),W.$set(ht);const ut={};r&5&&(ut.$$scope={dirty:r,ctx:a}),q.$set(ut);const pt={};r&5&&(pt.$$scope={dirty:r,ctx:a}),z.$set(pt)},i(a){Z||(b(t.$$.fragment,a),b(e.$$.fragment,a),b(c.$$.fragment,a),b(s.$$.fragment,a),b(N.$$.fragment,a),b(D.$$.fragment,a),b(P.$$.fragment,a),b(B.$$.fragment,a),b(R.$$.fragment,a),b(V.$$.fragment,a),b(A.$$.fragment,a),b(W.$$.fragment,a),b(q.$$.fragment,a),b(z.$$.fragment,a),Z=!0)},o(a){_(t.$$.fragment,a),_(e.$$.fragment,a),_(c.$$.fragment,a),_(s.$$.fragment,a),_(N.$$.fragment,a),_(D.$$.fragment,a),_(P.$$.fragment,a),_(B.$$.fragment,a),_(R.$$.fragment,a),_(V.$$.fragment,a),_(A.$$.fragment,a),_(W.$$.fragment,a),_(q.$$.fragment,a),_(z.$$.fragment,a),Z=!1},d(a){a&&(d(i),d(o),d(h),d(l),d(F),d(J),d(G),d(K),d(O),d(Q),d(U),d(X),d(Y)),w(t,a),w(e,a),w(c,a),w(s,a),w(N,a),w(D,a),w(P,a),w(B,a),w(R,a),w(V,a),w(A,a),w(W,a),w(q,a),w(z,a)}}}function Yt(n){let t,i;const e=[n[1],mt];let o={$$slots:{default:[Xt]},$$scope:{ctx:n}};for(let c=0;c<e.length;c+=1)o=tt(o,e[c]);return t=new yt({props:o}),{c(){m(t.$$.fragment)},l(c){g(t.$$.fragment,c)},m(c,h){v(t,c,h),i=!0},p(c,[h]){const s=h&2?wt(e,[h&2&&ft(c[1]),h&0&&ft(mt)]):{};h&5&&(s.$$scope={dirty:h,ctx:c}),t.$set(s)},i(c){i||(b(t.$$.fragment,c),i=!0)},o(c){_(t.$$.fragment,c),i=!1},d(c){w(t,c)}}}const mt={title:"Card",desc:"Cards are used to group and display content in a way that is easily readable.",published:!0,layout:"components"};function Zt(n,t,i){let e;return vt(n,xt,o=>i(0,e=o)),n.$$set=o=>{i(1,t=tt(tt({},t),$t(o)))},t=$t(t),[e,t]}class ie extends bt{constructor(t){super(),_t(this,t,Zt,Yt,gt,{})}}export{ie as component};
