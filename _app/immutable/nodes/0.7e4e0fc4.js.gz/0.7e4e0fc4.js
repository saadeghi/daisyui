import{L as e,_ as n}from"../chunks/0.1e7b4c53.js";export{e as component,n as universal};
