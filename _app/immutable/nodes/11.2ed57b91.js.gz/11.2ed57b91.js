import{s as ce,D as le,m as de,E as oe,a as _,e as $,F as Y,d as x,c as f,b,G as K,h as c,i as r,j as m,k,g as y,n as O,t as Q,f as W,I as X,J as Z}from"../chunks/scheduler.91e121cd.js";import{S as pe,i as re,c as L,b as j,m as E,t as I,a as D,d as V}from"../chunks/index.f3ad6f48.js";import{g as me,a as ae}from"../chunks/spread.8a54911c.js";import{M as ve}from"../chunks/mdsvex-components.37095076.js";import{p as ue,C as he,a as N,r as ee}from"../chunks/ClassTable.1ae76117.js";import"../chunks/singletons.eda6d649.js";import{T as ie}from"../chunks/Translate.7e4fef29.js";function $e(h){let e,p='<input type="radio" name="my-accordion-1" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',o,l,a='<input type="radio" name="my-accordion-1"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',d,t,n='<input type="radio" name="my-accordion-1"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=$("div"),e.innerHTML=p,o=_(),l=$("div"),l.innerHTML=a,d=_(),t=$("div"),t.innerHTML=n,this.h()},l(i){e=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(e)!=="svelte-clm1hr"&&(e.innerHTML=p),o=x(i),l=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(l)!=="svelte-h9xsaw"&&(l.innerHTML=a),d=x(i),t=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(t)!=="svelte-h9xsaw"&&(t.innerHTML=n),this.h()},h(){r(e,"class","collapse bg-base-200"),r(l,"class","collapse bg-base-200"),r(t,"class","collapse bg-base-200")},m(i,v){m(i,e,v),m(i,o,v),m(i,l,v),m(i,d,v),m(i,t,v)},p:O,d(i){i&&(c(e),c(o),c(l),c(d),c(t))}}}function fe(h){let e,p=`<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,o,l,a,d;return{c(){e=$("pre"),o=Q(p),this.h()},l(t){e=f(t,"PRE",{slot:!0});var n=b(e);o=W(n,p),n.forEach(c),this.h()},h(){r(e,"slot","html")},m(t,n){m(t,e,n),k(e,o),a||(d=X(l=ee.call(null,e,{to:h[0]})),a=!0)},p(t,n){l&&Z(l.update)&&n&1&&l.update.call(null,{to:t[0]})},d(t){t&&c(e),a=!1,d()}}}function _e(h){let e,p='<input type="radio" name="my-accordion-2" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',o,l,a='<input type="radio" name="my-accordion-2"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',d,t,n='<input type="radio" name="my-accordion-2"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=$("div"),e.innerHTML=p,o=_(),l=$("div"),l.innerHTML=a,d=_(),t=$("div"),t.innerHTML=n,this.h()},l(i){e=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(e)!=="svelte-497nvj"&&(e.innerHTML=p),o=x(i),l=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(l)!=="svelte-mpai6"&&(l.innerHTML=a),d=x(i),t=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(t)!=="svelte-mpai6"&&(t.innerHTML=n),this.h()},h(){r(e,"class","collapse collapse-arrow bg-base-200"),r(l,"class","collapse collapse-arrow bg-base-200"),r(t,"class","collapse collapse-arrow bg-base-200")},m(i,v){m(i,e,v),m(i,o,v),m(i,l,v),m(i,d,v),m(i,t,v)},p:O,d(i){i&&(c(e),c(o),c(l),c(d),c(t))}}}function xe(h){let e,p=`<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,o,l,a,d;return{c(){e=$("pre"),o=Q(p),this.h()},l(t){e=f(t,"PRE",{slot:!0});var n=b(e);o=W(n,p),n.forEach(c),this.h()},h(){r(e,"slot","html")},m(t,n){m(t,e,n),k(e,o),a||(d=X(l=ee.call(null,e,{to:h[0]})),a=!0)},p(t,n){l&&Z(l.update)&&n&1&&l.update.call(null,{to:t[0]})},d(t){t&&c(e),a=!1,d()}}}function be(h){let e,p='<input type="radio" name="my-accordion-3" checked="checked"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',o,l,a='<input type="radio" name="my-accordion-3"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>',d,t,n='<input type="radio" name="my-accordion-3"/> <div class="collapse-title text-xl font-medium">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div>';return{c(){e=$("div"),e.innerHTML=p,o=_(),l=$("div"),l.innerHTML=a,d=_(),t=$("div"),t.innerHTML=n,this.h()},l(i){e=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(e)!=="svelte-1n8yy1f"&&(e.innerHTML=p),o=x(i),l=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(l)!=="svelte-7maod4"&&(l.innerHTML=a),d=x(i),t=f(i,"DIV",{class:!0,"data-svelte-h":!0}),y(t)!=="svelte-7maod4"&&(t.innerHTML=n),this.h()},h(){r(e,"class","collapse collapse-plus bg-base-200"),r(l,"class","collapse collapse-plus bg-base-200"),r(t,"class","collapse collapse-plus bg-base-200")},m(i,v){m(i,e,v),m(i,o,v),m(i,l,v),m(i,d,v),m(i,t,v)},p:O,d(i){i&&(c(e),c(o),c(l),c(d),c(t))}}}function ke(h){let e,p=`<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,o,l,a,d;return{c(){e=$("pre"),o=Q(p),this.h()},l(t){e=f(t,"PRE",{slot:!0});var n=b(e);o=W(n,p),n.forEach(c),this.h()},h(){r(e,"slot","html")},m(t,n){m(t,e,n),k(e,o),a||(d=X(l=ee.call(null,e,{to:h[0]})),a=!0)},p(t,n){l&&Z(l.update)&&n&1&&l.update.call(null,{to:t[0]})},d(t){t&&c(e),a=!1,d()}}}function ye(h){let e,p='<div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4" checked="checked"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div> <div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div> <div class="collapse collapse-arrow join-item border border-base-300"><input type="radio" name="my-accordion-4"/> <div class="collapse-title">Click to open this one and close others</div> <div class="collapse-content"><p>hello</p></div></div>';return{c(){e=$("div"),e.innerHTML=p,this.h()},l(o){e=f(o,"DIV",{class:!0,"data-svelte-h":!0}),y(e)!=="svelte-mwrxrm"&&(e.innerHTML=p),this.h()},h(){r(e,"class","join join-vertical w-full")},m(o,l){m(o,e,l)},p:O,d(o){o&&c(e)}}}function ge(h){let e,p=`<div class="$$join $$join-vertical w-full">
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" checked="checked" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
</div>`,o,l,a,d;return{c(){e=$("pre"),o=Q(p),this.h()},l(t){e=f(t,"PRE",{slot:!0});var n=b(e);o=W(n,p),n.forEach(c),this.h()},h(){r(e,"slot","html")},m(t,n){m(t,e,n),k(e,o),a||(d=X(l=ee.call(null,e,{to:h[0]})),a=!0)},p(t,n){l&&Z(l.update)&&n&1&&l.update.call(null,{to:t[0]})},d(t){t&&c(e),a=!1,d()}}}function we(h){let e,p,o,l,a,d,t,n,i,v,g,w,te,B,A,J,C,S,M,q,T,G,H,U;return e=new he({props:{data:[{type:"component",class:"collapse",desc:"Container element"},{type:"component",class:"collapse-title",desc:"Title element"},{type:"component",class:"collapse-content",desc:"Container for content"},{type:"modifier",class:"collapse-arrow",desc:"Adds arrow icon"},{type:"modifier",class:"collapse-plus",desc:"Adds plus/minus icon"},{type:"modifier",class:"collapse-open",desc:"Force open"},{type:"modifier",class:"collapse-close",desc:"Force close"}]}}),n=new ie({props:{text:"Accordion uses the same style as the <a href='/components/collapse/' class='link'>collapse component</a> but it works with radio inputs. You can control which item to be open by checking/unchecking the hidden radio input."}}),A=new ie({props:{text:"All radio inputs with the same name work together and only one of them can be open at a time. If you have more than one set of accordion items on a page, use different names for the radio inputs on each set."}}),C=new N({props:{title:"Accordion using radio inputs",$$slots:{html:[fe],default:[$e]},$$scope:{ctx:h}}}),M=new N({props:{title:"Accordion with arrow icon",$$slots:{html:[xe],default:[_e]},$$scope:{ctx:h}}}),T=new N({props:{title:"Accordion with plus/minus icon",$$slots:{html:[ke],default:[be]},$$scope:{ctx:h}}}),H=new N({props:{title:"Using Accordion and Join together",desc:"to join the items together and handle border radius automatically",$$slots:{html:[ge],default:[ye]},$$scope:{ctx:h}}}),{c(){L(e.$$.fragment),p=_(),o=$("div"),l=Y("svg"),a=Y("path"),d=_(),t=$("div"),L(n.$$.fragment),i=_(),v=$("div"),g=Y("svg"),w=Y("path"),te=_(),B=$("div"),L(A.$$.fragment),J=_(),L(C.$$.fragment),S=_(),L(M.$$.fragment),q=_(),L(T.$$.fragment),G=_(),L(H.$$.fragment),this.h()},l(s){j(e.$$.fragment,s),p=x(s),o=f(s,"DIV",{class:!0});var u=b(o);l=K(u,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var R=b(l);a=K(R,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),b(a).forEach(c),R.forEach(c),d=x(u),t=f(u,"DIV",{});var F=b(t);j(n.$$.fragment,F),F.forEach(c),u.forEach(c),i=x(s),v=f(s,"DIV",{class:!0});var P=b(v);g=K(P,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var z=b(g);w=K(z,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),b(w).forEach(c),z.forEach(c),te=x(P),B=f(P,"DIV",{});var se=b(B);j(A.$$.fragment,se),se.forEach(c),P.forEach(c),J=x(s),j(C.$$.fragment,s),S=x(s),j(M.$$.fragment,s),q=x(s),j(T.$$.fragment,s),G=x(s),j(H.$$.fragment,s),this.h()},h(){r(a,"stroke-linecap","round"),r(a,"stroke-linejoin","round"),r(a,"stroke-width","2"),r(a,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),r(l,"xmlns","http://www.w3.org/2000/svg"),r(l,"fill","none"),r(l,"viewBox","0 0 24 24"),r(l,"class","stroke-current shrink-0 w-6 h-6"),r(o,"class","alert text-sm mt-4"),r(w,"stroke-linecap","round"),r(w,"stroke-linejoin","round"),r(w,"stroke-width","2"),r(w,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),r(g,"xmlns","http://www.w3.org/2000/svg"),r(g,"fill","none"),r(g,"viewBox","0 0 24 24"),r(g,"class","stroke-current shrink-0 w-6 h-6"),r(v,"class","alert text-sm mt-4")},m(s,u){E(e,s,u),m(s,p,u),m(s,o,u),k(o,l),k(l,a),k(o,d),k(o,t),E(n,t,null),m(s,i,u),m(s,v,u),k(v,g),k(g,w),k(v,te),k(v,B),E(A,B,null),m(s,J,u),E(C,s,u),m(s,S,u),E(M,s,u),m(s,q,u),E(T,s,u),m(s,G,u),E(H,s,u),U=!0},p(s,u){const R={};u&5&&(R.$$scope={dirty:u,ctx:s}),C.$set(R);const F={};u&5&&(F.$$scope={dirty:u,ctx:s}),M.$set(F);const P={};u&5&&(P.$$scope={dirty:u,ctx:s}),T.$set(P);const z={};u&5&&(z.$$scope={dirty:u,ctx:s}),H.$set(z)},i(s){U||(I(e.$$.fragment,s),I(n.$$.fragment,s),I(A.$$.fragment,s),I(C.$$.fragment,s),I(M.$$.fragment,s),I(T.$$.fragment,s),I(H.$$.fragment,s),U=!0)},o(s){D(e.$$.fragment,s),D(n.$$.fragment,s),D(A.$$.fragment,s),D(C.$$.fragment,s),D(M.$$.fragment,s),D(T.$$.fragment,s),D(H.$$.fragment,s),U=!1},d(s){s&&(c(p),c(o),c(i),c(v),c(J),c(S),c(q),c(G)),V(e,s),V(n),V(A),V(C,s),V(M,s),V(T,s),V(H,s)}}}function Ce(h){let e,p;const o=[h[1],ne];let l={$$slots:{default:[we]},$$scope:{ctx:h}};for(let a=0;a<o.length;a+=1)l=le(l,o[a]);return e=new ve({props:l}),{c(){L(e.$$.fragment)},l(a){j(e.$$.fragment,a)},m(a,d){E(e,a,d),p=!0},p(a,[d]){const t=d&2?me(o,[d&2&&ae(a[1]),d&0&&ae(ne)]):{};d&5&&(t.$$scope={dirty:d,ctx:a}),e.$set(t)},i(a){p||(I(e.$$.fragment,a),p=!0)},o(a){D(e.$$.fragment,a),p=!1},d(a){V(e,a)}}}const ne={title:"Accordion",desc:"Accordion is used for showing and hiding content but only one item can stay open at a time.",published:!0,layout:"components"};function Me(h,e,p){let o;return de(h,ue,l=>p(0,o=l)),h.$$set=l=>{p(1,e=le(le({},e),oe(l)))},e=oe(e),[o,e]}class Ve extends pe{constructor(e){super(),re(this,e,Me,Ce,ce,{})}}export{Ve as component};
