import{s as ls,z as N,m as cs,A as is,a as _,d as S,j as p,h as u,e as n,c as g,g as k,i as f,n as C,t as T,b as x,f as M,k as H,D as L,E}from"../chunks/scheduler.CmJ_ZkIC.js";import{S as os,i as ms,c as h,b as v,m as $,t as b,a as w,d as y}from"../chunks/index.BimWP6M-.js";import{g as ds,a as es}from"../chunks/spread.CgU5AtxT.js";import{M as rs}from"../chunks/mdsvex-components.CeleeIID.js";import{p as us,C as ps,a as j,r as D}from"../chunks/ClassTable.D04Cd5SB.js";import"../chunks/entry.7Hdi37jl.js";function ns(d){let s,c='<div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Carousel slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Carousel slider"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-1i0lc1s"&&(s.innerHTML=c),this.h()},h(){f(s,"class","carousel rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function gs(d){let s,c=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function fs(d){let s,c='<div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Tailwind CSS slider"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Tailwind CSS slider"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-1qfyyf7"&&(s.innerHTML=c),this.h()},h(){f(s,"class","carousel carousel-center rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function hs(d){let s,c=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function vs(d){let s,c='<div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Tailwind CSS slide component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Tailwind CSS slide component"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-1b6mm22"&&(s.innerHTML=c),this.h()},h(){f(s,"class","carousel carousel-end rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function $s(d){let s,c=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function bs(d){let s,c='<div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-5ul7u4"&&(s.innerHTML=c),this.h()},h(){f(s,"class","w-64 carousel rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function ws(d){let s,c=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function ys(d){let s,c='<div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Free Tailwind CSS Slider"/></div> <div class="carousel-item h-full"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Free Tailwind CSS Slider"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-gixyr0"&&(s.innerHTML=c),this.h()},h(){f(s,"class","h-96 carousel carousel-vertical rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function _s(d){let s,c=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function Ss(d){let s,c='<div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div> <div class="w-1/2 carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS slide plugin"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-18hfi0p"&&(s.innerHTML=c),this.h()},h(){f(s,"class","w-96 carousel rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function ks(d){let s,c=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function js(d){let s,c='<div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" alt="Tailwind CSS component"/></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-x6h0d5"&&(s.innerHTML=c),this.h()},h(){f(s,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function Cs(d){let s,c=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="https://img.daisyui.com/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" />
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function Ts(d){let s,c='<div id="item1" class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" alt="Tailwind CSS gallery"/></div> <div id="item2" class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" alt="Tailwind CSS gallery"/></div> <div id="item3" class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" alt="Tailwind CSS gallery"/></div> <div id="item4" class="w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" alt="Tailwind CSS gallery"/></div>',t,a,o='<a href="#item1" class="btn btn-xs">1</a> <a href="#item2" class="btn btn-xs">2</a> <a href="#item3" class="btn btn-xs">3</a> <a href="#item4" class="btn btn-xs">4</a>';return{c(){s=n("div"),s.innerHTML=c,t=_(),a=n("div"),a.innerHTML=o,this.h()},l(m){s=g(m,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-1lgixad"&&(s.innerHTML=c),t=S(m),a=g(m,"DIV",{class:!0,"data-svelte-h":!0}),k(a)!=="svelte-941awq"&&(a.innerHTML=o),this.h()},h(){f(s,"class","w-full carousel"),f(a,"class","flex justify-center w-full py-2 gap-2")},m(m,i){p(m,s,i),p(m,t,i),p(m,a,i)},p:C,d(m){m&&(u(s),u(t),u(a))}}}function xs(d){let s,c=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function Ms(d){let s,c='<div id="slide1" class="relative w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" alt="Tailwind CSS slide example"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide4" class="btn btn-circle">❮</a> <a href="#slide2" class="btn btn-circle">❯</a></div></div> <div id="slide2" class="relative w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" alt="Tailwind CSS slide example"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide1" class="btn btn-circle">❮</a> <a href="#slide3" class="btn btn-circle">❯</a></div></div> <div id="slide3" class="relative w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" alt="Tailwind CSS slide example"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide2" class="btn btn-circle">❮</a> <a href="#slide4" class="btn btn-circle">❯</a></div></div> <div id="slide4" class="relative w-full carousel-item"><img src="https://img.daisyui.com/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" alt="Tailwind CSS slide example"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide3" class="btn btn-circle">❮</a> <a href="#slide1" class="btn btn-circle">❯</a></div></div>';return{c(){s=n("div"),s.innerHTML=c,this.h()},l(t){s=g(t,"DIV",{class:!0,"data-svelte-h":!0}),k(s)!=="svelte-16bqnd9"&&(s.innerHTML=c),this.h()},h(){f(s,"class","w-full carousel")},m(t,a){p(t,s,a)},p:C,d(t){t&&u(s)}}}function Hs(d){let s,c=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">❮</a> 
      <a href="#slide2" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">❮</a> 
      <a href="#slide3" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">❮</a> 
      <a href="#slide4" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="https://img.daisyui.com/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">❮</a> 
      <a href="#slide1" class="btn btn-circle">❯</a>
    </div>
  </div>
</div>`,t,a,o,m;return{c(){s=n("pre"),t=T(c),this.h()},l(i){s=g(i,"PRE",{slot:!0});var l=x(s);t=M(l,c),l.forEach(u),this.h()},h(){f(s,"slot","html")},m(i,l){p(i,s,l),H(s,t),o||(m=L(a=D.call(null,s,{to:d[0]})),o=!0)},p(i,l){a&&E(a.update)&&l&1&&a.update.call(null,{to:i[0]})},d(i){i&&u(s),o=!1,m()}}}function Ls(d){let s,c,t,a,o,m,i,l,P,B,z,q,V,A,I,G,R,J,F,K;return s=new ps({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-start",desc:"Snap elements to start(default)"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),t=new j({props:{title:"Snap to start (default)",$$slots:{html:[gs],default:[ns]},$$scope:{ctx:d}}}),o=new j({props:{title:"Snap to center",$$slots:{html:[hs],default:[fs]},$$scope:{ctx:d}}}),i=new j({props:{title:"Snap to end",$$slots:{html:[$s],default:[vs]},$$scope:{ctx:d}}}),P=new j({props:{title:"Carousel with full width items",$$slots:{html:[ws],default:[bs]},$$scope:{ctx:d}}}),z=new j({props:{title:"Vertical carousel",$$slots:{html:[_s],default:[ys]},$$scope:{ctx:d}}}),V=new j({props:{title:"Carousel with half width items",$$slots:{html:[ks],default:[Ss]},$$scope:{ctx:d}}}),I=new j({props:{title:"Full-bleed carousel",$$slots:{html:[Cs],default:[js]},$$scope:{ctx:d}}}),R=new j({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[xs],default:[Ts]},$$scope:{ctx:d}}}),F=new j({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[Hs],default:[Ms]},$$scope:{ctx:d}}}),{c(){h(s.$$.fragment),c=_(),h(t.$$.fragment),a=_(),h(o.$$.fragment),m=_(),h(i.$$.fragment),l=_(),h(P.$$.fragment),B=_(),h(z.$$.fragment),q=_(),h(V.$$.fragment),A=_(),h(I.$$.fragment),G=_(),h(R.$$.fragment),J=_(),h(F.$$.fragment)},l(e){v(s.$$.fragment,e),c=S(e),v(t.$$.fragment,e),a=S(e),v(o.$$.fragment,e),m=S(e),v(i.$$.fragment,e),l=S(e),v(P.$$.fragment,e),B=S(e),v(z.$$.fragment,e),q=S(e),v(V.$$.fragment,e),A=S(e),v(I.$$.fragment,e),G=S(e),v(R.$$.fragment,e),J=S(e),v(F.$$.fragment,e)},m(e,r){$(s,e,r),p(e,c,r),$(t,e,r),p(e,a,r),$(o,e,r),p(e,m,r),$(i,e,r),p(e,l,r),$(P,e,r),p(e,B,r),$(z,e,r),p(e,q,r),$(V,e,r),p(e,A,r),$(I,e,r),p(e,G,r),$(R,e,r),p(e,J,r),$(F,e,r),K=!0},p(e,r){const O={};r&5&&(O.$$scope={dirty:r,ctx:e}),t.$set(O);const Q={};r&5&&(Q.$$scope={dirty:r,ctx:e}),o.$set(Q);const U={};r&5&&(U.$$scope={dirty:r,ctx:e}),i.$set(U);const W={};r&5&&(W.$$scope={dirty:r,ctx:e}),P.$set(W);const X={};r&5&&(X.$$scope={dirty:r,ctx:e}),z.$set(X);const Y={};r&5&&(Y.$$scope={dirty:r,ctx:e}),V.$set(Y);const Z={};r&5&&(Z.$$scope={dirty:r,ctx:e}),I.$set(Z);const ss={};r&5&&(ss.$$scope={dirty:r,ctx:e}),R.$set(ss);const ts={};r&5&&(ts.$$scope={dirty:r,ctx:e}),F.$set(ts)},i(e){K||(b(s.$$.fragment,e),b(t.$$.fragment,e),b(o.$$.fragment,e),b(i.$$.fragment,e),b(P.$$.fragment,e),b(z.$$.fragment,e),b(V.$$.fragment,e),b(I.$$.fragment,e),b(R.$$.fragment,e),b(F.$$.fragment,e),K=!0)},o(e){w(s.$$.fragment,e),w(t.$$.fragment,e),w(o.$$.fragment,e),w(i.$$.fragment,e),w(P.$$.fragment,e),w(z.$$.fragment,e),w(V.$$.fragment,e),w(I.$$.fragment,e),w(R.$$.fragment,e),w(F.$$.fragment,e),K=!1},d(e){e&&(u(c),u(a),u(m),u(l),u(B),u(q),u(A),u(G),u(J)),y(s,e),y(t,e),y(o,e),y(i,e),y(P,e),y(z,e),y(V,e),y(I,e),y(R,e),y(F,e)}}}function Es(d){let s,c;const t=[d[1],as];let a={$$slots:{default:[Ls]},$$scope:{ctx:d}};for(let o=0;o<t.length;o+=1)a=N(a,t[o]);return s=new rs({props:a}),{c(){h(s.$$.fragment)},l(o){v(s.$$.fragment,o)},m(o,m){$(s,o,m),c=!0},p(o,[m]){const i=m&2?ds(t,[m&2&&es(o[1]),m&0&&es(as)]):{};m&5&&(i.$$scope={dirty:m,ctx:o}),s.$set(i)},i(o){c||(b(s.$$.fragment,o),c=!0)},o(o){w(s.$$.fragment,o),c=!1},d(o){y(s,o)}}}const as={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0,layout:"components"};function Ds(d,s,c){let t;return cs(d,us,a=>c(0,t=a)),d.$$set=a=>{c(1,s=N(N({},s),is(a)))},s=is(s),[t,s]}class Bs extends os{constructor(s){super(),ms(this,s,Ds,Es,ls,{})}}export{Bs as component};
