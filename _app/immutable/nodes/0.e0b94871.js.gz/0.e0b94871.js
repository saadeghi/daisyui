import{L as e,_ as n}from"../chunks/0.690b53b6.js";export{e as component,n as universal};
