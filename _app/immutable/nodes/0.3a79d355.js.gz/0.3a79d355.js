import{L as e,_ as n}from"../chunks/0.0c9a890f.js";export{e as component,n as universal};
