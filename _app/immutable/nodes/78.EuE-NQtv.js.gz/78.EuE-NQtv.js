import{e as H,a as y,f as x,t as K,c as s,b as a}from"../chunks/disclose-version.BlBAdxPG.js";import{h as e}from"../chunks/html.CAZA5-yU.js";import{l as N,s as O}from"../chunks/props.CsqvDH4B.js";import{M as Q}from"../chunks/mdsvex.DDLP5kHV.js";import{T as n}from"../chunks/Translate.BZKkfO8g.js";var R=K('<h2 id=""><!></h2> <!> <pre class="language-json"><!></pre> <h2 id="-1"><a aria-hidden="true" tabindex="-1" href="#-1"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a><!></h2> <!> <div class="flex gap-4 py-6 justify-between max-w-3xl"><div class="w-28 aspect-square grid place-content-center text-xs bg-primary text-primary-content rounded-box">rounded-box</div> <div class="w-28 aspect-square grid place-content-center text-xs bg-primary text-primary-content rounded-btn">rounded-btn</div> <div class="w-28 aspect-square grid place-content-center text-xs bg-primary text-primary-content rounded-badge">rounded-badge</div></div> <pre class="language-json"><!></pre> <h2 id="-2"><a aria-hidden="true" tabindex="-1" href="#-2"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a><!></h2> <!> <div class="rounded p-10 max-w-3xl " style="background-image: url(/images/stock/photo-1507358522600-9f71e620c44e.jpg);"><div class="glass w-full h-40 rounded-box grid place-content-center">Glass</div></div> <pre class="language-html"><!></pre> <h2 id="-3"><a aria-hidden="true" tabindex="-1" href="#-3"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a><!></h2> <!> <pre class="language-json"><!></pre> <h2 id="-4"><a aria-hidden="true" tabindex="-1" href="#-4"><span class="mr-1 opacity-20 hover:opacity-60 text-base font-bold inline-block align-middle relative -mt-1">#</span></a><!></h2> <!> <pre class="language-json"><!></pre>',1);const V={title:"Utility classes and CSS variables",desc:"Additional utility classes and CSS variables that daisyUI uses for components and themes",published:!0};function ea(_,w){const S=N(w,["children","$$slots","$$events"]);var t=H(),z=x(t);Q(z,O(()=>S,V,{children:(j,W)=>{var o=R(),r=x(o),C=s(r);n(C,{text:"Color utility classes"});var p=a(a(r,!0));n(p,{text:"All daisyUI colors can be used as utility classes. Just like any other Tailwind CSS color. For example you can use `primary` color with any of Tailwind CSS color utilities."});var c=a(a(p,!0)),T=s(c);e(T,()=>`<code class="language-json">bg-primary
to-primary
via-primary
from-primary
text-primary
ring-primary
fill-primary
caret-primary
stroke-primary
border-primary
divide-primary
accent-primary
shadow-primary
outline-primary
decoration-primary
placeholder-primary
ring-offset-primary

<span class="token comment">// You can also change the opacity</span>
bg-primary/<span class="token number">50</span></code>`);var l=a(a(c,!0)),$=s(l),q=a($);n(q,{text:"Border radius"});var i=a(a(l,!0));n(i,{text:"These extended border radius are being used in daisyUI components. The values depend on the theme so you can have a different design decision about border radius of elements based on the active theme. You can use any Tailwind CSS border radius class for these names as well. Like `rounded-r-box` or `rounded-tr-btn`"});var U=a(a(i,!0)),d=a(a(U,!0)),G=s(d);e(G,()=>`<code class="language-json">rounded-box     <span class="token comment">// var(--rounded-box)</span>
                <span class="token comment">// for large sized components like card, modal, etc.</span>

rounded-btn     <span class="token comment">// var(--rounded-btn)</span>
                <span class="token comment">// for medium sized components like button, input, etc.</span>

rounded-badge   <span class="token comment">// var(--rounded-badge)</span>
                <span class="token comment">// for small sized components like badge, etc.</span></code>`);var m=a(a(d,!0)),I=s(m),Y=a(I);n(Y,{text:"Glass"});var u=a(a(m,!0));n(u,{text:"These glass class to give elements a matte glass effect"});var A=a(a(u,!0)),b=a(a(A,!0)),M=s(b);e(M,()=>'<code class="language-html"><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>glass<span class="token punctuation">"</span></span><span class="token punctuation">></span></span>Glass<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">></span></span></code>');var g=a(a(b,!0)),B=s(g),F=a(B);n(F,{text:"CSS variables"});var k=a(a(g,!0));n(k,{text:"These CSS variables are being used internally. You can customize them in your custom theme in `tailwind.config.js` or you can even customize them with a class name like `[--animation-btn:0]`"});var f=a(a(k,!0)),J=s(f);e(J,()=>`<code class="language-json"><span class="token property">"--rounded-box"</span><span class="token operator">:</span> <span class="token string">"1rem"</span><span class="token punctuation">,</span>          <span class="token comment">// border radius rounded-box utility class, used in card and other large boxes</span>
<span class="token property">"--rounded-btn"</span><span class="token operator">:</span> <span class="token string">"0.5rem"</span><span class="token punctuation">,</span>        <span class="token comment">// border radius rounded-btn utility class, used in buttons and similar element</span>
<span class="token property">"--rounded-badge"</span><span class="token operator">:</span> <span class="token string">"1.9rem"</span><span class="token punctuation">,</span>      <span class="token comment">// border radius rounded-badge utility class, used in badges and similar</span>
<span class="token property">"--animation-btn"</span><span class="token operator">:</span> <span class="token string">"0.25s"</span><span class="token punctuation">,</span>       <span class="token comment">// duration of animation when you click on button</span>
<span class="token property">"--animation-input"</span><span class="token operator">:</span> <span class="token string">"0.2s"</span><span class="token punctuation">,</span>      <span class="token comment">// duration of animation for inputs like checkbox, toggle, radio, etc</span>
<span class="token property">"--btn-focus-scale"</span><span class="token operator">:</span> <span class="token string">"0.95"</span><span class="token punctuation">,</span>      <span class="token comment">// scale transform of button when you focus on it</span>
<span class="token property">"--border-btn"</span><span class="token operator">:</span> <span class="token string">"1px"</span><span class="token punctuation">,</span>            <span class="token comment">// border width of buttons</span>
<span class="token property">"--tab-border"</span><span class="token operator">:</span> <span class="token string">"1px"</span><span class="token punctuation">,</span>            <span class="token comment">// border width of tabs</span>
<span class="token property">"--tab-radius"</span><span class="token operator">:</span> <span class="token string">"0.5rem"</span><span class="token punctuation">,</span>         <span class="token comment">// border radius of tabs</span></code>`);var h=a(a(f,!0)),L=s(h),P=a(L);n(P,{text:"Component specific CSS variables"});var v=a(a(h,!0));n(v,{text:"These CSS variables are being used internally for a specific component"});var D=a(a(v,!0)),E=s(D);e(E,()=>`<code class="language-json">tab
  --tab-border <span class="token comment">// border width of tab</span>
  --tab-border-color <span class="token comment">// border color of tab</span>
  --tab-padding <span class="token comment">// horizontal padding of tab</span>
  --tab-bg <span class="token comment">// background color of tabs-lifted</span>
  --tab-radius <span class="token comment">// border radius of tabs-lifted</span>
  --tab-corner-bg <span class="token comment">// background color of tabs-lifted corner</span>
  --circle-pos <span class="token comment">// position of circle in the corner of tabs-lifted</span>
  --tab-grad <span class="token comment">// radial-gradient size in the corner of tabs-lifted</span>

countdown
  --value <span class="token comment">// value of countdown</span>

radial-progress
  --value <span class="token comment">// value of progress circle</span>
  --size <span class="token comment">// size of progress circle</span>
  --thickness <span class="token comment">// thickness of progress circle</span>

tooltip
  --tooltip-color <span class="token comment">// background color of tooltip</span>
  --tooltip-text-color <span class="token comment">// text color of tooltip</span>
  --tooltip-offset <span class="token comment">// offset of tooltip from target element</span>
  --tooltip-tail <span class="token comment">// size of tooltip tail</span>
  --tooltip-tail-offset <span class="token comment">// offset of tooltip tail from target element</span>

checkbox
  --chkbg <span class="token comment">// background color of checkbox</span>
  --chkfg <span class="token comment">// foreground color of checkbox</span>

toggle
  --tglbg <span class="token comment">// background color of toggle</span>
  --handleoffset <span class="token comment">// offset of toggle handle</span>

range
  --filler-size <span class="token comment">// size of range thumb</span>
  --filler-offset <span class="token comment">// offset of range thumb</span>
  --range-shdw <span class="token comment">// shadow color of range thumb</span>

glass
  --glass-blur <span class="token comment">// blur value of glass effect</span>
  --glass-opacity <span class="token comment">// opacity of glass effect</span>
  --glass-border-opacity <span class="token comment">// opacity of glass border</span>
  --glass-reflex-degree <span class="token comment">// degree of glass reflex</span>
  --glass-reflex-opacity <span class="token comment">// opacity of glass reflex</span>
  --glass-text-shadow-opacity <span class="token comment">// opacity of text shadow</span></code>`),y(j,o)},$$slots:{default:!0}})),y(_,t)}export{ea as component};
