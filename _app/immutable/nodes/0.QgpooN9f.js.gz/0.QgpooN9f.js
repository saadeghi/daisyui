import{L as e,_ as n}from"../chunks/0.56p8zcv8.js";export{e as component,n as universal};
