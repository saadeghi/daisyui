import{L as e,_ as n}from"../chunks/0.1988581d.js";export{e as component,n as universal};
