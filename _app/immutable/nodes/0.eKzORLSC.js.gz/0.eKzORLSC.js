import{L as e,_ as n}from"../chunks/0.Bdv89A1p.js";export{e as component,n as universal};
