import{L as e,_ as n}from"../chunks/0.8b6a6158.js";export{e as component,n as universal};
