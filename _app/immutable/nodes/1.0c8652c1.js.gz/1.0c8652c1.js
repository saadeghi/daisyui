import{E as m}from"../chunks/vendor.0c0f6e56.js";export{m as component};
