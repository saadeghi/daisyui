import{L as e,_ as n}from"../chunks/0.f489c9f5.js";export{e as component,n as universal};
