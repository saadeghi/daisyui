import{L as e,_ as n}from"../chunks/0.bdbc5c0a.js";export{e as component,n as universal};
