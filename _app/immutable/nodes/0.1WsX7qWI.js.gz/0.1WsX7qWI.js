import{L as e,_ as n}from"../chunks/0.jZ2i14P-.js";export{e as component,n as universal};
