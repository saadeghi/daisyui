import{L as e,_ as n}from"../chunks/0.7cb02a33.js";export{e as component,n as universal};
