import{L as e,_ as n}from"../chunks/0.bdfcb51c.js";export{e as component,n as universal};
