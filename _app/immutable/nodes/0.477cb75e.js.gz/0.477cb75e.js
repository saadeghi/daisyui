import{L as e,_ as n}from"../chunks/0.196da79f.js";export{e as component,n as universal};
