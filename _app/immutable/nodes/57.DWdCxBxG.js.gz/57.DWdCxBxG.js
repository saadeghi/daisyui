import{s as Z,z as J,m as tt,A as Q,a as T,d as V,j as $,h as r,e as u,c as m,g as j,i as p,n as D,t as C,b as R,f as E,k as H,D as N,E as z}from"../chunks/scheduler.z1v5p5l_.js";import{S as st,i as et,c as h,b as f,m as w,t as g,a as _,d as b}from"../chunks/index.wUxZk5jp.js";import{g as at,a as X}from"../chunks/spread.rEx3vLA9.js";import{M as it}from"../chunks/mdsvex-components.kktLoTmX.js";import{p as lt,C as dt,a as L,r as F}from"../chunks/ClassTable.j58cxytw.js";import"../chunks/singletons.fhp9tom_.js";function nt(v){let t,l='<div class="stat"><div class="stat-title">Total Page Views</div> <div class="stat-value">89,400</div> <div class="stat-desc">21% more than last month</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-12p83uj"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function vt(v){let t,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Total Page Views</div>
    <div class="$$stat-value">89,400</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function ct(v){let t,l='<div class="stat"><div class="stat-figure text-primary"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></div> <div class="stat-title">Total Likes</div> <div class="stat-value text-primary">25.6K</div> <div class="stat-desc">21% more than last month</div></div> <div class="stat"><div class="stat-figure text-secondary"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg></div> <div class="stat-title">Page Views</div> <div class="stat-value text-secondary">2.6M</div> <div class="stat-desc">21% more than last month</div></div> <div class="stat"><div class="stat-figure text-secondary"><div class="avatar online"><div class="w-16 rounded-full"><img alt="Tailwind CSS stat example component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div></div> <div class="stat-value">86%</div> <div class="stat-title">Tasks done</div> <div class="stat-desc text-secondary">31 tasks remaining</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-meir7o"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function ot(v){let t,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-primary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
    </div>
    <div class="$$stat-title">Total Likes</div>
    <div class="$$stat-value text-primary">25.6K</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
    </div>
    <div class="$$stat-title">Page Views</div>
    <div class="$$stat-value text-secondary">2.6M</div>
    <div class="$$stat-desc">21% more than last month</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <div class="$$avatar $$online">
        <div class="w-16 rounded-full">
          <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
        </div>
      </div>
    </div>
    <div class="$$stat-value">86%</div>
    <div class="$$stat-title">Tasks done</div>
    <div class="$$stat-desc text-secondary">31 tasks remaining</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function rt(v){let t,l='<div class="stat"><div class="stat-figure text-secondary"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div> <div class="stat-title">Downloads</div> <div class="stat-value">31K</div> <div class="stat-desc">Jan 1st - Feb 1st</div></div> <div class="stat"><div class="stat-figure text-secondary"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg></div> <div class="stat-title">New Users</div> <div class="stat-value">4,200</div> <div class="stat-desc">↗︎ 400 (22%)</div></div> <div class="stat"><div class="stat-figure text-secondary"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg></div> <div class="stat-title">New Registers</div> <div class="stat-value">1,200</div> <div class="stat-desc">↘︎ 90 (14%)</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-18z3jyk"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function $t(v){let t,l=`<div class="$$stats shadow">
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    </div>
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
    </div>
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-figure text-secondary">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block w-8 h-8 stroke-current"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path></svg>
    </div>
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function ut(v){let t,l='<div class="stat place-items-center"><div class="stat-title">Downloads</div> <div class="stat-value">31K</div> <div class="stat-desc">From January 1st to February 1st</div></div> <div class="stat place-items-center"><div class="stat-title">Users</div> <div class="stat-value text-secondary">4,200</div> <div class="stat-desc text-secondary">↗︎ 40 (2%)</div></div> <div class="stat place-items-center"><div class="stat-title">New Registers</div> <div class="stat-value">1,200</div> <div class="stat-desc">↘︎ 90 (14%)</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-53yplc"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function mt(v){let t,l=`<div class="$$stats shadow">
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">From January 1st to February 1st</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">Users</div>
    <div class="$$stat-value text-secondary">4,200</div>
    <div class="$$stat-desc text-secondary">↗︎ 40 (2%)</div>
  </div>
  
  <div class="$$stat place-items-center">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function pt(v){let t,l='<div class="stat"><div class="stat-title">Downloads</div> <div class="stat-value">31K</div> <div class="stat-desc">Jan 1st - Feb 1st</div></div> <div class="stat"><div class="stat-title">New Users</div> <div class="stat-value">4,200</div> <div class="stat-desc">↗︎ 400 (22%)</div></div> <div class="stat"><div class="stat-title">New Registers</div> <div class="stat-value">1,200</div> <div class="stat-desc">↘︎ 90 (14%)</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-729j38"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats stats-vertical")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function ht(v){let t,l=`<div class="$$stats $$stats-vertical shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function ft(v){let t,l='<div class="stat"><div class="stat-title">Downloads</div> <div class="stat-value">31K</div> <div class="stat-desc">Jan 1st - Feb 1st</div></div> <div class="stat"><div class="stat-title">New Users</div> <div class="stat-value">4,200</div> <div class="stat-desc">↗︎ 400 (22%)</div></div> <div class="stat"><div class="stat-title">New Registers</div> <div class="stat-value">1,200</div> <div class="stat-desc">↘︎ 90 (14%)</div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-12r1jqt"&&(t.innerHTML=l),this.h()},h(){p(t,"class","shadow stats stats-vertical lg:stats-horizontal")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function wt(v){let t,l=`<div class="$$stats $$stats-vertical lg:$$stats-horizontal shadow">
  
  <div class="$$stat">
    <div class="$$stat-title">Downloads</div>
    <div class="$$stat-value">31K</div>
    <div class="$$stat-desc">Jan 1st - Feb 1st</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Users</div>
    <div class="$$stat-value">4,200</div>
    <div class="$$stat-desc">↗︎ 400 (22%)</div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">New Registers</div>
    <div class="$$stat-value">1,200</div>
    <div class="$$stat-desc">↘︎ 90 (14%)</div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function gt(v){let t,l='<div class="stat"><div class="stat-title">Account balance</div> <div class="stat-value">$89,400</div> <div class="stat-actions"><button class="btn btn-sm btn-success">Add funds</button></div></div> <div class="stat"><div class="stat-title">Current balance</div> <div class="stat-value">$89,400</div> <div class="stat-actions"><button class="btn btn-sm">Withdrawal</button> <button class="btn btn-sm">deposit</button></div></div>';return{c(){t=u("div"),t.innerHTML=l,this.h()},l(s){t=m(s,"DIV",{class:!0,"data-svelte-h":!0}),j(t)!=="svelte-d9q9in"&&(t.innerHTML=l),this.h()},h(){p(t,"class","stats bg-primary text-primary-content")},m(s,i){$(s,t,i)},p:D,d(s){s&&r(t)}}}function _t(v){let t,l=`<div class="$$stats bg-primary text-primary-content">
  
  <div class="$$stat">
    <div class="$$stat-title">Account balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm $$btn-success">Add funds</button>
    </div>
  </div>
  
  <div class="$$stat">
    <div class="$$stat-title">Current balance</div>
    <div class="$$stat-value">$89,400</div>
    <div class="$$stat-actions">
      <button class="$$btn $$btn-sm">Withdrawal</button> 
      <button class="$$btn $$btn-sm">deposit</button>
    </div>
  </div>
  
</div>`,s,i,d,c;return{c(){t=u("pre"),s=C(l),this.h()},l(e){t=m(e,"PRE",{slot:!0});var n=R(t);s=E(n,l),n.forEach(r),this.h()},h(){p(t,"slot","html")},m(e,n){$(e,t,n),H(t,s),d||(c=N(i=F.call(null,t,{to:v[0]})),d=!0)},p(e,n){i&&z(i.update)&&n&1&&i.update.call(null,{to:e[0]})},d(e){e&&r(t),d=!1,c()}}}function bt(v){let t,l,s,i,d,c,e,n,x,P,k,S,y,B,M,K;return t=new dt({props:{data:[{type:"component",class:"stats",desc:"Container of multiple stat items"},{type:"component",class:"stat",desc:"One stat item"},{type:"component",class:"stat-title",desc:"Title text"},{type:"component",class:"stat-value",desc:"Value text"},{type:"component",class:"stat-desc",desc:"Description text"},{type:"component",class:"stat-figure",desc:"For icon, image, etc"},{type:"component",class:"stat-actions",desc:"For buttons, input, etc"},{type:"responsive",class:"stats-horizontal",desc:"Shows items horizontally (default)"},{type:"responsive",class:"stats-vertical",desc:"Shows items vertically"}]}}),s=new L({props:{title:"Stat",$$slots:{html:[vt],default:[nt]},$$scope:{ctx:v}}}),d=new L({props:{title:"Stat with icons or image",$$slots:{html:[ot],default:[ct]},$$scope:{ctx:v}}}),e=new L({props:{title:"Stat",$$slots:{html:[$t],default:[rt]},$$scope:{ctx:v}}}),x=new L({props:{title:"Centered items",$$slots:{html:[mt],default:[ut]},$$scope:{ctx:v}}}),k=new L({props:{title:"Vertical",$$slots:{html:[ht],default:[pt]},$$scope:{ctx:v}}}),y=new L({props:{title:"Responsive (vertical on small screen, horizontal on large screen)",$$slots:{html:[wt],default:[ft]},$$scope:{ctx:v}}}),M=new L({props:{title:"With custom colors and button",$$slots:{html:[_t],default:[gt]},$$scope:{ctx:v}}}),{c(){h(t.$$.fragment),l=T(),h(s.$$.fragment),i=T(),h(d.$$.fragment),c=T(),h(e.$$.fragment),n=T(),h(x.$$.fragment),P=T(),h(k.$$.fragment),S=T(),h(y.$$.fragment),B=T(),h(M.$$.fragment)},l(a){f(t.$$.fragment,a),l=V(a),f(s.$$.fragment,a),i=V(a),f(d.$$.fragment,a),c=V(a),f(e.$$.fragment,a),n=V(a),f(x.$$.fragment,a),P=V(a),f(k.$$.fragment,a),S=V(a),f(y.$$.fragment,a),B=V(a),f(M.$$.fragment,a)},m(a,o){w(t,a,o),$(a,l,o),w(s,a,o),$(a,i,o),w(d,a,o),$(a,c,o),w(e,a,o),$(a,n,o),w(x,a,o),$(a,P,o),w(k,a,o),$(a,S,o),w(y,a,o),$(a,B,o),w(M,a,o),K=!0},p(a,o){const U={};o&5&&(U.$$scope={dirty:o,ctx:a}),s.$set(U);const I={};o&5&&(I.$$scope={dirty:o,ctx:a}),d.$set(I);const A={};o&5&&(A.$$scope={dirty:o,ctx:a}),e.$set(A);const q={};o&5&&(q.$$scope={dirty:o,ctx:a}),x.$set(q);const W={};o&5&&(W.$$scope={dirty:o,ctx:a}),k.$set(W);const O={};o&5&&(O.$$scope={dirty:o,ctx:a}),y.$set(O);const G={};o&5&&(G.$$scope={dirty:o,ctx:a}),M.$set(G)},i(a){K||(g(t.$$.fragment,a),g(s.$$.fragment,a),g(d.$$.fragment,a),g(e.$$.fragment,a),g(x.$$.fragment,a),g(k.$$.fragment,a),g(y.$$.fragment,a),g(M.$$.fragment,a),K=!0)},o(a){_(t.$$.fragment,a),_(s.$$.fragment,a),_(d.$$.fragment,a),_(e.$$.fragment,a),_(x.$$.fragment,a),_(k.$$.fragment,a),_(y.$$.fragment,a),_(M.$$.fragment,a),K=!1},d(a){a&&(r(l),r(i),r(c),r(n),r(P),r(S),r(B)),b(t,a),b(s,a),b(d,a),b(e,a),b(x,a),b(k,a),b(y,a),b(M,a)}}}function xt(v){let t,l;const s=[v[1],Y];let i={$$slots:{default:[bt]},$$scope:{ctx:v}};for(let d=0;d<s.length;d+=1)i=J(i,s[d]);return t=new it({props:i}),{c(){h(t.$$.fragment)},l(d){f(t.$$.fragment,d)},m(d,c){w(t,d,c),l=!0},p(d,[c]){const e=c&2?at(s,[c&2&&X(d[1]),c&0&&X(Y)]):{};c&5&&(e.$$scope={dirty:c,ctx:d}),t.$set(e)},i(d){l||(g(t.$$.fragment,d),l=!0)},o(d){_(t.$$.fragment,d),l=!1},d(d){b(t,d)}}}const Y={title:"Stat",desc:"Stat is used to show numbers and data in a box.",published:!0,layout:"components"};function kt(v,t,l){let s;return tt(v,lt,i=>l(0,s=i)),v.$$set=i=>{l(1,t=J(J({},t),Q(i)))},t=Q(t),[s,t]}class Dt extends st{constructor(t){super(),et(this,t,kt,xt,Z,{})}}export{Dt as component};
