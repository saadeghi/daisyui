import{L as e,_ as n}from"../chunks/0.1df2f772.js";export{e as component,n as universal};
