import{L as e,_ as n}from"../chunks/0.43b60d00.js";export{e as component,n as universal};
