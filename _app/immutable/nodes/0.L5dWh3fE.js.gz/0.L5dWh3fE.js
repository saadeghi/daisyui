import{L as e,_ as n}from"../chunks/0.glXnn_Gt.js";export{e as component,n as universal};
