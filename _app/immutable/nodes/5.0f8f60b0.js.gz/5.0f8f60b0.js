import{S as ke,i as ye,s as be,M as he,y as ee,z as te,A as le,U as Ee,$ as fe,g as oe,d as se,B as ae,H as xe,Y as $e,a as k,k as a,C as ie,q as C,c as y,l as i,m as d,D as ce,h as l,r as D,n as o,b as j,E as e,F as re,a9 as de,a4 as pe}from"../chunks/index.b33eaa49.js";import{M as Ie}from"../chunks/mdsvex.9d280e07.js";import{p as we,C as Ce,a as ne,r as ve}from"../chunks/ClassTable.e3ec4c1e.js";function De(R){let t,v,m,r,p,b,c,h,M,S,_,I,A,x,T,G,V,P,H,U,$,E,J,w,z,B,g,s,f;return{c(){t=a("div"),v=a("input"),m=k(),r=a("div"),p=C("Click to open this one and close others"),b=k(),c=a("div"),h=a("p"),M=C("hello"),S=k(),_=a("div"),I=a("input"),A=k(),x=a("div"),T=C("Click to open this one and close others"),G=k(),V=a("div"),P=a("p"),H=C("hello"),U=k(),$=a("div"),E=a("input"),J=k(),w=a("div"),z=C("Click to open this one and close others"),B=k(),g=a("div"),s=a("p"),f=C("hello"),this.h()},l(n){t=i(n,"DIV",{class:!0});var u=d(t);v=i(u,"INPUT",{type:!0,name:!0}),m=y(u),r=i(u,"DIV",{class:!0});var F=d(r);p=D(F,"Click to open this one and close others"),F.forEach(l),b=y(u),c=i(u,"DIV",{class:!0});var Y=d(c);h=i(Y,"P",{});var O=d(h);M=D(O,"hello"),O.forEach(l),Y.forEach(l),u.forEach(l),S=y(n),_=i(n,"DIV",{class:!0});var N=d(_);I=i(N,"INPUT",{type:!0,name:!0}),A=y(N),x=i(N,"DIV",{class:!0});var Q=d(x);T=D(Q,"Click to open this one and close others"),Q.forEach(l),G=y(N),V=i(N,"DIV",{class:!0});var K=d(V);P=i(K,"P",{});var W=d(P);H=D(W,"hello"),W.forEach(l),K.forEach(l),N.forEach(l),U=y(n),$=i(n,"DIV",{class:!0});var q=d($);E=i(q,"INPUT",{type:!0,name:!0}),J=y(q),w=i(q,"DIV",{class:!0});var X=d(w);z=D(X,"Click to open this one and close others"),X.forEach(l),B=y(q),g=i(q,"DIV",{class:!0});var L=d(g);s=i(L,"P",{});var Z=d(s);f=D(Z,"hello"),Z.forEach(l),L.forEach(l),q.forEach(l),this.h()},h(){o(v,"type","radio"),o(v,"name","my-accordion-1"),v.checked="checked",o(r,"class","collapse-title text-xl font-medium"),o(c,"class","collapse-content"),o(t,"class","collapse bg-base-200"),o(I,"type","radio"),o(I,"name","my-accordion-1"),o(x,"class","collapse-title text-xl font-medium"),o(V,"class","collapse-content"),o(_,"class","collapse bg-base-200"),o(E,"type","radio"),o(E,"name","my-accordion-1"),o(w,"class","collapse-title text-xl font-medium"),o(g,"class","collapse-content"),o($,"class","collapse bg-base-200")},m(n,u){j(n,t,u),e(t,v),e(t,m),e(t,r),e(r,p),e(t,b),e(t,c),e(c,h),e(h,M),j(n,S,u),j(n,_,u),e(_,I),e(_,A),e(_,x),e(x,T),e(_,G),e(_,V),e(V,P),e(P,H),j(n,U,u),j(n,$,u),e($,E),e($,J),e($,w),e(w,z),e($,B),e($,g),e(g,s),e(s,f)},p:re,d(n){n&&l(t),n&&l(S),n&&l(_),n&&l(U),n&&l($)}}}function Ve(R){let t,v=`<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse bg-base-200">
  <input type="radio" name="my-accordion-1" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,m,r,p,b;return{c(){t=a("pre"),m=C(v),this.h()},l(c){t=i(c,"PRE",{slot:!0});var h=d(t);m=D(h,v),h.forEach(l),this.h()},h(){o(t,"slot","html")},m(c,h){j(c,t,h),e(t,m),p||(b=de(r=ve.call(null,t,{to:R[0]})),p=!0)},p(c,h){r&&pe(r.update)&&h&1&&r.update.call(null,{to:c[0]})},d(c){c&&l(t),p=!1,b()}}}function ge(R){let t,v,m,r,p,b,c,h,M,S,_,I,A,x,T,G,V,P,H,U,$,E,J,w,z,B,g,s,f;return{c(){t=a("div"),v=a("input"),m=k(),r=a("div"),p=C("Click to open this one and close others"),b=k(),c=a("div"),h=a("p"),M=C("hello"),S=k(),_=a("div"),I=a("input"),A=k(),x=a("div"),T=C("Click to open this one and close others"),G=k(),V=a("div"),P=a("p"),H=C("hello"),U=k(),$=a("div"),E=a("input"),J=k(),w=a("div"),z=C("Click to open this one and close others"),B=k(),g=a("div"),s=a("p"),f=C("hello"),this.h()},l(n){t=i(n,"DIV",{class:!0});var u=d(t);v=i(u,"INPUT",{type:!0,name:!0}),m=y(u),r=i(u,"DIV",{class:!0});var F=d(r);p=D(F,"Click to open this one and close others"),F.forEach(l),b=y(u),c=i(u,"DIV",{class:!0});var Y=d(c);h=i(Y,"P",{});var O=d(h);M=D(O,"hello"),O.forEach(l),Y.forEach(l),u.forEach(l),S=y(n),_=i(n,"DIV",{class:!0});var N=d(_);I=i(N,"INPUT",{type:!0,name:!0}),A=y(N),x=i(N,"DIV",{class:!0});var Q=d(x);T=D(Q,"Click to open this one and close others"),Q.forEach(l),G=y(N),V=i(N,"DIV",{class:!0});var K=d(V);P=i(K,"P",{});var W=d(P);H=D(W,"hello"),W.forEach(l),K.forEach(l),N.forEach(l),U=y(n),$=i(n,"DIV",{class:!0});var q=d($);E=i(q,"INPUT",{type:!0,name:!0}),J=y(q),w=i(q,"DIV",{class:!0});var X=d(w);z=D(X,"Click to open this one and close others"),X.forEach(l),B=y(q),g=i(q,"DIV",{class:!0});var L=d(g);s=i(L,"P",{});var Z=d(s);f=D(Z,"hello"),Z.forEach(l),L.forEach(l),q.forEach(l),this.h()},h(){o(v,"type","radio"),o(v,"name","my-accordion-2"),v.checked="checked",o(r,"class","collapse-title text-xl font-medium"),o(c,"class","collapse-content"),o(t,"class","collapse collapse-arrow bg-base-200"),o(I,"type","radio"),o(I,"name","my-accordion-2"),o(x,"class","collapse-title text-xl font-medium"),o(V,"class","collapse-content"),o(_,"class","collapse collapse-arrow bg-base-200"),o(E,"type","radio"),o(E,"name","my-accordion-2"),o(w,"class","collapse-title text-xl font-medium"),o(g,"class","collapse-content"),o($,"class","collapse collapse-arrow bg-base-200")},m(n,u){j(n,t,u),e(t,v),e(t,m),e(t,r),e(r,p),e(t,b),e(t,c),e(c,h),e(h,M),j(n,S,u),j(n,_,u),e(_,I),e(_,A),e(_,x),e(x,T),e(_,G),e(_,V),e(V,P),e(P,H),j(n,U,u),j(n,$,u),e($,E),e($,J),e($,w),e(w,z),e($,B),e($,g),e(g,s),e(s,f)},p:re,d(n){n&&l(t),n&&l(S),n&&l(_),n&&l(U),n&&l($)}}}function Pe(R){let t,v=`<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-arrow bg-base-200">
  <input type="radio" name="my-accordion-2" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,m,r,p,b;return{c(){t=a("pre"),m=C(v),this.h()},l(c){t=i(c,"PRE",{slot:!0});var h=d(t);m=D(h,v),h.forEach(l),this.h()},h(){o(t,"slot","html")},m(c,h){j(c,t,h),e(t,m),p||(b=de(r=ve.call(null,t,{to:R[0]})),p=!0)},p(c,h){r&&pe(r.update)&&h&1&&r.update.call(null,{to:c[0]})},d(c){c&&l(t),p=!1,b()}}}function je(R){let t,v,m,r,p,b,c,h,M,S,_,I,A,x,T,G,V,P,H,U,$,E,J,w,z,B,g,s,f;return{c(){t=a("div"),v=a("input"),m=k(),r=a("div"),p=C("Click to open this one and close others"),b=k(),c=a("div"),h=a("p"),M=C("hello"),S=k(),_=a("div"),I=a("input"),A=k(),x=a("div"),T=C("Click to open this one and close others"),G=k(),V=a("div"),P=a("p"),H=C("hello"),U=k(),$=a("div"),E=a("input"),J=k(),w=a("div"),z=C("Click to open this one and close others"),B=k(),g=a("div"),s=a("p"),f=C("hello"),this.h()},l(n){t=i(n,"DIV",{class:!0});var u=d(t);v=i(u,"INPUT",{type:!0,name:!0}),m=y(u),r=i(u,"DIV",{class:!0});var F=d(r);p=D(F,"Click to open this one and close others"),F.forEach(l),b=y(u),c=i(u,"DIV",{class:!0});var Y=d(c);h=i(Y,"P",{});var O=d(h);M=D(O,"hello"),O.forEach(l),Y.forEach(l),u.forEach(l),S=y(n),_=i(n,"DIV",{class:!0});var N=d(_);I=i(N,"INPUT",{type:!0,name:!0}),A=y(N),x=i(N,"DIV",{class:!0});var Q=d(x);T=D(Q,"Click to open this one and close others"),Q.forEach(l),G=y(N),V=i(N,"DIV",{class:!0});var K=d(V);P=i(K,"P",{});var W=d(P);H=D(W,"hello"),W.forEach(l),K.forEach(l),N.forEach(l),U=y(n),$=i(n,"DIV",{class:!0});var q=d($);E=i(q,"INPUT",{type:!0,name:!0}),J=y(q),w=i(q,"DIV",{class:!0});var X=d(w);z=D(X,"Click to open this one and close others"),X.forEach(l),B=y(q),g=i(q,"DIV",{class:!0});var L=d(g);s=i(L,"P",{});var Z=d(s);f=D(Z,"hello"),Z.forEach(l),L.forEach(l),q.forEach(l),this.h()},h(){o(v,"type","radio"),o(v,"name","my-accordion-3"),v.checked="checked",o(r,"class","collapse-title text-xl font-medium"),o(c,"class","collapse-content"),o(t,"class","collapse collapse-plus bg-base-200"),o(I,"type","radio"),o(I,"name","my-accordion-3"),o(x,"class","collapse-title text-xl font-medium"),o(V,"class","collapse-content"),o(_,"class","collapse collapse-plus bg-base-200"),o(E,"type","radio"),o(E,"name","my-accordion-3"),o(w,"class","collapse-title text-xl font-medium"),o(g,"class","collapse-content"),o($,"class","collapse collapse-plus bg-base-200")},m(n,u){j(n,t,u),e(t,v),e(t,m),e(t,r),e(r,p),e(t,b),e(t,c),e(c,h),e(h,M),j(n,S,u),j(n,_,u),e(_,I),e(_,A),e(_,x),e(x,T),e(_,G),e(_,V),e(V,P),e(P,H),j(n,U,u),j(n,$,u),e($,E),e($,J),e($,w),e(w,z),e($,B),e($,g),e(g,s),e(s,f)},p:re,d(n){n&&l(t),n&&l(S),n&&l(_),n&&l(U),n&&l($)}}}function Ae(R){let t,v=`<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" checked="checked" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>
<div class="$$collapse $$collapse-plus bg-base-200">
  <input type="radio" name="my-accordion-3" /> 
  <div class="$$collapse-title text-xl font-medium">
    Click to open this one and close others
  </div>
  <div class="$$collapse-content"> 
    <p>hello</p>
  </div>
</div>`,m,r,p,b;return{c(){t=a("pre"),m=C(v),this.h()},l(c){t=i(c,"PRE",{slot:!0});var h=d(t);m=D(h,v),h.forEach(l),this.h()},h(){o(t,"slot","html")},m(c,h){j(c,t,h),e(t,m),p||(b=de(r=ve.call(null,t,{to:R[0]})),p=!0)},p(c,h){r&&pe(r.update)&&h&1&&r.update.call(null,{to:c[0]})},d(c){c&&l(t),p=!1,b()}}}function Te(R){let t,v,m,r,p,b,c,h,M,S,_,I,A,x,T,G,V,P,H,U,$,E,J,w,z,B,g,s,f,n;return{c(){t=a("div"),v=a("div"),m=a("input"),r=k(),p=a("div"),b=C("Click to open this one and close others"),c=k(),h=a("div"),M=a("p"),S=C("hello"),_=k(),I=a("div"),A=a("input"),x=k(),T=a("div"),G=C("Click to open this one and close others"),V=k(),P=a("div"),H=a("p"),U=C("hello"),$=k(),E=a("div"),J=a("input"),w=k(),z=a("div"),B=C("Click to open this one and close others"),g=k(),s=a("div"),f=a("p"),n=C("hello"),this.h()},l(u){t=i(u,"DIV",{class:!0});var F=d(t);v=i(F,"DIV",{class:!0});var Y=d(v);m=i(Y,"INPUT",{type:!0,name:!0}),r=y(Y),p=i(Y,"DIV",{class:!0});var O=d(p);b=D(O,"Click to open this one and close others"),O.forEach(l),c=y(Y),h=i(Y,"DIV",{class:!0});var N=d(h);M=i(N,"P",{});var Q=d(M);S=D(Q,"hello"),Q.forEach(l),N.forEach(l),Y.forEach(l),_=y(F),I=i(F,"DIV",{class:!0});var K=d(I);A=i(K,"INPUT",{type:!0,name:!0}),x=y(K),T=i(K,"DIV",{class:!0});var W=d(T);G=D(W,"Click to open this one and close others"),W.forEach(l),V=y(K),P=i(K,"DIV",{class:!0});var q=d(P);H=i(q,"P",{});var X=d(H);U=D(X,"hello"),X.forEach(l),q.forEach(l),K.forEach(l),$=y(F),E=i(F,"DIV",{class:!0});var L=d(E);J=i(L,"INPUT",{type:!0,name:!0}),w=y(L),z=i(L,"DIV",{class:!0});var Z=d(z);B=D(Z,"Click to open this one and close others"),Z.forEach(l),g=y(L),s=i(L,"DIV",{class:!0});var ue=d(s);f=i(ue,"P",{});var me=d(f);n=D(me,"hello"),me.forEach(l),ue.forEach(l),L.forEach(l),F.forEach(l),this.h()},h(){o(m,"type","radio"),o(m,"name","my-accordion-4"),m.checked="checked",o(p,"class","collapse-title"),o(h,"class","collapse-content"),o(v,"class","collapse collapse-arrow join-item border border-base-300"),o(A,"type","radio"),o(A,"name","my-accordion-4"),o(T,"class","collapse-title"),o(P,"class","collapse-content"),o(I,"class","collapse collapse-arrow join-item border border-base-300"),o(J,"type","radio"),o(J,"name","my-accordion-4"),o(z,"class","collapse-title"),o(s,"class","collapse-content"),o(E,"class","collapse collapse-arrow join-item border border-base-300"),o(t,"class","join join-vertical w-full")},m(u,F){j(u,t,F),e(t,v),e(v,m),e(v,r),e(v,p),e(p,b),e(v,c),e(v,h),e(h,M),e(M,S),e(t,_),e(t,I),e(I,A),e(I,x),e(I,T),e(T,G),e(I,V),e(I,P),e(P,H),e(H,U),e(t,$),e(t,E),e(E,J),e(E,w),e(E,z),e(z,B),e(E,g),e(E,s),e(s,f),e(f,n)},p:re,d(u){u&&l(t)}}}function Ue(R){let t,v=`<div class="$$join $$join-vertical w-full">
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" checked="checked" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
  <div class="$$collapse $$collapse-arrow $$join-item border border-base-300">
    <input type="radio" name="my-accordion-4" /> 
    <div class="$$collapse-title text-xl font-medium">
      Click to open this one and close others
    </div>
    <div class="$$collapse-content"> 
      <p>hello</p>
    </div>
  </div>
</div>`,m,r,p,b;return{c(){t=a("pre"),m=C(v),this.h()},l(c){t=i(c,"PRE",{slot:!0});var h=d(t);m=D(h,v),h.forEach(l),this.h()},h(){o(t,"slot","html")},m(c,h){j(c,t,h),e(t,m),p||(b=de(r=ve.call(null,t,{to:R[0]})),p=!0)},p(c,h){r&&pe(r.update)&&h&1&&r.update.call(null,{to:c[0]})},d(c){c&&l(t),p=!1,b()}}}function Ne(R){let t,v,m,r,p,b,c,h,M,S,_,I,A,x,T,G,V,P,H,U,$,E,J,w,z,B,g;return t=new Ce({props:{data:[{type:"component",class:"collapse",desc:"Container element"},{type:"component",class:"collapse-title",desc:"Title element"},{type:"component",class:"collapse-content",desc:"Container for content"},{type:"modifier",class:"collapse-arrow",desc:"Adds arrow icon"},{type:"modifier",class:"collapse-plus",desc:"Adds plus/minus icon"},{type:"modifier",class:"collapse-open",desc:"Force open"},{type:"modifier",class:"collapse-close",desc:"Force close"}]}}),U=new ne({props:{title:"Accordion using radio inputs",$$slots:{html:[Ve],default:[De]},$$scope:{ctx:R}}}),E=new ne({props:{title:"Accordion with arrow icon",$$slots:{html:[Pe],default:[ge]},$$scope:{ctx:R}}}),w=new ne({props:{title:"Accordion with plus/minus icon",$$slots:{html:[Ae],default:[je]},$$scope:{ctx:R}}}),B=new ne({props:{title:"Using Accordion and Join together",desc:"to join the items together and handle border radius automatically",$$slots:{html:[Ue],default:[Te]},$$scope:{ctx:R}}}),{c(){ee(t.$$.fragment),v=k(),m=a("div"),r=ie("svg"),p=ie("path"),b=k(),c=a("div"),h=C("Accordion uses the same style as the "),M=a("a"),S=C("collapse component"),_=C(" but it works with radio inputs. You can control which item to be open by checking/unchecking the hidden radio input."),I=k(),A=a("div"),x=ie("svg"),T=ie("path"),G=k(),V=a("div"),P=C("All radio inputs with the same name work together and only one of them can be open at a time. If you have more than one set of accordion items on a page, use different names for the radio inputs on each set."),H=k(),ee(U.$$.fragment),$=k(),ee(E.$$.fragment),J=k(),ee(w.$$.fragment),z=k(),ee(B.$$.fragment),this.h()},l(s){te(t.$$.fragment,s),v=y(s),m=i(s,"DIV",{class:!0});var f=d(m);r=ce(f,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var n=d(r);p=ce(n,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),d(p).forEach(l),n.forEach(l),b=y(f),c=i(f,"DIV",{});var u=d(c);h=D(u,"Accordion uses the same style as the "),M=i(u,"A",{href:!0,class:!0});var F=d(M);S=D(F,"collapse component"),F.forEach(l),_=D(u," but it works with radio inputs. You can control which item to be open by checking/unchecking the hidden radio input."),u.forEach(l),f.forEach(l),I=y(s),A=i(s,"DIV",{class:!0});var Y=d(A);x=ce(Y,"svg",{xmlns:!0,fill:!0,viewBox:!0,class:!0});var O=d(x);T=ce(O,"path",{"stroke-linecap":!0,"stroke-linejoin":!0,"stroke-width":!0,d:!0}),d(T).forEach(l),O.forEach(l),G=y(Y),V=i(Y,"DIV",{});var N=d(V);P=D(N,"All radio inputs with the same name work together and only one of them can be open at a time. If you have more than one set of accordion items on a page, use different names for the radio inputs on each set."),N.forEach(l),Y.forEach(l),H=y(s),te(U.$$.fragment,s),$=y(s),te(E.$$.fragment,s),J=y(s),te(w.$$.fragment,s),z=y(s),te(B.$$.fragment,s),this.h()},h(){o(p,"stroke-linecap","round"),o(p,"stroke-linejoin","round"),o(p,"stroke-width","2"),o(p,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),o(r,"xmlns","http://www.w3.org/2000/svg"),o(r,"fill","none"),o(r,"viewBox","0 0 24 24"),o(r,"class","stroke-current shrink-0 w-6 h-6"),o(M,"href","/components/collapse/"),o(M,"class","link"),o(m,"class","alert text-sm mt-4"),o(T,"stroke-linecap","round"),o(T,"stroke-linejoin","round"),o(T,"stroke-width","2"),o(T,"d","M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"),o(x,"xmlns","http://www.w3.org/2000/svg"),o(x,"fill","none"),o(x,"viewBox","0 0 24 24"),o(x,"class","stroke-current shrink-0 w-6 h-6"),o(A,"class","alert text-sm mt-4")},m(s,f){le(t,s,f),j(s,v,f),j(s,m,f),e(m,r),e(r,p),e(m,b),e(m,c),e(c,h),e(c,M),e(M,S),e(c,_),j(s,I,f),j(s,A,f),e(A,x),e(x,T),e(A,G),e(A,V),e(V,P),j(s,H,f),le(U,s,f),j(s,$,f),le(E,s,f),j(s,J,f),le(w,s,f),j(s,z,f),le(B,s,f),g=!0},p(s,f){const n={};f&5&&(n.$$scope={dirty:f,ctx:s}),U.$set(n);const u={};f&5&&(u.$$scope={dirty:f,ctx:s}),E.$set(u);const F={};f&5&&(F.$$scope={dirty:f,ctx:s}),w.$set(F);const Y={};f&5&&(Y.$$scope={dirty:f,ctx:s}),B.$set(Y)},i(s){g||(oe(t.$$.fragment,s),oe(U.$$.fragment,s),oe(E.$$.fragment,s),oe(w.$$.fragment,s),oe(B.$$.fragment,s),g=!0)},o(s){se(t.$$.fragment,s),se(U.$$.fragment,s),se(E.$$.fragment,s),se(w.$$.fragment,s),se(B.$$.fragment,s),g=!1},d(s){ae(t,s),s&&l(v),s&&l(m),s&&l(I),s&&l(A),s&&l(H),ae(U,s),s&&l($),ae(E,s),s&&l(J),ae(w,s),s&&l(z),ae(B,s)}}}function Me(R){let t,v;const m=[R[1],_e];let r={$$slots:{default:[Ne]},$$scope:{ctx:R}};for(let p=0;p<m.length;p+=1)r=he(r,m[p]);return t=new Ie({props:r}),{c(){ee(t.$$.fragment)},l(p){te(t.$$.fragment,p)},m(p,b){le(t,p,b),v=!0},p(p,[b]){const c=b&2?Ee(m,[b&2&&fe(p[1]),b&0&&fe(_e)]):{};b&5&&(c.$$scope={dirty:b,ctx:p}),t.$set(c)},i(p){v||(oe(t.$$.fragment,p),v=!0)},o(p){se(t.$$.fragment,p),v=!1},d(p){ae(t,p)}}}const _e={title:"Accordion",desc:"Accordion is used for showing and hiding content but only one item can stay open at a time.",published:!0};function Be(R,t,v){let m;return xe(R,we,r=>v(0,m=r)),R.$$set=r=>{v(1,t=he(he({},t),$e(r)))},t=$e(t),[m,t]}class Ye extends ke{constructor(t){super(),ye(this,t,Be,Me,be,{})}}export{Ye as component};
