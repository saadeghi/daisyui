import{L as e,_ as n}from"../chunks/0.2fec69ed.js";export{e as component,n as universal};
