import{L as e,_ as n}from"../chunks/0.q_fxW2AU.js";export{e as component,n as universal};
