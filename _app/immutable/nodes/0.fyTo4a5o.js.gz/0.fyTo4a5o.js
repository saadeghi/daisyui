import{L as e,_ as n}from"../chunks/0.4VF2DtUk.js";export{e as component,n as universal};
