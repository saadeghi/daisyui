import{L as e,_ as n}from"../chunks/0.QF_fmDS1.js";export{e as component,n as universal};
