import{s as ie,N as J,z as ce,S as te,a as _,c as j,i as u,d as n,f,g as p,A as S,j as g,y as x,l as C,h as z,m as D,x as I,X as P,E as y}from"../chunks/scheduler.5afb8bf4.js";import{S as oe,i as re,b as v,d as h,m as $,a as b,t as w,e as k}from"../chunks/index.2536167e.js";import{g as de,a as le}from"../chunks/spread.8a54911c.js";import{M as me,p as ne,C as ue,a as T,r as M}from"../chunks/ClassTable.d203da0d.js";function fe(d){let e,c='<div class="carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger"/></div> <div class="carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-1l2mnr9"&&(e.innerHTML=c),this.h()},h(){g(e,"class","carousel rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function pe(d){let e,c=`<div class="$$carousel rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Burger" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Burger" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function ge(d){let e,c='<div class="carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza"/></div> <div class="carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-h1ecbi"&&(e.innerHTML=c),this.h()},h(){g(e,"class","carousel carousel-center rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function ve(d){let e,c=`<div class="$$carousel $$carousel-center rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Pizza" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Pizza" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function he(d){let e,c='<div class="carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink"/></div> <div class="carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-1dbpbjk"&&(e.innerHTML=c),this.h()},h(){g(e,"class","carousel carousel-end rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function $e(d){let e,c=`<div class="$$carousel $$carousel-end rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Drink" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Drink" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function be(d){let e,c='<div class="w-full carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div> <div class="w-full carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS carousel component"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-pgj689"&&(e.innerHTML=c),this.h()},h(){g(e,"class","w-64 carousel rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function we(d){let e,c=`<div class="w-64 $$carousel rounded-box">
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div> 
  <div class="$$carousel-item w-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS Carousel component" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function ke(d){let e,c='<div class="carousel-item h-full"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" alt="Tailwind Image slider"/></div> <div class="carousel-item h-full"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" alt="Tailwind Image slider"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-10ifsdj"&&(e.innerHTML=c),this.h()},h(){g(e,"class","h-96 carousel carousel-vertical rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function _e(d){let e,c=`<div class="h-96 $$carousel $$carousel-vertical rounded-box">
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" />
  </div> 
  <div class="$$carousel-item h-full">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function je(d){let e,c='<div class="w-1/2 carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div> <div class="w-1/2 carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" alt="Tailwind CSS Image slider"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-n4ftvs"&&(e.innerHTML=c),this.h()},h(){g(e,"class","w-96 carousel rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function Se(d){let e,c=`<div class="$$carousel rounded-box w-96">
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="w-full" />
  </div> 
  <div class="$$carousel-item w-1/2">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="w-full" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function Te(d){let e,c='<div class="carousel-item"><img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" alt="Tailwind CSS component"/></div> <div class="carousel-item"><img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" alt="Tailwind CSS component"/></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-jpffvk"&&(e.innerHTML=c),this.h()},h(){g(e,"class","max-w-md p-4 space-x-4 carousel carousel-center bg-neutral rounded-box")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function xe(d){let e,c=`<div class="$$carousel $$carousel-center max-w-md p-4 space-x-4 bg-neutral rounded-box">
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559703248-dcaaec9fab78.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1565098772267-60af42b81ef2.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1572635148818-ef6fd45eb394.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1494253109108-2e30c049369b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1550258987-190a2d41a8ba.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1559181567-c3190ca9959b.jpg" class="rounded-box" />
  </div> 
  <div class="$$carousel-item">
    <img src="/images/stock/photo-1601004890684-d8cbf643f5f2.jpg" class="rounded-box" />
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function Ce(d){let e,c='<div id="item1" class="w-full carousel-item"><img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" alt="Tailwind CSS image gallery"/></div> <div id="item2" class="w-full carousel-item"><img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" alt="Tailwind CSS image gallery"/></div> <div id="item3" class="w-full carousel-item"><img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" alt="Tailwind CSS image gallery"/></div> <div id="item4" class="w-full carousel-item"><img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" alt="Tailwind CSS image gallery"/></div>',s,a,o='<a href="#item1" class="btn btn-xs">1</a> <a href="#item2" class="btn btn-xs">2</a> <a href="#item3" class="btn btn-xs">3</a> <a href="#item4" class="btn btn-xs">4</a>';return{c(){e=f("div"),e.innerHTML=c,s=_(),a=f("div"),a.innerHTML=o,this.h()},l(r){e=p(r,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-p45sct"&&(e.innerHTML=c),s=j(r),a=p(r,"DIV",{class:!0,"data-svelte-h":!0}),S(a)!=="svelte-941awq"&&(a.innerHTML=o),this.h()},h(){g(e,"class","w-full carousel"),g(a,"class","flex justify-center w-full py-2 gap-2")},m(r,t){u(r,e,t),u(r,s,t),u(r,a,t)},p:x,d(r){r&&(n(e),n(s),n(a))}}}function ze(d){let e,c=`<div class="$$carousel w-full">
  <div id="item1" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
  </div> 
  <div id="item2" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
  </div> 
  <div id="item3" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
  </div> 
  <div id="item4" class="$$carousel-item w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
  </div>
</div> 
<div class="flex justify-center w-full py-2 gap-2">
  <a href="#item1" class="$$btn $$btn-xs">1</a> 
  <a href="#item2" class="$$btn $$btn-xs">2</a> 
  <a href="#item3" class="$$btn $$btn-xs">3</a> 
  <a href="#item4" class="$$btn $$btn-xs">4</a>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function De(d){let e,c='<div id="slide1" class="relative w-full carousel-item"><img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" alt="Tailwind CSS image slide"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide4" class="btn btn-circle">❮</a> <a href="#slide2" class="btn btn-circle">❯</a></div></div> <div id="slide2" class="relative w-full carousel-item"><img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" alt="Tailwind CSS image slide"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide1" class="btn btn-circle">❮</a> <a href="#slide3" class="btn btn-circle">❯</a></div></div> <div id="slide3" class="relative w-full carousel-item"><img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" alt="Tailwind CSS image slide"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide2" class="btn btn-circle">❮</a> <a href="#slide4" class="btn btn-circle">❯</a></div></div> <div id="slide4" class="relative w-full carousel-item"><img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" alt="Tailwind CSS image slide"/> <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2"><a href="#slide3" class="btn btn-circle">❮</a> <a href="#slide1" class="btn btn-circle">❯</a></div></div>';return{c(){e=f("div"),e.innerHTML=c,this.h()},l(s){e=p(s,"DIV",{class:!0,"data-svelte-h":!0}),S(e)!=="svelte-1h9nq6p"&&(e.innerHTML=c),this.h()},h(){g(e,"class","w-full carousel")},m(s,a){u(s,e,a)},p:x,d(s){s&&n(e)}}}function Ie(d){let e,c=`<div class="$$carousel w-full">
  <div id="slide1" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1625726411847-8cbb60cc71e6.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide4" class="btn btn-circle">❮</a> 
      <a href="#slide2" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide2" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1609621838510-5ad474b7d25d.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide1" class="btn btn-circle">❮</a> 
      <a href="#slide3" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide3" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1414694762283-acccc27bca85.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide2" class="btn btn-circle">❮</a> 
      <a href="#slide4" class="btn btn-circle">❯</a>
    </div>
  </div> 
  <div id="slide4" class="$$carousel-item relative w-full">
    <img src="/images/stock/photo-1665553365602-b2fb8e5d1707.jpg" class="w-full" />
    <div class="absolute flex justify-between transform -translate-y-1/2 left-5 right-5 top-1/2">
      <a href="#slide3" class="btn btn-circle">❮</a> 
      <a href="#slide1" class="btn btn-circle">❯</a>
    </div>
  </div>
</div>`,s,a,o,r;return{c(){e=f("pre"),s=C(c),this.h()},l(t){e=p(t,"PRE",{slot:!0});var i=z(e);s=D(i,c),i.forEach(n),this.h()},h(){g(e,"slot","html")},m(t,i){u(t,e,i),I(e,s),o||(r=P(a=M.call(null,e,{to:d[0]})),o=!0)},p(t,i){a&&y(a.update)&&i&1&&a.update.call(null,{to:t[0]})},d(t){t&&n(e),o=!1,r()}}}function Pe(d){let e,c,s,a,o,r,t,i,H,q,L,A,E,F,B,N,V,X,R,G;return e=new ue({props:{data:[{type:"component",class:"carousel",desc:"Container element"},{type:"component",class:"carousel-item",desc:"Carousel item"},{type:"modifier",class:"carousel-center",desc:"Snap elements to center"},{type:"modifier",class:"carousel-end",desc:"Snap elements to end"},{type:"modifier",class:"carousel-vertical",desc:"Vertical carousel"}]}}),s=new T({props:{title:"Snap to start (default)",$$slots:{html:[pe],default:[fe]},$$scope:{ctx:d}}}),o=new T({props:{title:"Snap to center",$$slots:{html:[ve],default:[ge]},$$scope:{ctx:d}}}),t=new T({props:{title:"Snap to end",$$slots:{html:[$e],default:[he]},$$scope:{ctx:d}}}),H=new T({props:{title:"Carousel with full width items",$$slots:{html:[we],default:[be]},$$scope:{ctx:d}}}),L=new T({props:{title:"Vertical carousel",$$slots:{html:[_e],default:[ke]},$$scope:{ctx:d}}}),E=new T({props:{title:"Carousel with half width items",$$slots:{html:[Se],default:[je]},$$scope:{ctx:d}}}),B=new T({props:{title:"Full-bleed carousel",$$slots:{html:[xe],default:[Te]},$$scope:{ctx:d}}}),V=new T({props:{title:"Carousel with indicator buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[ze],default:[Ce]},$$scope:{ctx:d}}}),R=new T({props:{title:"Carousel with next/prev buttons",desc:"This slider works with anchor links so the browser will snap vertically to the image when you click buttons.",$$slots:{html:[Ie],default:[De]},$$scope:{ctx:d}}}),{c(){v(e.$$.fragment),c=_(),v(s.$$.fragment),a=_(),v(o.$$.fragment),r=_(),v(t.$$.fragment),i=_(),v(H.$$.fragment),q=_(),v(L.$$.fragment),A=_(),v(E.$$.fragment),F=_(),v(B.$$.fragment),N=_(),v(V.$$.fragment),X=_(),v(R.$$.fragment)},l(l){h(e.$$.fragment,l),c=j(l),h(s.$$.fragment,l),a=j(l),h(o.$$.fragment,l),r=j(l),h(t.$$.fragment,l),i=j(l),h(H.$$.fragment,l),q=j(l),h(L.$$.fragment,l),A=j(l),h(E.$$.fragment,l),F=j(l),h(B.$$.fragment,l),N=j(l),h(V.$$.fragment,l),X=j(l),h(R.$$.fragment,l)},m(l,m){$(e,l,m),u(l,c,m),$(s,l,m),u(l,a,m),$(o,l,m),u(l,r,m),$(t,l,m),u(l,i,m),$(H,l,m),u(l,q,m),$(L,l,m),u(l,A,m),$(E,l,m),u(l,F,m),$(B,l,m),u(l,N,m),$(V,l,m),u(l,X,m),$(R,l,m),G=!0},p(l,m){const K={};m&5&&(K.$$scope={dirty:m,ctx:l}),s.$set(K);const O={};m&5&&(O.$$scope={dirty:m,ctx:l}),o.$set(O);const Q={};m&5&&(Q.$$scope={dirty:m,ctx:l}),t.$set(Q);const U={};m&5&&(U.$$scope={dirty:m,ctx:l}),H.$set(U);const W={};m&5&&(W.$$scope={dirty:m,ctx:l}),L.$set(W);const Y={};m&5&&(Y.$$scope={dirty:m,ctx:l}),E.$set(Y);const Z={};m&5&&(Z.$$scope={dirty:m,ctx:l}),B.$set(Z);const ee={};m&5&&(ee.$$scope={dirty:m,ctx:l}),V.$set(ee);const se={};m&5&&(se.$$scope={dirty:m,ctx:l}),R.$set(se)},i(l){G||(b(e.$$.fragment,l),b(s.$$.fragment,l),b(o.$$.fragment,l),b(t.$$.fragment,l),b(H.$$.fragment,l),b(L.$$.fragment,l),b(E.$$.fragment,l),b(B.$$.fragment,l),b(V.$$.fragment,l),b(R.$$.fragment,l),G=!0)},o(l){w(e.$$.fragment,l),w(s.$$.fragment,l),w(o.$$.fragment,l),w(t.$$.fragment,l),w(H.$$.fragment,l),w(L.$$.fragment,l),w(E.$$.fragment,l),w(B.$$.fragment,l),w(V.$$.fragment,l),w(R.$$.fragment,l),G=!1},d(l){l&&(n(c),n(a),n(r),n(i),n(q),n(A),n(F),n(N),n(X)),k(e,l),k(s,l),k(o,l),k(t,l),k(H,l),k(L,l),k(E,l),k(B,l),k(V,l),k(R,l)}}}function ye(d){let e,c;const s=[d[1],ae];let a={$$slots:{default:[Pe]},$$scope:{ctx:d}};for(let o=0;o<s.length;o+=1)a=J(a,s[o]);return e=new me({props:a}),{c(){v(e.$$.fragment)},l(o){h(e.$$.fragment,o)},m(o,r){$(e,o,r),c=!0},p(o,[r]){const t=r&2?de(s,[r&2&&le(o[1]),r&0&&le(ae)]):{};r&5&&(t.$$scope={dirty:r,ctx:o}),e.$set(t)},i(o){c||(b(e.$$.fragment,o),c=!0)},o(o){w(e.$$.fragment,o),c=!1},d(o){k(e,o)}}}const ae={title:"Carousel",desc:"Carousel show images or content in a scrollable area.",published:!0,layout:"components"};function Me(d,e,c){let s;return ce(d,ne,a=>c(0,s=a)),d.$$set=a=>{c(1,e=J(J({},e),te(a)))},e=te(e),[s,e]}class Ve extends oe{constructor(e){super(),re(this,e,Me,ye,ie,{})}}export{Ve as component};
