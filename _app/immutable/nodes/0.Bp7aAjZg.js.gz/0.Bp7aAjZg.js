import{L as e,_ as n}from"../chunks/0.zgQ1hlLb.js";export{e as component,n as universal};
