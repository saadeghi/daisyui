import{S as ia,i as oa,s as ca,M as ta,y as z,z as B,A as F,U as da,$ as sa,g as H,d as U,B as Y,H as va,Y as la,a as x,c as C,b,h as r,k as n,l as u,m,K as M,n as o,E as p,F as Q,q as K,r as J,a9 as W,a4 as Z}from"../chunks/index.b33eaa49.js";import{M as na}from"../chunks/mdsvex.4b3953a3.js";import{p as ua,C as pa,a as L,r as y}from"../chunks/ClassTable.9c77c125.js";function fa(E){let a,c,l,v;return{c(){a=n("div"),c=n("div"),l=n("img"),this.h()},l(i){a=u(i,"DIV",{class:!0});var d=m(a);c=u(d,"DIV",{class:!0});var t=m(c);l=u(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 rounded bg-base-300"),o(a,"class","avatar")},m(i,d){b(i,a,d),p(a,c),p(c,l)},p:Q,d(i){i&&r(a)}}}function ma(E){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function $a(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A,I,D,k,V,j;return{c(){a=n("div"),c=n("div"),l=n("img"),i=x(),d=n("div"),t=n("div"),s=n("img"),g=x(),_=n("div"),w=n("div"),h=n("img"),I=x(),D=n("div"),k=n("div"),V=n("img"),this.h()},l($){a=u($,"DIV",{class:!0});var e=m(a);c=u(e,"DIV",{class:!0});var f=m(c);l=u(f,"IMG",{src:!0,alt:!0}),f.forEach(r),e.forEach(r),i=C($),d=u($,"DIV",{class:!0});var T=m(d);t=u(T,"DIV",{class:!0});var G=m(t);s=u(G,"IMG",{src:!0,alt:!0}),G.forEach(r),T.forEach(r),g=C($),_=u($,"DIV",{class:!0});var P=m(_);w=u(P,"DIV",{class:!0});var R=m(w);h=u(R,"IMG",{src:!0,alt:!0}),R.forEach(r),P.forEach(r),I=C($),D=u($,"DIV",{class:!0});var q=m(D);k=u(q,"DIV",{class:!0});var N=m(k);V=u(N,"IMG",{src:!0,alt:!0}),N.forEach(r),q.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 rounded bg-base-300"),o(a,"class","avatar"),M(s.src,S="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(s,"src",S),o(s,"alt","Tailwind-CSS-Avatar-component"),o(t,"class","w-16 rounded bg-base-300"),o(d,"class","avatar"),M(h.src,A="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(h,"src",A),o(h,"alt","Tailwind-CSS-Avatar-component"),o(w,"class","w-12 rounded bg-base-300"),o(_,"class","avatar"),M(V.src,j="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(V,"src",j),o(V,"alt","Tailwind-CSS-Avatar-component"),o(k,"class","w-8 rounded bg-base-300"),o(D,"class","avatar")},m($,e){b($,a,e),p(a,c),p(c,l),b($,i,e),b($,d,e),p(d,t),p(t,s),b($,g,e),b($,_,e),p(_,w),p(w,h),b($,I,e),b($,D,e),p(D,k),p(k,V)},p:Q,d($){$&&r(a),$&&r(i),$&&r(d),$&&r(g),$&&r(_),$&&r(I),$&&r(D)}}}function _a(E){let a,c=`<div class="$$avatar">
  <div class="w-32 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-20 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-16 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-8 rounded">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" alt="Tailwind-CSS-Avatar-component" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function ga(E){let a,c,l,v,i,d,t,s,S;return{c(){a=n("div"),c=n("div"),l=n("img"),i=x(),d=n("div"),t=n("div"),s=n("img"),this.h()},l(g){a=u(g,"DIV",{class:!0});var _=m(a);c=u(_,"DIV",{class:!0});var w=m(c);l=u(w,"IMG",{src:!0,alt:!0}),w.forEach(r),_.forEach(r),i=C(g),d=u(g,"DIV",{class:!0});var h=m(d);t=u(h,"DIV",{class:!0});var A=m(t);s=u(A,"IMG",{src:!0,alt:!0}),A.forEach(r),h.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 rounded-xl bg-base-300"),o(a,"class","avatar"),M(s.src,S="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(s,"src",S),o(s,"alt","Tailwind-CSS-Avatar-component"),o(t,"class","w-24 rounded-full bg-base-300"),o(d,"class","avatar")},m(g,_){b(g,a,_),p(a,c),p(c,l),b(g,i,_),b(g,d,_),p(d,t),p(t,s)},p:Q,d(g){g&&r(a),g&&r(i),g&&r(d)}}}function ha(E){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded-xl">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function ba(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A;return{c(){a=n("div"),c=n("div"),l=n("img"),i=x(),d=n("div"),t=n("div"),s=n("img"),g=x(),_=n("div"),w=n("div"),h=n("img"),this.h()},l(I){a=u(I,"DIV",{class:!0});var D=m(a);c=u(D,"DIV",{class:!0});var k=m(c);l=u(k,"IMG",{src:!0,alt:!0}),k.forEach(r),D.forEach(r),i=C(I),d=u(I,"DIV",{class:!0});var V=m(d);t=u(V,"DIV",{class:!0});var j=m(t);s=u(j,"IMG",{src:!0,alt:!0}),j.forEach(r),V.forEach(r),g=C(I),_=u(I,"DIV",{class:!0});var $=m(_);w=u($,"DIV",{class:!0});var e=m(w);h=u(e,"IMG",{src:!0,alt:!0}),e.forEach(r),$.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 mask mask-squircle bg-base-300"),o(a,"class","avatar"),M(s.src,S="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(s,"src",S),o(s,"alt","Tailwind-CSS-Avatar-component"),o(t,"class","w-24 mask mask-hexagon bg-base-300"),o(d,"class","avatar"),M(h.src,A="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(h,"src",A),o(h,"alt","Tailwind-CSS-Avatar-component"),o(w,"class","w-24 mask mask-triangle bg-base-300"),o(_,"class","avatar")},m(I,D){b(I,a,D),p(a,c),p(c,l),b(I,i,D),b(I,d,D),p(d,t),p(t,s),b(I,g,D),b(I,_,D),p(_,w),p(w,h)},p:Q,d(I){I&&r(a),I&&r(i),I&&r(d),I&&r(g),I&&r(_)}}}function wa(E){let a,c=`<div class="$$avatar">
  <div class="w-24 $$mask $$mask-squircle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-hexagon">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar">
  <div class="w-24 $$mask $$mask-triangle">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function Ea(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A,I,D,k,V,j,$;return{c(){a=n("div"),c=n("div"),l=n("div"),v=n("img"),d=x(),t=n("div"),s=n("div"),S=n("img"),_=x(),w=n("div"),h=n("div"),A=n("img"),D=x(),k=n("div"),V=n("div"),j=n("img"),this.h()},l(e){a=u(e,"DIV",{class:!0});var f=m(a);c=u(f,"DIV",{class:!0});var T=m(c);l=u(T,"DIV",{class:!0});var G=m(l);v=u(G,"IMG",{src:!0,alt:!0}),G.forEach(r),T.forEach(r),d=C(f),t=u(f,"DIV",{class:!0});var P=m(t);s=u(P,"DIV",{class:!0});var R=m(s);S=u(R,"IMG",{src:!0,alt:!0}),R.forEach(r),P.forEach(r),_=C(f),w=u(f,"DIV",{class:!0});var q=m(w);h=u(q,"DIV",{class:!0});var N=m(h);A=u(N,"IMG",{src:!0,alt:!0}),N.forEach(r),q.forEach(r),D=C(f),k=u(f,"DIV",{class:!0});var O=m(k);V=u(O,"DIV",{class:!0});var X=m(V);j=u(X,"IMG",{src:!0,alt:!0}),X.forEach(r),O.forEach(r),f.forEach(r),this.h()},h(){M(v.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(v,"src",i),o(v,"alt","Tailwind-CSS-Avatar-component"),o(l,"class","w-12 bg-base-300"),o(c,"class","avatar"),M(S.src,g="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(S,"src",g),o(S,"alt","Tailwind-CSS-Avatar-component"),o(s,"class","w-12 bg-base-300"),o(t,"class","avatar"),M(A.src,I="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(A,"src",I),o(A,"alt","Tailwind-CSS-Avatar-component"),o(h,"class","w-12 bg-base-300"),o(w,"class","avatar"),M(j.src,$="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(j,"src",$),o(j,"alt","Tailwind-CSS-Avatar-component"),o(V,"class","w-12 bg-base-300"),o(k,"class","avatar"),o(a,"class","avatar-group -space-x-6")},m(e,f){b(e,a,f),p(a,c),p(c,l),p(l,v),p(a,d),p(a,t),p(t,s),p(s,S),p(a,_),p(a,w),p(w,h),p(h,A),p(a,D),p(a,k),p(k,V),p(V,j)},p:Q,d(e){e&&r(a)}}}function Ia(E){let a,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function ka(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A,I,D,k,V,j,$;return{c(){a=n("div"),c=n("div"),l=n("div"),v=n("img"),d=x(),t=n("div"),s=n("div"),S=n("img"),_=x(),w=n("div"),h=n("div"),A=n("img"),D=x(),k=n("div"),V=n("div"),j=n("span"),$=K("+99"),this.h()},l(e){a=u(e,"DIV",{class:!0});var f=m(a);c=u(f,"DIV",{class:!0});var T=m(c);l=u(T,"DIV",{class:!0});var G=m(l);v=u(G,"IMG",{src:!0,alt:!0}),G.forEach(r),T.forEach(r),d=C(f),t=u(f,"DIV",{class:!0});var P=m(t);s=u(P,"DIV",{class:!0});var R=m(s);S=u(R,"IMG",{src:!0,alt:!0}),R.forEach(r),P.forEach(r),_=C(f),w=u(f,"DIV",{class:!0});var q=m(w);h=u(q,"DIV",{class:!0});var N=m(h);A=u(N,"IMG",{src:!0,alt:!0}),N.forEach(r),q.forEach(r),D=C(f),k=u(f,"DIV",{class:!0});var O=m(k);V=u(O,"DIV",{class:!0});var X=m(V);j=u(X,"SPAN",{});var aa=m(j);$=J(aa,"+99"),aa.forEach(r),X.forEach(r),O.forEach(r),f.forEach(r),this.h()},h(){M(v.src,i="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(v,"src",i),o(v,"alt","Tailwind-CSS-Avatar-component"),o(l,"class","w-12 bg-base-300"),o(c,"class","avatar"),M(S.src,g="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(S,"src",g),o(S,"alt","Tailwind-CSS-Avatar-component"),o(s,"class","w-12 bg-base-300"),o(t,"class","avatar"),M(A.src,I="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(A,"src",I),o(A,"alt","Tailwind-CSS-Avatar-component"),o(h,"class","w-12 bg-base-300"),o(w,"class","avatar"),o(V,"class","w-12 bg-neutral-focus text-neutral-content"),o(k,"class","avatar placeholder"),o(a,"class","avatar-group -space-x-6")},m(e,f){b(e,a,f),p(a,c),p(c,l),p(l,v),p(a,d),p(a,t),p(t,s),p(s,S),p(a,_),p(a,w),p(w,h),p(h,A),p(a,D),p(a,k),p(k,V),p(V,j),p(j,$)},p:Q,d(e){e&&r(a)}}}function Sa(E){let a,c=`<div class="$$avatar-group -space-x-6">
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar">
    <div class="w-12">
      <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$avatar $$placeholder">
    <div class="w-12 bg-neutral-focus text-neutral-content">
      <span>+99</span>
    </div>
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function Da(E){let a,c,l,v;return{c(){a=n("div"),c=n("div"),l=n("img"),this.h()},l(i){a=u(i,"DIV",{class:!0});var d=m(a);c=u(d,"DIV",{class:!0});var t=m(c);l=u(t,"IMG",{src:!0,alt:!0}),t.forEach(r),d.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2"),o(a,"class","avatar")},m(i,d){b(i,a,d),p(a,c),p(c,l)},p:Q,d(i){i&&r(a)}}}function Va(E){let a,c=`<div class="$$avatar">
  <div class="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function Aa(E){let a,c,l,v,i,d,t,s,S;return{c(){a=n("div"),c=n("div"),l=n("img"),i=x(),d=n("div"),t=n("div"),s=n("img"),this.h()},l(g){a=u(g,"DIV",{class:!0});var _=m(a);c=u(_,"DIV",{class:!0});var w=m(c);l=u(w,"IMG",{src:!0,alt:!0}),w.forEach(r),_.forEach(r),i=C(g),d=u(g,"DIV",{class:!0});var h=m(d);t=u(h,"DIV",{class:!0});var A=m(t);s=u(A,"IMG",{src:!0,alt:!0}),A.forEach(r),h.forEach(r),this.h()},h(){M(l.src,v="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(l,"src",v),o(l,"alt","Tailwind-CSS-Avatar-component"),o(c,"class","w-24 rounded-full bg-base-300"),o(a,"class","avatar online"),M(s.src,S="/images/stock/photo-1534528741775-53994a69daeb.jpg")||o(s,"src",S),o(s,"alt","Tailwind-CSS-Avatar-component"),o(t,"class","w-24 rounded-full bg-base-300"),o(d,"class","avatar offline")},m(g,_){b(g,a,_),p(a,c),p(c,l),b(g,i,_),b(g,d,_),p(d,t),p(t,s)},p:Q,d(g){g&&r(a),g&&r(i),g&&r(d)}}}function ja(E){let a,c=`<div class="$$avatar $$online">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>
<div class="$$avatar $$offline">
  <div class="w-24 rounded-full">
    <img src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function xa(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A,I,D,k,V,j;return{c(){a=n("div"),c=n("div"),l=n("span"),v=K("K"),i=x(),d=n("div"),t=n("div"),s=n("span"),S=K("JO"),g=x(),_=n("div"),w=n("div"),h=n("span"),A=K("MX"),I=x(),D=n("div"),k=n("div"),V=n("span"),j=K("AA"),this.h()},l($){a=u($,"DIV",{class:!0});var e=m(a);c=u(e,"DIV",{class:!0});var f=m(c);l=u(f,"SPAN",{class:!0});var T=m(l);v=J(T,"K"),T.forEach(r),f.forEach(r),e.forEach(r),i=C($),d=u($,"DIV",{class:!0});var G=m(d);t=u(G,"DIV",{class:!0});var P=m(t);s=u(P,"SPAN",{class:!0});var R=m(s);S=J(R,"JO"),R.forEach(r),P.forEach(r),G.forEach(r),g=C($),_=u($,"DIV",{class:!0});var q=m(_);w=u(q,"DIV",{class:!0});var N=m(w);h=u(N,"SPAN",{});var O=m(h);A=J(O,"MX"),O.forEach(r),N.forEach(r),q.forEach(r),I=C($),D=u($,"DIV",{class:!0});var X=m(D);k=u(X,"DIV",{class:!0});var aa=m(k);V=u(aa,"SPAN",{class:!0});var ea=m(V);j=J(ea,"AA"),ea.forEach(r),aa.forEach(r),X.forEach(r),this.h()},h(){o(l,"class","text-3xl"),o(c,"class","bg-neutral-focus text-neutral-content rounded-full w-24"),o(a,"class","avatar placeholder"),o(s,"class","text-xl"),o(t,"class","bg-neutral-focus text-neutral-content rounded-full w-16"),o(d,"class","avatar online placeholder"),o(w,"class","bg-neutral-focus text-neutral-content rounded-full w-12"),o(_,"class","avatar placeholder"),o(V,"class","text-xs"),o(k,"class","bg-neutral-focus text-neutral-content rounded-full w-8"),o(D,"class","avatar placeholder")},m($,e){b($,a,e),p(a,c),p(c,l),p(l,v),b($,i,e),b($,d,e),p(d,t),p(t,s),p(s,S),b($,g,e),b($,_,e),p(_,w),p(w,h),p(h,A),b($,I,e),b($,D,e),p(D,k),p(k,V),p(V,j)},p:Q,d($){$&&r(a),$&&r(i),$&&r(d),$&&r(g),$&&r(_),$&&r(I),$&&r(D)}}}function Ca(E){let a,c=`<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-24">
    <span class="text-3xl">K</span>
  </div>
</div> 
<div class="$$avatar $$online $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-16">
    <span class="text-xl">JO</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-12">
    <span>MX</span>
  </div>
</div> 
<div class="$$avatar $$placeholder">
  <div class="bg-neutral-focus text-neutral-content rounded-full w-8">
    <span class="text-xs">AA</span>
  </div>
</div>`,l,v,i,d;return{c(){a=n("pre"),l=K(c),this.h()},l(t){a=u(t,"PRE",{slot:!0});var s=m(a);l=J(s,c),s.forEach(r),this.h()},h(){o(a,"slot","html")},m(t,s){b(t,a,s),p(a,l),i||(d=W(v=y.call(null,a,{to:E[0]})),i=!0)},p(t,s){v&&Z(v.update)&&s&1&&v.update.call(null,{to:t[0]})},d(t){t&&r(a),i=!1,d()}}}function Ma(E){let a,c,l,v,i,d,t,s,S,g,_,w,h,A,I,D,k,V,j,$;return a=new pa({props:{data:[{type:"component",class:"avatar",desc:"Container element"},{type:"component",class:"avatar-group",desc:"Container for grouping multiple avatars"},{type:"modifier",class:"online",desc:"shows a green dot as online indicator"},{type:"modifier",class:"offline",desc:"shows a gray dot as offline indicator"},{type:"modifier",class:"placeholder",desc:"to show some letters as avatar placeholder"}]}}),l=new L({props:{title:"Avatar",$$slots:{html:[ma],default:[fa]},$$scope:{ctx:E}}}),i=new L({props:{title:"Avatar in custom sizes",$$slots:{html:[_a],default:[$a]},$$scope:{ctx:E}}}),t=new L({props:{title:"Avatar rounded",$$slots:{html:[ha],default:[ga]},$$scope:{ctx:E}}}),S=new L({props:{title:"Avatar with mask",$$slots:{html:[wa],default:[ba]},$$scope:{ctx:E}}}),_=new L({props:{title:"Avatar group",$$slots:{html:[Ia],default:[Ea]},$$scope:{ctx:E}}}),h=new L({props:{title:"Avatar group with counter",$$slots:{html:[Sa],default:[ka]},$$scope:{ctx:E}}}),I=new L({props:{title:"Avatar with ring",$$slots:{html:[Va],default:[Da]},$$scope:{ctx:E}}}),k=new L({props:{title:"Avatar with presence indicator",$$slots:{html:[ja],default:[Aa]},$$scope:{ctx:E}}}),j=new L({props:{title:"Avatar placeholder",$$slots:{html:[Ca],default:[xa]},$$scope:{ctx:E}}}),{c(){z(a.$$.fragment),c=x(),z(l.$$.fragment),v=x(),z(i.$$.fragment),d=x(),z(t.$$.fragment),s=x(),z(S.$$.fragment),g=x(),z(_.$$.fragment),w=x(),z(h.$$.fragment),A=x(),z(I.$$.fragment),D=x(),z(k.$$.fragment),V=x(),z(j.$$.fragment)},l(e){B(a.$$.fragment,e),c=C(e),B(l.$$.fragment,e),v=C(e),B(i.$$.fragment,e),d=C(e),B(t.$$.fragment,e),s=C(e),B(S.$$.fragment,e),g=C(e),B(_.$$.fragment,e),w=C(e),B(h.$$.fragment,e),A=C(e),B(I.$$.fragment,e),D=C(e),B(k.$$.fragment,e),V=C(e),B(j.$$.fragment,e)},m(e,f){F(a,e,f),b(e,c,f),F(l,e,f),b(e,v,f),F(i,e,f),b(e,d,f),F(t,e,f),b(e,s,f),F(S,e,f),b(e,g,f),F(_,e,f),b(e,w,f),F(h,e,f),b(e,A,f),F(I,e,f),b(e,D,f),F(k,e,f),b(e,V,f),F(j,e,f),$=!0},p(e,f){const T={};f&5&&(T.$$scope={dirty:f,ctx:e}),l.$set(T);const G={};f&5&&(G.$$scope={dirty:f,ctx:e}),i.$set(G);const P={};f&5&&(P.$$scope={dirty:f,ctx:e}),t.$set(P);const R={};f&5&&(R.$$scope={dirty:f,ctx:e}),S.$set(R);const q={};f&5&&(q.$$scope={dirty:f,ctx:e}),_.$set(q);const N={};f&5&&(N.$$scope={dirty:f,ctx:e}),h.$set(N);const O={};f&5&&(O.$$scope={dirty:f,ctx:e}),I.$set(O);const X={};f&5&&(X.$$scope={dirty:f,ctx:e}),k.$set(X);const aa={};f&5&&(aa.$$scope={dirty:f,ctx:e}),j.$set(aa)},i(e){$||(H(a.$$.fragment,e),H(l.$$.fragment,e),H(i.$$.fragment,e),H(t.$$.fragment,e),H(S.$$.fragment,e),H(_.$$.fragment,e),H(h.$$.fragment,e),H(I.$$.fragment,e),H(k.$$.fragment,e),H(j.$$.fragment,e),$=!0)},o(e){U(a.$$.fragment,e),U(l.$$.fragment,e),U(i.$$.fragment,e),U(t.$$.fragment,e),U(S.$$.fragment,e),U(_.$$.fragment,e),U(h.$$.fragment,e),U(I.$$.fragment,e),U(k.$$.fragment,e),U(j.$$.fragment,e),$=!1},d(e){Y(a,e),e&&r(c),Y(l,e),e&&r(v),Y(i,e),e&&r(d),Y(t,e),e&&r(s),Y(S,e),e&&r(g),Y(_,e),e&&r(w),Y(h,e),e&&r(A),Y(I,e),e&&r(D),Y(k,e),e&&r(V),Y(j,e)}}}function Ta(E){let a,c;const l=[E[1],ra];let v={$$slots:{default:[Ma]},$$scope:{ctx:E}};for(let i=0;i<l.length;i+=1)v=ta(v,l[i]);return a=new na({props:v}),{c(){z(a.$$.fragment)},l(i){B(a.$$.fragment,i)},m(i,d){F(a,i,d),c=!0},p(i,[d]){const t=d&2?da(l,[d&2&&sa(i[1]),d&0&&sa(ra)]):{};d&5&&(t.$$scope={dirty:d,ctx:i}),a.$set(t)},i(i){c||(H(a.$$.fragment,i),c=!0)},o(i){U(a.$$.fragment,i),c=!1},d(i){Y(a,i)}}}const ra={title:"Avatar",desc:"Avatars are used to show a thumbnail representation of an individual or business in the interface.",published:!0};function Ga(E,a,c){let l;return va(E,ua,v=>c(0,l=v)),E.$$set=v=>{c(1,a=ta(ta({},a),la(v)))},a=la(a),[l,a]}class Na extends ia{constructor(a){super(),oa(this,a,Ga,Ta,ca,{})}}export{Na as component};
