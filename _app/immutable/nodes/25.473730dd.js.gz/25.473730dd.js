import{s as Y,E as O,y as A,O as F,a as q,c as H,i as p,d as u,f as m,g as f,z as k,j as $,w as I,l as C,h as L,m as S,v as E,Y as T,U as M,k as J}from"../chunks/scheduler.e71eccdd.js";import{S as K,i as W,b,d as x,m as g,a as _,t as w,e as y}from"../chunks/index.445ee094.js";import{g as X,a as z}from"../chunks/index.18b79e66.js";import{M as Z}from"../chunks/mdsvex.316cd2e4.js";import{p as ee,C as te,a as P,r as Q}from"../chunks/ClassTable.b8d00d65.js";function ae(r){let e,i='<div class="text-center hero-content"><div class="max-w-md"><h3 class="text-5xl font-bold">Hello there</h3> <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p> <button class="btn btn-primary">Get Started</button></div></div>';return{c(){e=m("div"),e.innerHTML=i,this.h()},l(t){e=f(t,"DIV",{class:!0,["data-svelte-h"]:!0}),k(e)!=="svelte-b1oxtm"&&(e.innerHTML=i),this.h()},h(){$(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(t,l){p(t,e,l)},p:I,d(t){t&&u(e)}}}function se(r){let e,i=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content text-center">
    <div class="max-w-md">
      <h1 class="text-5xl font-bold">Hello there</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,t,l,n,c;return{c(){e=m("pre"),t=C(i),this.h()},l(a){e=f(a,"PRE",{slot:!0});var o=L(e);t=S(o,i),o.forEach(u),this.h()},h(){$(e,"slot","html")},m(a,o){p(a,e,o),E(e,t),n||(c=T(l=Q.call(null,e,{to:r[0]})),n=!0)},p(a,o){l&&M(l.update)&&o&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(e),n=!1,c()}}}function le(r){let e,i='<div class="flex-col hero-content lg:flex-row"><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" alt="Tailwind CSS hero component"/> <div><h3 class="text-5xl font-bold">Box Office News!</h3> <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p> <button class="btn btn-primary">Get Started</button></div></div>';return{c(){e=m("div"),e.innerHTML=i,this.h()},l(t){e=f(t,"DIV",{class:!0,["data-svelte-h"]:!0}),k(e)!=="svelte-ndrrj3"&&(e.innerHTML=i),this.h()},h(){$(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(t,l){p(t,e,l)},p:I,d(t){t&&u(e)}}}function ne(r){let e,i=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,t,l,n,c;return{c(){e=m("pre"),t=C(i),this.h()},l(a){e=f(a,"PRE",{slot:!0});var o=L(e);t=S(o,i),o.forEach(u),this.h()},h(){$(e,"slot","html")},m(a,o){p(a,e,o),E(e,t),n||(c=T(l=Q.call(null,e,{to:r[0]})),n=!0)},p(a,o){l&&M(l.update)&&o&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(e),n=!1,c()}}}function ie(r){let e,i='<div class="flex-col hero-content lg:flex-row-reverse"><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" alt="Tailwind CSS hero component"/> <div><h3 class="text-5xl font-bold">Box Office News!</h3> <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p> <button class="btn btn-primary">Get Started</button></div></div>';return{c(){e=m("div"),e.innerHTML=i,this.h()},l(t){e=f(t,"DIV",{class:!0,["data-svelte-h"]:!0}),k(e)!=="svelte-1vawo1k"&&(e.innerHTML=i),this.h()},h(){$(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(t,l){p(t,e,l)},p:I,d(t){t&&u(e)}}}function oe(r){let e,i=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <img src="/images/stock/photo-1635805737707-575885ab0820.jpg" class="max-w-sm rounded-lg shadow-2xl" />
    <div>
      <h1 class="text-5xl font-bold">Box Office News!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,t,l,n,c;return{c(){e=m("pre"),t=C(i),this.h()},l(a){e=f(a,"PRE",{slot:!0});var o=L(e);t=S(o,i),o.forEach(u),this.h()},h(){$(e,"slot","html")},m(a,o){p(a,e,o),E(e,t),n||(c=T(l=Q.call(null,e,{to:r[0]})),n=!0)},p(a,o){l&&M(l.update)&&o&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(e),n=!1,c()}}}function re(r){let e,i='<div class="flex-col hero-content lg:flex-row-reverse"><div class="text-center lg:text-left"><h3 class="text-5xl font-bold">Login now!</h3> <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p></div> <div class="card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100"><div class="card-body"><div class="form-control"><label class="label"><span class="label-text">Email</span></label> <input type="text" placeholder="email" class="input input-bordered"/></div> <div class="form-control"><label class="label"><span class="label-text">Password</span></label> <input type="text" placeholder="password" class="input input-bordered"/> <label class="label"><a href="#" class="label-text-alt link link-hover">Forgot password?</a></label></div> <div class="form-control mt-6"><button class="btn btn-primary">Login</button></div></div></div></div>';return{c(){e=m("div"),e.innerHTML=i,this.h()},l(t){e=f(t,"DIV",{class:!0,["data-svelte-h"]:!0}),k(e)!=="svelte-dpg0ry"&&(e.innerHTML=i),this.h()},h(){$(e,"class","hero min-h-[30rem] rounded bg-base-200")},m(t,l){p(t,e,l)},p:I,d(t){t&&u(e)}}}function ce(r){let e,i=`<div class="$$hero min-h-screen bg-base-200">
  <div class="$$hero-content flex-col lg:flex-row-reverse">
    <div class="text-center lg:text-left">
      <h1 class="text-5xl font-bold">Login now!</h1>
      <p class="py-6">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
    </div>
    <div class="$$card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
      <div class="$$card-body">
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Email</span>
          </label>
          <input type="text" placeholder="email" class="$$input $$input-bordered" />
        </div>
        <div class="$$form-control">
          <label class="$$label">
            <span class="$$label-text">Password</span>
          </label>
          <input type="text" placeholder="password" class="$$input $$input-bordered" />
          <label class="$$label">
            <a href="#" class="$$label-text-alt $$link $$link-hover">Forgot password?</a>
          </label>
        </div>
        <div class="$$form-control mt-6">
          <button class="$$btn $$btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</div>`,t,l,n,c;return{c(){e=m("pre"),t=C(i),this.h()},l(a){e=f(a,"PRE",{slot:!0});var o=L(e);t=S(o,i),o.forEach(u),this.h()},h(){$(e,"slot","html")},m(a,o){p(a,e,o),E(e,t),n||(c=T(l=Q.call(null,e,{to:r[0]})),n=!0)},p(a,o){l&&M(l.update)&&o&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(e),n=!1,c()}}}function de(r){let e,i='<div class="hero-overlay rounded bg-opacity-60"></div> <div class="text-center hero-content text-neutral-content"><div class="max-w-md"><h1 class="mb-5 text-5xl font-bold">Hello there</h1> <p class="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p> <button class="btn btn-primary">Get Started</button></div></div>';return{c(){e=m("div"),e.innerHTML=i,this.h()},l(t){e=f(t,"DIV",{class:!0,style:!0,["data-svelte-h"]:!0}),k(e)!=="svelte-1qb4t8e"&&(e.innerHTML=i),this.h()},h(){$(e,"class","hero min-h-[30rem] rounded"),J(e,"background-image","url(/images/stock/photo-1507358522600-9f71e620c44e.jpg)")},m(t,l){p(t,e,l)},p:I,d(t){t&&u(e)}}}function ue(r){let e,i=`<div class="$$hero min-h-screen" style="background-image: url(/images/stock/photo-1507358522600-9f71e620c44e.jpg);">
  <div class="$$hero-overlay bg-opacity-60"></div>
  <div class="$$hero-content text-center text-neutral-content">
    <div class="max-w-md">
      <h1 class="mb-5 text-5xl font-bold">Hello there</h1>
      <p class="mb-5">Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem quasi. In deleniti eaque aut repudiandae et a id nisi.</p>
      <button class="$$btn $$btn-primary">Get Started</button>
    </div>
  </div>
</div>`,t,l,n,c;return{c(){e=m("pre"),t=C(i),this.h()},l(a){e=f(a,"PRE",{slot:!0});var o=L(e);t=S(o,i),o.forEach(u),this.h()},h(){$(e,"slot","html")},m(a,o){p(a,e,o),E(e,t),n||(c=T(l=Q.call(null,e,{to:r[0]})),n=!0)},p(a,o){l&&M(l.update)&&o&1&&l.update.call(null,{to:a[0]})},d(a){a&&u(e),n=!1,c()}}}function pe(r){let e,i,t,l,n,c,a,o,h,j,v,G;return e=new te({props:{data:[{type:"component",class:"hero",desc:"Container element"},{type:"component",class:"hero-content",desc:"Container for content"},{type:"component",class:"hero-overlay",desc:"Overlay that covers the background image"}]}}),t=new P({props:{title:"Centered hero",$$slots:{html:[se],default:[ae]},$$scope:{ctx:r}}}),n=new P({props:{title:"Hero with figure",$$slots:{html:[ne],default:[le]},$$scope:{ctx:r}}}),a=new P({props:{title:"Hero with figure but reverse order",$$slots:{html:[oe],default:[ie]},$$scope:{ctx:r}}}),h=new P({props:{title:"Hero with form",$$slots:{html:[ce],default:[re]},$$scope:{ctx:r}}}),v=new P({props:{title:"Hero with overlay image",$$slots:{html:[ue],default:[de]},$$scope:{ctx:r}}}),{c(){b(e.$$.fragment),i=q(),b(t.$$.fragment),l=q(),b(n.$$.fragment),c=q(),b(a.$$.fragment),o=q(),b(h.$$.fragment),j=q(),b(v.$$.fragment)},l(s){x(e.$$.fragment,s),i=H(s),x(t.$$.fragment,s),l=H(s),x(n.$$.fragment,s),c=H(s),x(a.$$.fragment,s),o=H(s),x(h.$$.fragment,s),j=H(s),x(v.$$.fragment,s)},m(s,d){g(e,s,d),p(s,i,d),g(t,s,d),p(s,l,d),g(n,s,d),p(s,c,d),g(a,s,d),p(s,o,d),g(h,s,d),p(s,j,d),g(v,s,d),G=!0},p(s,d){const D={};d&5&&(D.$$scope={dirty:d,ctx:s}),t.$set(D);const R={};d&5&&(R.$$scope={dirty:d,ctx:s}),n.$set(R);const V={};d&5&&(V.$$scope={dirty:d,ctx:s}),a.$set(V);const B={};d&5&&(B.$$scope={dirty:d,ctx:s}),h.$set(B);const N={};d&5&&(N.$$scope={dirty:d,ctx:s}),v.$set(N)},i(s){G||(_(e.$$.fragment,s),_(t.$$.fragment,s),_(n.$$.fragment,s),_(a.$$.fragment,s),_(h.$$.fragment,s),_(v.$$.fragment,s),G=!0)},o(s){w(e.$$.fragment,s),w(t.$$.fragment,s),w(n.$$.fragment,s),w(a.$$.fragment,s),w(h.$$.fragment,s),w(v.$$.fragment,s),G=!1},d(s){s&&(u(i),u(l),u(c),u(o),u(j)),y(e,s),y(t,s),y(n,s),y(a,s),y(h,s),y(v,s)}}}function me(r){let e,i;const t=[r[1],U];let l={$$slots:{default:[pe]},$$scope:{ctx:r}};for(let n=0;n<t.length;n+=1)l=O(l,t[n]);return e=new Z({props:l}),{c(){b(e.$$.fragment)},l(n){x(e.$$.fragment,n)},m(n,c){g(e,n,c),i=!0},p(n,[c]){const a=c&2?X(t,[c&2&&z(n[1]),c&0&&z(U)]):{};c&5&&(a.$$scope={dirty:c,ctx:n}),e.$set(a)},i(n){i||(_(e.$$.fragment,n),i=!0)},o(n){w(e.$$.fragment,n),i=!1},d(n){y(e,n)}}}const U={title:"Hero",desc:"Hero is a component for displaying a large box or image with a title and description.",published:!0};function fe(r,e,i){let t;return A(r,ee,l=>i(0,t=l)),r.$$set=l=>{i(1,e=O(O({},e),F(l)))},e=F(e),[t,e]}class ge extends K{constructor(e){super(),W(this,e,fe,me,Y,{})}}export{ge as component};
