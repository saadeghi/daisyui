import{e as n,i as s}from"./runtime.Bfoy81my.js";function c(f,i,o){n(()=>{var r=s(()=>i(f,o==null?void 0:o())||{});if(r!=null&&r.destroy)return()=>r.destroy()})}export{c as a};
