import{X as s,l as t}from"./runtime.Uw9oq3Es.js";function i(f,n,o){s(()=>{var r=t(()=>n(f,o==null?void 0:o())||{});if(r!=null&&r.destroy)return()=>r.destroy()})}export{i as a};
