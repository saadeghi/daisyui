const s=!0,o=!1;export{s as b,o as d};
