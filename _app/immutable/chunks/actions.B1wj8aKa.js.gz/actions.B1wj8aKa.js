import{H as s,j as t}from"./runtime.BUdK6G03.js";function i(f,n,o){s(()=>{var r=t(()=>n(f,o==null?void 0:o())||{});if(r!=null&&r.destroy)return()=>r.destroy()})}export{i as a};
