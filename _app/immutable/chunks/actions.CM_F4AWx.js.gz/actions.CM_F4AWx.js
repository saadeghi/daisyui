import{Y as s,l as t}from"./runtime.DHikSq-X.js";function i(f,n,o){s(()=>{var r=t(()=>n(f,o==null?void 0:o())||{});if(r!=null&&r.destroy)return()=>r.destroy()})}export{i as a};
