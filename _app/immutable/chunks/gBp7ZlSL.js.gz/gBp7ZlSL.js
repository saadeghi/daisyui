import{j as o,E as f,v as i,n as p,K as c,k as d,x as h}from"./BAHzCZOW.js";function E(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{E as s};
